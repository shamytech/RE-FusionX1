/**
 * Resizable Layout Handler
 * Allows resizing sidebar and chat container with drag handle
 */

class ResizableLayout {
    constructor() {
        this.resizer = null;
        this.sidebar = null;
        this.chatContainer = null;
        this.isResizing = false;
        this.minSidebarWidth = 250;
        this.maxSidebarWidth = 500;
        this.minChatWidth = 400;
        
        this.init();
    }
    
    init() {
        // Wait for DOM to be ready
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', () => this.setupResizer());
        } else {
            this.setupResizer();
        }
    }
    
    setupResizer() {
        this.resizer = document.getElementById('resizer');
        this.sidebar = document.getElementById('sidebar');
        this.chatContainer = document.getElementById('chatContainer');
        
        if (!this.resizer || !this.sidebar || !this.chatContainer) {
            console.warn('Resizer elements not found');
            return;
        }
        
        // Add event listeners
        this.resizer.addEventListener('mousedown', this.startResize.bind(this));
        document.addEventListener('mousemove', this.doResize.bind(this));
        document.addEventListener('mouseup', this.stopResize.bind(this));
        
        // Prevent text selection during resize
        this.resizer.addEventListener('selectstart', (e) => e.preventDefault());
        
        console.log('✅ Resizable layout initialized');
    }
    
    startResize(e) {
        this.isResizing = true;
        document.body.style.cursor = 'col-resize';
        document.body.style.userSelect = 'none';
        
        // Add visual feedback
        this.resizer.style.background = 'var(--primary-color)';
        
        e.preventDefault();
    }
    
    doResize(e) {
        if (!this.isResizing) return;
        
        const containerRect = this.sidebar.parentElement.getBoundingClientRect();
        const newSidebarWidth = e.clientX - containerRect.left;
        
        // Check bounds
        if (newSidebarWidth < this.minSidebarWidth || newSidebarWidth > this.maxSidebarWidth) {
            return;
        }
        
        // Check if chat container would be too small
        const remainingWidth = containerRect.width - newSidebarWidth - 4; // 4px for resizer
        if (remainingWidth < this.minChatWidth) {
            return;
        }
        
        // Apply new width
        this.sidebar.style.width = `${newSidebarWidth}px`;
        
        // Store in localStorage for persistence
        localStorage.setItem('sidebarWidth', newSidebarWidth);
    }
    
    stopResize() {
        if (!this.isResizing) return;
        
        this.isResizing = false;
        document.body.style.cursor = '';
        document.body.style.userSelect = '';
        
        // Remove visual feedback
        this.resizer.style.background = '';
    }
    
    // Restore saved width on page load
    restoreSavedWidth() {
        const savedWidth = localStorage.getItem('sidebarWidth');
        if (savedWidth && this.sidebar) {
            const width = parseInt(savedWidth);
            if (width >= this.minSidebarWidth && width <= this.maxSidebarWidth) {
                this.sidebar.style.width = `${width}px`;
            }
        }
    }
}

// Initialize when DOM is ready
const resizableLayout = new ResizableLayout();

// Restore saved width after initialization
setTimeout(() => {
    resizableLayout.restoreSavedWidth();
}, 100);

// Make globally available
window.ResizableLayout = ResizableLayout;

