/**
 * RE-FusionX Main Application
 */

class REFusionXApp {
    constructor() {
        // تحديد البورت الصحيح
        const backendPort = 8000;
        const backendHost = window.location.hostname;
        
        const existingSessionId = localStorage.getItem('sessionId');
        const sessionId = existingSessionId || this.generateSessionId();

        this.config = {
            apiUrl: `http://${backendHost}:${backendPort}/api/v1`,
            wsUrl: `ws://${backendHost}:${backendPort}/ws`,
            sessionId
        };
        
        this.modules = {};
        this.state = {
            currentTab: 'analysis',
            isConnected: false,
            currentProperty: null,
            chatHistory: [],
            savedProperties: []
        };
        
        // Store session ID in localStorage
        localStorage.setItem('sessionId', this.config.sessionId);
    }
    
    /**
     * Initialize the application
     */
    async init() {
        try {
            // Show loading screen
            this.showLoading(true);
            
            // Initialize modules
            await this.initializeModules();
            
            // Setup event listeners
            this.setupEventListeners();
            
            // Load saved data
            await this.loadSavedData();
            
            // Connect to WebSocket
            await this.connectWebSocket();
            
            // Check API health
            await this.checkHealth();
            
            // Hide loading screen
            this.showLoading(false);
            
            // Show app
            document.getElementById('app').style.display = 'block';
            
            console.log('RE-FusionX initialized successfully');
            
        } catch (error) {
            console.error('Failed to initialize app:', error);
            this.showError('Failed to initialize application. Please refresh the page.');
        }
    }
    
    /**
     * Initialize all modules
     */
    async initializeModules() {
        // API Module
        this.modules.api = new APIClient(this.config.apiUrl);

        // WebSocket Module
        this.modules.websocket = new WebSocketManager(
            this.config.wsUrl,
            this.config.sessionId
        );

        // Load HTML components BEFORE initializing UI-dependent modules
        await this.loadComponents();

        // Chat Module - initialize after components are present in DOM
        if (typeof ChatInterface !== 'undefined') {
            this.modules.chat = new ChatInterface(
                'chatInterface',
                this.modules.api,
                this.modules.websocket
            );
        }

        // Analysis Module - initialize after property form is in DOM
        if (typeof AnalysisModule !== 'undefined') {
            this.modules.analysis = new AnalysisModule(
                'propertyForm',
                this.modules.api
            );
            
            // Ensure initialization completes
            if (this.modules.analysis.init) {
                await this.modules.analysis.init();
            }
        }
    }
    
    /**
     * Load HTML components
     */
    async loadComponents() {
        try {
            // Load property form
            const propertyFormResponse = await fetch('/components/property-form.html');
            if (propertyFormResponse.ok) {
                const propertyFormHtml = await propertyFormResponse.text();
                const propertyFormContainer = document.getElementById('propertyForm');
                if (propertyFormContainer) {
                    propertyFormContainer.innerHTML = propertyFormHtml;
                }
            }
            
            // Chat interface is initialized by ChatInterface class
            
            // Load analysis results template
            const resultsResponse = await fetch('/components/analysis-results.html');
            if (resultsResponse.ok) {
                const resultsHtml = await resultsResponse.text();
                const resultsContainer = document.getElementById('analysisResults');
                if (resultsContainer) {
                    resultsContainer.innerHTML = resultsHtml;
                }
            }
        } catch (error) {
            console.warn('Failed to load some components:', error);
        }
    }
    
    /**
     * Setup event listeners
     */
    setupEventListeners() {
        // Tab navigation
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                this.switchTab(e.target.closest('.tab-btn').dataset.tab);
            });
        });
        
        // Analyze button
        const analyzeBtn = document.getElementById('analyzeBtn');
        if (analyzeBtn) {
            analyzeBtn.addEventListener('click', () => {
                this.analyzeProperty();
            });
        }
        
        // Reset button
        const resetBtn = document.getElementById('resetBtn');
        if (resetBtn) {
            resetBtn.addEventListener('click', () => {
                this.resetForm();
            });
        }
        
        // Window resize
        window.addEventListener('resize', () => {
            this.handleResize();
        });
        
        // Keyboard shortcuts
        document.addEventListener('keydown', (e) => {
            this.handleKeyboardShortcuts(e);
        });
    }
    
    /**
     * Connect to WebSocket
     */
    async connectWebSocket() {
        this.modules.websocket.on('connected', () => {
            this.updateConnectionStatus(true);
        });
        
        this.modules.websocket.on('disconnected', () => {
            this.updateConnectionStatus(false);
        });
        
        this.modules.websocket.on('message', (data) => {
            this.handleWebSocketMessage(data);
        });
        
        try {
            await this.modules.websocket.connect();
        } catch (error) {
            console.warn('WebSocket connection failed, continuing without real-time features:', error);
        }
    }
    
    /**
     * Check API health
     */
    async checkHealth() {
        try {
            const health = await this.modules.api.checkHealth();
            console.log('API Health:', health);
            return health;
        } catch (error) {
            console.error('Health check failed:', error);
            // Continue anyway - API might be partially available
        }
    }
    
    /**
     * Switch tab
     */
    switchTab(tabName) {
        if (!tabName) return;
        
        // Update buttons
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.classList.toggle('active', btn.dataset.tab === tabName);
        });
        
        // Update content
        document.querySelectorAll('.tab-pane').forEach(pane => {
            pane.classList.toggle('active', pane.id === `${tabName}Tab`);
        });
        
        this.state.currentTab = tabName;
        
        // Tab-specific actions
        switch(tabName) {
            case 'search':
                this.loadSearchResults();
                break;
            case 'compare':
                this.loadComparison();
                break;
            case 'saved':
                this.loadSavedProperties();
                break;
        }
    }
    
    /**
     * Analyze property
     */
    async analyzeProperty() {
        try {
            // Check if we have cached results first
            if (this.showCachedAnalysis()) {
                return;
            }
            
            // Get form data
            const propertyData = this.modules.analysis?.getFormData();
            
            if (!propertyData) {
                this.showError('Please fill in the property details');
                return;
            }
            
            // Validate
            if (!this.modules.analysis.validateForm(propertyData)) {
                return;
            }
            
            // Show loading
            this.showAnalyzing(true);
            
            // Send to API (with or without images)
            console.log('📤 Sending property data:', {
                location: propertyData.location,
                hasImages: !!(propertyData.images && propertyData.images.length > 0),
                imageCount: propertyData.images?.length || 0,
                dataKeys: Object.keys(propertyData)
            });
            
            let result;
            if (propertyData.images && propertyData.images.length > 0) {
                // Extract images from property data
                const images = propertyData.images;
                const dataWithoutImages = { ...propertyData };
                delete dataWithoutImages.images;
                
                console.log('📸 Using image analysis endpoint');
                result = await this.modules.api.analyzePropertyWithImages(dataWithoutImages, images);
            } else {
                // Remove empty images array
                const dataWithoutImages = { ...propertyData };
                delete dataWithoutImages.images;
                
                console.log('📝 Using standard analysis endpoint');
                result = await this.modules.api.analyzeProperty(dataWithoutImages);
            }
            
            // Display results in modal only
            this.displayAnalysisResults(result);
            
            // Send simple info to chat
            this.sendSimpleAnalysisToChat(propertyData, result);
            
            // Store analysis results in backend cache for chat context
            this.storeAnalysisInBackendCache(propertyData, result);
            
        } catch (error) {
            console.error('Analysis failed:', error);
            this.showError('Failed to analyze property. Please try again.');
        } finally {
            this.showAnalyzing(false);
        }
    }
    
    /**
     * Display analysis results
     */
    displayAnalysisResults(results) {
        console.log('Analysis results:', results);
        
        if (!results) return;
        
        // Store results for later use and cache
        this.state.lastAnalysisResults = results;
        this.cacheAnalysisResults(results);
        
        // Show analysis modal ONLY (no chat message at all)
        this.showAnalysisModal(results);
        
        // Show success message
        this.showSuccess('Analysis completed! Dashboard opened.');
        
        // Update UI state
        this.showAnalyzing(false);
        
        // Do not send anything to chat - results show only in modal
        return;
        
        // Update Price Estimation
        if (results.price_estimation) {
            const priceEst = results.price_estimation;
            
            // Estimated Price
            const estimatedPriceEl = document.getElementById('estimatedPrice');
            if (estimatedPriceEl && priceEst.estimated_price) {
                estimatedPriceEl.textContent = `₺${priceEst.estimated_price.toLocaleString('tr-TR')}`;
            }
            
            // Price Range
            const priceRangeEl = document.getElementById('priceRange');
            if (priceRangeEl && priceEst.price_range) {
                const min = priceEst.price_range.min?.toLocaleString('tr-TR') || '-';
                const max = priceEst.price_range.max?.toLocaleString('tr-TR') || '-';
                priceRangeEl.textContent = `₺${min} - ₺${max}`;
            }
            
            // Confidence
            const confidenceEl = document.getElementById('confidence');
            if (confidenceEl && priceEst.confidence) {
                confidenceEl.textContent = `${(priceEst.confidence * 100).toFixed(1)}%`;
            }
        }
        
        // Update Market Analysis
        if (results.market_analysis) {
            const marketAnalysis = results.market_analysis;
            
            // Market Position
            const marketPositionEl = document.getElementById('marketPosition');
            if (marketPositionEl && marketAnalysis.market_position) {
                marketPositionEl.textContent = marketAnalysis.market_position;
            }
            
            // Demand Level
            const demandLevelEl = document.getElementById('demandLevel');
            if (demandLevelEl && marketAnalysis.demand_level) {
                demandLevelEl.textContent = marketAnalysis.demand_level;
            }
            
            // Growth Forecast
            const growthForecastEl = document.getElementById('growthForecast');
            if (growthForecastEl && marketAnalysis.growth_forecast) {
                growthForecastEl.textContent = `${marketAnalysis.growth_forecast}%`;
            }
        }
        
        // Update Investment Analysis
        if (results.investment_analysis) {
            const investmentAnalysis = results.investment_analysis;
            
            // Investment Score
            const investmentScoreEl = document.getElementById('investmentScore');
            if (investmentScoreEl && investmentAnalysis.investment_score) {
                investmentScoreEl.textContent = investmentAnalysis.investment_score.toFixed(1);
            }
            
            // ROI Potential
            const roiPotentialEl = document.getElementById('roiPotential');
            if (roiPotentialEl && investmentAnalysis.roi_potential) {
                roiPotentialEl.textContent = investmentAnalysis.roi_potential;
            }
            
            // Rental Yield
            const rentalYieldEl = document.getElementById('rentalYield');
            if (rentalYieldEl && investmentAnalysis.rental_yield) {
                rentalYieldEl.textContent = `${investmentAnalysis.rental_yield}%`;
            }
            
            // Risk Level
            const riskLevelEl = document.getElementById('riskLevel');
            if (riskLevelEl && investmentAnalysis.risk_level) {
                riskLevelEl.textContent = investmentAnalysis.risk_level;
            }
        }
        
        // Update Similar Properties
        if (results.similar_properties && Array.isArray(results.similar_properties)) {
            console.log(`Found ${results.similar_properties.length} similar properties`);
            
            const similarPropertiesContainer = document.querySelector('.similar-properties-list');
            if (similarPropertiesContainer && results.similar_properties.length > 0) {
                similarPropertiesContainer.innerHTML = '';
                
                results.similar_properties.slice(0, 5).forEach((property, index) => {
                    const propertyCard = document.createElement('div');
                    propertyCard.className = 'similar-property-card';
                    propertyCard.innerHTML = `
                        <div class="property-info">
                            <div class="property-location">${property.location || 'N/A'}</div>
                            <div class="property-details">
                                <span>${property.rooms || 'N/A'} rooms</span>
                                <span>•</span>
                                <span>${property.size || 'N/A'} m²</span>
                            </div>
                        </div>
                        <div class="property-price">
                            <div class="price">₺${(property.price || 0).toLocaleString('tr-TR')}</div>
                            <div class="price-per-sqm">₺${property.price_per_sqm ? Math.round(property.price_per_sqm).toLocaleString('tr-TR') : 'N/A'}/m²</div>
                        </div>
                        <div class="similarity-score">
                            <div class="score-bar">
                                <div class="score-fill" style="width: ${(property.similarity_score || 0) * 100}%"></div>
                            </div>
                            <span>${Math.round((property.similarity_score || 0) * 100)}% match</span>
                        </div>
                    `;
                    similarPropertiesContainer.appendChild(propertyCard);
                });
            }
        }
    }
    
    /**
     * Reset form
     */
    resetForm() {
        if (this.modules.analysis) {
            this.modules.analysis.resetForm();
        }
        this.showResultsPanel(false);
        this.state.currentProperty = null;
    }
    
    /**
     * Load saved data from localStorage
     */
    async loadSavedData() {
        // Load saved properties
        const saved = localStorage.getItem('savedProperties');
        if (saved) {
            try {
                this.state.savedProperties = JSON.parse(saved);
            } catch (e) {
                console.error('Failed to parse saved properties:', e);
            }
        }
        
        // Load chat history
        const history = localStorage.getItem('chatHistory');
        if (history) {
            try {
                this.state.chatHistory = JSON.parse(history);
                if (this.modules.chat) {
                    this.modules.chat.loadHistory(this.state.chatHistory);
                }
            } catch (e) {
                console.error('Failed to parse chat history:', e);
            }
        }
    }
    
    /**
     * Save data to localStorage
     */
    saveData() {
        try {
            localStorage.setItem('savedProperties', JSON.stringify(this.state.savedProperties));
            localStorage.setItem('chatHistory', JSON.stringify(this.state.chatHistory));
        } catch (e) {
            console.error('Failed to save data:', e);
        }
    }
    
    /**
     * Handle WebSocket messages
     */
    handleWebSocketMessage(data) {
        switch(data.type) {
            case 'analysis_update':
                this.updateAnalysisProgress(data.progress);
                break;
            case 'chat_response':
                if (this.modules.chat) {
                    this.modules.chat.addMessage(data.content, 'assistant');
                }
                break;
            case 'error':
                this.showError(data.message);
                break;
        }
    }
    
    /**
     * Handle keyboard shortcuts
     */
    handleKeyboardShortcuts(e) {
        // Ctrl/Cmd + Enter to analyze
        if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
            e.preventDefault();
            this.analyzeProperty();
        }
        
        // Ctrl/Cmd + R to reset (prevent page reload)
        if ((e.ctrlKey || e.metaKey) && e.key === 'r') {
            e.preventDefault();
            this.resetForm();
        }
        
        // Ctrl/Cmd + S to save
        if ((e.ctrlKey || e.metaKey) && e.key === 's') {
            e.preventDefault();
            this.saveCurrentProperty();
        }
    }
    
    /**
     * Handle window resize
     */
    handleResize() {
        // Adjust layout for mobile
        if (window.innerWidth < 768) {
            document.querySelector('.sidebar')?.classList.add('mobile');
            document.querySelector('.results-panel')?.classList.add('mobile');
        } else {
            document.querySelector('.sidebar')?.classList.remove('mobile');
            document.querySelector('.results-panel')?.classList.remove('mobile');
        }
    }
    
    /**
     * Update connection status
     */
    updateConnectionStatus(isConnected) {
        this.state.isConnected = isConnected;
        const statusEl = document.getElementById('connectionStatus');
        if (statusEl) {
            const dot = statusEl.querySelector('.status-dot');
            const text = statusEl.querySelector('span:last-child');
            
            if (isConnected) {
                dot?.classList.add('online');
                if (text) text.textContent = 'Connected';
            } else {
                dot?.classList.remove('online');
                if (text) text.textContent = 'Disconnected';
            }
        }
    }
    
    /**
     * Show/hide loading screen
     */
    showLoading(show) {
        const loadingScreen = document.getElementById('loadingScreen');
        if (loadingScreen) {
            loadingScreen.style.display = show ? 'flex' : 'none';
        }
    }
    
    /**
     * Show analyzing indicator
     */
    showAnalyzing(show) {
        const btn = document.getElementById('analyzeBtn');
        if (btn) {
            btn.disabled = show;
            btn.innerHTML = show 
                ? '<i class="fas fa-spinner fa-spin"></i> Analyzing...'
                : '<i class="fas fa-chart-line"></i> Analyze Property';
        }
    }
    
    /**
     * Show/hide results panel
     */
    showResultsPanel(show) {
        const panel = document.getElementById('resultsPanel');
        if (panel) {
            panel.style.display = show ? 'block' : 'none';
        }
    }
    
    /**
     * Show error message
     */
    showError(message) {
        // Create toast notification
        const toast = document.createElement('div');
        toast.className = 'toast error show';
        toast.innerHTML = `
            <i class="fas fa-exclamation-circle"></i>
            <span>${message}</span>
        `;
        
        document.body.appendChild(toast);
        
        setTimeout(() => {
            toast.classList.remove('show');
            setTimeout(() => toast.remove(), 300);
        }, 5000);
    }
    
    /**
     * Show success message
     */
    showSuccess(message) {
        const toast = document.createElement('div');
        toast.className = 'toast success show';
        toast.innerHTML = `
            <i class="fas fa-check-circle"></i>
            <span>${message}</span>
        `;
        
        document.body.appendChild(toast);
        
        setTimeout(() => {
            toast.classList.remove('show');
            setTimeout(() => toast.remove(), 300);
        }, 3000);
    }
    
    /**
     * Placeholder methods
     */
    loadSearchResults() {
        console.log('Loading search results...');
    }
    
    loadComparison() {
        console.log('Loading comparison...');
    }
    
    loadSavedProperties() {
        console.log('Loading saved properties...');
    }
    
    saveCurrentProperty() {
        console.log('Saving current property...');
        this.showSuccess('Property saved successfully');
    }
    
    updateAnalysisProgress(progress) {
        console.log('Analysis progress:', progress);
    }
    
    /**
     * Format currency
     */
    formatCurrency(amount) {
        return new Intl.NumberFormat('tr-TR', {
            style: 'currency',
            currency: 'TRY',
            minimumFractionDigits: 0,
            maximumFractionDigits: 0
        }).format(amount);
    }
    
    /**
     * Generate session ID
     */
    generateSessionId() {
        return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
            const r = Math.random() * 16 | 0;
            const v = c === 'x' ? r : (r & 0x3 | 0x8);
            return v.toString(16);
        });
    }
    
    /**
     * Show analysis results in modal
     */
    showAnalysisModal(results) {
        const modal = document.getElementById('analysisModal');
        const content = document.getElementById('analysisResultsContent');
        
        if (!modal || !content) {
            console.error('Analysis modal elements not found');
            return;
        }
        
        // Generate modal content
        content.innerHTML = this.generateModalContent(results);
        
        // Show modal
        modal.classList.add('show');
        document.body.style.overflow = 'hidden'; // Prevent body scroll
        
        // Add event listeners
        this.addModalEventListeners(modal);
        
        // Initialize charts after modal is shown
        setTimeout(() => {
            this.initializeCharts(results);
        }, 100);
    }
    
    /**
     * Close analysis modal
     */
    closeAnalysisModal() {
        const modal = document.getElementById('analysisModal');
        if (modal) {
            modal.classList.remove('show');
            document.body.style.overflow = ''; // Restore body scroll
            this.removeModalEventListeners();
        }
    }
    
    /**
     * Add modal event listeners
     */
    addModalEventListeners(modal) {
        // Click outside to close
        this.modalClickHandler = (e) => {
            if (e.target === modal) {
                this.closeAnalysisModal();
            }
        };
        
        // Escape key to close
        this.modalKeyHandler = (e) => {
            if (e.key === 'Escape') {
                this.closeAnalysisModal();
            }
        };
        
        modal.addEventListener('click', this.modalClickHandler);
        document.addEventListener('keydown', this.modalKeyHandler);
    }
    
    /**
     * Remove modal event listeners
     */
    removeModalEventListeners() {
        const modal = document.getElementById('analysisModal');
        if (modal && this.modalClickHandler) {
            modal.removeEventListener('click', this.modalClickHandler);
        }
        if (this.modalKeyHandler) {
            document.removeEventListener('keydown', this.modalKeyHandler);
        }
    }
    
    /**
     * Generate modal content from analysis results
     */
    generateModalContent(results) {
        // Get property data from analysis form or stored state
        const propertyData = this.modules.analysis?.getFormData() || this.state.currentProperty || {};
        
        return `
            <div class="dashboard-container">
                ${this.generateDashboardHeader()}
                ${this.generateMetricsGrid(results)}
                ${this.generateChartsSection(results)}
                ${this.generateBottomSection(propertyData, results.similar_properties, results.recommendations)}
            </div>
        `;
    }
    
    /**
     * Generate price estimation card
     */
    generatePriceCard(priceData) {
        const confidence = (priceData.confidence * 100).toFixed(0);
        const confidenceClass = priceData.confidence >= 0.8 ? 'high' : priceData.confidence >= 0.6 ? 'medium' : 'low';
        
        return `
            <div class="result-card">
                <h3><i class="fas fa-tag"></i> Price Valuation</h3>
                <div class="price-display">
                    <div class="main-price">
                        <span class="currency">₺</span>
                        <span class="amount">${(priceData.estimated_price / 1000000).toFixed(2)}M</span>
                        <div class="confidence-badge ${confidenceClass}">
                            ${confidence}% Confidence
                        </div>
                    </div>
                    <div class="price-range">
                        Range: ${this.formatCurrency(priceData.price_range.min)} - ${this.formatCurrency(priceData.price_range.max)}
                    </div>
                    <div class="methodology">
                        Method: ${priceData.methodology}
                    </div>
                </div>
            </div>
        `;
    }
    
    /**
     * Generate market analysis card
     */
    generateMarketCard(marketData) {
        return `
            <div class="result-card">
                <h3><i class="fas fa-chart-line"></i> Market Analysis</h3>
                <div class="market-metrics">
                    <div class="metric-item">
                        <span class="label">Average Price:</span>
                        <span class="value">${this.formatCurrency(marketData.average_price)}</span>
                    </div>
                    <div class="metric-item">
                        <span class="label">Market Position:</span>
                        <span class="value">${marketData.market_position}</span>
                    </div>
                    <div class="metric-item">
                        <span class="label">Demand Level:</span>
                        <span class="value">${marketData.demand_level}</span>
                    </div>
                    <div class="metric-item">
                        <span class="label">Growth Forecast:</span>
                        <span class="value">+${marketData.growth_forecast}%</span>
                    </div>
                </div>
            </div>
        `;
    }
    
    /**
     * Generate investment analysis card
     */
    generateInvestmentCard(investmentData) {
        return `
            <div class="result-card">
                <h3><i class="fas fa-coins"></i> Investment Analysis</h3>
                <div class="investment-score">
                    <div class="score-circle">
                        <span class="score">${investmentData.investment_score}</span>
                        <span class="max">/10</span>
                    </div>
                </div>
                <div class="investment-metrics">
                    <div class="metric-item">
                        <span class="label">ROI Potential:</span>
                        <span class="value">${investmentData.roi_potential}</span>
                    </div>
                    <div class="metric-item">
                        <span class="label">Rental Yield:</span>
                        <span class="value">${investmentData.rental_yield}%</span>
                    </div>
                    <div class="metric-item">
                        <span class="label">Risk Level:</span>
                        <span class="value">${investmentData.risk_level}</span>
                    </div>
                    <div class="metric-item">
                        <span class="label">Payback Period:</span>
                        <span class="value">${investmentData.payback_period} years</span>
                    </div>
                </div>
            </div>
        `;
    }
    
    /**
     * Generate Qwen analysis card
     */
    generateQwenCard(qwenText) {
        return `
            <div class="result-card qwen-card">
                <h3><i class="fas fa-brain"></i> AI Expert Analysis</h3>
                <div class="qwen-content">
                    ${this.formatQwenText(qwenText)}
                </div>
            </div>
        `;
    }
    
    /**
     * Generate similar properties card
     */
    generateSimilarPropertiesCard(properties) {
        const propertiesHtml = properties.slice(0, 6).map(prop => `
            <div class="property-item">
                <div class="property-location">${prop.location}</div>
                <div class="property-price">${this.formatCurrency(prop.price)}</div>
                <div class="property-details">
                    ${prop.rooms} • ${prop.size}m² • ₺${Math.round(prop.price_per_sqm).toLocaleString()}/m²
                </div>
                <div class="similarity-score">${Math.round(prop.similarity_score * 100)}% match</div>
            </div>
        `).join('');
        
        return `
            <div class="result-card">
                <h3><i class="fas fa-home"></i> Similar Properties (${properties.length})</h3>
                <div class="similar-properties">
                    ${propertiesHtml}
                </div>
            </div>
        `;
    }
    
    /**
     * Format Qwen text for display
     */
    formatQwenText(text) {
        return text
            .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
            .replace(/\n\n/g, '</p><p>')
            .replace(/\n/g, '<br>')
            .replace(/^/, '<p>')
            .replace(/$/, '</p>');
    }
    
    /**
     * Generate enhanced price card
     */
    generateEnhancedPriceCard(priceData) {
        const confidence = (priceData.confidence * 100).toFixed(0);
        const confidenceClass = priceData.confidence >= 0.8 ? 'high' : priceData.confidence >= 0.6 ? 'medium' : 'low';
        const confidenceAngle = priceData.confidence * 360;
        
        return `
            <div class="result-card price-overview-card">
                <h3><i class="fas fa-tag"></i> Price Valuation Overview</h3>
                <div class="price-overview-content">
                    <div class="price-main-display">
                        <div class="price-amount-large">
                            <span class="currency">₺</span>
                            <span class="amount">${(priceData.estimated_price / 1000000).toFixed(2)}M</span>
                        </div>
                        <div class="price-details-enhanced">
                            <div class="price-range-info">
                                <i class="fas fa-arrows-alt-h"></i>
                                <span>Range: ${this.formatCurrency(priceData.price_range.min)} - ${this.formatCurrency(priceData.price_range.max)}</span>
                            </div>
                            <div class="methodology-info">
                                <i class="fas fa-cogs"></i>
                                <span>Method: ${priceData.methodology}</span>
                            </div>
                        </div>
                        <div class="confidence-badge-large ${confidenceClass}">
                            <i class="fas fa-check-circle"></i>
                            ${confidence}% Confidence
                        </div>
                    </div>
                    <div class="price-visual">
                        <div class="price-circle" style="background: conic-gradient(from 0deg, #10b981 0deg, #10b981 ${confidenceAngle}deg, #e5e7eb ${confidenceAngle}deg, #e5e7eb 360deg);">
                            <div class="price-percentage">${confidence}%</div>
                        </div>
                    </div>
                </div>
            </div>
        `;
    }
    
    /**
     * Generate combined market and investment card
     */
    generateMarketInvestmentCard(marketData, investmentData) {
        return `
            <div class="result-card market-investment-card">
                <h3><i class="fas fa-chart-line"></i> Market & Investment Analysis</h3>
                <div class="market-investment-content">
                    ${marketData ? `
                        <div class="market-section">
                            <h4><i class="fas fa-chart-bar"></i> Market Insights</h4>
                            <div class="mini-chart">
                                <div class="chart-line"></div>
                            </div>
                            <div class="stat-grid">
                                <div class="stat-card">
                                    <div class="stat-icon"><i class="fas fa-home"></i></div>
                                    <div class="stat-value">${marketData.market_position}</div>
                                    <div class="stat-label">Position</div>
                                </div>
                                <div class="stat-card">
                                    <div class="stat-icon"><i class="fas fa-trending-up"></i></div>
                                    <div class="stat-value">+${marketData.growth_forecast}%</div>
                                    <div class="stat-label">Growth</div>
                                </div>
                            </div>
                            <div class="metric-item">
                                <span class="label">Average Price:</span>
                                <span class="value">${this.formatCurrency(marketData.average_price)}</span>
                            </div>
                            <div class="metric-item">
                                <span class="label">Demand Level:</span>
                                <span class="value">${marketData.demand_level}</span>
                            </div>
                        </div>
                    ` : ''}
                    
                    ${investmentData ? `
                        <div class="investment-section">
                            <h4><i class="fas fa-coins"></i> Investment Potential</h4>
                            <div class="investment-score-visual">
                                <div class="score-circle-enhanced">
                                    <span class="score-large">${investmentData.investment_score}</span>
                                    <span class="score-max">/10</span>
                                </div>
                            </div>
                            <div class="stat-grid">
                                <div class="stat-card">
                                    <div class="stat-icon"><i class="fas fa-percentage"></i></div>
                                    <div class="stat-value">${investmentData.rental_yield}%</div>
                                    <div class="stat-label">Yield</div>
                                </div>
                                <div class="stat-card">
                                    <div class="stat-icon"><i class="fas fa-calendar"></i></div>
                                    <div class="stat-value">${investmentData.payback_period}</div>
                                    <div class="stat-label">Years</div>
                                </div>
                            </div>
                            <div class="metric-item">
                                <span class="label">ROI Potential:</span>
                                <span class="value">${investmentData.roi_potential}</span>
                            </div>
                            <div class="metric-item">
                                <span class="label">Risk Level:</span>
                                <span class="value">${investmentData.risk_level}</span>
                            </div>
                        </div>
                    ` : ''}
                </div>
            </div>
        `;
    }
    
    /**
     * Generate enhanced Qwen analysis card
     */
    generateEnhancedQwenCard(qwenText) {
        return `
            <div class="result-card ai-analysis-card">
                <h3><i class="fas fa-brain"></i> AI Expert Analysis & Insights</h3>
                <div class="ai-analysis-content">
                    <div class="analysis-header-enhanced">
                        <div class="ai-badge-large">
                            <i class="fas fa-robot"></i>
                            Powered by Qwen 2.5-VL
                        </div>
                        <div class="analysis-stats">
                            <span class="stat"><i class="fas fa-file-alt"></i> ${qwenText.length} chars analyzed</span>
                            <span class="stat"><i class="fas fa-clock"></i> Real-time insights</span>
                        </div>
                    </div>
                    <div class="qwen-content-enhanced">
                        ${this.formatQwenTextEnhanced(qwenText)}
                    </div>
                </div>
            </div>
        `;
    }
    
    /**
     * Generate enhanced properties comparison card
     */
    generateEnhancedPropertiesCard(properties) {
        const avgPrice = properties.reduce((sum, p) => sum + (p.price || 0), 0) / properties.length;
        
        return `
            <div class="result-card properties-comparison-card">
                <h3><i class="fas fa-home"></i> Market Comparison Analysis (${properties.length} Properties)</h3>
                <div class="comparison-overview">
                    <div class="comparison-stats-header">
                        <div class="stat-card">
                            <div class="stat-icon"><i class="fas fa-chart-bar"></i></div>
                            <div class="stat-value">₺${Math.round(avgPrice / 1000000).toFixed(1)}M</div>
                            <div class="stat-label">Average Price</div>
                        </div>
                        <div class="stat-card">
                            <div class="stat-icon"><i class="fas fa-home"></i></div>
                            <div class="stat-value">${properties.length}</div>
                            <div class="stat-label">Similar Properties</div>
                        </div>
                        <div class="stat-card">
                            <div class="stat-icon"><i class="fas fa-map-marker-alt"></i></div>
                            <div class="stat-value">Kadıköy</div>
                            <div class="stat-label">Area Focus</div>
                        </div>
                    </div>
                </div>
                <div class="properties-grid">
                    ${properties.slice(0, 6).map(property => `
                        <div class="property-card-enhanced">
                            <div class="property-header">
                                <div class="property-location-enhanced">${property.location}</div>
                                <div class="similarity-badge">${Math.round(property.similarity_score * 100)}% match</div>
                            </div>
                            <div class="property-price-highlight">₺${(property.price || 0).toLocaleString('tr-TR')}</div>
                            <div class="property-details-grid">
                                <div><i class="fas fa-home"></i> ${property.rooms}</div>
                                <div><i class="fas fa-expand-arrows-alt"></i> ${property.size}m²</div>
                                <div><i class="fas fa-calculator"></i> ₺${Math.round(property.price_per_sqm || 0).toLocaleString()}/m²</div>
                                <div><i class="fas fa-layer-group"></i> Floor ${property.floor || 'N/A'}</div>
                            </div>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
    }
    
    /**
     * Format Qwen text with enhanced styling
     */
    formatQwenTextEnhanced(text) {
        return text
            .replace(/\*\*(.*?)\*\*/g, '<div class="highlight-section"><strong>$1</strong></div>')
            .replace(/- (.*?):/g, '<div class="insight-item"><i class="fas fa-chevron-right"></i><strong>$1:</strong>')
            .replace(/: (.*?)(?=\n|$)/g, ': <span class="insight-value">$1</span></div>')
            .replace(/\n\n/g, '</div><div class="content-section">')
            .replace(/\n/g, '<br>')
            .replace(/^/, '<div class="content-section">')
            .replace(/$/, '</div>');
    }
    
    /**
     * Generate dashboard header
     */
    generateDashboardHeader() {
        return `
            <div class="dashboard-header">
                <h1>🏢 Property Analysis Dashboard</h1>
                <div class="subtitle">RE-FusionX v2.0.0 - Comprehensive Property Analysis</div>
            </div>
        `;
    }
    
    /**
     * Generate metrics grid
     */
    generateMetricsGrid(results) {
        const priceData = results.price_estimation || {};
        const investmentData = results.investment_analysis || {};
        const marketData = results.market_analysis || {};
        
        return `
            <div class="metrics-grid">
                <div class="metric-card">
                    <div class="label">Estimated Price</div>
                    <div class="value">₺${(priceData.estimated_price || 0).toLocaleString()}</div>
                    <div class="change positive">↑ Below market average</div>
                </div>
                
                <div class="metric-card">
                    <div class="label">Rental Yield</div>
                    <div class="value">${investmentData.rental_yield || 'N/A'}%</div>
                    <div class="change positive">↑ Good return</div>
                </div>
                
                <div class="metric-card">
                    <div class="label">Investment Score</div>
                    <div class="value">${investmentData.investment_score || 'N/A'}/10</div>
                    <div class="change positive">↑ Good investment opportunity</div>
                </div>
                
                <div class="metric-card">
                    <div class="label">Risk Level</div>
                    <div class="value">${investmentData.risk_level || 'N/A'}</div>
                    <div class="change neutral">⟷ Moderate risk</div>
                </div>
                
                <div class="metric-card">
                    <div class="label">Payback Period</div>
                    <div class="value">${investmentData.payback_period || 'N/A'} years</div>
                    <div class="change neutral">⟷ Reasonable period</div>
                </div>
                
                <div class="metric-card">
                    <div class="label">Expected Annual Return</div>
                    <div class="value">${investmentData.roi_potential || 'N/A'}</div>
                    <div class="change positive">↑ Excellent return</div>
                </div>
            </div>
        `;
    }
    /**
     * Generate charts section
     */
    generateChartsSection(results) {
        return `
            <div class="charts-section">
                <div class="chart-card">
                    <h3>📊 Price Comparison</h3>
                    <div class="chart-canvas">
                        <canvas id="priceChart"></canvas>
                    </div>
                </div>
                
                <div class="chart-card">
                    <h3>📈 Market Analysis Distribution</h3>
                    <div class="chart-canvas">
                        <canvas id="marketChart"></canvas>
                    </div>
                </div>
                
                <div class="chart-card">
                    <h3>💰 Investment Analysis</h3>
                    <div class="chart-canvas">
                        <canvas id="investmentChart"></canvas>
                    </div>
                </div>
                
                <div class="chart-card">
                    <h3>🏘️ Similar Properties Prices</h3>
                    <div class="chart-canvas">
                        <canvas id="similarChart"></canvas>
                    </div>
                </div>
            </div>
        `;
    }
    
    /**
     * Generate similar properties section
     */
    generateSimilarProperties(properties) {
        if (!properties || !properties.length) return '';
        
        const propertyItems = properties.slice(0, 5).map(property => `
            <div class="property-item">
                <div>
                    <strong>${property.rooms || 'N/A'}</strong> - ${property.size || 'N/A'} m² - ${property.district || property.city || 'N/A'}
                </div>
                <div class="price">₺${(property.price || 0).toLocaleString()}</div>
            </div>
        `).join('');
        
        return `
            <div class="similar-properties">
                <h3>🏘️ Similar Properties in the Area</h3>
                <div class="property-list">
                    ${propertyItems}
                </div>
            </div>
        `;
    }
    
    /**
     * Generate recommendations section
     */
    generateRecommendations(recommendations) {
        if (!recommendations || !recommendations.length) return '';
        
        const recommendationItems = recommendations.map(rec => `
            <li>✅ ${rec}</li>
        `).join('');
        
        return `
            <div class="recommendations">
                <h4>💡 Recommendations & Notes</h4>
                <ul class="recommendation-list">
                    ${recommendationItems}
                </ul>
            </div>
        `;
    }

        /**
     * Generate property details section
     */
        generatePropertyDetails(propertyData) {
            return `
                <div class="property-details">
                    <h3>📍 Property Details</h3>
                    <div class="details-grid">
                        <div class="detail-item">
                            <div class="icon">📍</div>
                            <div class="info">
                                <div class="info-label">Location</div>
                                <div class="info-value">${propertyData.location || 'N/A'}</div>
                            </div>
                        </div>
                        
                        <div class="detail-item">
                            <div class="icon">🏠</div>
                            <div class="info">
                                <div class="info-label">Property Type</div>
                                <div class="info-value">${propertyData.property_type || 'N/A'}</div>
                            </div>
                        </div>
                        
                        <div class="detail-item">
                            <div class="icon">📐</div>
                            <div class="info">
                                <div class="info-label">Size</div>
                                <div class="info-value">${propertyData.size_net || propertyData.size_gross || 'N/A'} m²</div>
                            </div>
                        </div>
                        
                        <div class="detail-item">
                            <div class="icon">🛏️</div>
                            <div class="info">
                                <div class="info-label">Rooms</div>
                                <div class="info-value">${propertyData.rooms || 'N/A'}</div>
                            </div>
                        </div>
                        
                        <div class="detail-item">
                            <div class="icon">🏗️</div>
                            <div class="info">
                                <div class="info-label">Building Age</div>
                                <div class="info-value">${propertyData.building_age || 'N/A'} years</div>
                            </div>
                        </div>
                        
                        <div class="detail-item">
                            <div class="icon">🏢</div>
                            <div class="info">
                                <div class="info-label">Floor</div>
                                <div class="info-value">${propertyData.floor_level || 'N/A'}</div>
                            </div>
                        </div>
                    </div>
                </div>
            `;
        }
    
    /**
     * Generate bottom section with property details, similar properties and recommendations
     */
    generateBottomSection(propertyData, properties, recommendations) {
        return `
            <div class="bottom-section">
                ${this.generatePropertyDetails(propertyData)}
                ${this.generateSimilarProperties(properties)}
                ${this.generateRecommendations(recommendations)}
            </div>
        `;
    }
    
    /**
     * Send simple analysis info to chat
     */
    sendSimpleAnalysisToChat(propertyData, results) {
        if (!this.modules.chat) return;
        
        const priceData = results.price_estimation || {};
        const investmentData = results.investment_analysis || {};
        const marketData = results.market_analysis || {};
        const qwenAnalysis = results.qwen_analysis || '';
        const similarProperties = results.similar_properties || [];
        const recommendations = results.recommendations || [];
        
        let message = `🏢 **Property Analysis Completed**\n\n`;
        
        // Property Details Section
        message += `📍 **Property Details:**\n`;
        message += `📍 Location: ${propertyData.location || 'N/A'}\n`;
        message += `🏠 Type: ${propertyData.property_type || 'N/A'}\n`;
        message += `📐 Size: ${propertyData.size_net || propertyData.size_gross || 'N/A'} m²\n`;
        message += `🛏️ Rooms: ${propertyData.rooms || 'N/A'}\n`;
        message += `🏗️ Building Age: ${propertyData.building_age || 'N/A'} years\n`;
        message += `🏢 Floor: ${propertyData.floor_level || 'N/A'}\n\n`;
        
        // Price Analysis Section
        message += `💰 **Price Analysis:**\n`;
        message += `💰 Estimated Price: ₺${(priceData.estimated_price || 0).toLocaleString()}\n`;
        message += `📊 Confidence: ${Math.round((priceData.confidence || 0) * 100)}%\n`;
        message += `📈 Price Range: ₺${(priceData.price_range?.min || 0).toLocaleString()} - ₺${(priceData.price_range?.max || 0).toLocaleString()}\n`;
        message += `🔧 Method: ${priceData.methodology || 'N/A'}\n\n`;
        
        // Market Analysis Section
        message += `📊 **Market Analysis:**\n`;
        message += `📈 Average Price: ₺${(marketData.average_price || 0).toLocaleString()}\n`;
        message += `📊 Market Position: ${marketData.market_position || 'N/A'}\n`;
        message += `📈 Growth Forecast: ${marketData.growth_forecast || 'N/A'}%\n`;
        message += `📉 Demand Level: ${marketData.demand_level || 'N/A'}\n`;
        message += `📊 Supply Level: ${marketData.supply_level || 'N/A'}\n`;
        message += `📈 Price Trend: ${marketData.price_trend || 'N/A'}\n\n`;
        
        // Investment Analysis Section
        message += `💼 **Investment Analysis:**\n`;
        message += `📊 Investment Score: ${investmentData.investment_score || 'N/A'}/10\n`;
        message += `💵 Rental Yield: ${investmentData.rental_yield || 'N/A'}%\n`;
        message += `📈 ROI Potential: ${investmentData.roi_potential || 'N/A'}\n`;
        message += `⚠️ Risk Level: ${investmentData.risk_level || 'N/A'}\n`;
        message += `📅 Payback Period: ${investmentData.payback_period || 'N/A'} years\n`;
        message += `📈 Appreciation Forecast: ${investmentData.appreciation_forecast || 'N/A'}\n\n`;
        
        // Key Insights Section
        if (results.key_insights && results.key_insights.length > 0) {
            message += `🔍 **Key Insights:**\n`;
            results.key_insights.forEach(insight => {
                message += `💡 ${insight}\n`;
            });
            message += `\n`;
        }
        
        // Similar Properties Section
        if (similarProperties.length > 0) {
            message += `🏘️ **Similar Properties (${similarProperties.length}):**\n`;
            similarProperties.slice(0, 5).forEach((property, index) => {
                message += `${index + 1}. ${property.rooms || 'N/A'} - ${property.size || 'N/A'} m² - ${property.district || property.city || 'N/A'}\n`;
                message += `   💰 Price: ₺${(property.price || 0).toLocaleString()} (${Math.round((property.similarity_score || 0) * 100)}% match)\n`;
            });
            message += `\n`;
        }
        
        // Qwen AI Analysis Section
        if (qwenAnalysis) {
            message += `🤖 **AI Expert Analysis (Qwen 2.5-VL):**\n`;
            // Clean and format Qwen text for simple display
            const cleanQwenText = qwenAnalysis
                .replace(/\*\*(.*?)\*\*/g, '$1') // Remove bold formatting
                .replace(/\n\n/g, '\n') // Reduce double line breaks
                .replace(/\n/g, '\n   ') // Add indentation
                .trim();
            message += `   ${cleanQwenText}\n\n`;
        }
        
        // Recommendations Section
        if (recommendations.length > 0) {
            message += `💡 **Recommendations:**\n`;
            recommendations.forEach(rec => {
                message += `✅ ${rec}\n`;
            });
            message += `\n`;
        }
        
        message += `📊 **Click "Analyze Property" button to view detailed dashboard with charts and visualizations.**`;
        
        this.modules.chat.addMessage(message, 'assistant', { type: 'analysis-summary' });
    }
    
    /**
     * Cache analysis results for later retrieval
     */
    cacheAnalysisResults(results) {
        try {
            const cacheKey = 'last_analysis_results';
            const cacheData = {
                results: results,
                timestamp: new Date().toISOString(),
                propertyData: this.state.currentProperty
            };
            localStorage.setItem(cacheKey, JSON.stringify(cacheData));
            console.log('Analysis results cached successfully in localStorage:', {
                cacheKey,
                hasResults: !!results,
                hasPropertyData: !!this.state.currentProperty,
                timestamp: cacheData.timestamp
            });
        } catch (error) {
            console.error('Failed to cache analysis results:', error);
        }
    }
    
    /**
     * Get cached analysis results
     */
    getCachedAnalysisResults() {
        try {
            const cacheKey = 'last_analysis_results';
            const cached = localStorage.getItem(cacheKey);
            if (cached) {
                const cacheData = JSON.parse(cached);
                // Check if cache is not too old (24 hours)
                const cacheTime = new Date(cacheData.timestamp);
                const now = new Date();
                const hoursDiff = (now - cacheTime) / (1000 * 60 * 60);
                
                if (hoursDiff < 24) {
                    return cacheData;
                } else {
                    this.clearAnalysisCache();
                    return null;
                }
            }
            return null;
        } catch (error) {
            console.error('Failed to get cached analysis results:', error);
            return null;
        }
    }
    
    /**
     * Clear analysis cache
     */
    clearAnalysisCache() {
        try {
            const cacheKey = 'last_analysis_results';
            localStorage.removeItem(cacheKey);
            console.log('Analysis cache cleared');
        } catch (error) {
            console.error('Failed to clear analysis cache:', error);
        }
    }
    
    /**
     * Show cached analysis if available
     */
    showCachedAnalysis() {
        const cached = this.getCachedAnalysisResults();
        if (cached && cached.results) {
            this.state.lastAnalysisResults = cached.results;
            this.state.currentProperty = cached.propertyData;
            this.showAnalysisModal(cached.results);
            this.showSuccess('Dashboard reopened from cache.');
            return true;
        }
        return false;
    }
    
    /**
     * Store analysis results in backend cache for chat context
     */
    async storeAnalysisInBackendCache(propertyData, results) {
        try {
            console.log('Storing analysis in backend cache...', {
                sessionId: this.getSessionId(),
                hasPropertyData: !!propertyData,
                hasResults: !!results
            });
            
            // Send analysis results to backend to store in cache
            const response = await fetch(`${this.config.apiUrl}/chat/store-analysis`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    property_data: propertyData,
                    analysis_results: results,
                    session_id: this.getSessionId()
                })
            });
            
            if (response.ok) {
                const responseData = await response.json();
                console.log('Analysis results stored in backend cache successfully:', responseData);
            } else {
                const errorText = await response.text();
                console.error('Failed to store analysis in backend cache:', {
                    status: response.status,
                    statusText: response.statusText,
                    error: errorText
                });
            }
        } catch (error) {
            console.error('Error storing analysis in backend cache:', error);
        }
    }
    
    /**
     * Get session ID
     */
    getSessionId() {
        // Use the same session ID as the WebSocket connection
        return this.config.sessionId;
    }
    
    /**
     * Initialize charts
     */
    initializeCharts(results) {
        const priceData = results.price_estimation || {};
        const marketData = results.market_analysis || {};
        const investmentData = results.investment_analysis || {};
        const properties = results.similar_properties || [];
        
        // Price Chart
        this.createPriceChart(priceData, marketData);
        
        // Market Chart
        this.createMarketChart(marketData);
        
        // Investment Chart
        this.createInvestmentChart(investmentData);
        
        // Similar Properties Chart
        this.createSimilarPropertiesChart(properties, priceData);
    }
    
    /**
     * Create price comparison chart
     */
    createPriceChart(priceData, marketData) {
        const ctx = document.getElementById('priceChart');
        if (!ctx) return;
        
        new Chart(ctx, {
            type: 'bar',
            data: {
                labels: ['Estimated Price', 'Min Price', 'Max Price', 'Market Average'],
                datasets: [{
                    label: 'Prices (₺)',
                    data: [
                        priceData.estimated_price || 0,
                        priceData.price_range?.min || 0,
                        priceData.price_range?.max || 0,
                        marketData.average_price || 0
                    ],
                    backgroundColor: [
                        'rgba(102, 126, 234, 0.8)',
                        'rgba(16, 185, 129, 0.8)',
                        'rgba(239, 68, 68, 0.8)',
                        'rgba(245, 158, 11, 0.8)'
                    ],
                    borderColor: [
                        'rgba(102, 126, 234, 1)',
                        'rgba(16, 185, 129, 1)',
                        'rgba(239, 68, 68, 1)',
                        'rgba(245, 158, 11, 1)'
                    ],
                    borderWidth: 2
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return '₺' + value.toLocaleString();
                            }
                        }
                    }
                }
            }
        });
    }
    
    /**
     * Create market analysis chart
     */
    createMarketChart(marketData) {
        const ctx = document.getElementById('marketChart');
        if (!ctx) return;
        
        new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: ['Demand Level', 'Supply Level', 'Market Growth'],
                datasets: [{
                    data: [50, 50, marketData.growth_forecast || 8.5],
                    backgroundColor: [
                        'rgba(102, 126, 234, 0.8)',
                        'rgba(118, 75, 162, 0.8)',
                        'rgba(16, 185, 129, 0.8)'
                    ],
                    borderColor: [
                        'rgba(102, 126, 234, 1)',
                        'rgba(118, 75, 162, 1)',
                        'rgba(16, 185, 129, 1)'
                    ],
                    borderWidth: 2
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom'
                    }
                }
            }
        });
    }
    
    /**
     * Create investment analysis chart
     */
    createInvestmentChart(investmentData) {
        const ctx = document.getElementById('investmentChart');
        if (!ctx) return;
        
        new Chart(ctx, {
            type: 'radar',
            data: {
                labels: ['Investment Score', 'Rental Yield', 'Growth Potential', 'Risk Level', 'Market Position'],
                datasets: [{
                    label: 'Investment Assessment',
                    data: [
                        investmentData.investment_score || 7,
                        investmentData.rental_yield || 6,
                        8.5,
                        5,
                        7.5
                    ],
                    backgroundColor: 'rgba(102, 126, 234, 0.2)',
                    borderColor: 'rgba(102, 126, 234, 1)',
                    borderWidth: 2,
                    pointBackgroundColor: 'rgba(102, 126, 234, 1)',
                    pointBorderColor: '#fff',
                    pointHoverBackgroundColor: '#fff',
                    pointHoverBorderColor: 'rgba(102, 126, 234, 1)'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    r: {
                        beginAtZero: true,
                        max: 10
                    }
                },
                plugins: {
                    legend: {
                        display: false
                    }
                }
            }
        });
    }
    
    /**
     * Create similar properties chart
     */
    createSimilarPropertiesChart(properties, priceData) {
        const ctx = document.getElementById('similarChart');
        if (!ctx || !properties.length) return;
        
        const propertyPrices = properties.slice(0, 5).map(p => p.price || 0);
        const estimatedPrice = priceData.estimated_price || 0;
        
        new Chart(ctx, {
            type: 'line',
            data: {
                labels: properties.slice(0, 5).map((_, i) => `Property ${i + 1}`),
                datasets: [{
                    label: 'Similar Properties Prices (₺)',
                    data: propertyPrices,
                    backgroundColor: 'rgba(102, 126, 234, 0.2)',
                    borderColor: 'rgba(102, 126, 234, 1)',
                    borderWidth: 2,
                    fill: true,
                    tension: 0.4
                }, {
                    label: 'Estimated Price',
                    data: new Array(5).fill(estimatedPrice),
                    backgroundColor: 'rgba(16, 185, 129, 0.2)',
                    borderColor: 'rgba(16, 185, 129, 1)',
                    borderWidth: 2,
                    borderDash: [5, 5],
                    fill: false
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom'
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return '₺' + value.toLocaleString();
                            }
                        }
                    }
                }
            }
        });
    }
    
    /**
     * Export analysis to PDF
     */
    async exportToPDF() {
        try {
            const { jsPDF } = window.jspdf;
            if (!jsPDF) {
                console.error('jsPDF library not loaded');
                this.showError('PDF export library not available');
                return;
            }
            
            const results = this.state.lastAnalysisResults;
            if (!results) {
                this.showError('No analysis results to export');
                return;
            }
            
            const doc = new jsPDF();
            let yPosition = 20;
            
            // Title
            doc.setFontSize(20);
            doc.setFont(undefined, 'bold');
            doc.text('Property Analysis Report', 20, yPosition);
            yPosition += 15;
            
            // Date
            doc.setFontSize(10);
            doc.setFont(undefined, 'normal');
            doc.text(`Generated on: ${new Date().toLocaleDateString()}`, 20, yPosition);
            yPosition += 20;
            
            // Price Estimation
            if (results.price_estimation) {
                doc.setFontSize(14);
                doc.setFont(undefined, 'bold');
                doc.text('Price Valuation', 20, yPosition);
                yPosition += 10;
                
                doc.setFontSize(10);
                doc.setFont(undefined, 'normal');
                doc.text(`Estimated Price: ${this.formatCurrency(results.price_estimation.estimated_price)}`, 20, yPosition);
                yPosition += 7;
                doc.text(`Confidence: ${(results.price_estimation.confidence * 100).toFixed(0)}%`, 20, yPosition);
                yPosition += 7;
                doc.text(`Range: ${this.formatCurrency(results.price_estimation.price_range.min)} - ${this.formatCurrency(results.price_estimation.price_range.max)}`, 20, yPosition);
                yPosition += 15;
            }
            
            // Market Analysis
            if (results.market_analysis) {
                doc.setFontSize(14);
                doc.setFont(undefined, 'bold');
                doc.text('Market Analysis', 20, yPosition);
                yPosition += 10;
                
                doc.setFontSize(10);
                doc.setFont(undefined, 'normal');
                doc.text(`Market Position: ${results.market_analysis.market_position}`, 20, yPosition);
                yPosition += 7;
                doc.text(`Demand Level: ${results.market_analysis.demand_level}`, 20, yPosition);
                yPosition += 7;
                doc.text(`Growth Forecast: +${results.market_analysis.growth_forecast}%`, 20, yPosition);
                yPosition += 15;
            }
            
            // Investment Analysis
            if (results.investment_analysis) {
                doc.setFontSize(14);
                doc.setFont(undefined, 'bold');
                doc.text('Investment Analysis', 20, yPosition);
                yPosition += 10;
                
                doc.setFontSize(10);
                doc.setFont(undefined, 'normal');
                doc.text(`Investment Score: ${results.investment_analysis.investment_score}/10`, 20, yPosition);
                yPosition += 7;
                doc.text(`ROI Potential: ${results.investment_analysis.roi_potential}`, 20, yPosition);
                yPosition += 7;
                doc.text(`Rental Yield: ${results.investment_analysis.rental_yield}%`, 20, yPosition);
                yPosition += 7;
                doc.text(`Risk Level: ${results.investment_analysis.risk_level}`, 20, yPosition);
                yPosition += 15;
            }
            
            // Save PDF
            const fileName = `property-analysis-${new Date().toISOString().split('T')[0]}.pdf`;
            doc.save(fileName);
            
            this.showSuccess('Analysis exported to PDF successfully!');
            
        } catch (error) {
            console.error('PDF export failed:', error);
            this.showError('Failed to export PDF: ' + error.message);
        }
    }
    
    /**
     * Print analysis
     */
    printAnalysis() {
        try {
            const printContent = document.getElementById('analysisResultsContent');
            if (!printContent) {
                this.showError('No content to print');
                return;
            }
            
            const printWindow = window.open('', '_blank');
            printWindow.document.write(`
                <!DOCTYPE html>
                <html>
                <head>
                    <title>Property Analysis Report</title>
                    <style>
                        body { 
                            font-family: Arial, sans-serif; 
                            margin: 20px; 
                            color: #333;
                        }
                        .result-card { 
                            margin-bottom: 30px; 
                            padding: 20px; 
                            border: 1px solid #ddd; 
                            border-radius: 8px;
                            page-break-inside: avoid;
                        }
                        .result-card h3 { 
                            color: #667eea; 
                            border-bottom: 2px solid #667eea; 
                            padding-bottom: 10px;
                            margin-bottom: 20px;
                        }
                        .metric-item { 
                            display: flex; 
                            justify-content: space-between; 
                            margin: 10px 0; 
                            padding: 5px 0;
                            border-bottom: 1px dotted #ccc;
                        }
                        .price-display { 
                            text-align: center; 
                            margin: 20px 0;
                            padding: 20px;
                            background: #f8f9fa;
                            border-radius: 8px;
                        }
                        .amount { 
                            font-size: 2em; 
                            color: #667eea; 
                            font-weight: bold; 
                        }
                        .investment-score { 
                            text-align: center; 
                            margin: 20px 0; 
                        }
                        .score-circle { 
                            display: inline-block; 
                            width: 80px; 
                            height: 80px; 
                            border-radius: 50%; 
                            background: #667eea; 
                            color: white; 
                            line-height: 80px; 
                            font-size: 1.5em; 
                            font-weight: bold;
                            margin: 10px;
                        }
                        .property-item { 
                            margin: 10px 0; 
                            padding: 15px; 
                            background: #f8f9fa; 
                            border-radius: 5px; 
                        }
                        @media print {
                            body { margin: 0; }
                            .result-card { break-inside: avoid; }
                        }
                    </style>
                </head>
                <body>
                    <h1 style="color: #667eea; text-align: center; margin-bottom: 30px;">
                        Property Analysis Report
                    </h1>
                    <p style="text-align: center; margin-bottom: 40px; color: #666;">
                        Generated on ${new Date().toLocaleDateString()} at ${new Date().toLocaleTimeString()}
                    </p>
                    ${printContent.innerHTML}
                </body>
                </html>
            `);
            
            printWindow.document.close();
            printWindow.focus();
            
            // Wait for content to load then print
            setTimeout(() => {
                printWindow.print();
                printWindow.close();
            }, 500);
            
            this.showSuccess('Opening print dialog...');
            
        } catch (error) {
            console.error('Print failed:', error);
            this.showError('Failed to print: ' + error.message);
        }
    }
}

// Initialize app when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    // Create global app instance
    window.app = new REFusionXApp();
    window.app.init();
});
