/**
 * Chat Interface Module
 */

// تحقق من عدم وجود ChatInterface مسبقاً
if (typeof ChatInterface === 'undefined') {

class ChatInterface {
    constructor(containerId, apiClient, wsManager) {
        this.containerId = containerId;
        this.container = document.getElementById(containerId);
        this.api = apiClient;
        this.ws = wsManager;
        this.messages = [];
        this.isTyping = false;
        this.attachedImages = [];
        
        if (!this.container) {
            console.error(`Chat container with ID '${containerId}' not found`);
            // Try to find the container again after a short delay
            setTimeout(() => {
                this.container = document.getElementById(this.containerId);
                if (this.container) {
                    this.init();
                } else {
                    console.error(`Failed to find chat container after retry`);
                }
            }, 100);
        } else {
            this.init();
        }
    }
    
    /**
     * Initialize chat interface
     */
    init() {
        // Ensure container exists
        if (!this.container) {
            console.error('Chat container not found');
            return;
        }

        // Initialize chat UI if it doesn't exist
        if (!this.container.querySelector('.chat-messages')) {
            this.container.innerHTML = `
                <div class="chat-header">
                    <div class="chat-title">
                        <i class="fas fa-robot"></i>
                        <span>AI Assistant</span>
                        <span class="status-indicator online"></span>
                    </div>
                    
                    <div class="chat-actions">
                        <button class="icon-btn" onclick="app.modules.chat.clearChat()" title="Clear Chat">
                            <i class="fas fa-trash"></i>
                        </button>
                        <button class="icon-btn" onclick="app.modules.chat.exportChat()" title="Export Chat">
                            <i class="fas fa-download"></i>
                        </button>
                    </div>
                </div>
                
                <div class="chat-messages" id="chatMessages"></div>
                
                <div class="chat-input-area">
                    <div class="attached-images-container" id="attachedImagesContainer" style="display: none;"></div>
                    
                    <div class="quick-actions-bar">
                        <button class="quick-action" data-action="market-trends">
                            <i class="fas fa-chart-line"></i> Market Trends
                        </button>
                        <button class="quick-action" data-action="investment-tips">
                            <i class="fas fa-lightbulb"></i> Investment Tips
                        </button>
                        <button class="quick-action" data-action="legal-requirements">
                            <i class="fas fa-gavel"></i> Legal Info
                        </button>
                        <button class="quick-action" data-action="mortgage-info">
                            <i class="fas fa-percentage"></i> Mortgage
                        </button>
                    </div>
                    
                    <div class="input-container">
                        <textarea id="chatInput" 
                                  class="chat-input" 
                                  placeholder="Type your message or question..."
                                  rows="1"></textarea>
                        
                        <div class="input-actions">
                            <button id="attachImageBtn" class="attach-btn" title="Attach Image">
                                <i class="fas fa-paperclip"></i>
                            </button>
                            <button id="sendMessageBtn" class="send-btn">
                                <i class="fas fa-paper-plane"></i>
                            </button>
                        </div>
                    </div>
                </div>
            `;
        }

        this.setupEventListeners();
        this.setupWebSocketHandlers();
        this.loadWelcomeMessage();
    }
    
    /**
     * Setup event listeners
     */
    setupEventListeners() {
        // Send button
        const sendBtn = document.getElementById('sendMessageBtn');
        if (sendBtn) {
            sendBtn.addEventListener('click', () => this.sendMessage());
        }
        
        // Input field
        const input = document.getElementById('chatInput');
        if (input) {
            // Auto-resize
            input.addEventListener('input', (e) => {
                this.autoResizeInput(e.target);
            });
            
            // Enter to send
            input.addEventListener('keydown', (e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    this.sendMessage();
                }
            });
        }
        
        // Attach image button
        const attachBtn = document.getElementById('attachImageBtn');
        if (attachBtn) {
            attachBtn.addEventListener('click', () => this.attachImage());
        }
        
        // Quick actions - استخدام event delegation
        this.container.addEventListener('click', (e) => {
            if (e.target.closest('.quick-action')) {
                const btn = e.target.closest('.quick-action');
                this.handleQuickAction(btn.dataset.action);
            }
        });
    }
    
    /**
     * Setup WebSocket handlers
     */
    setupWebSocketHandlers() {
        this.ws.on('chat_response', (data) => {
            this.hideTypingIndicator();
            this.addMessage(data.content, 'assistant', {
                sources: data.sources,
                confidence: data.confidence
            });
        });
        
        this.ws.on('typing', (isTyping) => {
            if (isTyping) {
                this.showTypingIndicator();
            } else {
                this.hideTypingIndicator();
            }
        });
    }
    
    /**
     * Load welcome message
     */
    loadWelcomeMessage() {
        const welcomeMessage = `
            👋 Welcome to RE-FusionX!
            
            I'm your AI-powered real estate assistant specialized in the Turkish property market. 
            I can help you with:
            
            • Property valuation and price predictions
            • Market analysis and investment advice
            • Visual property assessment from images
            • Neighborhood insights and comparisons
            • Legal and financial guidance
            
            How can I assist you today?
        `;
        
        this.addMessage(welcomeMessage, 'assistant');
    }
    
    /**
     * Send message
     */
    async sendMessage() {
        const input = document.getElementById('chatInput');
        if (!input) return;
        
        const message = input.value.trim();
        
        if (!message && this.attachedImages.length === 0) return;
        
        // Add user message
        this.addMessage(message, 'user', { images: this.attachedImages });
        
        // Clear input
        input.value = '';
        this.autoResizeInput(input);
        
        // Clear attached images
        this.clearAttachedImages();
        
        // Show typing indicator
        this.showTypingIndicator();
        
        try {
            // Send via WebSocket if connected
            if (this.ws.isConnected) {
                this.ws.send('chat', {
                    content: message,
                    images: this.attachedImages,
                    context: this.getContext()
                });
            } else {
                // Fallback to API
                const response = await this.api.sendChatMessage(message, this.getContext());
                this.hideTypingIndicator();
                this.addMessage(response.response, 'assistant', {
                    sources: response.sources,
                    confidence: response.confidence
                });
            }
        } catch (error) {
            this.hideTypingIndicator();
            this.addMessage('Sorry, I encountered an error. Please try again.', 'assistant');
            console.error('Failed to send message:', error);
        }
    }
    
    /**
     * Add message to chat
     */
    addMessage(content, sender, metadata = {}) {
        // Get messages container - البحث عن العنصر الصحيح
        let messagesContainer = document.getElementById('chatMessages') || 
                                this.container?.querySelector('.chat-messages');
        
        if (!messagesContainer) {
            console.error('Messages container not found, reinitializing...');
            this.init();
            messagesContainer = document.getElementById('chatMessages') || 
                               this.container?.querySelector('.chat-messages');
            
            if (!messagesContainer) {
                console.error('Failed to find messages container after reinit');
                return;
            }
        }

        // Create message element
        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${sender}`;
        messageDiv.dataset.timestamp = new Date().toISOString();
        
        // Create message wrapper
        const messageWrapper = document.createElement('div');
        messageWrapper.className = 'message-wrapper';
        
        // Create message bubble
        const bubble = document.createElement('div');
        bubble.className = 'message-bubble';
        
        // Process content based on type
        if (typeof content === 'string') {
            bubble.innerHTML = this.formatMessage(content);
        } else {
            bubble.innerHTML = content;
        }
        
        // Add images if present
        if (metadata.images && metadata.images.length > 0) {
            const imagesDiv = document.createElement('div');
            imagesDiv.className = 'message-images';
            
            metadata.images.forEach(img => {
                const imgEl = document.createElement('img');
                imgEl.src = img;
                imgEl.alt = 'Attached image';
                imgEl.onclick = () => this.showImageModal(img);
                imagesDiv.appendChild(imgEl);
            });
            
            bubble.appendChild(imagesDiv);
        }
        
        // Add sources if present
        if (metadata.sources && metadata.sources.length > 0) {
            const sourcesDiv = document.createElement('div');
            sourcesDiv.className = 'message-sources';
            sourcesDiv.innerHTML = `
                <div class="sources-header">
                    <i class="fas fa-info-circle"></i> Sources
                </div>
                <ul>
                    ${metadata.sources.map(s => `<li>${s}</li>`).join('')}
                </ul>
            `;
            bubble.appendChild(sourcesDiv);
        }
        
        // Add confidence indicator
        if (metadata.confidence) {
            const confidenceDiv = document.createElement('div');
            confidenceDiv.className = 'confidence-indicator';
            confidenceDiv.innerHTML = `
                <span>Confidence: ${(metadata.confidence * 100).toFixed(1)}%</span>
                <div class="confidence-bar">
                    <div class="confidence-fill" style="width: ${metadata.confidence * 100}%"></div>
                </div>
            `;
            bubble.appendChild(confidenceDiv);
        }
        
        messageWrapper.appendChild(bubble);
        
        // Add metadata
        const metaDiv = document.createElement('div');
        metaDiv.className = 'message-meta';
        metaDiv.innerHTML = `
            <i class="fas fa-${sender === 'user' ? 'user' : 'robot'}"></i>
            <span>${sender === 'user' ? 'You' : 'AI Assistant'}</span>
            <span>•</span>
            <span>${this.formatTime(new Date())}</span>
        `;
        messageWrapper.appendChild(metaDiv);
        
        messageDiv.appendChild(messageWrapper);
        
        // Add to container
        messagesContainer.appendChild(messageDiv);
        
        // Scroll to bottom
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
        
        // Store message
        this.messages.push({
            content,
            sender,
            metadata,
            timestamp: new Date().toISOString()
        });
        
        // Save to localStorage
        this.saveHistory();
    }
    
    /**
     * Show typing indicator
     */
    showTypingIndicator() {
        if (this.isTyping) return;
        
        this.isTyping = true;
        
        // Get messages container - البحث عن العنصر الصحيح
        const messagesContainer = document.getElementById('chatMessages') || 
                                 this.container?.querySelector('.chat-messages');
        
        if (!messagesContainer) {
            console.error('Messages container not found for typing indicator');
            return;
        }
        
        const typingDiv = document.createElement('div');
        typingDiv.id = 'typingIndicator';
        typingDiv.className = 'message assistant';
        typingDiv.innerHTML = `
            <div class="typing-indicator">
                <span class="typing-dot"></span>
                <span class="typing-dot"></span>
                <span class="typing-dot"></span>
            </div>
        `;
        
        messagesContainer.appendChild(typingDiv);
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
    }
    
    /**
     * Hide typing indicator
     */
    hideTypingIndicator() {
        this.isTyping = false;
        const indicator = document.getElementById('typingIndicator');
        if (indicator) {
            indicator.remove();
        }
    }
    
    /**
     * Format message content
     */
    formatMessage(content) {
        // Convert markdown to HTML
        content = content
            .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
            .replace(/\*(.*?)\*/g, '<em>$1</em>')
            .replace(/\n/g, '<br>')
            .replace(/```(.*?)```/gs, '<pre><code>$1</code></pre>')
            .replace(/`(.*?)`/g, '<code>$1</code>');
        
        // Convert URLs to links
        content = content.replace(
            /(https?:\/\/[^\s]+)/g,
            '<a href="$1" target="_blank" rel="noopener">$1</a>'
        );
        
        return content;
    }
    
    /**
     * Handle quick actions
     */
    handleQuickAction(action) {
        const actions = {
            'market-trends': 'What are the current real estate market trends in Turkey?',
            'investment-tips': 'What should I consider when investing in Turkish real estate?',
            'legal-requirements': 'What are the legal requirements for buying property in Turkey?',
            'mortgage-info': 'How does mortgage financing work in Turkey?',
            'best-locations': 'Which locations in Turkey offer the best investment opportunities?'
        };
        
        const message = actions[action];
        if (message) {
            const input = document.getElementById('chatInput');
            if (input) {
                input.value = message;
                this.sendMessage();
            }
        }
    }
    
    /**
     * Attach image
     */
    attachImage() {
        const input = document.createElement('input');
        input.type = 'file';
        input.accept = 'image/*';
        input.multiple = true;
        
        input.onchange = (e) => {
            const files = Array.from(e.target.files);
            files.forEach(file => {
                this.processImageFile(file);
            });
        };
        
        input.click();
    }
    
    /**
     * Process image file
     */
    processImageFile(file) {
        const reader = new FileReader();
        
        reader.onload = (e) => {
            this.attachedImages.push(e.target.result);
            this.displayAttachedImage(e.target.result, file.name);
        };
        
        reader.readAsDataURL(file);
    }
    
    /**
     * Display attached image
     */
    displayAttachedImage(src, name) {
        const container = document.getElementById('attachedImagesContainer');
        if (!container) return;
        
        const imageDiv = document.createElement('div');
        imageDiv.className = 'attached-image';
        imageDiv.innerHTML = `
            <img src="${src}" alt="${name}">
            <button class="remove-btn" onclick="app.modules.chat.removeAttachedImage('${src}')">
                <i class="fas fa-times"></i>
            </button>
        `;
        
        container.appendChild(imageDiv);
        container.style.display = 'flex';
    }
    
    /**
     * Remove attached image
     */
    removeAttachedImage(src) {
        this.attachedImages = this.attachedImages.filter(img => img !== src);
        
        const container = document.getElementById('attachedImagesContainer');
        if (!container) return;
        
        const images = container.querySelectorAll('.attached-image');
        
        images.forEach(div => {
            const img = div.querySelector('img');
            if (img.src === src) {
                div.remove();
            }
        });
        
        if (this.attachedImages.length === 0) {
            container.style.display = 'none';
        }
    }
    
    /**
     * Clear attached images
     */
    clearAttachedImages() {
        this.attachedImages = [];
        const container = document.getElementById('attachedImagesContainer');
        if (container) {
            container.innerHTML = '';
            container.style.display = 'none';
        }
    }
    
    /**
     * Auto-resize input
     */
    autoResizeInput(element) {
        element.style.height = 'auto';
        element.style.height = Math.min(element.scrollHeight, 120) + 'px';
    }
    
    /**
     * Get context for message
     */
    getContext() {
        return {
            currentProperty: window.app?.state?.currentProperty || null,
            recentMessages: this.messages.slice(-5)
        };
    }
    
    /**
     * Save chat history
     */
    saveHistory() {
        try {
            const history = this.messages.slice(-100); // Keep last 100 messages
            localStorage.setItem('chatHistory', JSON.stringify(history));
        } catch (e) {
            console.warn('Failed to save chat history:', e);
        }
    }
    
    /**
     * Load chat history
     */
    loadHistory(history) {
        if (!Array.isArray(history)) return;
        
        history.forEach(msg => {
            this.addMessage(msg.content, msg.sender, msg.metadata);
        });
    }
    
    /**
     * Clear chat
     */
    clearChat() {
        if (confirm('Are you sure you want to clear the chat history?')) {
            this.messages = [];
            const messagesContainer = document.getElementById('chatMessages') || 
                                     this.container?.querySelector('.chat-messages');
            if (messagesContainer) {
                messagesContainer.innerHTML = '';
            }
            this.loadWelcomeMessage();
            
            // Clear analysis cache when clearing chat
            if (window.app && window.app.clearAnalysisCache) {
                window.app.clearAnalysisCache();
            }
            localStorage.removeItem('chatHistory');
        }
    }
    
    /**
     * Export chat
     */
    exportChat() {
        const content = this.messages.map(msg => {
            const sender = msg.sender === 'user' ? 'You' : 'AI Assistant';
            const time = new Date(msg.timestamp).toLocaleString();
            return `[${time}] ${sender}: ${typeof msg.content === 'string' ? msg.content : 'Complex message'}`;
        }).join('\n\n');
        
        const blob = new Blob([content], { type: 'text/plain' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `chat-export-${new Date().toISOString().split('T')[0]}.txt`;
        a.click();
        URL.revokeObjectURL(url);
    }
    
    /**
     * Show image modal
     */
    showImageModal(src) {
        const modal = document.createElement('div');
        modal.className = 'image-modal';
        modal.innerHTML = `
            <div class="modal-content">
                <span class="close-btn" onclick="this.parentElement.parentElement.remove()">
                    <i class="fas fa-times"></i>
                </span>
                <img src="${src}" alt="Full size image">
            </div>
        `;
        
        document.body.appendChild(modal);
        
        modal.onclick = (e) => {
            if (e.target === modal) {
                modal.remove();
            }
        };
    }
    
    /**
     * Format time
     */
    formatTime(date) {
        return date.toLocaleTimeString('en-US', {
            hour: '2-digit',
            minute: '2-digit'
        });
    }
    
    /**
     * Format currency
     */
    formatCurrency(amount) {
        return new Intl.NumberFormat('tr-TR', {
            style: 'currency',
            currency: 'TRY',
            minimumFractionDigits: 0,
            maximumFractionDigits: 0
        }).format(amount);
    }
    
    /**
     * Add analysis message - DISABLED: Results now show only in modal
     */
    addAnalysisMessage(propertyData, results) {
        // Analysis results are now shown only in the modal dashboard
        // No longer displaying in chat to avoid duplication
        return;
    }
    
    /**
     * Format analysis results - DISABLED: No longer used
     */
    formatAnalysisResults(propertyData, results) {
        // This function is no longer used as results are shown in modal only
        return '';
        // Create property summary
        const location = propertyData.location || 'Unknown Location';
        const propertyType = propertyData.property_type || 'Property';
        const rooms = propertyData.rooms || 'N/A';
        const size = propertyData.size_net || propertyData.size_gross || 'N/A';
        
        let html = `
            <div class="analysis-message">
                <div class="analysis-header">
                    <div class="header-content">
                        <h4>🏠 Property Analysis Report</h4>
                        <div class="property-summary">
                            <div class="property-details">
                                <span class="location"><i class="fas fa-map-marker-alt"></i> ${location}</span>
                                <span class="type-rooms">${propertyType} • ${rooms} rooms • ${size}m²</span>
                            </div>
                            <div class="analysis-timestamp">
                                <i class="fas fa-clock"></i> ${new Date().toLocaleString('en-GB', {
                                    day: '2-digit',
                                    month: '2-digit', 
                                    year: 'numeric',
                                    hour: '2-digit',
                                    minute: '2-digit'
                                })}
                            </div>
                        </div>
                    </div>
                </div>
        `;
        
        // Price Estimation with enhanced styling
        if (results.price_estimation) {
            const price = results.price_estimation.estimated_price;
            const priceRange = results.price_estimation.price_range;
            const confidence = results.price_estimation.confidence;
            
            // Determine confidence level styling
            const confidenceClass = confidence >= 0.8 ? 'high' : confidence >= 0.6 ? 'medium' : 'low';
            const confidenceIcon = confidence >= 0.8 ? '🟢' : confidence >= 0.6 ? '🟡' : '🔴';
            
            html += `
                <div class="analysis-section price-section">
                    <div class="section-header">
                        <h5><i class="fas fa-tag"></i> Price Valuation</h5>
                        <span class="confidence-badge ${confidenceClass}">
                            ${confidenceIcon} ${(confidence * 100).toFixed(0)}% Confidence
                        </span>
                    </div>
                    <div class="price-display-enhanced">
                        <div class="main-price">
                            <span class="currency">₺</span>
                            <span class="amount">${(price / 1000000).toFixed(2)}M</span>
                            <span class="full-amount">(${this.formatCurrency(price)})</span>
                        </div>
                        <div class="price-details">
                            <div class="price-range">
                                <i class="fas fa-arrows-alt-h"></i>
                                <span>Range: ${this.formatCurrency(priceRange.min)} - ${this.formatCurrency(priceRange.max)}</span>
                            </div>
                            ${size && size !== 'N/A' ? `
                            <div class="price-per-sqm">
                                <i class="fas fa-calculator"></i>
                                <span>₺${Math.round(price / parseFloat(size)).toLocaleString()} per m²</span>
                            </div>
                            ` : ''}
                        </div>
                    </div>
                </div>
            `;
        }
        
        // Market Analysis with visual indicators
        if (results.market_analysis) {
            const market = results.market_analysis;
            
            // Market position styling
            const positionClass = market.market_position === 'Above Average' ? 'above-avg' : 
                                market.market_position === 'Below Average' ? 'below-avg' : 'average';
            const positionIcon = market.market_position === 'Above Average' ? '📈' : 
                               market.market_position === 'Below Average' ? '📉' : '📊';
            
            html += `
                <div class="analysis-section market-section">
                    <div class="section-header">
                        <h5><i class="fas fa-chart-line"></i> Market Analysis</h5>
                    </div>
                    <div class="market-metrics">
                        <div class="metric-row">
                            <div class="metric-card ${positionClass}">
                                <div class="metric-icon">${positionIcon}</div>
                                <div class="metric-content">
                                    <div class="metric-value">${market.market_position}</div>
                                    <div class="metric-label">Market Position</div>
                                </div>
                            </div>
                            <div class="metric-card">
                                <div class="metric-icon">🎯</div>
                                <div class="metric-content">
                                    <div class="metric-value">${market.demand_level}</div>
                                    <div class="metric-label">Demand Level</div>
                                </div>
                            </div>
                        </div>
                        <div class="metric-row">
                            <div class="metric-card">
                                <div class="metric-icon">📦</div>
                                <div class="metric-content">
                                    <div class="metric-value">${market.supply_level}</div>
                                    <div class="metric-label">Supply Level</div>
                                </div>
                            </div>
                            <div class="metric-card growth">
                                <div class="metric-icon">🚀</div>
                                <div class="metric-content">
                                    <div class="metric-value">+${market.growth_forecast}%</div>
                                    <div class="metric-label">Growth Forecast</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            `;
        }
        
        // Investment Analysis (enhanced to show even when empty)
        if (results.investment_analysis && Object.keys(results.investment_analysis).length > 0) {
            html += `
                <div class="analysis-section investment-section">
                    <div class="section-header">
                        <h5><i class="fas fa-coins"></i> Investment Metrics</h5>
                    </div>
                    <div class="investment-metrics">
                        <div class="metric-card score">
                            <div class="score-circle">
                                <span class="score-value">${results.investment_analysis.investment_score || 'N/A'}</span>
                                <span class="score-max">/10</span>
                            </div>
                            <div class="metric-label">Investment Score</div>
                        </div>
                        <div class="investment-details">
                            <div class="detail-item">
                                <i class="fas fa-percentage"></i>
                                <span class="label">ROI Potential</span>
                                <span class="value">${results.investment_analysis.roi_potential || 'TBD'}</span>
                            </div>
                            <div class="detail-item">
                                <i class="fas fa-home"></i>
                                <span class="label">Rental Yield</span>
                                <span class="value">${results.investment_analysis.rental_yield || 'TBD'}%</span>
                            </div>
                            <div class="detail-item">
                                <i class="fas fa-shield-alt"></i>
                                <span class="label">Risk Level</span>
                                <span class="value">${results.investment_analysis.risk_level || 'Medium'}</span>
                            </div>
                        </div>
                    </div>
                </div>
            `;
        } else {
            // Show investment section even when data is not available
            html += `
                <div class="analysis-section investment-section">
                    <div class="section-header">
                        <h5><i class="fas fa-coins"></i> Investment Metrics</h5>
                        <span class="status-badge pending">Analysis Pending</span>
                    </div>
                    <div class="investment-placeholder">
                        <i class="fas fa-chart-pie fa-2x"></i>
                        <p>Investment analysis will be available in the detailed report</p>
                    </div>
                </div>
            `;
        }
        
        // Qwen AI Analysis Section (ENHANCED - Always show if available)
        console.log('🔍 DEBUG: Checking qwen_analysis:', results.qwen_analysis ? 'EXISTS' : 'MISSING');
        if (results.qwen_analysis) {
            console.log('🔍 DEBUG: qwen_analysis content:', results.qwen_analysis);
            html += `
                <div class="analysis-section qwen-section">
                    <div class="section-header">
                        <h5><i class="fas fa-brain"></i> AI Expert Analysis</h5>
                        <span class="ai-badge">Powered by Mahmoud Almohammad</span>
                    </div>
                    <div class="qwen-analysis-content">
                        <div class="analysis-text">
                            ${this.formatQwenAnalysis(results.qwen_analysis)}
                        </div>
                        <div class="qwen-metrics">
                            <div class="metric-chip">
                                <i class="fas fa-chart-line"></i>
                                <span>Advanced AI Analysis</span>
                            </div>
                            <div class="metric-chip">
                                <i class="fas fa-database"></i>
                                <span>${results.qwen_analysis.length} characters analyzed</span>
                            </div>
                        </div>
                        <div class="analysis-footer">
                            <small><i class="fas fa-robot"></i> Generated by Mahmoud Almohammad - Advanced Language Model</small>
                        </div>
                    </div>
                </div>
            `;
        } else {
            // Show placeholder when Qwen analysis is not available
            html += `
                <div class="analysis-section qwen-section-placeholder">
                    <div class="section-header">
                        <h5><i class="fas fa-brain"></i> AI Expert Analysis</h5>
                        <span class="status-badge processing">Processing...</span>
                    </div>
                    <div class="placeholder-content">
                        <div class="placeholder-icon">
                            <i class="fas fa-cog fa-spin"></i>
                        </div>
                        <p>Advanced AI analysis is being generated...</p>
                        <small>This provides deeper insights beyond basic calculations</small>
                    </div>
                </div>
            `;
        }
        
        // Similar Properties Details (ENHANCED)
        const similarCount = (results.similar_properties && results.similar_properties.length) || 0;
        if (results.similar_properties && results.similar_properties.length > 0) {
            // Calculate average price and size for comparison
            const avgPrice = results.similar_properties.reduce((sum, p) => sum + (p.price || 0), 0) / similarCount;
            const avgSize = results.similar_properties.reduce((sum, p) => sum + (p.size || 0), 0) / similarCount;
            const avgPricePerSqm = avgPrice / avgSize;
            
            html += `
                <div class="analysis-section similar-properties-section">
                    <div class="section-header">
                        <h5><i class="fas fa-home"></i> Market Comparison (${similarCount} Properties)</h5>
                        <div class="comparison-stats">
                            <span class="stat-chip">Avg: ₺${Math.round(avgPrice).toLocaleString('tr-TR')}</span>
                            <span class="stat-chip">₺${Math.round(avgPricePerSqm).toLocaleString('tr-TR')}/m²</span>
                        </div>
                    </div>
                    
                    <div class="market-summary">
                        <div class="summary-metrics">
                            <div class="summary-item">
                                <i class="fas fa-chart-bar"></i>
                                <div class="summary-content">
                                    <div class="summary-value">₺${Math.round(avgPrice).toLocaleString('tr-TR')}</div>
                                    <div class="summary-label">Average Price</div>
                                </div>
                            </div>
                            <div class="summary-item">
                                <i class="fas fa-ruler-combined"></i>
                                <div class="summary-content">
                                    <div class="summary-value">${Math.round(avgSize)} m²</div>
                                    <div class="summary-label">Average Size</div>
                                </div>
                            </div>
                            <div class="summary-item">
                                <i class="fas fa-calculator"></i>
                                <div class="summary-content">
                                    <div class="summary-value">₺${Math.round(avgPricePerSqm).toLocaleString('tr-TR')}</div>
                                    <div class="summary-label">Price per m²</div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="similar-properties-grid">
                        ${results.similar_properties.slice(0, 4).map((property, index) => {
                            const priceVariance = property.price ? ((property.price - avgPrice) / avgPrice * 100) : 0;
                            const priceClass = priceVariance > 10 ? 'above-market' : priceVariance < -10 ? 'below-market' : 'market-rate';
                            
                            return `
                            <div class="similar-property-card enhanced">
                                <div class="property-header">
                                    <div class="property-location">${property.location || 'N/A'}</div>
                                    <div class="similarity-badge high">${Math.round((property.similarity_score || 0) * 100)}% match</div>
                                </div>
                                <div class="property-price-main">
                                    <span class="price-amount">₺${(property.price || 0).toLocaleString('tr-TR')}</span>
                                    <span class="price-variance ${priceClass}">
                                        ${priceVariance > 0 ? '+' : ''}${priceVariance.toFixed(1)}%
                                    </span>
                                </div>
                                <div class="property-details enhanced">
                                    <div class="detail-row">
                                        <i class="fas fa-home"></i>
                                        <span class="detail-label">Type & Rooms:</span>
                                        <span class="detail-value">${property.rooms || 'N/A'}</span>
                                    </div>
                                    <div class="detail-row">
                                        <i class="fas fa-expand-arrows-alt"></i>
                                        <span class="detail-label">Size:</span>
                                        <span class="detail-value">${property.size || 'N/A'} m²</span>
                                    </div>
                                    <div class="detail-row">
                                        <i class="fas fa-calculator"></i>
                                        <span class="detail-label">Price/m²:</span>
                                        <span class="detail-value">₺${property.price_per_sqm ? Math.round(property.price_per_sqm).toLocaleString('tr-TR') : 'N/A'}</span>
                                    </div>
                                    ${property.building_age ? `
                                    <div class="detail-row">
                                        <i class="fas fa-calendar-alt"></i>
                                        <span class="detail-label">Age:</span>
                                        <span class="detail-value">${property.building_age} years</span>
                                    </div>
                                    ` : ''}
                                </div>
                                <div class="property-footer">
                                    <div class="market-position ${priceClass}">
                                        ${priceClass === 'above-market' ? 'Above Market' : 
                                          priceClass === 'below-market' ? 'Below Market' : 'Market Rate'}
                                    </div>
                                </div>
                            </div>
                        `}).join('')}
                    </div>
                    
                    ${similarCount > 4 ? `
                        <div class="more-properties enhanced">
                            <div class="more-info">
                                <i class="fas fa-plus-circle"></i>
                                <span><strong>+${similarCount - 4} more properties</strong> analyzed in market comparison</span>
                            </div>
                            <div class="data-freshness">
                                <i class="fas fa-clock"></i>
                                <span>Data refreshed from live sources</span>
                            </div>
                        </div>
                    ` : ''}
                </div>
            `;
        }
        
        // Analysis Summary
        html += `
            <div class="analysis-section summary-section">
                <div class="section-header">
                    <h5><i class="fas fa-chart-line"></i> Analysis Summary</h5>
                </div>
                <div class="summary-stats">
                    <div class="stat-item">
                        <i class="fas fa-home"></i>
                        <span class="stat-value">${similarCount}</span>
                        <span class="stat-label">Similar Properties</span>
                    </div>
                    <div class="stat-item">
                        <i class="fas fa-database"></i>
                        <span class="stat-value">Fresh</span>
                        <span class="stat-label">Market Data</span>
                    </div>
                    <div class="stat-item">
                        <i class="fas fa-check-circle"></i>
                        <span class="stat-value">Complete</span>
                        <span class="stat-label">Analysis Status</span>
                    </div>
                    <div class="stat-item">
                        <i class="fas fa-brain"></i>
                        <span class="stat-value">${results.qwen_analysis ? 'AI Enhanced' : 'Standard'}</span>
                        <span class="stat-label">Analysis Type</span>
                    </div>
                </div>
            </div>
        `;
        
        // Simple completion message instead of action buttons
        html += `
            <div class="analysis-completion">
                <div class="completion-message">
                    <i class="fas fa-check-circle"></i>
                    <span>Analysis completed! Click "Analyze Property" button to view detailed dashboard.</span>
                </div>
            </div>
        `;
        
        html += `</div>`;
        
        return html;
    }
    
    /**
     * Format Qwen analysis for display - ENHANCED VERSION
     */
    formatQwenAnalysis(qwenText) {
        if (!qwenText) return '';
        
        // 🔍 DEBUG: Print full Qwen response for analysis
        console.log('=================== QWEN ANALYSIS FULL TEXT ===================');
        console.log('Length:', qwenText.length, 'characters');
        console.log('Raw text:');
        console.log(qwenText);
        console.log('================================================================');
        
        // Also log it in a more readable format
        console.group('🧠 Qwen Analysis Breakdown');
        console.log('📊 Character count:', qwenText.length);
        console.log('📝 First 200 characters:', qwenText.substring(0, 200) + '...');
        console.log('📝 Last 200 characters:', '...' + qwenText.substring(qwenText.length - 200));
        
        // Check for key patterns
        const patterns = {
            'Investment Score': /investment.*score.*(\d+(?:\.\d+)?)/gi,
            'ROI': /roi.*(\d+(?:\.\d+)?\%?)/gi,
            'Rental Yield': /rental.*yield.*(\d+(?:\.\d+)?\%?)/gi,
            'Risk Level': /risk.*(low|medium|high)/gi,
            'Price Analysis': /price.*₺?([\d,]+(?:\.\d+)?)/gi,
            'Location References': /(İstanbul|Kadıköy|district|location)/gi
        };
        
        console.log('🔍 Pattern Analysis:');
        Object.entries(patterns).forEach(([name, pattern]) => {
            const matches = qwenText.match(pattern);
            console.log(`  ${name}:`, matches ? matches.length + ' matches' : 'No matches', matches || '');
        });
        
        console.groupEnd();
        
        // ENHANCED PARSING: Extract structured sections from Qwen response
        const sections = this.parseQwenSections(qwenText);
        
        // Build structured HTML from parsed sections
        let formatted = '<div class="qwen-structured-analysis">';
        
        // Property Details Section
        if (sections.propertyDetails) {
            formatted += `
                <div class="qwen-section-block property-details-block">
                    <div class="section-title">
                        <i class="fas fa-home"></i>
                        <h6>Property Overview</h6>
                    </div>
                    <div class="details-grid">
                        ${this.formatPropertyDetails(sections.propertyDetails)}
                    </div>
                </div>
            `;
        }
        
        // Market Context Section
        if (sections.marketContext) {
            formatted += `
                <div class="qwen-section-block market-context-block">
                    <div class="section-title">
                        <i class="fas fa-chart-bar"></i>
                        <h6>Market Intelligence</h6>
                    </div>
                    <div class="market-stats-grid">
                        ${this.formatMarketContext(sections.marketContext)}
                    </div>
                </div>
            `;
        }
        
        // Value Assessment Section
        if (sections.valueAssessment) {
            formatted += `
                <div class="qwen-section-block value-assessment-block">
                    <div class="section-title">
                        <i class="fas fa-calculator"></i>
                        <h6>Value Assessment</h6>
                    </div>
                    <div class="value-content">
                        ${this.formatValueAssessment(sections.valueAssessment)}
                    </div>
                </div>
            `;
        }
        
        // Location Factors Section
        if (sections.locationFactors) {
            formatted += `
                <div class="qwen-section-block location-factors-block">
                    <div class="section-title">
                        <i class="fas fa-map-marker-alt"></i>
                        <h6>Location Analysis</h6>
                    </div>
                    <div class="location-content">
                        ${this.formatLocationFactors(sections.locationFactors)}
                    </div>
                </div>
            `;
        }
        
        // Financial Outlook Section
        if (sections.financialOutlook) {
            formatted += `
                <div class="qwen-section-block financial-outlook-block">
                    <div class="section-title">
                        <i class="fas fa-chart-line"></i>
                        <h6>Financial Outlook</h6>
                    </div>
                    <div class="financial-content">
                        ${this.formatFinancialOutlook(sections.financialOutlook)}
                    </div>
                </div>
            `;
        }
        
        // Negotiation Strategy Section
        if (sections.negotiationStrategy) {
            formatted += `
                <div class="qwen-section-block negotiation-strategy-block">
                    <div class="section-title">
                        <i class="fas fa-handshake"></i>
                        <h6>Negotiation Strategy</h6>
                    </div>
                    <div class="negotiation-content">
                        ${this.formatNegotiationStrategy(sections.negotiationStrategy)}
                    </div>
                </div>
            `;
        }
        
        // Recommendations Section
        if (sections.recommendations) {
            formatted += `
                <div class="qwen-section-block recommendations-block">
                    <div class="section-title">
                        <i class="fas fa-lightbulb"></i>
                        <h6>Expert Recommendations</h6>
                    </div>
                    <div class="recommendations-content">
                        ${this.formatRecommendations(sections.recommendations)}
                    </div>
                </div>
            `;
        }
        
        // Handle fallback/generic sections
        Object.entries(sections).forEach(([key, content]) => {
            if (!['propertyDetails', 'marketContext', 'valueAssessment', 'locationFactors', 'financialOutlook', 'negotiationStrategy', 'recommendations'].includes(key)) {
                formatted += `
                    <div class="qwen-section-block generic-section-block">
                        <div class="section-title">
                            <i class="fas fa-info-circle"></i>
                            <h6>${this.formatSectionTitle(key)}</h6>
                        </div>
                        <div class="generic-content">
                            ${this.formatGenericContent(content)}
                        </div>
                    </div>
                `;
            }
        });
        
        formatted += '</div>';
        
        // Wrap in enhanced container
        if (!formatted.includes('<p>')) {
            formatted = '<div class="qwen-content">' + formatted + '</div>';
        } else {
            formatted = '<div class="qwen-content"><p>' + formatted + '</p></div>';
        }
        
        // Add analysis insights section if content is substantial
        if (qwenText.length > 500) {
            const insights = this.extractQwenInsights(qwenText);
            if (insights.length > 0) {
                formatted += `
                    <div class="qwen-insights">
                        <h6 class="insights-header"><i class="fas fa-brain"></i> Key AI Insights</h6>
                        <ul class="insights-list">
                            ${insights.map(insight => `<li class="insight-item"><i class="fas fa-check-circle"></i>${insight}</li>`).join('')}
                        </ul>
                    </div>
                `;
            }
        }
        
        return formatted;
    }
    
    /**
     * Extract key insights from Qwen analysis
     */
    extractQwenInsights(qwenText) {
        const insights = [];
        
        // Extract investment-related insights
        if (qwenText.match(/investment.*score.*(\d+)/i)) {
            const score = qwenText.match(/investment.*score.*(\d+(?:\.\d+)?)/i);
            if (score) {
                insights.push(`Investment score of ${score[1]} indicates ${score[1] > 7 ? 'excellent' : score[1] > 5 ? 'good' : 'moderate'} potential`);
            }
        }
        
        // Extract market position insights
        if (qwenText.match(/(above|below|market|average)/i)) {
            insights.push('Market position analysis completed with comparative data');
        }
        
        // Extract risk assessment
        if (qwenText.match(/risk.*(low|medium|high)/i)) {
            const risk = qwenText.match(/risk.*(low|medium|high)/i);
            if (risk) {
                insights.push(`Risk level assessed as ${risk[1]} based on market conditions`);
            }
        }
        
        // Extract ROI insights
        if (qwenText.match(/roi.*(\d+(?:\.\d+)?\%?)/i)) {
            insights.push('Return on investment calculation includes rental yield projections');
        }
        
        // Extract location insights
        if (qwenText.match(/(İstanbul|Kadıköy|district|location)/i)) {
            insights.push('Location-specific market analysis with district-level data');
        }
        
        return insights;
    }
    
    /**
     * Parse Qwen text into structured sections - ENHANCED for flexible parsing
     */
    parseQwenSections(qwenText) {
        console.log('🔍 DEBUG: Parsing Qwen sections from text:', qwenText.substring(0, 200) + '...');
        
        const sections = {};
        
        // More flexible section extraction patterns
        const sectionPatterns = {
            propertyDetails: [
                /\*\*Property Details\*\*(.*?)(?=\*\*|$)/s,
                /\*\*Property Analysis Report\*\*(.*?)(?=\*\*|$)/s,
                /Property Details:(.*?)(?=\n\n|\*\*|$)/s
            ],
            marketContext: [
                /\*\*Market Context\*\*(.*?)(?=\*\*|$)/s,
                /Market Context:(.*?)(?=\n\n|\*\*|$)/s,
                /- Average Price:(.*?)(?=\*\*|$)/s
            ],
            valueAssessment: [
                /\*\*Value Assessment\*\*(.*?)(?=\*\*|$)/s,
                /Value Assessment:(.*?)(?=\n\n|\*\*|$)/s,
                /- Market Position:(.*?)(?=\*\*|$)/s
            ],
            locationFactors: [
                /\*\*Location Factors\*\*(.*?)(?=\*\*|$)/s,
                /Location Factors:(.*?)(?=\n\n|\*\*|$)/s
            ],
            financialOutlook: [
                /\*\*Financial Outlook\*\*(.*?)(?=\*\*|$)/s,
                /Financial Outlook:(.*?)(?=\n\n|\*\*|$)/s
            ],
            negotiationStrategy: [
                /\*\*Negotiation Strategy\*\*(.*?)(?=\*\*|$)/s,
                /Negotiation Strategy:(.*?)(?=\n\n|\*\*|$)/s
            ],
            recommendations: [
                /\*\*Recommendations\*\*(.*?)(?=\*\*|$)/s,
                /Recommendations:(.*?)(?=\n\n|\*\*|$)/s,
                /- Consider (.*?)(?=Best regards|$)/s
            ]
        };
        
        // Try each pattern for each section
        Object.entries(sectionPatterns).forEach(([sectionName, patterns]) => {
            for (const pattern of patterns) {
                const match = qwenText.match(pattern);
                if (match && match[1].trim()) {
                    sections[sectionName] = match[1].trim();
                    console.log(`✅ Found ${sectionName}:`, match[1].trim().substring(0, 100) + '...');
                    break; // Use first successful match
                }
            }
        });
        
        // If no structured sections found, create a fallback
        if (Object.keys(sections).length === 0) {
            console.log('⚠️ No structured sections found, creating fallback sections');
            
            // Split by double asterisks and create generic sections
            const parts = qwenText.split(/\*\*([^*]+)\*\*/);
            for (let i = 1; i < parts.length; i += 2) {
                const title = parts[i];
                const content = parts[i + 1];
                
                if (content && content.trim()) {
                    const key = title.toLowerCase().replace(/\s+/g, '');
                    sections[key] = content.trim();
                    console.log(`✅ Created fallback section '${key}':`, content.trim().substring(0, 100) + '...');
                }
            }
            
            // If still no sections, create a single comprehensive section
            if (Object.keys(sections).length === 0) {
                sections.comprehensive = qwenText;
                console.log('✅ Created comprehensive fallback section');
            }
        }
        
        console.log('🔍 Final parsed sections:', Object.keys(sections));
        return sections;
    }
    
    /**
     * Format Property Details section
     */
    formatPropertyDetails(text) {
        if (!text) return '';
        
        return text
            .replace(/- Location: (.+)/g, '<div class="detail-item location"><i class="fas fa-map-marker-alt"></i><span class="label">Location:</span><span class="value">$1</span></div>')
            .replace(/- Property Type: (.+)/g, '<div class="detail-item type"><i class="fas fa-home"></i><span class="label">Type:</span><span class="value">$1</span></div>')
            .replace(/- Size: (.+)/g, '<div class="detail-item size"><i class="fas fa-expand-arrows-alt"></i><span class="label">Size:</span><span class="value">$1</span></div>')
            .replace(/- Room Layout: (.+)/g, '<div class="detail-item rooms"><i class="fas fa-bed"></i><span class="label">Layout:</span><span class="value">$1</span></div>')
            .replace(/- Building Age: (.+)/g, '<div class="detail-item age"><i class="fas fa-calendar-alt"></i><span class="label">Age:</span><span class="value">$1</span></div>')
            .replace(/- Floor Level: (.+)/g, '<div class="detail-item floor"><i class="fas fa-layer-group"></i><span class="label">Floor:</span><span class="value">$1</span></div>');
    }
    
    /**
     * Format Market Context section
     */
    formatMarketContext(text) {
        if (!text) return '';
        
        return text
            .replace(/- Sample Size: (.+)/g, '<div class="market-stat sample"><i class="fas fa-database"></i><span class="label">Sample Size:</span><span class="value">$1</span></div>')
            .replace(/- Average Price: (.+)/g, '<div class="market-stat avg-price"><i class="fas fa-chart-line"></i><span class="label">Average Price:</span><span class="value highlight-price">$1</span></div>')
            .replace(/- Price Range: (.+)/g, '<div class="market-stat price-range"><i class="fas fa-arrows-alt-h"></i><span class="label">Price Range:</span><span class="value">$1</span></div>')
            .replace(/- Price per Sqm: (.+)/g, '<div class="market-stat price-sqm"><i class="fas fa-calculator"></i><span class="label">Price/m²:</span><span class="value highlight-price">$1</span></div>');
    }
    
    /**
     * Format Value Assessment section
     */
    formatValueAssessment(text) {
        if (!text) return '';
        
        return text
            .replace(/- Listed Price: (.+)/g, '<div class="value-item listed"><i class="fas fa-tag"></i><span class="label">Listed Price:</span><span class="value">$1</span></div>')
            .replace(/- Estimated Value: (.+)/g, '<div class="value-item estimated"><i class="fas fa-calculator"></i><span class="label">Estimated Value:</span><span class="value highlight-price">$1</span></div>')
            .replace(/- Price Justification: (.+)/g, '<div class="value-item justification"><i class="fas fa-check-circle"></i><span class="label">Assessment:</span><span class="value">$1</span></div>');
    }
    
    /**
     * Format Location Factors section
     */
    formatLocationFactors(text) {
        if (!text) return '';
        
        return text
            .replace(/- Accessibility: (.+)/g, '<div class="location-factor access"><i class="fas fa-route"></i><span class="label">Accessibility:</span><span class="value">$1</span></div>')
            .replace(/- Neighborhood Grade: (.+)/g, '<div class="location-factor grade"><i class="fas fa-star"></i><span class="label">Neighborhood:</span><span class="value">$1</span></div>')
            .replace(/- Growth Potential: (.+)/g, '<div class="location-factor growth"><i class="fas fa-trending-up"></i><span class="label">Growth Potential:</span><span class="value">$1</span></div>');
    }
    
    /**
     * Format Financial Outlook section
     */
    formatFinancialOutlook(text) {
        if (!text) return '';
        
        return text
            .replace(/- Mortgage Affordability: (.+)/g, '<div class="financial-item mortgage"><i class="fas fa-university"></i><span class="label">Mortgage:</span><span class="value">$1</span></div>')
            .replace(/- Rental Income Potential: (.+)/g, '<div class="financial-item rental"><i class="fas fa-coins"></i><span class="label">Rental Potential:</span><span class="value">$1</span></div>')
            .replace(/- Investment Appeal: (.+)/g, '<div class="financial-item investment"><i class="fas fa-chart-pie"></i><span class="label">Investment Appeal:</span><span class="value">$1</span></div>');
    }
    
    /**
     * Format Negotiation Strategy section
     */
    formatNegotiationStrategy(text) {
        if (!text) return '';
        
        return text
            .replace(/- Approach: (.+)/g, '<div class="negotiation-item approach"><i class="fas fa-handshake"></i><span class="label">Approach:</span><span class="value">$1</span></div>')
            .replace(/- Pricing Strategy: (.+)/g, '<div class="negotiation-item pricing"><i class="fas fa-money-bill-wave"></i><span class="label">Pricing:</span><span class="value">$1</span></div>')
            .replace(/- Communication: (.+)/g, '<div class="negotiation-item communication"><i class="fas fa-comments"></i><span class="label">Communication:</span><span class="value">$1</span></div>');
    }
    
    /**
     * Format Recommendations section
     */
    formatRecommendations(text) {
        if (!text) return '';
        
        return text
            .replace(/- Consideration for Purchase: (.+)/g, '<div class="recommendation-item purchase"><i class="fas fa-shopping-cart"></i><span class="label">Purchase Consideration:</span><span class="value">$1</span></div>')
            .replace(/- Comparative Market Analysis: (.+)/g, '<div class="recommendation-item analysis"><i class="fas fa-chart-bar"></i><span class="label">Market Analysis:</span><span class="value">$1</span></div>')
            .replace(/- Professional Advice: (.+)/g, '<div class="recommendation-item advice"><i class="fas fa-user-tie"></i><span class="label">Professional Advice:</span><span class="value">$1</span></div>');
    }
    
    /**
     * Format section title for display
     */
    formatSectionTitle(key) {
        const titleMap = {
            'propertyanalysisreport': 'Property Analysis Report',
            'propertydetails': 'Property Details',
            'marketcontext': 'Market Context',
            'valueassessment': 'Value Assessment',
            'locationfactors': 'Location Factors',
            'financialoutlook': 'Financial Outlook',
            'negotiationstrategy': 'Negotiation Strategy',
            'recommendations': 'Recommendations',
            'comprehensive': 'Comprehensive Analysis'
        };
        
        return titleMap[key] || key.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase());
    }
    
    /**
     * Format generic content with enhanced styling
     */
    formatGenericContent(content) {
        if (!content) return '';
        
        return content
            // Format lists
            .replace(/^- (.+)$/gm, '<div class="content-item"><i class="fas fa-chevron-right"></i><span>$1</span></div>')
            
            // Format key-value pairs
            .replace(/^([^:]+):\s*(.+)$/gm, '<div class="key-value-item"><span class="key">$1:</span><span class="value">$2</span></div>')
            
            // Format prices and monetary values
            .replace(/(₺?[\d,]+(?:\.\d+)?\s*(?:TL|₺))/g, '<span class="currency-highlight">$1</span>')
            
            // Format percentages
            .replace(/(\d+(?:\.\d+)?\s*%)/g, '<span class="percentage-highlight">$1</span>')
            
            // Format property types and locations
            .replace(/(İstanbul|Kadıköy|Apartment|Villa|House|Daire)/gi, '<span class="highlight-term">$1</span>')
            
            // Convert line breaks to proper HTML
            .replace(/\n\n+/g, '</div><div class="content-paragraph"><div class="content-paragraph">')
            .replace(/\n/g, '<br>');
    }
}

// Make ChatInterface globally available
window.ChatInterface = ChatInterface;

} // End of if statement checking for ChatInterface
