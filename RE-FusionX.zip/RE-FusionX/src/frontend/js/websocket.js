/**
 * WebSocket Manager for real-time communication
 */

class WebSocketManager {
    constructor(wsUrl, sessionId) {
        this.wsUrl = wsUrl;
        this.sessionId = sessionId;
        this.ws = null;
        this.reconnectAttempts = 0;
        this.maxReconnectAttempts = 5;
        this.reconnectDelay = 1000;
        this.handlers = {};
        this.messageQueue = [];
        this.isConnected = false;
        this.heartbeatInterval = null;
    }
    
    /**
     * Connect to WebSocket server
     */
    async connect() {
        return new Promise((resolve, reject) => {
            try {
                // تحديد البورت الصحيح للـ backend
                const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
                const backendHost = window.location.hostname;
                const backendPort = 8000; // Backend port
                const wsUrl = `${protocol}//${backendHost}:${backendPort}/ws/${this.sessionId}`;
                
                console.log(`Connecting to WebSocket: ${wsUrl}`);
                this.ws = new WebSocket(wsUrl);
                
                this.ws.onopen = () => {
                    console.log('WebSocket connected');
                    this.isConnected = true;
                    this.reconnectAttempts = 0;
                    this.flushMessageQueue();
                    this.startHeartbeat();
                    this.emit('connected');
                    resolve();
                };
                
                this.ws.onmessage = (event) => {
                    this.handleMessage(event.data);
                };
                
                this.ws.onerror = (error) => {
                    console.error('WebSocket error:', error);
                    this.emit('error', error);
                };
                
                this.ws.onclose = (event) => {
                    console.log('WebSocket disconnected', event.code, event.reason);
                    this.isConnected = false;
                    this.stopHeartbeat();
                    this.emit('disconnected');
                    
                    // Only reconnect if not a normal closure
                    if (event.code !== 1000 && event.code !== 1001) {
                        this.attemptReconnect();
                    }
                };
                
            } catch (error) {
                console.error('Failed to connect WebSocket:', error);
                reject(error);
            }
        });
    }
    
    /**
     * Start heartbeat interval
     */
    startHeartbeat() {
        this.stopHeartbeat(); // Clear any existing interval
        this.heartbeatInterval = setInterval(() => {
            if (this.isConnected && this.ws.readyState === WebSocket.OPEN) {
                this.send('ping', {});
            }
        }, 30000); // Every 30 seconds
    }
    
    /**
     * Stop heartbeat interval
     */
    stopHeartbeat() {
        if (this.heartbeatInterval) {
            clearInterval(this.heartbeatInterval);
            this.heartbeatInterval = null;
        }
    }
    
    /**
     * Disconnect from WebSocket
     */
    disconnect() {
        this.stopHeartbeat();
        if (this.ws) {
            this.ws.close(1000, 'Client disconnect');
            this.ws = null;
        }
        this.isConnected = false;
    }
    
    /**
     * Send message through WebSocket
     */
    send(type, data) {
        const message = JSON.stringify({
            type,
            data,
            timestamp: new Date().toISOString()
        });
        
        if (this.isConnected && this.ws.readyState === WebSocket.OPEN) {
            this.ws.send(message);
        } else {
            // Queue message if not connected
            this.messageQueue.push(message);
        }
    }
    
    /**
     * Handle incoming message
     */
    handleMessage(data) {
        try {
            const message = JSON.parse(data);
            console.log('WebSocket message received:', message);
            
            // Handle different message types
            switch (message.type) {
                case 'connection':
                    console.log('Connection confirmed:', message);
                    break;
                    
                case 'chat_response':
                    this.emit('chat_response', message);
                    break;
                    
                case 'analysis_complete':
                    this.emit('analysis_complete', message.results);
                    break;
                    
                case 'progress':
                    this.emit('progress', {
                        progress: message.progress,
                        message: message.message
                    });
                    break;
                    
                case 'typing':
                    this.emit('typing', message.is_typing);
                    break;
                    
                case 'error':
                    this.emit('error', message.message);
                    break;
                    
                case 'pong':
                    // Heartbeat response
                    break;
                    
                default:
                    this.emit('message', message);
            }
            
        } catch (error) {
            console.error('Failed to parse WebSocket message:', error);
        }
    }
    
    /**
     * Attempt to reconnect
     */
    attemptReconnect() {
        if (this.reconnectAttempts >= this.maxReconnectAttempts) {
            console.error('Max reconnection attempts reached');
            this.emit('reconnect_failed');
            return;
        }
        
        this.reconnectAttempts++;
        const delay = this.reconnectDelay * Math.pow(2, this.reconnectAttempts - 1);
        
        console.log(`Attempting to reconnect in ${delay}ms (attempt ${this.reconnectAttempts})`);
        
        setTimeout(() => {
            this.connect();
        }, delay);
    }
    
    /**
     * Flush message queue
     */
    flushMessageQueue() {
        while (this.messageQueue.length > 0) {
            const message = this.messageQueue.shift();
            if (this.ws.readyState === WebSocket.OPEN) {
                this.ws.send(message);
            }
        }
    }
    
    /**
     * Register event handler
     */
    on(event, handler) {
        if (!this.handlers[event]) {
            this.handlers[event] = [];
        }
        this.handlers[event].push(handler);
    }
    
    /**
     * Remove event handler
     */
    off(event, handler) {
        if (this.handlers[event]) {
            this.handlers[event] = this.handlers[event].filter(h => h !== handler);
        }
    }
    
    /**
     * Emit event
     */
    emit(event, data) {
        if (this.handlers[event]) {
            this.handlers[event].forEach(handler => {
                try {
                    handler(data);
                } catch (error) {
                    console.error(`Error in event handler for ${event}:`, error);
                }
            });
        }
    }
}

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = WebSocketManager;
}
