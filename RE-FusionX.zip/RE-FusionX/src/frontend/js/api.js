/**
 * API Client for RE-FusionX
 */

class APIClient {
    constructor(baseUrl) {
        // تحديد البورت الصحيح للـ backend
        this.baseUrl = baseUrl || `http://${window.location.hostname}:8000/api/v1`;
        this.headers = {
            'Content-Type': 'application/json',
            'X-Session-ID': localStorage.getItem('sessionId') || ''
        };
    }
    
    /**
     * Make API request
     */
    async request(endpoint, options = {}) {
        const url = `${this.baseUrl}${endpoint}`;
        
        const config = {
            ...options,
            headers: {
                ...this.headers,
                ...options.headers
            }
        };
        
        // Remove Content-Type for FormData to let browser set it with boundary
        if (options.body instanceof FormData) {
            delete config.headers['Content-Type'];
        }
        
        try {
            const response = await fetch(url, config);
            
            if (!response.ok) {
                const error = await response.json();
                console.error('API Error Details:', error);
                
                // Format error message properly
                let errorMessage = 'API request failed';
                if (error.detail) {
                    if (typeof error.detail === 'string') {
                        errorMessage = error.detail;
                    } else if (Array.isArray(error.detail)) {
                        errorMessage = error.detail.map(e => 
                            typeof e === 'string' ? e : JSON.stringify(e)
                        ).join(', ');
                    } else {
                        errorMessage = JSON.stringify(error.detail);
                    }
                }
                
                throw new Error(errorMessage);
            }
            
            return await response.json();
            
        } catch (error) {
            console.error('API Error:', error);
            throw error;
        }
    }
    
    /**
     * Check API health
     */
    async checkHealth() {
        return this.request('/health');
    }
    
    /**
     * Analyze property
     */
    async analyzeProperty(propertyData) {
        return this.request('/analysis/property', {
            method: 'POST',
            body: JSON.stringify(propertyData)
        });
    }
    
    /**
     * Analyze property with images
     */
    async analyzePropertyWithImages(propertyData, images) {
        const formData = new FormData();
        formData.append('property_data', JSON.stringify(propertyData));
        
        // Ensure images are File objects
        images.forEach((image, index) => {
            if (image instanceof File) {
                formData.append('images', image);
            } else {
                console.warn('Invalid image object at index', index, image);
            }
        });
        
        // Don't set Content-Type header for FormData - browser will set it with boundary
        return this.request('/analysis/property/images', {
            method: 'POST',
            body: formData,
            headers: {
                'X-Session-ID': this.headers['X-Session-ID']
                // Remove Content-Type - browser sets multipart/form-data automatically
            }
        });
    }
    
    /**
     * Send chat message
     */
    async sendChatMessage(message, context = null) {
        return this.request('/chat/message', {
            method: 'POST',
            body: JSON.stringify({
                message,
                context,
                include_sources: true
            })
        });
    }
    
    /**
     * Get chat history
     */
    async getChatHistory(limit = 50) {
        return this.request(`/chat/history?limit=${limit}`);
    }
    
    /**
     * Search properties
     */
    async searchProperties(criteria) {
        const params = new URLSearchParams(criteria);
        return this.request(`/properties/search?${params}`);
    }
    
    /**
     * Get property details
     */
    async getPropertyDetails(propertyId) {
        return this.request(`/properties/${propertyId}`);
    }
    
    /**
     * Find similar properties
     */
    async findSimilarProperties(propertyId, limit = 10) {
        return this.request(`/properties/similar/${propertyId}?limit=${limit}`);
    }
    
    /**
     * Compare properties
     */
    async compareProperties(propertyIds) {
        return this.request('/properties/compare', {
            method: 'POST',
            body: JSON.stringify(propertyIds)
        });
    }
    
    /**
     * Analyze market
     */
    async analyzeMarket(location, propertyType = null) {
        const formData = new FormData();
        formData.append('location', location);
        if (propertyType) {
            formData.append('property_type', propertyType);
        }
        
        return this.request('/analysis/market', {
            method: 'POST',
            body: formData,
            headers: {
                'X-Session-ID': this.headers['X-Session-ID']
            }
        });
    }
    
    /**
     * Analyze investment
     */
    async analyzeInvestment(budget, location, preferences = {}) {
        const formData = new FormData();
        formData.append('budget', budget);
        formData.append('location', location);
        formData.append('preferences', JSON.stringify(preferences));
        
        return this.request('/analysis/investment', {
            method: 'POST',
            body: formData,
            headers: {
                'X-Session-ID': this.headers['X-Session-ID']
            }
        });
    }
}

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = APIClient;
}
