// frontend/js/agents.js
/**
 * Agent Interface Module
 */

class AgentInterface {
    constructor(wsManager) {
        this.ws = wsManager;
        this.currentAgent = null;
        this.agents = {
            'property_valuator': {
                name: 'Dr. Ahmed',
                avatar: '👨‍⚕️',
                specialty: 'Property Valuation'
            },
            'market_analyst': {
                name: 'Sarah',
                avatar: '📊',
                specialty: 'Market Analysis'
            },
            'investment_advisor': {
                name: 'Michael',
                avatar: '💼',
                specialty: 'Investment Strategy'
            },
            'legal_consultant': {
                name: 'Lawyer Fatma',
                avatar: '⚖️',
                specialty: 'Legal Affairs'
            },
            'neighborhood_scout': {
                name: 'Ali',
                avatar: '🏘️',
                specialty: 'Neighborhood Expert'
            }
        };
    }
    
    showAgentProgress(agents) {
        // عرض الوكلاء أثناء العمل
        const html = `
            <div class="agents-working">
                <h4>🤖 AI Agents at Work</h4>
                <div class="agents-grid">
                    ${agents.map(agent => `
                        <div class="agent-card ${agent.status}">
                            <div class="agent-avatar">${this.agents[agent.name].avatar}</div>
                            <div class="agent-info">
                                <div class="agent-name">${this.agents[agent.name].name}</div>
                                <div class="agent-status">${agent.status}</div>
                                <div class="agent-progress">
                                    <div class="progress-bar" style="width: ${agent.progress}%"></div>
                                </div>
                            </div>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
        
        document.getElementById('agentsContainer').innerHTML = html;
    }
}
