/**
 * Property Analysis Module
 */

class AnalysisModule {
    constructor(containerId, apiClient) {
        this.container = document.getElementById(containerId);
        this.api = apiClient;
        this.uploadedImages = [];
        this.formData = {};
        
        this.init();
    }
    
    /**
     * Initialize analysis module
     */
    async init() {
        this.setupEventListeners();
        this.initializeImageUpload();
        // Setup location inputs immediately with hardcoded data
        this.setupLocationInputsDirectly();
    }
    
    /**
     * Setup event listeners
     */
    setupEventListeners() {
        // Form inputs
        document.querySelectorAll('.form-input').forEach(input => {
            input.addEventListener('change', () => {
                this.updateFormData();
            });
        });
        
        // Feature checkboxes
        document.querySelectorAll('.feature-checkbox').forEach(checkbox => {
            checkbox.addEventListener('change', () => {
                this.updateFeatures();
            });
        });
        
        // Location inputs will be set up after data loads
    }
    
    /**
     * Load location index (cities/districts/neighborhoods) from backend or local file
     */
    async loadLocationIndex() {
        try {
            // Try multiple sources for location data (prefer local file, then backend with correct port)
            let resp = null;

            // 1) Absolute path served by frontend server
            try {
                resp = await fetch('/data/cities_and_districts_data.json', { cache: 'no-store' });
            } catch (e) {
                console.log('Absolute frontend data not available, trying relative...');
            }

            // 2) Relative path (works when app is served from index root)
            if (!resp || !resp.ok) {
                try {
                    resp = await fetch('./data/cities_and_districts_data.json', { cache: 'no-store' });
                } catch (e) {
                    console.log('Relative frontend data not available, trying backend...');
                }
            }

            // 3) Backend API with correct base URL (port 8000), avoids 404 on port 3000
            if (!resp || !resp.ok) {
                try {
                    const apiBase = (window.app && window.app.config && window.app.config.apiUrl) ? window.app.config.apiUrl : null;
                    if (apiBase) {
                        const backendUrl = `${apiBase}/locations/data`;
                        resp = await fetch(backendUrl, { cache: 'no-store' });
                    }
                } catch (e) {
                    console.log('Backend API fetch failed');
                }
            }

            if (resp && resp.ok) {
                this.locationIndex = await resp.json();
                console.log('Location index loaded successfully:', Object.keys(this.locationIndex.cities || {}).length, 'cities');
                console.log('Available cities:', Object.keys(this.locationIndex.cities || {}));
                // Setup location inputs after data is loaded
                setTimeout(() => this.setupHierarchicalLocationInputs(), 100);
            } else {
                // Minimal fallback with major Turkish cities
                this.locationIndex = this.getMinimalLocationFallback();
                console.warn('Using minimal location fallback');
                console.log('Fallback cities:', Object.keys(this.locationIndex.cities || {}));
                // Setup location inputs after fallback data is set
                setTimeout(() => this.setupHierarchicalLocationInputs(), 100);
            }
        } catch (e) {
            console.error('Failed to load location index:', e);
            this.locationIndex = this.getMinimalLocationFallback();
        }
    }

    /**
     * Get minimal location fallback data
     */
    getMinimalLocationFallback() {
        return {
            cities: {
                "İstanbul": {
                    districts: ["Kadıköy", "Beşiktaş", "Şişli", "Beyoğlu", "Bakırköy", "Üsküdar", "Fatih", "Ataşehir", "Maltepe", "Kartal"]
                },
                "Ankara": {
                    districts: ["Çankaya", "Keçiören", "Yenimahalle", "Mamak", "Altındağ", "Etimesgut", "Sincan", "Pursaklar"]
                },
                "İzmir": {
                    districts: ["Konak", "Karşıyaka", "Bornova", "Buca", "Çiğli", "Gaziemir", "Balçova", "Narlıdere"]
                }
            },
            neighborhoods: {
                "İstanbul": {
                    "Kadıköy": ["Moda", "Fenerbahçe", "Göztepe", "Bostancı", "Suadiye"],
                    "Beşiktaş": ["Etiler", "Levent", "Bebek", "Ortaköy", "Arnavutköy"]
                },
                "Ankara": {
                    "Çankaya": ["Kızılay", "Bahçelievler", "Emek", "Ayrancı", "Gaziosmanpaşa"]
                },
                "İzmir": {
                    "Konak": ["Alsancak", "Güzelyalı", "Basmane", "Çankaya"]
                }
            }
        };
    }

    /**
     * Setup location inputs directly with hardcoded data
     */
    setupLocationInputsDirectly() {
        // Try multiple times to ensure DOM is ready
        let attempts = 0;
        const maxAttempts = 20;
        
        const trySetup = () => {
            attempts++;
            
            const cityInput = document.getElementById('cityInput');
            const districtInput = document.getElementById('districtInput');
            const neighborhoodInput = document.getElementById('neighborhoodInput');
            
            if (!cityInput || !districtInput || !neighborhoodInput) {
                if (attempts < maxAttempts) {
                    setTimeout(trySetup, 500);
                }
                return;
            }
            
            this.setupHierarchicalLocationInputs(cityInput, districtInput, neighborhoodInput);
        };
        
        // Start immediately and also try after a delay
        trySetup();
        setTimeout(trySetup, 1000);
        setTimeout(trySetup, 2000);
    }
    
    createLocationInputsManually() {
        // Fallback method - not needed in production
    }
    
    /**
     * Setup hierarchical city/district/neighborhood inputs with filtering
     */
    setupHierarchicalLocationInputs(cityInput, districtInput, neighborhoodInput) {
        // Load data from source
        
        if (!this.locationIndex) {
            this.loadLocationDataSync().then(() => {
                this.setupLocationEvents(cityInput, districtInput, neighborhoodInput);
            });
        } else {
            this.setupLocationEvents(cityInput, districtInput, neighborhoodInput);
        }
    }
    
    async loadLocationDataSync() {
        try {
            const resp = await fetch('/data/cities_and_districts_data.json');
            if (resp.ok) {
                this.locationIndex = await resp.json();
            } else {
                throw new Error('Failed to load data');
            }
        } catch (e) {
            // Fallback to minimal data
            this.locationIndex = this.getMinimalLocationFallback();
        }
    }
    
    setupLocationEvents(cityInput, districtInput, neighborhoodInput) {
        const cities = this.locationIndex.cities || {};
        const neighborhoods = this.locationIndex.neighborhoods || {};
        
        const showSuggestions = (input, suggestions, onSelect) => {
            let dropdown = input.parentNode.querySelector('.suggestions-dropdown');
            if (!dropdown) {
                dropdown = document.createElement('div');
                dropdown.className = 'suggestions-dropdown';
                dropdown.style.cssText = 'position:absolute;top:100%;left:0;right:0;background:white;border:1px solid #ddd;border-radius:4px;max-height:200px;overflow-y:auto;z-index:1000;display:none';
                input.parentNode.appendChild(dropdown);
            }
            
            if (suggestions.length === 0) {
                dropdown.style.display = 'none';
                return;
            }
            
            dropdown.innerHTML = suggestions.map(item => 
                `<div class="suggestion-item" style="padding:8px 12px;cursor:pointer;border-bottom:1px solid #eee">${item}</div>`
            ).join('');
            
            dropdown.style.display = 'block';
            
            dropdown.querySelectorAll('.suggestion-item').forEach(item => {
                item.addEventListener('click', () => {
                    onSelect(item.textContent);
                    dropdown.style.display = 'none';
                });
            });
        };

        const composeLocationHidden = () => {
            const parts = [];
            if (cityInput.value) parts.push(cityInput.value);
            if (districtInput.value) parts.push(districtInput.value);
            if (neighborhoodInput.value) parts.push(neighborhoodInput.value);
            document.getElementById('location').value = parts.join(' - ');
            this.updateFormData();
        };

        // City input - show all on focus, filter on input
        cityInput.addEventListener('focus', () => {
            const allCities = Object.keys(cities);
            showSuggestions(cityInput, allCities, (selectedCity) => {
                cityInput.value = selectedCity;
                districtInput.disabled = false;
                districtInput.value = '';
                districtInput.placeholder = `Select district in ${selectedCity}`;
                neighborhoodInput.disabled = true;
                neighborhoodInput.value = '';
                composeLocationHidden();
            });
        });
        
        cityInput.addEventListener('input', (e) => {
            const query = e.target.value.toLowerCase();
            if (query === '') {
                // Show all cities when input is empty
                const allCities = Object.keys(cities);
                showSuggestions(cityInput, allCities, (selectedCity) => {
                    cityInput.value = selectedCity;
                    districtInput.disabled = false;
                    districtInput.value = '';
                    districtInput.placeholder = `Select district in ${selectedCity}`;
                    neighborhoodInput.disabled = true;
                    neighborhoodInput.value = '';
                    composeLocationHidden();
                });
            } else {
                // Filter cities based on input
                const matches = Object.keys(cities).filter(city => 
                    city.toLowerCase().includes(query)
                );
                showSuggestions(cityInput, matches, (selectedCity) => {
                    cityInput.value = selectedCity;
                    districtInput.disabled = false;
                    districtInput.value = '';
                    districtInput.placeholder = `Select district in ${selectedCity}`;
                    neighborhoodInput.disabled = true;
                    neighborhoodInput.value = '';
                    composeLocationHidden();
                });
            }
        });

        // District input - show all on focus, filter on input
        districtInput.addEventListener('focus', () => {
            const selectedCity = cityInput.value;
            if (selectedCity && cities[selectedCity]) {
                const allDistricts = cities[selectedCity].districts || [];
                showSuggestions(districtInput, allDistricts, (selectedDistrict) => {
                    districtInput.value = selectedDistrict;
                    neighborhoodInput.disabled = false;
                    neighborhoodInput.value = '';
                    neighborhoodInput.placeholder = `Select neighborhood in ${selectedDistrict}`;
                    composeLocationHidden();
                });
            }
        });
        
        districtInput.addEventListener('input', (e) => {
            const selectedCity = cityInput.value;
            if (!selectedCity || !cities[selectedCity]) return;
            
            const query = e.target.value.toLowerCase();
            const allDistricts = cities[selectedCity].districts || [];
            
            if (query === '') {
                showSuggestions(districtInput, allDistricts, (selectedDistrict) => {
                    districtInput.value = selectedDistrict;
                    neighborhoodInput.disabled = false;
                    neighborhoodInput.value = '';
                    neighborhoodInput.placeholder = `Select neighborhood in ${selectedDistrict}`;
                    composeLocationHidden();
                });
            } else {
                const matches = allDistricts.filter(district => 
                    district.toLowerCase().includes(query)
                );
                showSuggestions(districtInput, matches, (selectedDistrict) => {
                    districtInput.value = selectedDistrict;
                    neighborhoodInput.disabled = false;
                    neighborhoodInput.value = '';
                    neighborhoodInput.placeholder = `Select neighborhood in ${selectedDistrict}`;
                    composeLocationHidden();
                });
            }
        });
        
        // Neighborhood input - show all on focus, filter on input
        neighborhoodInput.addEventListener('focus', () => {
            const selectedCity = cityInput.value;
            const selectedDistrict = districtInput.value;
            
            if (selectedCity && selectedDistrict && neighborhoods[selectedCity] && neighborhoods[selectedCity][selectedDistrict]) {
                const allNeighborhoods = neighborhoods[selectedCity][selectedDistrict];
                showSuggestions(neighborhoodInput, allNeighborhoods, (selectedNeighborhood) => {
                    neighborhoodInput.value = selectedNeighborhood;
                    composeLocationHidden();
                });
            }
        });
        
        neighborhoodInput.addEventListener('input', (e) => {
            const selectedCity = cityInput.value;
            const selectedDistrict = districtInput.value;
            if (!selectedCity || !selectedDistrict || !neighborhoods[selectedCity] || !neighborhoods[selectedCity][selectedDistrict]) return;
            
            const query = e.target.value.toLowerCase();
            const allNeighborhoods = neighborhoods[selectedCity][selectedDistrict];
            
            if (query === '') {
                showSuggestions(neighborhoodInput, allNeighborhoods, (selectedNeighborhood) => {
                    neighborhoodInput.value = selectedNeighborhood;
                    composeLocationHidden();
                });
            } else {
                const matches = allNeighborhoods.filter(neighborhood => 
                    neighborhood.toLowerCase().includes(query)
                );
                showSuggestions(neighborhoodInput, matches, (selectedNeighborhood) => {
                    neighborhoodInput.value = selectedNeighborhood;
                    composeLocationHidden();
                });
            }
        });
        
        // Location inputs setup complete
    }


    /**
     * Initialize image upload
     */
    initializeImageUpload() {
        const dropZone = document.getElementById('imageDropZone');
        const fileInput = document.getElementById('imageFileInput');
        
        if (!dropZone || !fileInput) return;
        
        // Check if already initialized
        if (dropZone.dataset.initialized) return;
        dropZone.dataset.initialized = 'true';
        
        // Click to upload
        dropZone.addEventListener('click', () => {
            fileInput.click();
        });
        
        // Drag and drop
        dropZone.addEventListener('dragover', (e) => {
            e.preventDefault();
            dropZone.classList.add('dragover');
        });
        
        dropZone.addEventListener('dragleave', () => {
            dropZone.classList.remove('dragover');
        });
        
        dropZone.addEventListener('drop', (e) => {
            e.preventDefault();
            dropZone.classList.remove('dragover');
            this.handleFiles(e.dataTransfer.files);
        });
        
        // File input change
        fileInput.addEventListener('change', (e) => {
            this.handleFiles(e.target.files);
            // Clear the input to allow selecting the same file again if needed
            e.target.value = '';
        });
    }
    
    /**
     * Handle file upload
     */
    handleFiles(files) {
        Array.from(files).forEach(file => {
            if (file.type.startsWith('image/')) {
                // Check if image already exists
                const existingImage = this.uploadedImages.find(img => 
                    img.name === file.name && img.size === file.size
                );
                
                if (!existingImage) {
                    this.processImage(file);
                }
            }
        });
    }
    
    /**
     * Process uploaded image
     */
    processImage(file) {
        const reader = new FileReader();
        
        reader.onload = (e) => {
            const imageData = {
                file: file,
                url: e.target.result,
                name: file.name,
                size: file.size
            };
            
            this.uploadedImages.push(imageData);
            this.displayImage(imageData);
        };
        
        reader.readAsDataURL(file);
    }
    
    /**
     * Display uploaded image
     */
    displayImage(imageData) {
        const container = document.getElementById('uploadedImagesContainer');
        if (!container) return;
        
        const imageDiv = document.createElement('div');
        imageDiv.className = 'uploaded-image';
        imageDiv.innerHTML = `
            <img src="${imageData.url}" alt="${imageData.name}">
            <div class="image-overlay">
                <button class="btn-remove" data-name="${imageData.name}">
                    <i class="fas fa-trash"></i>
                </button>
            </div>
            <div class="image-info">
                <span class="image-name">${imageData.name}</span>
                <span class="image-size">${this.formatFileSize(imageData.size)}</span>
            </div>
        `;
        
        // Add remove handler
        imageDiv.querySelector('.btn-remove').addEventListener('click', (e) => {
            e.stopPropagation(); // Prevent event bubbling
            this.removeImage(e.target.closest('.btn-remove').dataset.name);
        });
        
        container.appendChild(imageDiv);
        
        // Update count
        this.updateImageCount();
    }
    
    /**
     * Remove uploaded image
     */
    removeImage(fileName) {
        this.uploadedImages = this.uploadedImages.filter(img => img.name !== fileName);
        
        const container = document.getElementById('uploadedImagesContainer');
        const images = container.querySelectorAll('.uploaded-image');
        
        images.forEach(div => {
            const nameEl = div.querySelector('.image-name');
            if (nameEl && nameEl.textContent === fileName) {
                div.remove();
            }
        });
        
        this.updateImageCount();
    }
    
    /**
     * Update image count
     */
    updateImageCount() {
        const countEl = document.getElementById('imageCount');
        if (countEl) {
            countEl.textContent = `${this.uploadedImages.length} image(s) uploaded`;
        }
    }
    
    /**
     * Get form data
     */
    getFormData() {
        // Get individual location components
        const city = document.getElementById('cityInput')?.value || '';
        const district = document.getElementById('districtInput')?.value || '';
        const neighborhood = document.getElementById('neighborhoodInput')?.value || '';
        
        // Compose full location for backward compatibility
        let fullLocation = '';
        if (city) fullLocation += city;
        if (district) fullLocation += (fullLocation ? ' - ' : '') + district;
        if (neighborhood) fullLocation += (fullLocation ? ' - ' : '') + neighborhood;
        
        const data = {
            // Basic Information - Enhanced location data
            location: fullLocation,
            city: city,
            district: district,
            neighborhood: neighborhood,
            property_type: document.getElementById('propertyType')?.value || '',
            rooms: document.getElementById('roomCount')?.value || '',
            size_net: parseFloat(document.getElementById('sizeNet')?.value) || null,
            size_gross: parseFloat(document.getElementById('sizeGross')?.value) || null,
            price: parseFloat(document.getElementById('price')?.value) || null,
            
            // Building Details
            floor: document.getElementById('floor')?.value || '',
            total_floors: parseInt(document.getElementById('totalFloors')?.value) || null,
            building_age: document.getElementById('buildingAge')?.value || '',
            bathrooms: parseInt(document.getElementById('bathrooms')?.value) || null,
            
            // Additional Details
            heating: document.getElementById('heating')?.value || '',
            usage_status: document.getElementById('usageStatus')?.value || '',
            deed_status: document.getElementById('deedStatus')?.value || '',
            furnished: document.getElementById('furnished')?.value || '',
            in_site: document.getElementById('inSite')?.value || '',
            credit_eligible: document.getElementById('creditEligible')?.value || '',
            
            // Features
            features: this.collectFeatures(),
            
            // Images (convert to file objects for API)
            images: this.uploadedImages.map(img => img.file)
        };
        
        // Remove null values
        Object.keys(data).forEach(key => {
            if (data[key] === null || data[key] === '') {
                delete data[key];
            }
        });
        
        return data;
    }
    
    /**
     * Collect selected features
     */
    collectFeatures() {
        const features = {
            interior: [],
            exterior: [],
            location: []
        };
        
        document.querySelectorAll('.feature-checkbox:checked').forEach(checkbox => {
            const category = checkbox.dataset.category;
            const feature = checkbox.dataset.feature;
            
            if (features[category]) {
                features[category].push(feature);
            }
        });
        
        return features;
    }
    
    /**
     * Update form data
     */
    updateFormData() {
        this.formData = this.getFormData();
        this.updatePriceEstimate();
    }
    
    /**
     * Update features
     */
    updateFeatures() {
        const features = this.collectFeatures();
        const totalFeatures = 
            features.interior.length + 
            features.exterior.length + 
            features.location.length;
        
        const countEl = document.getElementById('selectedFeaturesCount');
        if (countEl) {
            countEl.textContent = `${totalFeatures} features selected`;
        }
    }
    
    /**
     * Update price estimate (live preview)
     */
    async updatePriceEstimate() {
        const data = this.getFormData();
        
        // Check if we have minimum required data
        if (!data.location || !data.size_net) return;
        
        const estimateEl = document.getElementById('liveEstimate');
        if (!estimateEl) return;
        
        try {
            // Show loading
            estimateEl.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Calculating...';
            
            // Quick estimate based on local calculation
            const estimate = this.calculateQuickEstimate(data);
            
            estimateEl.innerHTML = `
                <span class="estimate-label">Quick Estimate:</span>
                <span class="estimate-value">${this.formatCurrency(estimate)}</span>
            `;
            
        } catch (error) {
            console.error('Failed to update estimate:', error);
            estimateEl.innerHTML = '';
        }
    }
    
    /**
     * Calculate quick estimate
     */
    calculateQuickEstimate(data) {
        // Base price per m² by city (simplified)
        const basePrices = {
            'Istanbul': 25000,
            'Ankara': 15000,
            'Izmir': 18000,
            'Antalya': 20000,
            'Bursa': 12000,
            'default': 10000
        };
        
        // Get city from location
        const city = data.location.split(' - ')[0] || 'default';
        const basePrice = basePrices[city] || basePrices['default'];
        
        // Calculate base value
        let estimate = basePrice * (data.size_net || 100);
        
        // Age adjustment
        const ageMultipliers = {
            '0': 1.2,
            '1-4': 1.1,
            '5-10': 1.0,
            '11-15': 0.9,
            '16-20': 0.85,
            '21-25': 0.8,
            '26-30': 0.75,
            '31+': 0.7
        };
        
        if (data.building_age && ageMultipliers[data.building_age]) {
            estimate *= ageMultipliers[data.building_age];
        }
        
        // Floor adjustment
        if (data.floor) {
            if (data.floor.includes('Zemin') || data.floor.includes('Bahçe')) {
                estimate *= 0.9;
            } else if (parseInt(data.floor) > 5) {
                estimate *= 1.05;
            }
        }
        
        // In-site adjustment
        if (data.in_site === 'Evet') {
            estimate *= 1.15;
        }
        
        // Features adjustment
        const featureCount = 
            (data.features?.interior?.length || 0) + 
            (data.features?.exterior?.length || 0);
        
        if (featureCount > 5) {
            estimate *= 1.1;
        }
        
        return Math.round(estimate);
    }
    
    /**
     * Validate form
     */
    validateForm(data) {
        const errors = [];
        
        // Required fields
        if (!data.location || data.location.trim() === '') {
            errors.push('Location is required (City and District minimum)');
        }
        
        // Check if we have at least city and district
        const locationParts = (data.location || '').split(' - ');
        if (locationParts.length < 2) {
            errors.push('Please select both City and District');
        }
        
        if (!data.property_type) {
            errors.push('Property type is required');
        }
        
        if (!data.size_net && !data.size_gross) {
            errors.push('Property size is required (Net or Gross)');
        }
        
        // Validate numeric fields
        if (data.size_net && data.size_net <= 0) {
            errors.push('Net size must be positive');
        }
        
        if (data.size_gross && data.size_gross <= 0) {
            errors.push('Gross size must be positive');
        }
        
        if (data.price && data.price <= 0) {
            errors.push('Price must be positive');
        }
        
        // Show errors
        if (errors.length > 0) {
            this.showValidationErrors(errors);
            return false;
        }
        
        return true;
    }
    
    /**
     * Show validation errors
     */
    showValidationErrors(errors) {
        const errorHtml = `
            <div class="alert alert-danger">
                <h5>Please fix the following errors:</h5>
                <ul>
                    ${errors.map(e => `<li>${e}</li>`).join('')}
                </ul>
            </div>
        `;
        
        // Show in modal or toast
        window.app.showError(errors.join('\n'));
    }
    
    /**
     * Handle location search
     */
    async handleLocationSearch(query) {
        if (query.length < 3) return;
        
        const suggestionsEl = document.getElementById('locationSuggestions');
        if (!suggestionsEl) return;
        
        // Turkish cities and districts (simplified)
        const locations = [
            'Istanbul - Kadıköy',
            'Istanbul - Beşiktaş',
            'Istanbul - Şişli',
            'Istanbul - Bakırköy',
            'Istanbul - Üsküdar',
            'Ankara - Çankaya',
            'Ankara - Keçiören',
            'Ankara - Mamak',
            'Izmir - Konak',
            'Izmir - Karşıyaka',
            'Izmir - Bornova',
            'Antalya - Muratpaşa',
            'Antalya - Konyaaltı',
            'Antalya - Kepez',
            'Bursa - Nilüfer',
            'Bursa - Osmangazi',
            'Bursa - Yıldırım'
        ];
        
        const filtered = locations.filter(loc => 
            loc.toLowerCase().includes(query.toLowerCase())
        );
        
        if (filtered.length > 0) {
            suggestionsEl.innerHTML = filtered.map(loc => `
                <div class="suggestion-item" data-value="${loc}">
                    <i class="fas fa-map-marker-alt"></i> ${loc}
                </div>
            `).join('');
            
            suggestionsEl.style.display = 'block';
            
            // Add click handlers
            suggestionsEl.querySelectorAll('.suggestion-item').forEach(item => {
                item.addEventListener('click', () => {
                    document.getElementById('location').value = item.dataset.value;
                    suggestionsEl.style.display = 'none';
                    this.updateFormData();
                });
            });
        } else {
            suggestionsEl.style.display = 'none';
        }
    }
    
    /**
     * Reset form
     */
    resetForm() {
        // Reset all inputs
        document.querySelectorAll('.form-input').forEach(input => {
            if (input.type === 'checkbox') {
                input.checked = false;
            } else {
                input.value = '';
            }
        });
        
        // Clear images
        this.uploadedImages = [];
        const container = document.getElementById('uploadedImagesContainer');
        if (container) {
            container.innerHTML = '';
        }
        
        // Reset counts
        this.updateImageCount();
        this.updateFeatures();
        
        // Clear form data
        this.formData = {};
        
        // Clear estimate
        const estimateEl = document.getElementById('liveEstimate');
        if (estimateEl) {
            estimateEl.innerHTML = '';
        }
    }
    
    /**
     * Format file size
     */
    formatFileSize(bytes) {
        if (bytes === 0) return '0 Bytes';
        
        const k = 1024;
        const sizes = ['Bytes', 'KB', 'MB', 'GB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        
        return Math.round(bytes / Math.pow(k, i) * 100) / 100 + ' ' + sizes[i];
    }
    
    /**
     * Format currency
     */
    formatCurrency(amount) {
        return new Intl.NumberFormat('tr-TR', {
            style: 'currency',
            currency: 'TRY',
            minimumFractionDigits: 0,
            maximumFractionDigits: 0
        }).format(amount);
    }
}
