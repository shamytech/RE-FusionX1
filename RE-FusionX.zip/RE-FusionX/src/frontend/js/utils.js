
/**
 * Chat Interface Module
 */

class ChatInterface {
    constructor(containerId, apiClient, wsManager) {
        this.containerId = containerId;
        this.container = document.getElementById(containerId);
        this.api = apiClient;
        this.ws = wsManager;
        this.messages = [];
        this.isTyping = false;
        this.attachedImages = [];
        
        if (!this.container) {
            console.error(`Chat container with ID '${containerId}' not found`);
            // Try to find the container again after a short delay
            setTimeout(() => {
                this.container = document.getElementById(this.containerId);
                if (this.container) {
                    this.init();
                } else {
                    console.error(`Failed to find chat container after retry`);
                }
            }, 100);
        } else {
            this.init();
        }
    }
    
    /**
     * Initialize chat interface
     */
    init() {
        // Ensure container exists
        if (!this.container) {
            console.error('Chat container not found');
            return;
        }

        // Initialize chat UI if it doesn't exist
        if (!this.container.querySelector('.chat-messages')) {
            this.container.innerHTML = `
                <div class="chat-header">
                    <div class="chat-title">
                        <i class="fas fa-robot"></i>
                        <span>AI Assistant</span>
                        <span class="status-indicator online"></span>
                    </div>
                    
                    <div class="chat-actions">
                        <button class="icon-btn" onclick="app.modules.chat.clearChat()" title="Clear Chat">
                            <i class="fas fa-trash"></i>
                        </button>
                        <button class="icon-btn" onclick="app.modules.chat.exportChat()" title="Export Chat">
                            <i class="fas fa-download"></i>
                        </button>
                    </div>
                </div>
                
                <div class="chat-messages" id="chatMessages"></div>
                
                <div class="chat-input-area">
                    <div class="attached-images-container" id="attachedImagesContainer" style="display: none;"></div>
                    
                    <div class="quick-actions-bar">
                        <button class="quick-action" data-action="market-trends">
                            <i class="fas fa-chart-line"></i> Market Trends
                        </button>
                        <button class="quick-action" data-action="investment-tips">
                            <i class="fas fa-lightbulb"></i> Investment Tips
                        </button>
                        <button class="quick-action" data-action="legal-requirements">
                            <i class="fas fa-gavel"></i> Legal Info
                        </button>
                        <button class="quick-action" data-action="mortgage-info">
                            <i class="fas fa-percentage"></i> Mortgage
                        </button>
                    </div>
                    
                    <div class="input-container">
                        <textarea id="chatInput" 
                                  class="chat-input" 
                                  placeholder="Type your message or question..."
                                  rows="1"></textarea>
                        
                        <div class="input-actions">
                            <button id="attachImageBtn" class="attach-btn" title="Attach Image">
                                <i class="fas fa-paperclip"></i>
                            </button>
                            <button id="sendMessageBtn" class="send-btn">
                                <i class="fas fa-paper-plane"></i>
                            </button>
                        </div>
                    </div>
                </div>
            `;
        }

        this.setupEventListeners();
        this.setupWebSocketHandlers();
        this.loadWelcomeMessage();
    }
    
    /**
     * Setup event listeners
     */
    setupEventListeners() {
        // Send button
        const sendBtn = document.getElementById('sendMessageBtn');
        if (sendBtn) {
            sendBtn.addEventListener('click', () => this.sendMessage());
        }
        
        // Input field
        const input = document.getElementById('chatInput');
        if (input) {
            // Auto-resize
            input.addEventListener('input', (e) => {
                this.autoResizeInput(e.target);
            });
            
            // Enter to send
            input.addEventListener('keydown', (e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    this.sendMessage();
                }
            });
        }
        
        // Attach image button
        const attachBtn = document.getElementById('attachImageBtn');
        if (attachBtn) {
            attachBtn.addEventListener('click', () => this.attachImage());
        }
        
        // Quick actions - استخدام event delegation
        this.container.addEventListener('click', (e) => {
            if (e.target.closest('.quick-action')) {
                const btn = e.target.closest('.quick-action');
                this.handleQuickAction(btn.dataset.action);
            }
        });
    }
    
    /**
     * Setup WebSocket handlers
     */
    setupWebSocketHandlers() {
        this.ws.on('chat_response', (data) => {
            this.hideTypingIndicator();
            this.addMessage(data.content, 'assistant', {
                sources: data.sources,
                confidence: data.confidence
            });
        });
        
        this.ws.on('typing', (isTyping) => {
            if (isTyping) {
                this.showTypingIndicator();
            } else {
                this.hideTypingIndicator();
            }
        });
    }
    
    /**
     * Load welcome message
     */
    loadWelcomeMessage() {
        const welcomeMessage = `
            👋 Welcome to RE-FusionX!
            
            I'm your AI-powered real estate assistant specialized in the Turkish property market. 
            I can help you with:
            
            • Property valuation and price predictions
            • Market analysis and investment advice
            • Visual property assessment from images
            • Neighborhood insights and comparisons
            • Legal and financial guidance
            
            How can I assist you today?
        `;
        
        this.addMessage(welcomeMessage, 'assistant');
    }
    
    /**
     * Send message
     */
    async sendMessage() {
        const input = document.getElementById('chatInput');
        if (!input) return;
        
        const message = input.value.trim();
        
        if (!message && this.attachedImages.length === 0) return;
        
        // Add user message
        this.addMessage(message, 'user', { images: this.attachedImages });
        
        // Clear input
        input.value = '';
        this.autoResizeInput(input);
        
        // Clear attached images
        this.clearAttachedImages();
        
        // Show typing indicator
        this.showTypingIndicator();
        
        try {
            // Send via WebSocket if connected
            if (this.ws.isConnected) {
                this.ws.send('chat', {
                    content: message,
                    images: this.attachedImages,
                    context: this.getContext()
                });
            } else {
                // Fallback to API
                const response = await this.api.sendChatMessage(message, this.getContext());
                this.hideTypingIndicator();
                this.addMessage(response.response, 'assistant', {
                    sources: response.sources,
                    confidence: response.confidence
                });
            }
        } catch (error) {
            this.hideTypingIndicator();
            this.addMessage('Sorry, I encountered an error. Please try again.', 'assistant');
            console.error('Failed to send message:', error);
        }
    }
    
    /**
     * Add message to chat
     */
    addMessage(content, sender, metadata = {}) {
        // Get messages container - البحث عن العنصر الصحيح
        let messagesContainer = document.getElementById('chatMessages') || 
                                this.container?.querySelector('.chat-messages');
        
        if (!messagesContainer) {
            console.error('Messages container not found, reinitializing...');
            this.init();
            messagesContainer = document.getElementById('chatMessages') || 
                               this.container?.querySelector('.chat-messages');
            
            if (!messagesContainer) {
                console.error('Failed to find messages container after reinit');
                return;
            }
        }

        // Create message element
        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${sender}`;
        messageDiv.dataset.timestamp = new Date().toISOString();
        
        // Create message wrapper
        const messageWrapper = document.createElement('div');
        messageWrapper.className = 'message-wrapper';
        
        // Create message bubble
        const bubble = document.createElement('div');
        bubble.className = 'message-bubble';
        
        // Process content based on type
        if (typeof content === 'string') {
            bubble.innerHTML = this.formatMessage(content);
        } else {
            bubble.innerHTML = content;
        }
        
        // Add images if present
        if (metadata.images && metadata.images.length > 0) {
            const imagesDiv = document.createElement('div');
            imagesDiv.className = 'message-images';
            
            metadata.images.forEach(img => {
                const imgEl = document.createElement('img');
                imgEl.src = img;
                imgEl.alt = 'Attached image';
                imgEl.onclick = () => this.showImageModal(img);
                imagesDiv.appendChild(imgEl);
            });
            
            bubble.appendChild(imagesDiv);
        }
        
        // Add sources if present
        if (metadata.sources && metadata.sources.length > 0) {
            const sourcesDiv = document.createElement('div');
            sourcesDiv.className = 'message-sources';
            sourcesDiv.innerHTML = `
                <div class="sources-header">
                    <i class="fas fa-info-circle"></i> Sources
                </div>
                <ul>
                    ${metadata.sources.map(s => `<li>${s}</li>`).join('')}
                </ul>
            `;
            bubble.appendChild(sourcesDiv);
        }
        
        // Add confidence indicator
        if (metadata.confidence) {
            const confidenceDiv = document.createElement('div');
            confidenceDiv.className = 'confidence-indicator';
            confidenceDiv.innerHTML = `
                <span>Confidence: ${(metadata.confidence * 100).toFixed(1)}%</span>
                <div class="confidence-bar">
                    <div class="confidence-fill" style="width: ${metadata.confidence * 100}%"></div>
                </div>
            `;
            bubble.appendChild(confidenceDiv);
        }
        
        messageWrapper.appendChild(bubble);
        
        // Add metadata
        const metaDiv = document.createElement('div');
        metaDiv.className = 'message-meta';
        metaDiv.innerHTML = `
            <i class="fas fa-${sender === 'user' ? 'user' : 'robot'}"></i>
            <span>${sender === 'user' ? 'You' : 'AI Assistant'}</span>
            <span>•</span>
            <span>${this.formatTime(new Date())}</span>
        `;
        messageWrapper.appendChild(metaDiv);
        
        messageDiv.appendChild(messageWrapper);
        
        // Add to container
        messagesContainer.appendChild(messageDiv);
        
        // Scroll to bottom
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
        
        // Store message
        this.messages.push({
            content,
            sender,
            metadata,
            timestamp: new Date().toISOString()
        });
        
        // Save to localStorage
        this.saveHistory();
    }
    
    /**
     * Show typing indicator
     */
    showTypingIndicator() {
        if (this.isTyping) return;
        
        this.isTyping = true;
        
        // Get messages container - البحث عن العنصر الصحيح
        const messagesContainer = document.getElementById('chatMessages') || 
                                 this.container?.querySelector('.chat-messages');
        
        if (!messagesContainer) {
            console.error('Messages container not found for typing indicator');
            return;
        }
        
        const typingDiv = document.createElement('div');
        typingDiv.id = 'typingIndicator';
        typingDiv.className = 'message assistant';
        typingDiv.innerHTML = `
            <div class="typing-indicator">
                <span class="typing-dot"></span>
                <span class="typing-dot"></span>
                <span class="typing-dot"></span>
            </div>
        `;
        
        messagesContainer.appendChild(typingDiv);
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
    }
    
    /**
     * Hide typing indicator
     */
    hideTypingIndicator() {
        this.isTyping = false;
        const indicator = document.getElementById('typingIndicator');
        if (indicator) {
            indicator.remove();
        }
    }
        
    /**
     * Format message content
     */
    formatMessage(content) {
        // Convert markdown to HTML
        content = content
            .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
            .replace(/\*(.*?)\*/g, '<em>$1</em>')
            .replace(/\n/g, '<br>')
            .replace(/```(.*?)```/gs, '<pre><code>$1</code></pre>')
            .replace(/`(.*?)`/g, '<code>$1</code>');
        
        // Convert URLs to links
        content = content.replace(
            /(https?:\/\/[^\s]+)/g,
            '<a href="$1" target="_blank" rel="noopener">$1</a>'
        );
        
        return content;
    }
    
    /**
     * Handle quick actions
     */
    handleQuickAction(action) {
        const actions = {
            'market-trends': 'What are the current real estate market trends in Turkey?',
            'investment-tips': 'What should I consider when investing in Turkish real estate?',
            'legal-requirements': 'What are the legal requirements for buying property in Turkey?',
            'mortgage-info': 'How does mortgage financing work in Turkey?',
            'best-locations': 'Which locations in Turkey offer the best investment opportunities?'
        };
        
        const message = actions[action];
        if (message) {
            const input = document.getElementById('chatInput');
            if (input) {
                input.value = message;
                this.sendMessage();
            }
        }
    }
    
    /**
     * Attach image
     */
    attachImage() {
        const input = document.createElement('input');
        input.type = 'file';
        input.accept = 'image/*';
        input.multiple = true;
        
        input.onchange = (e) => {
            const files = Array.from(e.target.files);
            files.forEach(file => {
                this.processImageFile(file);
            });
        };
        
        input.click();
    }
    
    /**
     * Process image file
     */
    processImageFile(file) {
        const reader = new FileReader();
        
        reader.onload = (e) => {
            this.attachedImages.push(e.target.result);
            this.displayAttachedImage(e.target.result, file.name);
        };
        
        reader.readAsDataURL(file);
    }
    
    /**
     * Display attached image
     */
    displayAttachedImage(src, name) {
        const container = document.getElementById('attachedImagesContainer');
        if (!container) return;
        
        const imageDiv = document.createElement('div');
        imageDiv.className = 'attached-image';
        imageDiv.innerHTML = `
            <img src="${src}" alt="${name}">
            <button class="remove-btn" onclick="app.modules.chat.removeAttachedImage('${src}')">
                <i class="fas fa-times"></i>
            </button>
        `;
        
        container.appendChild(imageDiv);
        container.style.display = 'flex';
    }
    
    /**
     * Remove attached image
     */
    removeAttachedImage(src) {
        this.attachedImages = this.attachedImages.filter(img => img !== src);
        
        const container = document.getElementById('attachedImagesContainer');
        const images = container.querySelectorAll('.attached-image');
        
        images.forEach(div => {
            const img = div.querySelector('img');
            if (img.src === src) {
                div.remove();
            }
        });
        
        if (this.attachedImages.length === 0) {
            container.style.display = 'none';
        }
    }
    
    /**
     * Clear attached images
     */
    clearAttachedImages() {
        this.attachedImages = [];
        const container = document.getElementById('attachedImagesContainer');
        if (container) {
            container.innerHTML = '';
            container.style.display = 'none';
        }
    }
    
    /**
     * Auto-resize input
     */
    autoResizeInput(element) {
        element.style.height = 'auto';
        element.style.height = Math.min(element.scrollHeight, 120) + 'px';
    }
    
    /**
     * Get context for message
     */
    getContext() {
        return {
            currentProperty: window.app?.state?.currentProperty || null,
            recentMessages: this.messages.slice(-5)
        };
    }
    
    /**
     * Save chat history
     */
    saveHistory() {
        try {
            const history = this.messages.slice(-100); // Keep last 100 messages
            localStorage.setItem('chatHistory', JSON.stringify(history));
        } catch (e) {
            console.warn('Failed to save chat history:', e);
        }
    }
    
    /**
     * Load chat history
     */
    loadHistory(history) {
        history.forEach(msg => {
            this.addMessage(msg.content, msg.sender, msg.metadata);
        });
    }
    
    /**
     * Clear chat
     */
    clearChat() {
        if (confirm('Are you sure you want to clear the chat history?')) {
            this.messages = [];
            const messagesContainer = document.getElementById('chatMessages') || 
                                     this.container?.querySelector('.chat-messages');
            if (messagesContainer) {
                messagesContainer.innerHTML = '';
            }
            this.loadWelcomeMessage();
            localStorage.removeItem('chatHistory');
        }
    }
    
    /**
     * Export chat
     */
    exportChat() {
        const content = this.messages.map(msg => {
            const sender = msg.sender === 'user' ? 'You' : 'AI Assistant';
            const time = new Date(msg.timestamp).toLocaleString();
            return `[${time}] ${sender}: ${msg.content}`;
        }).join('\n\n');
        
        const blob = new Blob([content], { type: 'text/plain' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `chat-export-${new Date().toISOString().split('T')[0]}.txt`;
        a.click();
        URL.revokeObjectURL(url);
    }
    
    /**
     * Show image modal
     */
    showImageModal(src) {
        const modal = document.createElement('div');
        modal.className = 'image-modal';
        modal.innerHTML = `
            <div class="modal-content">
                <span class="close-btn" onclick="this.parentElement.parentElement.remove()">
                    <i class="fas fa-times"></i>
                </span>
                <img src="${src}" alt="Full size image">
            </div>
        `;
        
        document.body.appendChild(modal);
        
        modal.onclick = (e) => {
            if (e.target === modal) {
                modal.remove();
            }
        };
    }
    
    /**
     * Format time
     */
    formatTime(date) {
        return date.toLocaleTimeString('en-US', {
            hour: '2-digit',
            minute: '2-digit'
        });
    }
    
    /**
     * Format currency
     */
    formatCurrency(amount) {
        return new Intl.NumberFormat('tr-TR', {
            style: 'currency',
            currency: 'TRY',
            minimumFractionDigits: 0,
            maximumFractionDigits: 0
        }).format(amount);
    }
    
    /**
     * Add analysis message
     */
    addAnalysisMessage(propertyData, results) {
        // Analysis results are now shown only in the modal dashboard
        // No longer displaying in chat to avoid duplication
        return;
    }
    
    /**
     * Format analysis results
     */
    formatAnalysisResults(propertyData, results) {
        let html = `
            <div class="analysis-message">
                <div class="analysis-header">
                    <h4>📊 Property Analysis Complete</h4>
                </div>
        `;
        
        // Only show old analysis format if Qwen analysis is NOT available
        if (!results.qwen_analysis) {
            // Price Estimation
            if (results.price_estimation) {
                html += `
                    <div class="analysis-section">
                        <h5>💰 Price Estimation</h5>
                        <div class="price-display">
                            <div class="estimated-price">
                                ${this.formatCurrency(results.price_estimation.estimated_price)}
                            </div>
                            <div class="price-range">
                                Range: ${this.formatCurrency(results.price_estimation.price_range.min)} - 
                                ${this.formatCurrency(results.price_estimation.price_range.max)}
                            </div>
                            <div class="confidence">
                                Confidence: ${(results.price_estimation.confidence * 100).toFixed(1)}%
                            </div>
                        </div>
                    </div>
                `;
            }
            
            // Market Analysis
            if (results.market_analysis) {
                html += `
                    <div class="analysis-section">
                        <h5>📈 Market Analysis</h5>
                        <ul>
                            <li>Market Position: <strong>${results.market_analysis.market_position}</strong></li>
                            <li>Demand Level: <strong>${results.market_analysis.demand_level}</strong></li>
                            <li>Supply Level: <strong>${results.market_analysis.supply_level}</strong></li>
                            <li>Growth Forecast: <strong>${results.market_analysis.growth_forecast}%</strong></li>
                        </ul>
                    </div>
                `;
            }
            
            // Investment Analysis
            if (results.investment_analysis) {
                html += `
                    <div class="analysis-section">
                        <h5>💎 Investment Analysis</h5>
                        <div class="metrics-grid">
                            <div class="metric">
                                <span class="metric-value">${results.investment_analysis.investment_score}/10</span>
                                <span class="metric-label">Investment Score</span>
                            </div>
                            <div class="metric">
                                <span class="metric-value">${results.investment_analysis.roi_potential}</span>
                                <span class="metric-label">ROI Potential</span>
                            </div>
                            <div class="metric">
                                <span class="metric-value">${results.investment_analysis.rental_yield}%</span>
                                <span class="metric-label">Rental Yield</span>
                            </div>
                        </div>
                    </div>
                `;
            }
        }
        
        // Enhanced Data Summary Section (NEW - Show structured data from backend)
        html += this.formatEnhancedDataSummary(results);
        
        // Qwen AI Analysis Section (ENHANCED - Always show if available)
        if (results.qwen_analysis) {
            // Use ChatInterface for enhanced formatting if available
            if (window.ChatInterface) {
                try {
                    const chatInterface = new window.ChatInterface();
                    const enhancedQwenHtml = chatInterface.formatQwenAnalysis(results.qwen_analysis);
                    html += `
                        <div class="analysis-section qwen-section">
                            <div class="section-header">
                                <h5><i class="fas fa-brain"></i> AI Expert Analysis</h5>
                            </div>
                            <div class="qwen-analysis-content">
                                ${enhancedQwenHtml}
                            </div>
                        </div>
                    `;
                } catch (error) {
                    console.error('Error formatting Qwen analysis:', error);
                    // Fallback to simple display
                    html += `
                        <div class="analysis-section qwen-section">
                            <div class="section-header">
                                <h5><i class="fas fa-brain"></i> AI Expert Analysis</h5>
                            </div>
                            <div class="qwen-analysis-content">
                                <pre style="white-space: pre-wrap; font-family: inherit;">${results.qwen_analysis}</pre>
                            </div>
                        </div>
                    `;
                }
            } else {
                // Simple fallback if ChatInterface not available
                html += `
                    <div class="analysis-section qwen-section">
                        <div class="section-header">
                            <h5><i class="fas fa-brain"></i> AI Expert Analysis</h5>
                        </div>
                        <div class="qwen-analysis-content">
                            <pre style="white-space: pre-wrap; font-family: inherit; line-height: 1.6;">${results.qwen_analysis}</pre>
                        </div>
                    </div>
                `;
            }
        }

        // Recommendations (only show if Qwen analysis is NOT available)
        if (!results.qwen_analysis && results.recommendations && results.recommendations.length > 0) {
            html += `
                <div class="analysis-section">
                    <h5>💡 Recommendations</h5>
                    <ul>
                        ${results.recommendations.map(r => `<li>${r}</li>`).join('')}
                    </ul>
                </div>
            `;
        }
        
        html += `</div>`;
        
        return html;
    }
    
    /**
     * Format Enhanced Data Summary - NEW METHOD
     * Displays structured backend data in organized sections
     */
    formatEnhancedDataSummary(results) {
        if (!results) return '';
        
        let html = `
            <div class="enhanced-data-summary">
                <div class="summary-header">
                    <h5><i class="fas fa-chart-area"></i> Comprehensive Analysis Dashboard</h5>
                    <div class="analysis-meta">
                        <span class="analysis-id">${results.analysis_id || 'N/A'}</span>
                        <span class="data-sources">${results.data_sources ? results.data_sources.join(', ') : 'N/A'}</span>
                    </div>
                </div>
        `;
        
        // Price Analysis Card
        if (results.price_estimation) {
            const pe = results.price_estimation;
            html += `
                <div class="data-card price-card">
                    <div class="card-header">
                        <h6><i class="fas fa-dollar-sign"></i> Price Analysis</h6>
                        <div class="confidence-badge confidence-${this.getConfidenceLevel(pe.confidence)}">
                            ${Math.round(pe.confidence * 100)}% Confidence
                        </div>
                    </div>
                    <div class="card-content">
                        <div class="price-main">
                            <div class="estimated-price-large">
                                ${this.formatCurrency(pe.estimated_price)}
                            </div>
                            <div class="price-range-detailed">
                                Range: ${this.formatCurrency(pe.price_range.min)} - ${this.formatCurrency(pe.price_range.max)}
                            </div>
                        </div>
                        ${pe.factors && pe.factors.length > 0 ? `
                            <div class="price-factors">
                                <h7>Key Factors:</h7>
                                <div class="factors-list">
                                    ${pe.factors.map(factor => `
                                        <div class="factor-item">
                                            <div class="factor-name">${factor.factor}</div>
                                            <div class="factor-impact">${factor.impact}% impact</div>
                                            <div class="factor-desc">${factor.description}</div>
                                        </div>
                                    `).join('')}
                                </div>
                            </div>
                        ` : ''}
                        ${pe.methodology ? `
                            <div class="methodology">
                                <small><i class="fas fa-cog"></i> ${pe.methodology}</small>
                            </div>
                        ` : ''}
                    </div>
                </div>
            `;
        }
        
        // Market Analysis Card
        if (results.market_analysis) {
            const ma = results.market_analysis;
            html += `
                <div class="data-card market-card">
                    <div class="card-header">
                        <h6><i class="fas fa-chart-line"></i> Market Intelligence</h6>
                        <div class="position-badge position-${ma.market_position ? ma.market_position.toLowerCase().replace(' ', '-') : 'unknown'}">
                            ${ma.market_position || 'Unknown'}
                        </div>
                    </div>
                    <div class="card-content">
                        <div class="market-grid">
                            ${ma.average_price ? `
                                <div class="market-stat">
                                    <div class="stat-value">${this.formatCurrency(ma.average_price)}</div>
                                    <div class="stat-label">Market Average</div>
                                </div>
                            ` : ''}
                            <div class="market-stat">
                                <div class="stat-value">${ma.demand_level || 'N/A'}</div>
                                <div class="stat-label">Demand Level</div>
                            </div>
                            <div class="market-stat">
                                <div class="stat-value">${ma.supply_level || 'N/A'}</div>
                                <div class="stat-label">Supply Level</div>
                            </div>
                            <div class="market-stat">
                                <div class="stat-value">${ma.growth_forecast || 'N/A'}%</div>
                                <div class="stat-label">Growth Forecast</div>
                            </div>
                        </div>
                    </div>
                </div>
            `;
        }
        
        // Investment Analysis Card
        if (results.investment_analysis) {
            const ia = results.investment_analysis;
            html += `
                <div class="data-card investment-card">
                    <div class="card-header">
                        <h6><i class="fas fa-chart-pie"></i> Investment Metrics</h6>
                        <div class="score-badge score-${this.getScoreLevel(ia.investment_score)}">
                            ${ia.investment_score}/10
                        </div>
                    </div>
                    <div class="card-content">
                        <div class="investment-grid">
                            <div class="investment-metric primary">
                                <div class="metric-icon"><i class="fas fa-trophy"></i></div>
                                <div class="metric-content">
                                    <div class="metric-value">${ia.investment_score}/10</div>
                                    <div class="metric-label">Investment Score</div>
                                </div>
                            </div>
                            <div class="investment-metric">
                                <div class="metric-icon"><i class="fas fa-percentage"></i></div>
                                <div class="metric-content">
                                    <div class="metric-value">${ia.rental_yield}%</div>
                                    <div class="metric-label">Rental Yield</div>
                                </div>
                            </div>
                            <div class="investment-metric">
                                <div class="metric-icon"><i class="fas fa-chart-line"></i></div>
                                <div class="metric-content">
                                    <div class="metric-value">${ia.roi_potential}</div>
                                    <div class="metric-label">ROI Potential</div>
                                </div>
                            </div>
                            <div class="investment-metric">
                                <div class="metric-icon"><i class="fas fa-shield-alt"></i></div>
                                <div class="metric-content">
                                    <div class="metric-value">${ia.risk_level}</div>
                                    <div class="metric-label">Risk Level</div>
                                </div>
                            </div>
                            ${ia.payback_period ? `
                                <div class="investment-metric">
                                    <div class="metric-icon"><i class="fas fa-clock"></i></div>
                                    <div class="metric-content">
                                        <div class="metric-value">${ia.payback_period} years</div>
                                        <div class="metric-label">Payback Period</div>
                                    </div>
                                </div>
                            ` : ''}
                            ${ia.appreciation_forecast ? `
                                <div class="investment-metric">
                                    <div class="metric-icon"><i class="fas fa-trending-up"></i></div>
                                    <div class="metric-content">
                                        <div class="metric-value">${ia.appreciation_forecast}</div>
                                        <div class="metric-label">Appreciation</div>
                                    </div>
                                </div>
                            ` : ''}
                        </div>
                    </div>
                </div>
            `;
        }
        
        // Similar Properties Card
        if (results.similar_properties && results.similar_properties.length > 0) {
            const props = results.similar_properties.slice(0, 3); // Show top 3
            html += `
                <div class="data-card properties-card">
                    <div class="card-header">
                        <h6><i class="fas fa-home"></i> Similar Properties</h6>
                        <div class="count-badge">${results.similar_properties.length} found</div>
                    </div>
                    <div class="card-content">
                        <div class="properties-list">
                            ${props.map(prop => `
                                <div class="property-item">
                                    <div class="property-header">
                                        <div class="property-location">${prop.location || 'N/A'}</div>
                                        <div class="similarity-score">
                                            ${Math.round((prop.similarity_score || 0) * 100)}% match
                                        </div>
                                    </div>
                                    <div class="property-details">
                                        <div class="detail">${prop.rooms || 'N/A'} rooms</div>
                                        <div class="detail">${prop.size || 'N/A'} m²</div>
                                        <div class="detail price">${this.formatCurrency(prop.price || 0)}</div>
                                        ${prop.price_per_sqm ? `<div class="detail">${this.formatCurrency(prop.price_per_sqm)}/m²</div>` : ''}
                                    </div>
                                </div>
                            `).join('')}
                        </div>
                        ${results.similar_properties.length > 3 ? `
                            <div class="more-properties">
                                +${results.similar_properties.length - 3} more properties available
                            </div>
                        ` : ''}
                    </div>
                </div>
            `;
        }
        
        // Key Insights Card
        if (results.key_insights && results.key_insights.length > 0) {
            html += `
                <div class="data-card insights-card">
                    <div class="card-header">
                        <h6><i class="fas fa-lightbulb"></i> Key Insights</h6>
                    </div>
                    <div class="card-content">
                        <div class="insights-list">
                            ${results.key_insights.map(insight => `
                                <div class="insight-item">
                                    <i class="fas fa-check-circle"></i>
                                    <span>${insight}</span>
                                </div>
                            `).join('')}
                        </div>
                    </div>
                </div>
            `;
        }
        
        html += `</div>`;
        
        return html;
    }
    
    /**
     * Helper methods for enhanced data summary
     */
    getConfidenceLevel(confidence) {
        if (confidence >= 0.8) return 'high';
        if (confidence >= 0.6) return 'medium';
        return 'low';
    }
    
    getScoreLevel(score) {
        if (score >= 8) return 'excellent';
        if (score >= 7) return 'good';
        if (score >= 5) return 'fair';
        return 'poor';
    }
}

class Utils {
    /**
     * Format a number as currency
     * @param {number} value - The value to format
     * @param {string} currency - The currency code (default: 'TRY')
     * @returns {string} Formatted currency string
     */
    static formatCurrency(value, currency = 'TRY') {
        return new Intl.NumberFormat('tr-TR', {
            style: 'currency',
            currency: currency,
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        }).format(value);
    }

    /**
     * Format a date string
     * @param {string|Date} date - The date to format
     * @returns {string} Formatted date string
     */
    static formatDate(date) {
        const d = new Date(date);
        return d.toLocaleDateString('tr-TR', {
            year: 'numeric',
            month: 'long',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        });
    }

    /**
     * Generate a unique ID
     * @returns {string} A unique ID
     */
    static generateId() {
        return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
            const r = Math.random() * 16 | 0;
            const v = c === 'x' ? r : (r & 0x3 | 0x8);
            return v.toString(16);
        });
    }

    /**
     * Debounce a function
     * @param {Function} func - The function to debounce
     * @param {number} wait - The time to wait in milliseconds
     * @returns {Function} The debounced function
     */
    static debounce(func, wait) {
        let timeout;
        return function(...args) {
            const context = this;
            clearTimeout(timeout);
            timeout = setTimeout(() => func.apply(context, args), wait);
        };
    }

    /**
     * Validate an email address
     * @param {string} email - The email to validate
     * @returns {boolean} True if the email is valid
     */
    static validateEmail(email) {
        const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return re.test(email);
    }

    /**
     * Show a toast notification
     * @param {string} message - The message to show
     * @param {string} type - The type of notification (success, error, warning, info)
     * @param {number} duration - How long to show the notification in milliseconds (default: 3000)
     */
    static showToast(message, type = 'info', duration = 3000) {
        const toast = document.createElement('div');
        toast.className = `toast toast-${type}`;
        toast.textContent = message;
        
        // Add to toast container or create one
        let container = document.getElementById('toast-container');
        if (!container) {
            container = document.createElement('div');
            container.id = 'toast-container';
            document.body.appendChild(container);
        }
        
        container.appendChild(toast);
        
        // Show with animation
        setTimeout(() => toast.classList.add('show'), 10);
        
        // Remove after duration
        setTimeout(() => {
            toast.classList.remove('show');
            setTimeout(() => toast.remove(), 300);
        }, duration);
    }
}

// Add to global scope
window.Utils = Utils;
