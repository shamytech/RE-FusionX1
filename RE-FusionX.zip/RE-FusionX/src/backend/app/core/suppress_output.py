"""Suppress unwanted output"""
import os
import sys
import warnings

def suppress_all():
    """Suppress all unwanted output"""
    # Environment variables
    os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'
    os.environ['TRANSFORMERS_VERBOSITY'] = 'error'
    os.environ['TOKENIZERS_PARALLELISM'] = 'false'
    os.environ['TQDM_DISABLE'] = '1'
    
    # Warnings
    warnings.filterwarnings('ignore')
    
    # Disable progress bars
    try:
        import tqdm
        tqdm.tqdm.__init__ = lambda *a, **k: None
    except:
        pass
    
    # Redirect stderr temporarily during model loading
    class SuppressStderr:
        def __enter__(self):
            self._original_stderr = sys.stderr
            sys.stderr = open(os.devnull, 'w')
            return self
            
        def __exit__(self, *args):
            sys.stderr.close()
            sys.stderr = self._original_stderr
    
    return SuppressStderr()
