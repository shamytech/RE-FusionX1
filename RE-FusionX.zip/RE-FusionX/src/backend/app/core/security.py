"""
Security utilities for RE-FusionX.
Handles authentication, authorization, and security validations.
"""

import hashlib
import hmac
import secrets
from typing import Optional, Dict, Any
from datetime import datetime, timedelta
import jwt
from passlib.context import CryptContext
from fastapi import HTTPException, Security, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
import re

from .config import settings
from .exceptions import ValidationException


# Password hashing context
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

# Bearer token security
security_bearer = HTTPBearer(auto_error=False)


class SecurityManager:
    """Manages security operations for the application."""
    
    def __init__(self):
        """Initialize security manager."""
        self.secret_key = settings.SECRET_KEY
        self.algorithm = "HS256"
        self.access_token_expire = timedelta(hours=24)
        
    def create_access_token(
        self,
        data: Dict[str, Any],
        expires_delta: Optional[timedelta] = None
    ) -> str:
        """
        Create JWT access token.
        
        Args:
            data: Data to encode in token
            expires_delta: Token expiration time
            
        Returns:
            Encoded JWT token
        """
        to_encode = data.copy()
        
        if expires_delta:
            expire = datetime.utcnow() + expires_delta
        else:
            expire = datetime.utcnow() + self.access_token_expire
            
        to_encode.update({"exp": expire})
        
        encoded_jwt = jwt.encode(
            to_encode,
            self.secret_key,
            algorithm=self.algorithm
        )
        
        return encoded_jwt
    
    def verify_token(self, token: str) -> Dict[str, Any]:
        """
        Verify and decode JWT token.
        
        Args:
            token: JWT token to verify
            
        Returns:
            Decoded token data
            
        Raises:
            HTTPException: If token is invalid
        """
        try:
            payload = jwt.decode(
                token,
                self.secret_key,
                algorithms=[self.algorithm]
            )
            return payload
        except jwt.ExpiredSignatureError:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Token has expired"
            )
        except jwt.JWTError:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid token"
            )
    
    def hash_password(self, password: str) -> str:
        """
        Hash a password.
        
        Args:
            password: Plain text password
            
        Returns:
            Hashed password
        """
        return pwd_context.hash(password)
    
    def verify_password(self, plain_password: str, hashed_password: str) -> bool:
        """
        Verify a password against its hash.
        
        Args:
            plain_password: Plain text password
            hashed_password: Hashed password
            
        Returns:
            True if password matches
        """
        return pwd_context.verify(plain_password, hashed_password)
    
    def generate_api_key(self) -> str:
        """
        Generate a secure API key.
        
        Returns:
            Secure random API key
        """
        return secrets.token_urlsafe(32)
    
    def validate_api_key(self, api_key: str) -> bool:
        """
        Validate API key format.
        
        Args:
            api_key: API key to validate
            
        Returns:
            True if valid format
        """
        # API key should be 43 characters (32 bytes base64url encoded)
        return len(api_key) == 43 and re.match(r'^[A-Za-z0-9_-]+$', api_key)


class InputSanitizer:
    """Sanitize and validate user inputs for security."""
    
    @staticmethod
    def sanitize_string(value: str, max_length: int = 1000) -> str:
        """
        Sanitize string input.
        
        Args:
            value: String to sanitize
            max_length: Maximum allowed length
            
        Returns:
            Sanitized string
            
        Raises:
            ValidationException: If input is invalid
        """
        if not value:
            return ""
        
        # Remove null bytes
        value = value.replace('\x00', '')
        
        # Trim whitespace
        value = value.strip()
        
        # Check length
        if len(value) > max_length:
            raise ValidationException(
                f"Input exceeds maximum length of {max_length}",
                field="input",
                invalid_value=f"{len(value)} characters"
            )
        
        # Remove control characters except newlines and tabs
        value = ''.join(
            char for char in value
            if char == '\n' or char == '\t' or not ord(char) < 32
        )
        
        return value
    
    @staticmethod
    def sanitize_filename(filename: str) -> str:
        """
        Sanitize filename for safe storage.
        
        Args:
            filename: Original filename
            
        Returns:
            Sanitized filename
        """
        # Remove path components
        filename = filename.replace('/', '').replace('\\', '')
        
        # Remove special characters
        filename = re.sub(r'[^a-zA-Z0-9._-]', '_', filename)
        
        # Limit length
        max_length = 255
        if len(filename) > max_length:
            name, ext = filename.rsplit('.', 1) if '.' in filename else (filename, '')
            filename = name[:max_length - len(ext) - 1] + '.' + ext if ext else name[:max_length]
        
        return filename
    
    @staticmethod
    def validate_email(email: str) -> str:
        """
        Validate and sanitize email address.
        
        Args:
            email: Email address to validate
            
        Returns:
            Sanitized email
            
        Raises:
            ValidationException: If email is invalid
        """
        email = email.strip().lower()
        
        # Basic email regex
        email_pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        
        if not re.match(email_pattern, email):
            raise ValidationException(
                "Invalid email format",
                field="email",
                invalid_value=email
            )
        
        return email
    
    @staticmethod
    def validate_url(url: str) -> str:
        """
        Validate and sanitize URL.
        
        Args:
            url: URL to validate
            
        Returns:
            Sanitized URL
            
        Raises:
            ValidationException: If URL is invalid
        """
        url = url.strip()
        
        # Basic URL regex
        url_pattern = r'^https?:\/\/(www\.)?[-a-zA-Z0-9@:%._\+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%_\+.~#?&//=]*)$'
        
        if not re.match(url_pattern, url):
            raise ValidationException(
                "Invalid URL format",
                field="url",
                invalid_value=url
            )
        
        return url
    
    @staticmethod
    def prevent_sql_injection(value: str) -> str:
        """
        Check for SQL injection patterns.
        
        Args:
            value: Value to check
            
        Returns:
            Original value if safe
            
        Raises:
            ValidationException: If SQL injection detected
        """
        # Common SQL injection patterns
        sql_patterns = [
            r'(\b(SELECT|INSERT|UPDATE|DELETE|DROP|UNION|ALTER|CREATE)\b)',
            r'(--|#|\/\*|\*\/)',
            r'(\bOR\b.*=.*)',
            r'(\bAND\b.*=.*)',
            r'(\'.*\bOR\b.*\')',
            r'(;.*\b(SELECT|INSERT|UPDATE|DELETE|DROP)\b)'
        ]
        
        value_upper = value.upper()
        for pattern in sql_patterns:
            if re.search(pattern, value_upper):
                raise ValidationException(
                    "Potential SQL injection detected",
                    field="input",
                    invalid_value="[REDACTED]"
                )
        
        return value
    
    @staticmethod
    def prevent_xss(value: str) -> str:
        """
        Prevent XSS attacks by escaping HTML.
        
        Args:
            value: Value to escape
            
        Returns:
            Escaped value
        """
        # HTML escape mappings
        html_escape_table = {
            "&": "&amp;",
            '"': "&quot;",
            "'": "&#x27;",
            ">": "&gt;",
            "<": "&lt;",
            "/": "&#x2F;",
        }
        
        return "".join(html_escape_table.get(c, c) for c in value)


class RateLimiter:
    """Rate limiting for API endpoints."""
    
    def __init__(self, max_requests: int = 100, window_seconds: int = 60):
        """
        Initialize rate limiter.
        
        Args:
            max_requests: Maximum requests allowed
            window_seconds: Time window in seconds
        """
        self.max_requests = max_requests
        self.window_seconds = window_seconds
        self.requests = {}
    
    def check_rate_limit(self, identifier: str) -> bool:
        """
        Check if request is within rate limit.
        
        Args:
            identifier: Unique identifier (IP, user ID, etc.)
            
        Returns:
            True if within limit
        """
        now = datetime.utcnow()
        
        # Clean old entries
        self._clean_old_entries(now)
        
        # Check current requests
        if identifier not in self.requests:
            self.requests[identifier] = []
        
        # Count requests in window
        request_times = self.requests[identifier]
        if len(request_times) >= self.max_requests:
            return False
        
        # Add current request
        request_times.append(now)
        return True
    
    def _clean_old_entries(self, now: datetime):
        """Remove entries outside the time window."""
        cutoff = now - timedelta(seconds=self.window_seconds)
        
        for identifier in list(self.requests.keys()):
            self.requests[identifier] = [
                req_time for req_time in self.requests[identifier]
                if req_time > cutoff
            ]
            
            if not self.requests[identifier]:
                del self.requests[identifier]


# Global instances
security_manager = SecurityManager()
input_sanitizer = InputSanitizer()
rate_limiter = RateLimiter()
