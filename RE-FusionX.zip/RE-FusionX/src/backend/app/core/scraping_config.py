# app/core/scraping_config.py
"""
Hybrid Scraping Configuration
==============================
Controls which scraping tools to use and their priority
"""

from enum import Enum
from typing import Dict, Any, List
from dataclasses import dataclass
from pathlib import Path

class ScrapingTool(Enum):
    """Available scraping tools in priority order"""
    SCRAPEGRAPHAI = "scrapegraphai"  # Priority 1 - Most intelligent
    CRAWL4AI = "crawl4ai"            # Priority 2 - Fast and efficient  
    LANGCHAIN_BS4 = "langchain_bs4"  # Priority 3 - Stable fallback
    TRADITIONAL = "traditional"       # Priority 4 - Basic fallback

@dataclass
class ScrapingConfig:
    """Scraping configuration settings"""
    
    # Tool selection
    enabled_tools: List[ScrapingTool] = None
    primary_tool: ScrapingTool = ScrapingTool.SCRAPEGRAPHAI
    auto_fallback: bool = True
    max_retries_per_tool: int = 2
    
    # Tool-specific configurations
    scrapegraphai_config: Dict[str, Any] = None
    crawl4ai_config: Dict[str, Any] = None
    langchain_config: Dict[str, Any] = None
    
    # Common settings
    timeout: int = 30
    rate_limit: int = 10  # requests per minute
    cache_results: bool = True
    cache_duration_hours: int = 24
    
    # Turkish real estate specific
    turkish_prompts: Dict[str, str] = None
    
    def __post_init__(self):
        """Initialize default configurations"""
        
        if self.enabled_tools is None:
            self.enabled_tools = [
                ScrapingTool.SCRAPEGRAPHAI,
                ScrapingTool.CRAWL4AI,
                ScrapingTool.LANGCHAIN_BS4,
                ScrapingTool.TRADITIONAL
            ]
        
        if self.scrapegraphai_config is None:
            self.scrapegraphai_config = {
                "llm": {
                    "model": "local",
                    "temperature": 0.1,
                    "max_tokens": 2000
                },
                "verbose": False,
                "headless": True,
                "use_cache": True
            }
        
        if self.crawl4ai_config is None:
            self.crawl4ai_config = {
                "browser": "chromium",
                "headless": True,
                "wait_for": "networkidle",
                "screenshot": False,
                "extract_media": False
            }
        
        if self.langchain_config is None:
            self.langchain_config = {
                "chunk_size": 4000,
                "chunk_overlap": 200,
                "use_async": True
            }
        
        if self.turkish_prompts is None:
            self.turkish_prompts = {
                "property_extraction": """
                Extract the following information from this Turkish real estate listing:
                
                Required fields:
                - price (fiyat): Numeric value in TL
                - location (konum/yer): City, district, neighborhood
                - size (metrekare/m²/alan): Total area in square meters
                - rooms (oda sayısı): Room configuration (e.g., 3+1)
                - building_age (bina yaşı): Age or construction year
                - floor (kat): Floor number and total floors
                
                Optional fields:
                - heating (ısıtma): Heating system type
                - furnished (eşyalı): Yes/No
                - in_site (site içinde): Yes/No
                - features (özellikler): List of amenities
                - seller_type (satıcı): Individual/Agency
                - listing_date (ilan tarihi): When listed
                - description (açıklama): Property description
                
                Return as structured JSON with Turkish terms mapped to English keys.
                """,
                
                "market_search": """
                Search for similar properties with these criteria:
                - Same city and district
                - Size within 20% range
                - Same room configuration or ±1 room
                - Price within 30% range
                
                Extract all matching properties with their details.
                """,
                
                "price_comparison": """
                Compare property prices and identify:
                - Average price per square meter
                - Price range (min, max, median)
                - Price trends
                - Factors affecting price
                """
            }

# Global configuration instance
SCRAPING_CONFIG = ScrapingConfig()

def update_scraping_config(**kwargs):
    """Update scraping configuration"""
    global SCRAPING_CONFIG
    for key, value in kwargs.items():
        if hasattr(SCRAPING_CONFIG, key):
            setattr(SCRAPING_CONFIG, key, value)

def get_active_tools() -> List[ScrapingTool]:
    """Get list of active scraping tools in priority order"""
    return SCRAPING_CONFIG.enabled_tools
