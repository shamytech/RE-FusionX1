"""
Enhanced Logging System for RE-FusionX with Rich formatting
نظام تسجيل متقدم مع تنسيق جميل باستخدام Rich
"""

import logging
import logging.handlers
import sys
import json
import time
import os
from datetime import datetime
from typing import Optional, Dict, Any, List
from pathlib import Path
from contextvars import ContextVar
from functools import wraps
from collections import defaultdict

# Rich imports
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn, TimeElapsedColumn
from rich.logging import RichHandler
from rich.text import Text
from rich.layout import Layout
from rich.live import Live
from rich.columns import Columns
from rich.syntax import Syntax
from rich.tree import Tree
from rich.align import Align
from rich.rule import Rule

from app.core.config import settings

# Suppress warnings
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'
os.environ['TF_ENABLE_ONEDNN_OPTS'] = '0'
import warnings
warnings.filterwarnings('ignore')

# Suppress protobuf warnings
import logging as _logging
_logging.getLogger('absl').setLevel(_logging.ERROR)

# Initialize Rich console with custom theme
console = Console(
    color_system="auto",
    force_terminal=True,
    force_jupyter=False,
    width=120
)

# Context variables
request_id_var: ContextVar[Optional[str]] = ContextVar('request_id', default=None)
user_id_var: ContextVar[Optional[str]] = ContextVar('user_id', default=None)

# Message buffer for grouping
message_buffer = defaultdict(list)
last_flush_time = time.time()


class LoggerMixin:
    """Mixin class to provide logging capabilities to any class."""
    
    @property
    def logger(self) -> logging.Logger:
        """Get logger for the class."""
        if not hasattr(self, '_logger'):
            self._logger = logging.getLogger(
                f"re_fusionx.{self.__class__.__module__}.{self.__class__.__name__}"
            )
        return self._logger


class ContextFilter(logging.Filter):
    """Add context information to log records."""
    
    def filter(self, record: logging.LogRecord) -> bool:
        record.request_id = request_id_var.get() or "no-request"
        record.user_id = user_id_var.get() or "anonymous"
        record.service = "re-fusionx"
        record.version = settings.APP_VERSION
        return True


class CustomJsonFormatter(logging.Formatter):
    """Custom JSON formatter for file logging."""
    
    def format(self, record: logging.LogRecord) -> str:
        log_obj = {
            'timestamp': datetime.utcnow().isoformat(),
            'level': record.levelname,
            'message': record.getMessage(),
            'module': record.module,
            'function': record.funcName,
            'line': record.lineno,
            'file': record.pathname
        }
        
        # Add context if available
        if hasattr(record, 'request_id'):
            log_obj['request_id'] = record.request_id
        if hasattr(record, 'user_id'):
            log_obj['user_id'] = record.user_id
            
        return json.dumps(log_obj)


class LogMessage:
    """Structured log message"""
    
    def __init__(self, record: logging.LogRecord):
        self.timestamp = datetime.now()
        self.level = record.levelname
        self.message = record.getMessage()
        self.module = record.module
        self.function = record.funcName
        self.line = record.lineno
        self.file = Path(record.pathname).name if record.pathname else "unknown"
        
        # Extract context
        self.request_id = getattr(record, 'request_id', 'no-request')
        self.user_id = getattr(record, 'user_id', 'anonymous')
        
        # Categorize message
        self.category = self._categorize_message()
        
    def _categorize_message(self) -> str:
        """Categorize message for grouping"""
        msg_lower = self.message.lower()
        
        if 'orchestrator' in msg_lower or 'routing' in msg_lower:
            return '🎯 Orchestrator'
        elif 'agent' in msg_lower:
            return '🤖 Agents'
        elif 'model' in msg_lower or 'loading' in msg_lower:
            return '🧠 Model'
        elif 'database' in msg_lower or 'storage' in msg_lower:
            return '💾 Storage'
        elif 'api' in msg_lower or 'endpoint' in msg_lower:
            return '🌐 API'
        elif 'error' in msg_lower or 'failed' in msg_lower:
            return '❌ Errors'
        elif 'warning' in msg_lower:
            return '⚠️ Warnings'
        elif 'market' in msg_lower or 'property' in msg_lower:
            return '🏠 Real Estate'
        else:
            return 'ℹ️ General'


class RichConsoleHandler(logging.Handler):
    """Advanced Rich console handler with beautiful formatting"""
    
    def __init__(self):
        super().__init__()
        self.console = console
        self.last_category = None
        self.message_count = 0
        self.start_time = time.time()
        
    def emit(self, record: logging.LogRecord):
        """Emit a beautifully formatted log record"""
        try:
            # Skip JSON formatted messages
            if record.getMessage().startswith('{'):
                # Parse and display JSON nicely
                self._display_json_log(record)
                return
            
            # تجاهل رسائل checkpoint shards و layers not sharded
            msg = record.getMessage()
            if any(skip in msg for skip in [
                "Loading checkpoint shards:",
                "The following layers were not sharded:",
                "%|",  # Progress bars
                "it/s]"  # Progress timing
            ]):
                return
            # Create structured message
            log_msg = LogMessage(record)
            
            # Display based on level and category
            if record.levelno >= logging.ERROR:
                self._display_error(log_msg)
            elif record.levelno >= logging.WARNING:
                self._display_warning(log_msg)
            else:
                self._display_info(log_msg)
                
        except Exception as e:
            # Fallback to simple output
            self.console.print(f"[red]Logging error: {e}[/red]")
            self.console.print(record.getMessage())
    
    def _display_json_log(self, record: logging.LogRecord):
        """Display JSON log in a structured way"""
        try:
            data = json.loads(record.getMessage())
            
            # Create a nice table for JSON data
            table = Table(
                show_header=True,
                header_style="bold cyan",
                border_style="dim",
                title=f"📋 {data.get('message', 'Log Entry')}",
                title_style="bold white",
                show_lines=False,
                expand=False,
                box=None
            )
            
            # Add columns
            table.add_column("Field", style="cyan", width=20)
            table.add_column("Value", style="white", overflow="fold")
            
            # Add important fields first
            priority_fields = ['message', 'level', 'timestamp', 'source']
            
            for field in priority_fields:
                if field in data:
                    value = data[field]
                    if field == 'source' and isinstance(value, dict):
                        value = f"{value.get('file', 'unknown')}:{value.get('line', '?')} in {value.get('function', '?')}"
                    elif field == 'timestamp':
                        # Format timestamp nicely
                        try:
                            dt = datetime.fromisoformat(value.replace('Z', '+00:00'))
                            value = dt.strftime('%H:%M:%S.%f')[:-3]
                        except:
                            pass
                    
                    table.add_row(field.title(), str(value))
            
            # Add other fields
            for field, value in data.items():
                if field not in priority_fields and field not in ['request_id', 'user_id', 'service', 'version']:
                    table.add_row(field.replace('_', ' ').title(), str(value)[:100])
            
            # Display with appropriate styling
            if data.get('level') == 'ERROR':
                self.console.print(Panel(table, border_style="red", padding=(0, 1)))
            elif data.get('level') == 'WARNING':
                self.console.print(Panel(table, border_style="yellow", padding=(0, 1)))
            else:
                # For INFO, make it more compact
                self._display_compact_info(data)
                
        except json.JSONDecodeError:
            # Not JSON, display as regular message
            self.console.print(f"[dim]{record.getMessage()}[/dim]")
    
    def _display_compact_info(self, data: Dict[str, Any]):
        """Display INFO level JSON in a compact format"""
        message = data.get('message', '')
        source = data.get('source', {})
        
        # Format based on message type
        if 'Processing through orchestrator' in message:
            intent = message.split('intent: ')[-1] if 'intent:' in message else 'unknown'
            self.console.print(
                f"  [cyan]→[/cyan] Orchestrator: Processing [yellow]{intent}[/yellow] request"
            )
        elif 'Routing to agent' in message:
            agent = message.split('agent: ')[-1] if 'agent:' in message else 'unknown'
            self.console.print(
                f"    [green]↳[/green] Routing to [bold green]{agent}[/bold green] agent"
            )
        elif 'Analyzing' in message or 'analysis' in message.lower():
            self.console.print(
                f"    [blue]🔍[/blue] {message}"
            )
        elif 'result' in message.lower():
            self.console.print(
                f"    [green]✓[/green] {message[:80]}..."
            )
        else:
            # Generic info
            icon = self._get_icon_for_message(message)
            self.console.print(f"  {icon} {message[:100]}")
    
    def _display_error(self, log_msg: LogMessage):
        """Display error with full details"""
        error_table = Table(
            show_header=False,
            border_style="red",
            box=None,
            padding=(0, 1)
        )
        
        error_table.add_column("", style="red")
        error_table.add_column("", style="white")
        
        error_table.add_row("❌ ERROR", log_msg.message)
        error_table.add_row("📁 Source", f"{log_msg.file}:{log_msg.line}")
        error_table.add_row("🔧 Function", log_msg.function)
        error_table.add_row("⏰ Time", log_msg.timestamp.strftime('%H:%M:%S'))
        
        self.console.print(Panel(
            error_table,
            title="[bold red]Error Detected[/bold red]",
            border_style="red",
            expand=False
        ))
    
    def _display_warning(self, log_msg: LogMessage):
        """Display warning in a noticeable way"""
        self.console.print(
            f"  [yellow]⚠️ Warning:[/yellow] {log_msg.message} "
            f"[dim]({log_msg.file}:{log_msg.line})[/dim]"
        )
    
    def _display_info(self, log_msg: LogMessage):
        """Display info message based on category"""
        # Group by category
        if log_msg.category != self.last_category:
            self.console.print(f"\n[bold]{log_msg.category}[/bold]")
            self.last_category = log_msg.category
        
        # Format message based on content
        icon = self._get_icon_for_message(log_msg.message)
        
        # Clean up the message
        msg = self._clean_message(log_msg.message)
        
        # Add context if in debug mode
        if settings.DEBUG:
            context = f"[dim]({log_msg.function})[/dim]"
        else:
            context = ""
        
        self.console.print(f"  {icon} {msg} {context}")
    
    def _get_icon_for_message(self, message: str) -> str:
        """Get appropriate icon for message"""
        msg_lower = message.lower()
        
        if 'success' in msg_lower or 'completed' in msg_lower:
            return '✅'
        elif 'loading' in msg_lower or 'initializing' in msg_lower:
            return '⏳'
        elif 'processing' in msg_lower:
            return '⚙️'
        elif 'analyzing' in msg_lower:
            return '🔍'
        elif 'routing' in msg_lower:
            return '🔀'
        elif 'agent' in msg_lower:
            return '🤖'
        elif 'model' in msg_lower:
            return '🧠'
        elif 'database' in msg_lower or 'storage' in msg_lower:
            return '💾'
        elif 'api' in msg_lower:
            return '🌐'
        elif 'property' in msg_lower or 'real estate' in msg_lower:
            return '🏠'
        elif 'market' in msg_lower:
            return '📊'
        elif 'cached' in msg_lower:
            return '📦'
        else:
            return '•'
    
    def _clean_message(self, message: str) -> str:
        """Clean up message for display"""
        # Remove unicode escape sequences
        message = message.encode('utf-8').decode('utf-8', 'ignore')
        
        # Remove excessive paths
        if 'D:\\' in message or '/home/' in message:
            # Shorten paths
            parts = message.split('\\')
            if len(parts) > 3:
                message = message.replace('\\'.join(parts[:-2]), '...')
        
        # Limit length
        if len(message) > 100:
            message = message[:97] + '...'
        
        return message


class AgentLogger:
    """Enhanced agent logger with beautiful output"""
    
    def __init__(self):
        self.console = console
        self.start_times = {}
        self.agent_activities = defaultdict(list)
        self.enabled = True  # Always enabled for better visibility
        
    def agent_start(self, agent_name: str, task_type: str, data: Dict[str, Any] = None):
        """Agent starting with beautiful display"""
        self.start_times[agent_name] = time.time()
        
        # Create a beautiful panel for agent start
        content = f"[bold green]{agent_name}[/bold green]\n"
        content += f"[yellow]Task:[/yellow] {task_type}\n"
        
        if data:
            content += "[cyan]Parameters:[/cyan]\n"
            for key, value in list(data.items())[:5]:
                content += f"  • {key}: {str(value)[:50]}\n"
        
        self.console.print(Panel(
            content.strip(),
            title=f"🤖 Agent Activated",
            border_style="green",
            padding=(0, 1),
            expand=False
        ))
        
    def agent_action(self, agent_name: str, action: str, data: Dict[str, Any] = None):
        """Log agent action"""
        message = f"[cyan]→[/cyan] {agent_name}: {action}"
        if data:
            params = [f"{k}={v}" for k, v in list(data.items())[:3]]
            if params:
                message += f" [dim]({', '.join(params)})[/dim]"
        self.console.print(f"  {message}")
        
    def info(self, agent_name: str, message: str, data: Dict[str, Any] = None):
        """Log agent info message"""
        msg = f"  [blue]ℹ️[/blue] {agent_name}: {message}"
        if data:
            params = [f"{k}={v}" for k, v in list(data.items())[:3]]
            if params:
                msg += f" [dim]({', '.join(params)})[/dim]"
        self.console.print(msg)
    
    def warning(self, agent_name: str, message: str):
        """Log agent warning"""
        self.console.print(f"  [yellow]⚠️[/yellow] {agent_name}: {message}")
    
    def debug(self, agent_name: str, message: str):
        """Log agent debug message"""
        if settings.DEBUG:
            self.console.print(f"  [dim]🔍 {agent_name}: {message}[/dim]")
    
    def agent_thinking(self, agent_name: str, message: str):
        """Agent thinking process"""
        self.console.print(f"    [dim italic]💭 {agent_name}: {message}[/dim italic]")
    
    def agent_tool_use(self, agent_name: str, tool_name: str, params: Dict = None):
        """Agent using a tool"""
        param_str = ""
        if params:
            param_list = [f"{k}={v}" for k, v in list(params.items())[:3]]
            param_str = f" [dim]({', '.join(param_list)})[/dim]"
        
        self.console.print(
            f"    [cyan]🔧 Tool:[/cyan] [yellow]{tool_name}[/yellow]{param_str}"
        )
    
    def agent_result(self, agent_name: str, result: Any, success: bool = True):
        """Agent result with timing"""
        elapsed = time.time() - self.start_times.get(agent_name, time.time())
        
        # Create result panel
        if success:
            status = Panel(
                self._format_result(result),
                title=f"✅ {agent_name} Complete",
                subtitle=f"[dim]{elapsed:.2f}s[/dim]",
                border_style="green",
                padding=(0, 1)
            )
        else:
            status = Panel(
                f"[red]Failed: {result}[/red]",
                title=f"❌ {agent_name} Failed",
                subtitle=f"[dim]{elapsed:.2f}s[/dim]",
                border_style="red",
                padding=(0, 1)
            )
        
        self.console.print(status)
    
    def _format_result(self, result: Any) -> str:
        """Format result for display"""
        if isinstance(result, dict):
            lines = []
            
            # Special handling for property/market results
            if 'estimated_value' in result:
                lines.append(f"💰 Value: [bold green]{result['estimated_value']:,.0f} TL[/bold green]")
            if 'confidence_level' in result:
                lines.append(f"📊 Confidence: {result['confidence_level']*100:.0f}%")
            if 'properties_found' in result:
                lines.append(f"🏠 Properties: {result['properties_found']}")
            
            # Add other important fields
            for key in ['status', 'message', 'recommendation']:
                if key in result:
                    lines.append(f"• {key.title()}: {result[key]}")
            
            return '\n'.join(lines) if lines else f"{len(result)} fields processed"
            
        elif isinstance(result, list):
            return f"📋 {len(result)} items returned"
        else:
            return str(result)[:200]
    
    def show_property_analysis(self, property_data: Dict[str, Any], valuation: Dict[str, Any]):
        """Display property analysis beautifully"""
        if not self.enabled:
            return
            
        # Property details table
        prop_table = Table(title="🏠 Property Details", show_header=False)
        prop_table.add_column("Feature", style="cyan")
        prop_table.add_column("Value", style="white")
        
        for key, value in property_data.items():
            prop_table.add_row(key.replace('_', ' ').title(), str(value))
        
        self.console.print(prop_table)
        
        # Valuation panel
        if valuation:
            val_text = f"""
[bold green]Estimated Value:[/bold green] {valuation.get('estimated_value', 0):,.0f} TL
[yellow]Price per m²:[/yellow] {valuation.get('price_per_sqm', 0):,.0f} TL/m²
[cyan]Confidence:[/cyan] {valuation.get('confidence_level', 0)*100:.0f}%
            """
            
            val_panel = Panel(
                val_text.strip(),
                title="💰 Valuation Results",
                border_style="green"
            )
            self.console.print(val_panel)
    
    def show_market_comparison(self, similar_properties: list, market_stats: Dict):
        """Display market comparison"""
        if not self.enabled:
            return
            
        if similar_properties:
            # Similar properties table
            table = Table(title="📊 Similar Properties", show_header=True)
            table.add_column("#", style="dim", width=3)
            table.add_column("Location", style="cyan")
            table.add_column("Price", style="green")
            table.add_column("Size", style="yellow")
            table.add_column("Similarity", style="magenta")
            
            for i, prop in enumerate(similar_properties[:5], 1):
                table.add_row(
                    str(i),
                    prop.get('location', 'N/A')[:30],
                    f"{prop.get('price', 0):,.0f}",
                    f"{prop.get('size', 'N/A')} m²",
                    f"{prop.get('similarity_score', 0)*100:.0f}%"
                )
            
            self.console.print(table)
        
        # Market statistics
        if market_stats:
            stats_text = f"""
[bold]Market Statistics:[/bold]
• Average Price: {market_stats.get('average_price', 0):,.0f} TL
• Price Range: {market_stats.get('min_price', 0):,.0f} - {market_stats.get('max_price', 0):,.0f} TL
• Properties Found: {market_stats.get('total_properties', 0)}
• Market Activity: {market_stats.get('market_activity', 'Normal')}
            """
            
            self.console.print(Panel(
                stats_text.strip(),
                title="📈 Market Overview",
                border_style="blue"
            ))
    
    def error(self, agent_name: str, error: str, details: str = None):
        """Display agent error"""
        error_text = f"[red]❌ {agent_name} Error:[/red] {error}"
        if details:
            error_text += f"\n[dim]Details: {details}[/dim]"
        
        self.console.print(Panel(
            error_text,
            border_style="red",
            title="Error"
        ))
    
    def show_session_summary(self, session_id: str, stats: Dict[str, Any]):
        """Show session summary"""
        # Create summary table
        table = Table(
            title=f"📊 Session Summary: {session_id}",
            show_header=True,
            header_style="bold cyan"
        )
        
        table.add_column("Metric", style="cyan")
        table.add_column("Value", style="green")
        
        for key, value in stats.items():
            table.add_row(key.replace('_', ' ').title(), str(value))
        
        self.console.print(table)


class ProgressTracker:
    """Enhanced progress tracking with Rich"""
    
    def __init__(self):
        self.console = console
        self.tasks = {}
        
    def start_task(self, task_id: str, description: str, total: int = 100):
        """Start a new task with progress tracking"""
        if task_id not in self.tasks:
            progress = Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                BarColumn(),
                TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
                TimeElapsedColumn(),
                console=self.console,
                transient=True,
                refresh_per_second=2
            )
            progress.start()
            task = progress.add_task(description, total=total)
            self.tasks[task_id] = {'progress': progress, 'task': task}
    
    def update_task(self, task_id: str, advance: int = 1, description: str = None):
        """Update task progress"""
        if task_id in self.tasks:
            task_info = self.tasks[task_id]
            if description:
                task_info['progress'].update(task_info['task'], description=description)
            task_info['progress'].update(task_info['task'], advance=advance)
    
    def complete_task(self, task_id: str):
        """Complete and remove task"""
        if task_id in self.tasks:
            task_info = self.tasks[task_id]
            task_info['progress'].update(task_info['task'], completed=100)
            task_info['progress'].stop()
            del self.tasks[task_id]


def log_execution_time(func):
    """
    Decorator to log function execution time.
    
    Args:
        func: Function to wrap
    
    Returns:
        Wrapped function
    """
    @wraps(func)
    async def async_wrapper(*args, **kwargs):
        logger = logging.getLogger(f"re_fusionx.{func.__module__}")
        start_time = time.time()
        
        try:
            result = await func(*args, **kwargs)
            execution_time = time.time() - start_time
            
            logger.info(
                f"Function executed successfully",
                extra={
                    "function": func.__name__,
                    "execution_time": execution_time,
                    "status": "success"
                }
            )
            
            return result
        except Exception as e:
            execution_time = time.time() - start_time
            
            logger.error(
                f"Function execution failed",
                extra={
                    "function": func.__name__,
                    "execution_time": execution_time,
                    "status": "error",
                    "error": str(e)
                },
                exc_info=True
            )
            
            raise
    
    @wraps(func)
    def sync_wrapper(*args, **kwargs):
        logger = logging.getLogger(f"re_fusionx.{func.__module__}")
        start_time = time.time()
        
        try:
            result = func(*args, **kwargs)
            execution_time = time.time() - start_time
            
            logger.info(
                f"Function executed successfully",
                extra={
                    "function": func.__name__,
                    "execution_time": execution_time,
                    "status": "success"
                }
            )
            
            return result
        except Exception as e:
            execution_time = time.time() - start_time
            
            logger.error(
                f"Function execution failed",
                extra={
                    "function": func.__name__,
                    "execution_time": execution_time,
                    "status": "error",
                    "error": str(e)
                },
                exc_info=True
            )
            
            raise
    
    # Return appropriate wrapper based on function type
    import asyncio
    if asyncio.iscoroutinefunction(func):
        return async_wrapper
    else:
        return sync_wrapper


def setup_logging() -> logging.Logger:
    """
    Configure and setup application logging with Rich formatting.
    
    Returns:
        Configured logger instance
    """
    # Create logs directory
    log_dir = Path("logs")
    log_dir.mkdir(exist_ok=True)
    
    # Configure root logger
    root_logger = logging.getLogger()
    root_logger.setLevel(logging.DEBUG if settings.DEBUG else logging.INFO)
    
    # Remove existing handlers
    root_logger.handlers = []
    
    # Add our custom Rich console handler
    console_handler = RichConsoleHandler()
    console_handler.setLevel(logging.DEBUG if settings.DEBUG else logging.INFO)
    console_handler.addFilter(ContextFilter())
    root_logger.addHandler(console_handler)
    
    # File handler for JSON logs (for debugging/analysis)
    file_handler = logging.handlers.RotatingFileHandler(
        filename=log_dir / "re_fusionx.json",
        maxBytes=10485760,  # 10MB
        backupCount=5,
        encoding='utf-8'
    )
    file_handler.setLevel(logging.DEBUG)
    file_handler.setFormatter(CustomJsonFormatter())
    file_handler.addFilter(ContextFilter())
    root_logger.addHandler(file_handler)
    
    # Error file handler
    error_handler = logging.handlers.RotatingFileHandler(
        filename=log_dir / "re_fusionx_errors.log",
        maxBytes=10485760,
        backupCount=5,
        encoding='utf-8'
    )
    error_handler.setLevel(logging.ERROR)
    error_handler.setFormatter(CustomJsonFormatter())
    error_handler.addFilter(ContextFilter())
    root_logger.addHandler(error_handler)
    
    # Suppress noisy loggers completely
    noisy_loggers = [
        "uvicorn", "uvicorn.access", "uvicorn.error",
        "transformers", "transformers.tokenization_utils", "transformers.modeling_utils",
        "accelerate", "tensorflow", "absl", "grpc",
        "httpx", "httpcore", "urllib3", "requests",
        "PIL", "matplotlib", "torch", "tqdm",
        "asyncio", "concurrent", "multiprocessing"
    ]
    
    for logger_name in noisy_loggers:
        logger = logging.getLogger(logger_name)
        logger.setLevel(logging.ERROR)
        logger.propagate = False
    
    # Create application logger
    app_logger = logging.getLogger("re_fusionx")
    app_logger.setLevel(logging.DEBUG if settings.DEBUG else logging.INFO)
    
    return app_logger


def print_startup_banner():
    """Print beautiful startup banner with system info"""
    import torch
    import platform
    
    # Clear screen
    os.system('cls' if os.name == 'nt' else 'clear')
    
    # Main banner
    banner = Panel(
        Align.center(
            Text.from_markup(
                "[bold cyan]🏠 RE-FusionX v2.0[/bold cyan]\n"
                "[yellow]AI-Powered Turkish Real Estate System[/yellow]\n"
                "[dim]Intelligent Property Analysis & Market Insights[/dim]",
                justify="center"
            )
        ),
        border_style="bright_blue",
        padding=(1, 2)
    )
    
    console.print(banner)
    
    # System information table
    info_table = Table(
        show_header=False,
        box=None,
        padding=(0, 2),
        expand=False
    )
    
    info_table.add_column("", style="cyan", width=20)
    info_table.add_column("", style="green")
    
    # Add system information
    info_table.add_row("📅 Started", datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
    info_table.add_row("🖥️ System", platform.system() + " " + platform.release())
    info_table.add_row("🐍 Python", platform.python_version())
    info_table.add_row("🔥 PyTorch", torch.__version__ if torch else "Not installed")
    info_table.add_row("⚡ Device", "CUDA" if torch.cuda.is_available() else "CPU")
    
    if torch.cuda.is_available():
        info_table.add_row("🎮 GPU", torch.cuda.get_device_name(0))
        info_table.add_row("💾 VRAM", f"{torch.cuda.get_device_properties(0).total_memory / 1024**3:.1f} GB")
    
    info_table.add_row("🔗 API", "http://localhost:8000")
    info_table.add_row("📚 Docs", "http://localhost:8000/api/docs")
    info_table.add_row("🌐 WebSocket", "ws://localhost:8000/ws/{session_id}")
    info_table.add_row("⚙️ Debug", "ON" if settings.DEBUG else "OFF")
    info_table.add_row("📝 Log Level", settings.LOG_LEVEL)
    
    # Display in a nice panel
    console.print(Panel(
        info_table,
        title="System Information",
        border_style="cyan",
        padding=(0, 1)
    ))
    
    console.print()


# Initialize components
logger = setup_logging()
agent_logger = AgentLogger()
progress_tracker = ProgressTracker()

# Export all required components
__all__ = [
    'logger',
    'agent_logger',
    'progress_tracker',
    'console',
    'setup_logging',
    'print_startup_banner',
    'request_id_var',
    'user_id_var',
    'LoggerMixin',
    'log_execution_time',
    'ContextFilter',
    'CustomJsonFormatter'
]
