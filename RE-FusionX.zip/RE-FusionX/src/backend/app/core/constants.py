"""
System-wide constants for RE-FusionX.
Defines all static values used across the application.
"""

from enum import Enum
from typing import Dict, List, Tuple


class SystemInfo:
    """System identity and metadata."""
    NAME = "RE-FusionX"
    VERSION = "2.0.0"
    DEVELOPER = "Mahmoud Almohammad"
    SPECIALIZATION = "Turkish Real Estate Market Analysis"
    SUPPORTED_LANGUAGES = ["en", "tr","ar"]
    

class PropertyType(str, Enum):
    """Property type enumeration."""
    APARTMENT = "Daire"
    VILLA = "Villa"
    RESIDENCE = "Residence"
    DETACHED_HOUSE = "Müstakil Ev"
    OFFICE = "Ofis"
    SHOP = "Dükkan"
    LAND = "Arsa"
    

class RoomConfiguration(str, Enum):
    """Room configuration enumeration."""
    STUDIO = "1+0"
    ONE_PLUS_ONE = "1+1"
    TWO_PLUS_ONE = "2+1"
    THREE_PLUS_ONE = "3+1"
    FOUR_PLUS_ONE = "4+1"
    FOUR_PLUS_TWO = "4+2"
    FIVE_PLUS_ONE = "5+1"
    FIVE_PLUS_TWO = "5+2"
    SIX_PLUS = "6+"
    

class HeatingType(str, Enum):
    """Heating system types."""
    CENTRAL = "Merkezi"
    CENTRAL_METERED = "Merkezi (Pay Ölçer)"
    COMBI = "Kombi Doğalgaz"
    UNDERFLOOR = "Yerden Isıtma"
    AC = "Klima"
    STOVE = "Soba"
    NONE = "Yok"
    

class BuildingAge(str, Enum):
    """Building age categories."""
    NEW = "0"
    ONE_TO_FOUR = "1-4"
    FIVE_TO_TEN = "5-10"
    ELEVEN_TO_FIFTEEN = "11-15"
    SIXTEEN_TO_TWENTY = "16-20"
    TWENTY_ONE_TO_TWENTY_FIVE = "21-25"
    TWENTY_SIX_TO_THIRTY = "26-30"
    THIRTY_PLUS = "31+"
    

class AnalysisType(str, Enum):
    """Types of analysis available."""
    PRICE_ESTIMATION = "price_estimation"
    MARKET_ANALYSIS = "market_analysis"
    INVESTMENT_ANALYSIS = "investment_analysis"
    COMPARATIVE_ANALYSIS = "comparative_analysis"
    LOCATION_ANALYSIS = "location_analysis"
    VISUAL_ANALYSIS = "visual_analysis"
    

class ResponseStatus(str, Enum):
    """API response status codes."""
    SUCCESS = "success"
    ERROR = "error"
    WARNING = "warning"
    PENDING = "pending"
    

class CityTier:
    """City importance tiers for Turkey."""
    TIER_A_PLUS = ["Istanbul", "Ankara", "Izmir"]
    TIER_A = ["Bursa", "Antalya", "Adana", "Konya"]
    TIER_B = ["Kocaeli", "Gaziantep", "Mersin", "Kayseri", "Eskişehir"]
    TIER_C = ["Samsun", "Denizli", "Şanlıurfa", "Malatya", "Kahramanmaraş"]
    

class DistrictGrade:
    """District socioeconomic grades."""
    GRADE_A_PLUS = 10  # Luxury districts
    GRADE_A = 8        # High-end districts
    GRADE_B = 6        # Middle-upper districts
    GRADE_C = 4        # Middle districts
    GRADE_D = 2        # Lower districts
    

class MarketIndicators:
    """Market analysis indicators."""
    GROWTH_THRESHOLD_HIGH = 15  # %
    GROWTH_THRESHOLD_MEDIUM = 10  # %
    GROWTH_THRESHOLD_LOW = 5  # %
    
    ROI_EXCELLENT = 20  # %
    ROI_GOOD = 15  # %
    ROI_AVERAGE = 10  # %
    ROI_POOR = 5  # %
    

class ValidationLimits:
    """Input validation limits."""
    MIN_PRICE = 100_000  # TL
    MAX_PRICE = 100_000_000  # TL
    MIN_SIZE = 20  # m²
    MAX_SIZE = 5000  # m²
    MIN_FLOOR = -2
    MAX_FLOOR = 100
    MIN_ROOMS = 1
    MAX_ROOMS = 20
    

class CacheKeys:
    """Redis cache key prefixes."""
    PROPERTY_ANALYSIS = "analysis:property:"
    SIMILAR_PROPERTIES = "similar:properties:"
    MARKET_DATA = "market:data:"
    LOCATION_DATA = "location:data:"
    SESSION_DATA = "session:data:"
    

class ErrorMessages:
    """Standardized error messages."""
    INVALID_INPUT = "Invalid input provided. Please check your data and try again."
    MISSING_REQUIRED_FIELDS = "Required fields are missing: {fields}"
    MODEL_LOADING_ERROR = "Failed to load AI model. Please try again later."
    ANALYSIS_FAILED = "Analysis failed. Please try again with valid data."
    SESSION_EXPIRED = "Your session has expired. Please start a new conversation."
    RATE_LIMIT_EXCEEDED = "Rate limit exceeded. Please wait before making another request."
    

class SuccessMessages:
    """Standardized success messages."""
    ANALYSIS_COMPLETE = "Property analysis completed successfully."
    DATA_SAVED = "Data saved successfully."
    SESSION_CREATED = "New session created successfully."
