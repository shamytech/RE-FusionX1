"""
Session Context Management
=========================
Handles conversation context and session data structures.
"""

from typing import Dict, Any, List, Optional
from datetime import datetime
from collections import deque
from enum import Enum
from dataclasses import dataclass


class ConversationPhase(Enum):
    """Conversation phases"""
    INITIAL = "initial"
    INFORMATION_GATHERING = "information_gathering"
    ANALYSIS_DISCUSSION = "analysis_discussion"
    CONSTRAINT_HANDLING = "constraint_handling"
    ALTERNATIVES_EXPLORATION = "alternatives_exploration"
    FINALIZATION = "finalization"


class Intent(Enum):
    """User intent types"""
    PROPERTY_VALUATION = "property_valuation"
    MARKET_COMPARISON = "market_comparison"
    MARKET_TRENDS = "market_trends"
    INVESTMENT_ADVICE = "investment_advice"
    LOCATION_ANALYSIS = "location_analysis"
    PROPERTY_SEARCH = "property_search"
    CONSTRAINT_UPDATE = "constraint_update"
    ALTERNATIVES_REQUEST = "alternatives_request"
    GENERAL_INQUIRY = "general_inquiry"
    GREETING = "greeting"
    HELP = "help"


@dataclass
class Message:
    """Message structure"""
    role: str
    content: str
    timestamp: str
    metadata: Dict[str, Any]
    intent: Optional[Intent] = None
    extracted_info: Optional[Dict[str, Any]] = None


@dataclass
class ConversationContext:
    """Complete conversation context"""
    session_id: str
    created_at: str
    last_activity: str
    phase: ConversationPhase
    message_count: int
    
    # Extracted information (cumulative)
    location: Dict[str, Any]
    property: Dict[str, Any]  
    financial: Dict[str, Any]
    purpose: Optional[str]
    preferences: List[str]
    constraints: List[Dict[str, Any]]
    
    # Conversation flow
    messages: deque
    intent_history: List[Intent]
    topics: List[str]
    
    # User profile
    user_profile: Dict[str, Any]
    
    # Analysis status
    information_completeness: Dict[str, Any]
    ready_for_analysis: bool
    
    # Progressive updates tracking
    progressive_updates: Dict[str, Any]
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for serialization"""
        return {
            "session_id": self.session_id,
            "created_at": self.created_at,
            "last_activity": self.last_activity,
            "phase": self.phase.value if isinstance(self.phase, ConversationPhase) else self.phase,
            "message_count": self.message_count,
            "location": self.location,
            "property": self.property,
            "financial": self.financial,
            "purpose": self.purpose,
            "preferences": self.preferences,
            "constraints": self.constraints,
            "messages": list(self.messages),  # Convert deque to list
            "intent_history": [intent.value if isinstance(intent, Intent) else intent for intent in self.intent_history],
            "topics": self.topics,
            "user_profile": self.user_profile,
            "information_completeness": self.information_completeness,
            "ready_for_analysis": self.ready_for_analysis,
            "progressive_updates": self.progressive_updates
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'ConversationContext':
        """Create from dictionary"""
        from collections import deque
        
        # Convert phase back to enum if needed
        phase = data.get("phase", ConversationPhase.GREETING)
        if isinstance(phase, str):
            try:
                phase = ConversationPhase(phase)
            except ValueError:
                phase = ConversationPhase.GREETING
        
        # Convert intent history back to enums
        intent_history = []
        for intent in data.get("intent_history", []):
            if isinstance(intent, str):
                try:
                    intent_history.append(Intent(intent))
                except ValueError:
                    intent_history.append(Intent.GREETING)
            else:
                intent_history.append(intent)
        
        return cls(
            session_id=data.get("session_id", ""),
            created_at=data.get("created_at", ""),
            last_activity=data.get("last_activity", ""),
            phase=phase,
            message_count=data.get("message_count", 0),
            location=data.get("location", {}),
            property=data.get("property", {}),
            financial=data.get("financial", {}),
            purpose=data.get("purpose"),
            preferences=data.get("preferences", []),
            constraints=data.get("constraints", []),
            messages=deque(data.get("messages", [])),  # Convert list back to deque
            intent_history=intent_history,
            topics=data.get("topics", []),
            user_profile=data.get("user_profile", {}),
            information_completeness=data.get("information_completeness", {}),
            ready_for_analysis=data.get("ready_for_analysis", False),
            progressive_updates=data.get("progressive_updates", {})
        )
