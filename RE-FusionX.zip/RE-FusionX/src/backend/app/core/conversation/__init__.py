"""
Conversation Management Module
=============================
Unified conversation handling system.
"""

from .conversation_manager import ConversationManager, get_conversation_manager
from .session_context import ConversationContext, ConversationPhase, Intent, Message
from .message_analyzer import MessageAnalyzer

__all__ = [
    'ConversationManager',
    'get_conversation_manager',
    'ConversationContext',
    'ConversationPhase',
    'Intent',
    'Message',
    'MessageAnalyzer'
]




