"""
Message Analysis Module
======================
Handles LLM-based message analysis with intelligent fallbacks.
"""

import json
import os
from typing import Dict, Any, List, Optional
from datetime import datetime

from app.core.logging import logger
from .session_context import ConversationContext, Intent
from dotenv import load_dotenv
import sys
import os
load_dotenv()

class MessageAnalyzer:
    """
    Unified message analyzer that replaces both Context Manager and Intent Extractor
    """
    
    def __init__(self, model_loader=None):
        """Initialize message analyzer"""
        self.model_loader = model_loader
        self._groq_client = None
        self._ollama_available = None
        
        # Intent keywords for fallback
        self.intent_keywords = {
            Intent.PROPERTY_SEARCH: [
                'buy', 'purchase', 'looking', 'want', 'need', 'search', 'find',
                'apartment', 'house', 'villa', 'property', 'room', 'rooms',
                '1+1', '2+1', '3+1', '4+1', '5+1', 'm2', 'sqm', 'square',
                'budget', 'million', 'thousand', 'tl', 'lira',
                'istanbul', 'ankara', 'izmir', 'kadıköy', 'beşiktaş',
                'satın', 'almak', 'arıyorum', 'istiyorum', 'ev', 'daire'
            ],
            Intent.PROPERTY_VALUATION: [
                'value', 'worth', 'price', 'estimate', 'appraise', 'evaluate',
                'değer', 'fiyat', 'tahmini', 'kaç', 'eder', 'değerleme'
            ],
            Intent.MARKET_COMPARISON: [
                'compare', 'comparison', 'versus', 'vs', 'against',
                'karşılaştır', 'karşı', 'mukayese'
            ],
            Intent.INVESTMENT_ADVICE: [
                'invest', 'investment', 'roi', 'return', 'yield', 'profit',
                'yatırım', 'getiri', 'kar', 'kazanç'
            ],
            Intent.CONSTRAINT_UPDATE: [
                "can't", "cannot", "won't", "unable", "limit", "fixed",
                "yapamam", "olmaz", "imkansız"
            ],
            Intent.ALTERNATIVES_REQUEST: [
                "what if", "instead", "alternative", "other", "different",
                "ya", "başka", "alternatif", "farklı"
            ]
        }
    
    @property
    def groq_client(self):
        """Lazy load Groq client"""
        if self._groq_client is None:
            try:
                from groq import Groq
                groq_key = os.getenv("GROQ_API_KEY")
                if groq_key:
                    self._groq_client = Groq(api_key=groq_key)
                    logger.info("✅ Groq client initialized")
            except Exception as e:
                logger.warning(f"Groq client initialization failed: {e}")
        return self._groq_client
    
    async def analyze_message(
        self, 
        message: str, 
        context: ConversationContext
    ) -> Dict[str, Any]:
        """
        Main analysis method with intelligent fallback
        """
        try:
            # Create conversation history for context
            conversation_history = [
                {
                    "role": msg.role,
                    "content": msg.content,
                    "timestamp": msg.timestamp
                }
                for msg in list(context.messages)[-5:]  # Last 5 messages
            ]
            
            # Try multiple LLM approaches in order - LLM first as requested by user
            analysis_methods = [
                ("Groq", self._analyze_with_groq),
                ("Ollama", self._analyze_with_ollama),
                ("Qwen", self._analyze_with_qwen),
                ("Rule-based", self._analyze_with_rules)  # Fallback only
            ]
            
            for method_name, method_func in analysis_methods:
                try:
                    logger.debug(f"Trying {method_name} for analysis...")
                    
                    result = await method_func(message, conversation_history, context)
                    
                    if result and self._validate_analysis_result(result):
                        logger.info(f"✅ {method_name} analysis successful")
                        result["analysis_method"] = method_name
                        result["timestamp"] = datetime.utcnow().isoformat()
                        return result
                    else:
                        logger.warning(f"⚠️ {method_name} returned invalid result")
                        
                except Exception as e:
                    logger.warning(f"⚠️ {method_name} analysis failed: {e}")
                    continue
            
            # If all methods fail, return basic fallback
            logger.error("All analysis methods failed, using basic fallback")
            return self._create_fallback_analysis(message, conversation_history)
            
        except Exception as e:
            logger.error(f"Message analysis completely failed: {e}")
            return self._create_fallback_analysis(message, [])
    
    async def _analyze_with_groq(
        self, 
        message: str, 
        conversation_history: List[Dict], 
        context: ConversationContext
    ) -> Dict[str, Any]:
        """Analyze with Groq LLaMA"""
        if not self.groq_client:
            raise Exception("Groq client not available")
        
        prompt = self._create_analysis_prompt(message, conversation_history, context)
        
        response = self.groq_client.chat.completions.create(
            model="llama-3.3-70b-versatile",
            messages=[{"role": "user", "content": prompt}],
            temperature=0.1,
            max_completion_tokens=1500,
            response_format={"type": "json_object"}
        )
        
        content = response.choices[0].message.content
        
        if not content or content.strip() == "":
            raise Exception("Groq returned empty content")
        
        # Clean and parse JSON
        if content.startswith('```json'):
            content = content.split('```json')[1].split('```')[0].strip()
        elif content.startswith('```'):
            content = content.split('```')[1].split('```')[0].strip()
        
        return json.loads(content)
    
    async def _analyze_with_ollama(
        self, 
        message: str, 
        conversation_history: List[Dict], 
        context: ConversationContext
    ) -> Dict[str, Any]:
        """Analyze with Ollama"""
        if not self._check_ollama():
            raise Exception("Ollama not available")
        
        import requests
        
        prompt = self._create_analysis_prompt(message, conversation_history, context)
        
        response = requests.post(
            "http://localhost:11434/api/generate",
            json={
                "model": "gpt-oss:20b",
                "prompt": prompt,
                "stream": False,
                "options": {
                    "temperature": 0.1,
                    "num_predict": 1500
                }
            },
            timeout=120
        )
        
        if response.status_code != 200:
            raise Exception(f"Ollama request failed with status {response.status_code}")
        
        result = response.json()
        content = result.get("response", "").strip()
        
        if not content:
            raise Exception("Ollama returned empty content")
        
        # Parse JSON response
        if content.startswith('```json'):
            content = content.split('```json')[1].split('```')[0].strip()
        elif content.startswith('```'):
            content = content.split('```')[1].split('```')[0].strip()
        
        return json.loads(content)
    
    async def _analyze_with_qwen(
        self, 
        message: str, 
        conversation_history: List[Dict], 
        context: ConversationContext
    ) -> Dict[str, Any]:
        """Analyze with Qwen"""
        if not self.model_loader:
            raise Exception("Qwen model loader not available")
        
        prompt = self._create_analysis_prompt(message, conversation_history, context)
        
        qwen_model = await self.model_loader.get_model()
        response = await qwen_model.generate(
            prompt,
            max_tokens=1500,
            temperature=0.1
        )
        
        content = response.strip()
        
        if not content:
            raise Exception("Qwen returned empty content")
        
        # Parse JSON
        if content.startswith('```json'):
            content = content.split('```json')[1].split('```')[0].strip()
        elif content.startswith('```'):
            content = content.split('```')[1].split('```')[0].strip()
        
        return json.loads(content)
    
    async def _analyze_with_rules(
        self, 
        message: str, 
        conversation_history: List[Dict], 
        context: ConversationContext
    ) -> Dict[str, Any]:
        """Rule-based analysis fallback"""
        message_lower = message.lower()
        
        # Detect intent
        detected_intent = Intent.GENERAL_INQUIRY
        confidence = 0.3
        
        for intent, keywords in self.intent_keywords.items():
            matches = sum(1 for keyword in keywords if keyword in message_lower)
            if matches > 0:
                detected_intent = intent
                confidence = min(0.8, 0.3 + (matches * 0.1))
                break
        
        # Extract entities using location manager
        from app.utils.location_utils import get_location_manager
        location_manager = get_location_manager()
        location_info = location_manager.extract_location_from_text(message)
        
        # Extract property and financial info with patterns
        property_info = self._extract_property_patterns(message)
        financial_info = self._extract_financial_patterns(message)
        
        return {
            "intent": {
                "primary_intent": detected_intent.value,
                "confidence": confidence
            },
            "extracted_information": {
                "location": location_info,
                "property": property_info,
                "financial": financial_info,
                "purpose": self._extract_purpose(message_lower)
            },
            "message_relationship": {
                "is_related_to_previous": len(conversation_history) > 0,
                "relationship_type": "continuation"
            },
            "context_signals": {
                "limitation_expressed": any(word in message_lower for word in ["can't", "cannot", "won't"]),
                "alternatives_requested": any(word in message_lower for word in ["what if", "instead", "alternative"])
            },
            "confidence_score": confidence,
            "language": "tr" if any(word in message_lower for word in ["merhaba", "ev", "daire"]) else "en"
        }
    
    def _create_analysis_prompt(
        self, 
        message: str, 
        conversation_history: List[Dict], 
        context: ConversationContext
    ) -> str:
        """Create comprehensive analysis prompt"""
        
        # Build context summary
        context_summary = {
            "current_information": {
                "location": context.location,
                "property": context.property,
                "financial": context.financial,
                "purpose": context.purpose
            },
            "conversation_phase": context.phase.value,
            "message_count": context.message_count,
            "intent_history": [intent.value for intent in context.intent_history[-3:]]
        }
        
        prompt = f"""You are an expert real estate NLU system. Analyze the user's message and classify their intent accurately.

CONVERSATION CONTEXT:
{json.dumps(context_summary, indent=2, ensure_ascii=False)}

RECENT MESSAGES:
{json.dumps(conversation_history[-3:], indent=2, ensure_ascii=False)}

USER MESSAGE: "{message}"

INTENT CLASSIFICATION RULES:
1. **property_search**: User wants to find/buy/rent properties
   - Keywords: "looking", "want", "buy", "purchase", "search", "find", "apartment", "house"
   - Examples: "I want to buy apartment", "looking for 3+1", "130m2 budget 7M TL"

2. **property_valuation**: User wants price estimate for specific property
   - Keywords: "value", "worth", "price", "estimate", "how much"
   - Examples: "What's this worth?", "price estimate", "market value"

3. **market_comparison**: User wants to compare properties/markets
   - Keywords: "compare", "versus", "vs", "better", "difference"

4. **constraint_update**: User expressing limitations/cannot do something
   - Keywords: "can't", "cannot", "too expensive", "budget limit"

5. **alternatives_request**: User asking for different options
   - Keywords: "what if", "instead", "alternative", "other options"

6. **general_inquiry**: Only for greetings or very vague questions
   - Use ONLY when message has NO property-related content

CRITICAL: If message contains ANY property details (size, rooms, budget, location), it's NOT general_inquiry!

Return ONLY this JSON:
{{
    "intent": {{
        "primary_intent": "property_search|property_valuation|market_comparison|constraint_update|alternatives_request|general_inquiry",
        "confidence": 0.95
    }},
    "extracted_information": {{
        "location": {{"city": "", "district": "", "neighborhood": ""}},
        "property": {{"type": "Apartment", "size": 0, "rooms": "", "features": []}},
        "financial": {{"budget": 0, "budget_flexibility": "flexible"}},
        "purpose": "buy|rent|invest|unknown"
    }},
    "context_signals": {{
        "information_provided": true|false,
        "limitation_expressed": false,
        "alternatives_requested": false
    }},
    "confidence_score": 0.95,
    "language": "en"
}}"""
        
        return prompt
    
    def _check_ollama(self) -> bool:
        """Check if Ollama is available"""
        if self._ollama_available is not None:
            return self._ollama_available
        
        try:
            import requests
            response = requests.get("http://localhost:11434/api/tags", timeout=5)
            self._ollama_available = response.status_code == 200
        except:
            self._ollama_available = False
        
        return self._ollama_available
    
    def _validate_analysis_result(self, result: Dict[str, Any]) -> bool:
        """Validate analysis result has required structure"""
        if not isinstance(result, dict):
            return False
        
        required_fields = ["intent", "extracted_information"]
        return all(field in result for field in required_fields)
    
    def _create_fallback_analysis(
        self, 
        message: str, 
        conversation_history: List[Dict]
    ) -> Dict[str, Any]:
        """Create basic fallback analysis"""
        return {
            "intent": {
                "primary_intent": Intent.GENERAL_INQUIRY.value,
                "confidence": 0.3
            },
            "extracted_information": {
                "location": {},
                "property": {},
                "financial": {},
                "purpose": "unknown"
            },
            "message_relationship": {
                "is_related_to_previous": len(conversation_history) > 0,
                "relationship_type": "continuation"
            },
            "context_signals": {
                "limitation_expressed": False,
                "alternatives_requested": False,
                "information_provided": False
            },
            "confidence_score": 0.3,
            "language": "en"
        }
    
    def _extract_property_patterns(self, message: str) -> Dict[str, Any]:
        """Extract property information using patterns"""
        import re
        
        message_lower = message.lower()
        property_info = {}
        
        # Room patterns
        room_match = re.search(r'(\d+\+\d+)', message)
        if room_match:
            property_info["rooms"] = room_match.group(1)
        
        # Size patterns
        size_match = re.search(r'(\d+)\s*(?:m2|m²|square|meter)', message_lower)
        if size_match:
            property_info["size"] = int(size_match.group(1))
        
        # Property type
        if any(word in message_lower for word in ['apartment', 'daire']):
            property_info["type"] = "Apartment"
        elif any(word in message_lower for word in ['house', 'ev', 'villa']):
            property_info["type"] = "House"
        
        return property_info
    
    def _extract_financial_patterns(self, message: str) -> Dict[str, Any]:
        """Extract financial information using patterns"""
        import re
        
        message_lower = message.lower()
        financial_info = {}
        
        # Budget patterns
        budget_patterns = [
            r'(\d+(?:\.\d+)?)\s*(?:million|m)\s*(?:tl|lira)?',
            r'budget.*?(\d+(?:\.\d+)?)\s*(?:million|m)?'
        ]
        
        for pattern in budget_patterns:
            match = re.search(pattern, message_lower)
            if match:
                try:
                    amount = float(match.group(1))
                    if 'million' in match.group(0) or ' m ' in match.group(0):
                        amount *= 1000000
                    financial_info["budget"] = amount
                    break
                except:
                    continue
        
        # Budget flexibility
        if any(word in message_lower for word in ["can't", "cannot", "won't", "fixed"]):
            financial_info["budget_flexibility"] = "fixed"
        
        return financial_info
    
    def _extract_purpose(self, message_lower: str) -> str:
        """Extract purpose from message"""
        if any(word in message_lower for word in ["buy", "purchase", "satın"]):
            return "buy"
        elif any(word in message_lower for word in ["rent", "kira", "lease"]):
            return "rent"
        elif any(word in message_lower for word in ["invest", "yatırım", "investment"]):
            return "invest"
        else:
            return "unknown"
