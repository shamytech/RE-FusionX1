"""
Conversation Manager - Unified system for conversation handling
==============================================================
Replaces multiple separate systems with a single, efficient manager.
"""

import uuid
from typing import Dict, Any, List, Optional
from datetime import datetime

from app.core.logging import logger
from app.core.storage.unified_cache import get_cache, CacheType
from .session_context import ConversationContext, ConversationPhase, Intent, Message
from .message_analyzer import MessageAnalyzer


class ConversationManager:
    """
    Unified conversation manager that handles:
    - Session management
    - Message analysis (replaces Context + Intent agents)
    - Memory management
    - Context tracking
    """
    
    def __init__(self, model_loader=None):
        """Initialize conversation manager"""
        self.model_loader = model_loader
        self._cache = None
        self.analyzer = MessageAnalyzer(model_loader)
        
        logger.info("🚀 ConversationManager initialized")
    
    @property
    def cache(self):
        """Lazy load cache"""
        if self._cache is None:
            # Use unified cache integration
            try:
                from app.core.storage.integration import get_storage_integration
                import asyncio
                try:
                    loop = asyncio.get_event_loop()
                    integration = loop.run_until_complete(get_storage_integration())
                    self._cache = integration.cache
                except RuntimeError:
                    # Fallback if no event loop
                    self._cache = get_cache()
            except Exception as e:
                logger.error(f"Failed to get cache in ConversationManager: {e}")
                self._cache = get_cache()
        return self._cache
    
    async def process_message(
        self,
        message: str,
        session_id: Optional[str] = None,
        role: str = "user",
        metadata: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Process message with unified analysis
        
        Args:
            message: User message
            session_id: Session ID (auto-generated if None)
            role: Message role
            metadata: Additional metadata
            
        Returns:
            Complete analysis result
        """
        try:
            # Generate session ID if not provided
            if not session_id:
                session_id = str(uuid.uuid4())
            
            # Get or create session context
            context = await self._get_or_create_context(session_id)
            
            # Process only user messages for analysis
            analysis_result = {}
            if role == "user":
                # Analyze message
                analysis_result = await self.analyzer.analyze_message(message, context)
                
                # Update context with analysis
                await self._update_context_with_analysis(context, analysis_result)
            
            # Create and add message
            msg = Message(
                role=role,
                content=message,
                timestamp=datetime.utcnow().isoformat(),
                metadata=metadata or {},
                intent=Intent(analysis_result.get("intent", {}).get("primary_intent", "general_inquiry")) if analysis_result and analysis_result.get("intent") else None,
                extracted_info=analysis_result.get("extracted_information", {})
            )
            
            context.messages.append(msg)
            context.message_count += 1
            context.last_activity = datetime.utcnow().isoformat()
            
            # Update conversation phase
            self._update_conversation_phase(context)
            
            # Save updated context
            await self._save_context(context)
            
            # Determine next steps
            next_steps = self._determine_next_steps(context, analysis_result)
            
            return {
                "session_id": session_id,
                "message_processed": True,
                "analysis": analysis_result,
                "context_summary": self._generate_context_summary(context),
                "next_steps": next_steps,
                "conversation_phase": context.phase.value,
                "ready_for_analysis": context.ready_for_analysis,
                "timestamp": datetime.utcnow().isoformat()
            }
            
        except Exception as e:
            logger.error(f"Message processing failed: {e}")
            return {
                "session_id": session_id or "unknown",
                "message_processed": False,
                "error": str(e),
                "analysis": {},
                "next_steps": {"action": "error", "message": "Processing failed"},
                "timestamp": datetime.utcnow().isoformat()
            }
    
    async def _get_or_create_context(self, session_id: str) -> ConversationContext:
        """Get existing context or create new one"""
        cache_key = self.cache.generate_key(CacheType.SESSION, session_id)
        
        cached_data = await self.cache.get(cache_key, CacheType.SESSION)
        
        if cached_data:
            return self._deserialize_context(cached_data)
        
        # Create new context
        now = datetime.utcnow().isoformat()
        
        from collections import deque
        
        context = ConversationContext(
            session_id=session_id,
            created_at=now,
            last_activity=now,
            phase=ConversationPhase.INITIAL,
            message_count=0,
            location={},
            property={},
            financial={},
            purpose=None,
            preferences=[],
            constraints=[],
            messages=deque(maxlen=50),
            intent_history=[],
            topics=[],
            user_profile={
                "created_at": now,
                "preferred_language": "en",
                "communication_style": "neutral",
                "interests": []
            },
            information_completeness={
                "overall_score": 0.0,
                "category_scores": {},
                "missing_categories": [],
                "is_sufficient": False
            },
            ready_for_analysis=False,
            progressive_updates={
                "detected": False,
                "updates": []
            }
        )
        
        await self._save_context(context)
        return context
    
    async def _update_context_with_analysis(
        self, 
        context: ConversationContext, 
        analysis: Dict[str, Any]
    ) -> None:
        """Update context with analysis results"""
        
        # Update intent history
        if analysis.get("intent", {}).get("primary_intent"):
            try:
                intent = Intent(analysis["intent"]["primary_intent"])
                if not context.intent_history or context.intent_history[-1] != intent:
                    context.intent_history.append(intent)
                    context.intent_history = context.intent_history[-10:]  # Keep last 10
            except ValueError:
                pass
        
        # Update cumulative information
        extracted = analysis.get("extracted_information", {})
        
        # Merge information intelligently
        for category in ["location", "property", "financial"]:
            if extracted.get(category):
                current_data = getattr(context, category)
                for key, value in extracted[category].items():
                    if value:  # Only update non-empty values
                        current_data[key] = value
        
        # Update purpose
        if extracted.get("purpose") and extracted["purpose"] != "unknown":
            context.purpose = extracted["purpose"]
        
        # Update information completeness
        context.information_completeness = self._assess_information_completeness(context)
        context.ready_for_analysis = context.information_completeness.get("is_sufficient", False)
    
    def _assess_information_completeness(self, context: ConversationContext) -> Dict[str, Any]:
        """Assess information completeness with stricter criteria"""
        scores = {}
        missing = []
        critical_missing = []
        
        # Location score - MORE STRICT: need district for meaningful analysis
        location_score = 0
        if context.location.get("city"):
            location_score += 0.3  # City alone is not enough
        if context.location.get("district"):
            location_score += 0.7  # District is critical
        scores["location"] = location_score
        if location_score < 0.7:  # Need at least district
            missing.append("location")
            if location_score < 0.3:  # No district at all
                critical_missing.append("location")
        
        # Property score - MORE STRICT: need size AND rooms for analysis
        property_score = 0
        if context.property.get("type"):
            property_score += 0.2
        if context.property.get("size"):
            property_score += 0.4  # Size is critical
        if context.property.get("rooms"):
            property_score += 0.4  # Rooms are critical
        scores["property"] = property_score
        if property_score < 0.6:  # Need size AND rooms
            missing.append("property")
            if property_score < 0.3:  # Very incomplete
                critical_missing.append("property")
        
        # Financial score - STRICT: need budget for search
        financial_score = 0
        if context.financial.get("budget"):
            financial_score += 0.8  # Budget is very important
        if context.purpose:
            financial_score += 0.2
        scores["financial"] = financial_score
        if financial_score < 0.5:
            missing.append("financial")
            if financial_score < 0.2:
                critical_missing.append("financial")
        
        # Overall score
        overall_score = sum(scores.values()) / len(scores)
        
        # STRICTER CRITERIA FOR ANALYSIS
        # Need at least 75% completion for full analysis
        is_sufficient_for_full_analysis = overall_score >= 0.75
        
        # For basic analysis, need at least district + some property info
        has_minimum_for_basic = (
            location_score >= 0.7 and  # At least district
            property_score >= 0.2 and  # At least type
            len(critical_missing) == 0  # No critical gaps
        )
        
        # Generate completion percentage for Orchestrator
        completion_percentage = overall_score * 100
        
        return {
            "overall_score": overall_score,
            "completion_percentage": completion_percentage,
            "category_scores": scores,
            "missing_categories": missing,
            "critical_missing": critical_missing,
            "is_sufficient": is_sufficient_for_full_analysis,
            "can_proceed": has_minimum_for_basic,
            "ready_for_analysis": is_sufficient_for_full_analysis,
            "suggestions": self._generate_completion_suggestions(missing, critical_missing)
        }
    
    def _generate_completion_suggestions(self, missing: List[str], critical_missing: List[str]) -> List[str]:
        """Generate suggestions for missing information"""
        suggestions = []
        
        if "location" in critical_missing:
            suggestions.append("Specific district/neighborhood (prices vary significantly by location)")
        elif "location" in missing:
            suggestions.append("More specific location details (district or neighborhood)")
            
        if "property" in critical_missing:
            suggestions.append("Property details: size (m²) and room configuration (e.g., 3+1)")
        elif "property" in missing:
            if "size" not in [k for k in missing if "property" in k]:
                suggestions.append("Property size in square meters")
            if "rooms" not in [k for k in missing if "property" in k]:
                suggestions.append("Room configuration (e.g., 2+1, 3+1, 4+1)")
                
        if "financial" in critical_missing:
            suggestions.append("Budget range (essential for property recommendations)")
        elif "financial" in missing:
            suggestions.append("Your preferred budget or price range")
            
        return suggestions
    
    def _update_conversation_phase(self, context: ConversationContext) -> None:
        """Update conversation phase"""
        if context.message_count <= 1:
            context.phase = ConversationPhase.INITIAL
        elif not context.ready_for_analysis:
            context.phase = ConversationPhase.INFORMATION_GATHERING
        elif context.ready_for_analysis:
            # Check recent intents for specific phases
            recent_intents = context.intent_history[-3:]
            if Intent.CONSTRAINT_UPDATE in recent_intents:
                context.phase = ConversationPhase.CONSTRAINT_HANDLING
            elif Intent.ALTERNATIVES_REQUEST in recent_intents:
                context.phase = ConversationPhase.ALTERNATIVES_EXPLORATION
            else:
                context.phase = ConversationPhase.ANALYSIS_DISCUSSION
    
    def _determine_next_steps(
        self, 
        context: ConversationContext, 
        analysis: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Determine next steps and required agents"""
        
        # Agent mapping
        intent_agent_map = {
            Intent.PROPERTY_SEARCH: ["property", "market", "location"],
            Intent.PROPERTY_VALUATION: ["property", "market", "location"],
            Intent.MARKET_COMPARISON: ["property", "market"],
            Intent.MARKET_TRENDS: ["market", "location"],
            Intent.INVESTMENT_ADVICE: ["property", "market", "location"],
            Intent.LOCATION_ANALYSIS: ["location", "market"],
            Intent.CONSTRAINT_UPDATE: ["property", "market"],
            Intent.ALTERNATIVES_REQUEST: ["property", "market", "location"],
            Intent.GREETING: ["conversation"],
            Intent.HELP: ["conversation"],
            Intent.GENERAL_INQUIRY: ["conversation"]
        }
        
        # Get primary intent
        primary_intent = None
        if context.intent_history:
            primary_intent = context.intent_history[-1]
        
        # Determine action based on phase
        if context.phase == ConversationPhase.CONSTRAINT_HANDLING:
            return {
                "action": "handle_constraint",
                "message": "I understand your constraint. Let me work within those parameters.",
                "required_agents": intent_agent_map.get(primary_intent, ["property", "market"])
            }
        elif context.phase == ConversationPhase.ALTERNATIVES_EXPLORATION:
            return {
                "action": "provide_alternatives",
                "message": "I'll find alternative options for you.",
                "required_agents": ["property", "market", "location"]
            }
        elif context.ready_for_analysis:
            return {
                "action": "proceed_with_analysis",
                "message": "I have enough information to provide a comprehensive analysis.",
                "required_agents": intent_agent_map.get(primary_intent, ["property", "market", "location"])
            }
        else:
            missing = context.information_completeness.get("missing_categories", [])
            return {
                "action": "gather_information",
                "message": self._generate_information_request(missing),
                "missing_categories": missing,
                "required_agents": ["conversation"]
            }
    
    def _generate_information_request(self, missing_categories: List[str]) -> str:
        """Generate request for missing information"""
        requests = []
        
        if "location" in missing_categories:
            requests.append("which area or district you're interested in")
        if "property" in missing_categories:
            requests.append("property details (size, rooms, type)")
        if "financial" in missing_categories:
            requests.append("your budget range")
        
        if len(requests) == 1:
            return f"To provide better assistance, could you please tell me {requests[0]}?"
        else:
            return f"To provide better assistance, could you please provide: {', '.join(requests)}?"
    
    def _generate_context_summary(self, context: ConversationContext) -> Dict[str, Any]:
        """Generate context summary"""
        return {
            "session_info": {
                "id": context.session_id,
                "phase": context.phase.value,
                "message_count": context.message_count,
                "created_at": context.created_at
            },
            "extracted_information": {
                "location": context.location,
                "property": context.property,
                "financial": context.financial,
                "purpose": context.purpose
            },
            "conversation_flow": {
                "recent_intents": [intent.value for intent in context.intent_history[-3:]],
                "topics": context.topics,
                "preferences": context.preferences,
                "constraints": context.constraints
            },
            "analysis_status": {
                "information_completeness": context.information_completeness,
                "ready_for_analysis": context.ready_for_analysis
            },
            "user_profile": context.user_profile
        }
    
    async def _save_context(self, context: ConversationContext) -> None:
        """Save context to cache"""
        cache_key = self.cache.generate_key(CacheType.SESSION, context.session_id)
        
        serialized = self._serialize_context(context)
        
        await self.cache.set(cache_key, serialized, CacheType.SESSION)
    
    def _serialize_context(self, context: ConversationContext) -> Dict[str, Any]:
        """Serialize context for caching"""
        return {
            "session_id": context.session_id,
            "created_at": context.created_at,
            "last_activity": context.last_activity,
            "phase": context.phase.value,
            "message_count": context.message_count,
            "location": context.location,
            "property": context.property,
            "financial": context.financial,
            "purpose": context.purpose,
            "preferences": context.preferences,
            "constraints": context.constraints,
            "messages": [
                {
                    "role": msg.role,
                    "content": msg.content,
                    "timestamp": msg.timestamp,
                    "metadata": msg.metadata,
                    "intent": msg.intent.value if msg.intent else None,
                    "extracted_info": msg.extracted_info
                }
                for msg in context.messages
            ],
            "intent_history": [intent.value for intent in context.intent_history],
            "topics": context.topics,
            "user_profile": context.user_profile,
            "information_completeness": context.information_completeness,
            "ready_for_analysis": context.ready_for_analysis,
            "progressive_updates": context.progressive_updates
        }
    
    def _deserialize_context(self, data: Dict[str, Any]) -> ConversationContext:
        """Deserialize context from cache"""
        from collections import deque
        
        # Deserialize messages
        messages = deque(maxlen=50)
        for msg_data in data.get("messages", []):
            # Handle both dict and Message objects
            if isinstance(msg_data, dict):
                # It's a dictionary
                intent = None
                if msg_data.get("intent"):
                    try:
                        intent = Intent(msg_data["intent"])
                    except ValueError:
                        pass
                
                message = Message(
                    role=msg_data["role"],
                    content=msg_data["content"],
                    timestamp=msg_data["timestamp"],
                    metadata=msg_data.get("metadata", {}),
                    intent=intent,
                    extracted_info=msg_data.get("extracted_info")
                )
                messages.append(message)
            else:
                # It's already a Message object, use as-is
                messages.append(msg_data)
        
        # Deserialize intent history
        intent_history = []
        for intent_value in data.get("intent_history", []):
            try:
                intent_history.append(Intent(intent_value))
            except ValueError:
                pass
        
        # Deserialize phase
        try:
            phase = ConversationPhase(data.get("phase", "initial"))
        except ValueError:
            phase = ConversationPhase.INITIAL
        
        return ConversationContext(
            session_id=data["session_id"],
            created_at=data["created_at"],
            last_activity=data["last_activity"],
            phase=phase,
            message_count=data.get("message_count", 0),
            location=data.get("location", {}),
            property=data.get("property", {}),
            financial=data.get("financial", {}),
            purpose=data.get("purpose"),
            preferences=data.get("preferences", []),
            constraints=data.get("constraints", []),
            messages=messages,
            intent_history=intent_history,
            topics=data.get("topics", []),
            user_profile=data.get("user_profile", {}),
            information_completeness=data.get("information_completeness", {}),
            ready_for_analysis=data.get("ready_for_analysis", False),
            progressive_updates=data.get("progressive_updates", {"detected": False, "updates": []})
        )
    
    async def get_session_summary(self, session_id: str) -> Optional[Dict[str, Any]]:
        """Get session summary"""
        try:
            context = await self._get_or_create_context(session_id)
            return self._generate_context_summary(context)
        except Exception as e:
            logger.error(f"Failed to get session summary: {e}")
            return None
    
    async def delete_session(self, session_id: str) -> bool:
        """Delete session"""
        try:
            cache_key = self.cache.generate_key(CacheType.SESSION, session_id)
            return await self.cache.delete(cache_key)
        except Exception as e:
            logger.error(f"Failed to delete session: {e}")
            return False
    
    async def get_conversation_history(self, session_id: str) -> List[Dict[str, Any]]:
        """Get conversation history for compatibility"""
        try:
            context = await self._get_or_create_context(session_id)
            
            # Convert deque messages to list of dicts
            history = []
            for msg in context.messages:
                if isinstance(msg, dict):
                    # Already a dict
                    history.append(msg)
                else:
                    # Convert Message object to dict
                    history.append({
                        "role": msg.role if hasattr(msg, 'role') else 'unknown',
                        "content": msg.content if hasattr(msg, 'content') else '',
                        "timestamp": msg.timestamp if hasattr(msg, 'timestamp') else '',
                        "metadata": msg.metadata if hasattr(msg, 'metadata') else {}
                    })
            
            return history
        except Exception as e:
            logger.error(f"Failed to get conversation history: {e}")
            return []
    
    async def add_message_to_history(self, session_id: str, role: str, content: str, metadata: Optional[Dict] = None):
        """Add message to conversation history for compatibility"""
        try:
            context = await self._get_or_create_context(session_id)
            
            # Create message dict (compatible with deque)
            message = {
                "role": role,
                "content": content,
                "timestamp": datetime.utcnow().isoformat(),
                "metadata": metadata or {}
            }
            
            # Add to messages deque
            context.messages.append(message)
            
            # Update message count
            context.message_count += 1
            context.last_activity = datetime.utcnow().isoformat()
            
            # Save updated context
            cache_key = self.cache.generate_key(CacheType.SESSION, session_id)
            await self.cache.set(cache_key, context.to_dict(), CacheType.SESSION)
            
        except Exception as e:
            logger.error(f"Failed to add message to history: {e}")
    
    async def clear_session(self, session_id: str) -> bool:
        """Clear session for compatibility"""
        return await self.delete_session(session_id)


# Singleton
_conversation_manager = None

def get_conversation_manager(model_loader=None) -> ConversationManager:
    """Get conversation manager singleton"""
    global _conversation_manager
    if _conversation_manager is None:
        _conversation_manager = ConversationManager(model_loader)
    return _conversation_manager
