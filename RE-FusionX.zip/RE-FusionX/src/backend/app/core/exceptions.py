"""
Custom exception classes for RE-FusionX.
Provides structured error handling across the application.
"""

from typing import Optional, Dict, Any, List
from fastapi import HTTPException, status


class REFusionXException(Exception):
    """Base exception class for RE-FusionX application."""
    
    def __init__(
        self,
        message: str,
        error_code: Optional[str] = None,
        details: Optional[Dict[str, Any]] = None
    ):
        """
        Initialize exception with structured information.
        
        Args:
            message: Human-readable error message
            error_code: Machine-readable error code
            details: Additional error details
        """
        self.message = message
        self.error_code = error_code or "GENERIC_ERROR"
        self.details = details or {}
        super().__init__(self.message)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert exception to dictionary for API responses."""
        return {
            "error": self.error_code,
            "message": self.message,
            "details": self.details
        }


class ValidationException(REFusionXException):
    """Exception raised for validation errors."""
    
    def __init__(
        self,
        message: str,
        field: Optional[str] = None,
        invalid_value: Optional[Any] = None
    ):
        """
        Initialize validation exception.
        
        Args:
            message: Validation error message
            field: Field that failed validation
            invalid_value: The invalid value provided
        """
        details = {}
        if field:
            details["field"] = field
        if invalid_value is not None:
            details["invalid_value"] = str(invalid_value)
        
        super().__init__(
            message=message,
            error_code="VALIDATION_ERROR",
            details=details
        )


class ModelException(REFusionXException):
    """Exception raised for model-related errors."""
    
    def __init__(
        self,
        message: str,
        model_name: Optional[str] = None,
        operation: Optional[str] = None
    ):
        """
        Initialize model exception.
        
        Args:
            message: Error message
            model_name: Name of the model that failed
            operation: Operation that failed (load, predict, etc.)
        """
        details = {}
        if model_name:
            details["model"] = model_name
        if operation:
            details["operation"] = operation
        
        super().__init__(
            message=message,
            error_code="MODEL_ERROR",
            details=details
        )


class DataNotFoundException(REFusionXException):
    """Exception raised when requested data is not found."""
    
    def __init__(
        self,
        message: str,
        resource_type: Optional[str] = None,
        resource_id: Optional[str] = None
    ):
        """
        Initialize data not found exception.
        
        Args:
            message: Error message
            resource_type: Type of resource not found
            resource_id: ID of resource not found
        """
        details = {}
        if resource_type:
            details["resource_type"] = resource_type
        if resource_id:
            details["resource_id"] = resource_id
        
        super().__init__(
            message=message,
            error_code="DATA_NOT_FOUND",
            details=details
        )


class ExternalServiceException(REFusionXException):
    """Exception raised for external service failures."""
    
    def __init__(
        self,
        message: str,
        service_name: Optional[str] = None,
        status_code: Optional[int] = None
    ):
        """
        Initialize external service exception.
        
        Args:
            message: Error message
            service_name: Name of the failed service
            status_code: HTTP status code if applicable
        """
        details = {}
        if service_name:
            details["service"] = service_name
        if status_code:
            details["status_code"] = status_code
        
        super().__init__(
            message=message,
            error_code="EXTERNAL_SERVICE_ERROR",
            details=details
        )


class RateLimitException(REFusionXException):
    """Exception raised when rate limit is exceeded."""
    
    def __init__(
        self,
        message: str = "Rate limit exceeded",
        retry_after: Optional[int] = None
    ):
        """
        Initialize rate limit exception.
        
        Args:
            message: Error message
            retry_after: Seconds until retry is allowed
        """
        details = {}
        if retry_after:
            details["retry_after"] = retry_after
        
        super().__init__(
            message=message,
            error_code="RATE_LIMIT_EXCEEDED",
            details=details
        )


class InsufficientDataException(REFusionXException):
    """Exception raised when insufficient data is provided for analysis."""
    
    def __init__(
        self,
        message: str,
        required_fields: Optional[List[str]] = None,
        provided_fields: Optional[List[str]] = None
    ):
        """
        Initialize insufficient data exception.
        
        Args:
            message: Error message
            required_fields: List of required fields
            provided_fields: List of provided fields
        """
        details = {}
        if required_fields:
            details["required_fields"] = required_fields
        if provided_fields:
            details["provided_fields"] = provided_fields
        if required_fields and provided_fields:
            missing = set(required_fields) - set(provided_fields)
            details["missing_fields"] = list(missing)
        
        super().__init__(
            message=message,
            error_code="INSUFFICIENT_DATA",
            details=details
        )


def create_http_exception(
    exception: REFusionXException,
    status_code: int = status.HTTP_400_BAD_REQUEST
) -> HTTPException:
    """
    Convert custom exception to FastAPI HTTPException.
    
    Args:
        exception: Custom exception instance
        status_code: HTTP status code
    
    Returns:
        HTTPException with structured detail
    """
    return HTTPException(
        status_code=status_code,
        detail=exception.to_dict()
    )
