"""
Unified Cache System for RE-FusionX
====================================
Single caching solution for all data types
"""

import json
import hashlib
import asyncio
from typing import Dict, Any, Optional, Union, List
from datetime import datetime, timedelta
from pathlib import Path
import pickle
from enum import Enum

from app.core.logging import logger
from app.core.config import settings
from app.utils.location_utils import normalize_text


class CacheType(Enum):
    """Cache types with different TTLs"""
    SESSION = "session"          # 24 hours
    PROPERTY = "property"        # 6 hours  
    MARKET = "market"           # 24 hours
    NEWS = "news"              # 12 hours
    SEARCH = "search"          # 1 hour
    API = "api"               # 30 minutes

class UnifiedCache:
    """
    Unified caching system with Redis support and memory fallback
    """
    def __init__(self):
        """Initialize unified cache"""
        self.redis_client = None
        self.memory_cache = {}
        self.cache_stats = {
            "hits": 0,
            "misses": 0,
            "evictions": 0
        }
        
        # TTL configurations (in seconds)
        self.ttl_config = {
            CacheType.SESSION: 86400,    # 24 hours
            CacheType.PROPERTY: 21600,   # 6 hours
            CacheType.MARKET: 86400,     # 24 hours
            CacheType.NEWS: 43200,       # 12 hours
            CacheType.SEARCH: 3600,      # 1 hour
            CacheType.API: 1800          # 30 minutes
        }
        
        # Initialize Redis if available
        self._init_redis()
        
        logger.info("✅ UnifiedCache initialized")
    
    def _init_redis(self):
        """Initialize Redis connection if available"""
        if hasattr(settings, 'REDIS_URL') and settings.REDIS_URL:
            try:
                import redis.asyncio as redis
                self.redis_client = redis.from_url(
                    settings.REDIS_URL,
                    decode_responses=True
                )
                logger.info("✅ Redis cache initialized")
            except ImportError:
                logger.info("📦 Redis not installed, using memory cache")
            except Exception as e:
                logger.warning(f"⚠️ Redis connection failed: {e}, using memory cache")
    
    def generate_key(self, cache_type: CacheType, identifier: str, params: Optional[Dict[str, Any]] = None) -> str:
        """
        Generate normalized cache key for consistent access
        """
        # تطبيع المعرف
        normalized_identifier = normalize_text(identifier).replace(' ', '_').replace('-', '_')
        
        key_parts = [cache_type.value, normalized_identifier]
        
        if params:
            # تطبيع المعاملات
            normalized_params = {}
            for k, v in params.items():
                if isinstance(v, str):
                    normalized_params[k] = normalize_text(v)
                else:
                    normalized_params[k] = v
            
            param_str = json.dumps(normalized_params, sort_keys=True)
            param_hash = hashlib.md5(param_str.encode()).hexdigest()[:8]
            key_parts.append(param_hash)
        
        return ":".join(key_parts)

    async def get(self, key: str, cache_type: Optional[CacheType] = None) -> Optional[Any]:
        """
        Get value from cache
        
        Args:
            key: Cache key
            cache_type: Optional cache type for validation
            
        Returns:
            Cached value or None
        """
        try:
            # Try Redis first
            if self.redis_client:
                try:
                    value = await self.redis_client.get(key)
                    if value:
                        self.cache_stats["hits"] += 1
                        return json.loads(value) if isinstance(value, str) else value
                except Exception as e:
                    logger.debug(f"Redis get failed: {e}")
            
            # Fallback to memory cache
            if key in self.memory_cache:
                entry = self.memory_cache[key]
                if datetime.now() < entry['expires']:
                    self.cache_stats["hits"] += 1
                    return entry['value']
                else:
                    # Expired, remove it
                    del self.memory_cache[key]
            
            self.cache_stats["misses"] += 1
            return None
            
        except Exception as e:
            logger.error(f"Cache get error: {e}")
            return None
    
    async def set(self, key: str, value: Any, cache_type: CacheType = CacheType.API, ttl_override: Optional[int] = None) -> bool:
        """
        Set value in cache
        
        Args:
            key: Cache key
            value: Value to cache
            cache_type: Type of cache for TTL
            ttl_override: Override TTL in seconds
            
        Returns:
            Success status
        """
        try:
            ttl = ttl_override or self.ttl_config.get(cache_type, 3600)
            
            # Try Redis first
            if self.redis_client:
                try:
                    serialized = json.dumps(value, default=str)
                    await self.redis_client.setex(key, ttl, serialized)
                    return True
                except Exception as e:
                    logger.debug(f"Redis set failed: {e}")
            
            # Fallback to memory cache
            self.memory_cache[key] = {
                'value': value,
                'expires': datetime.now() + timedelta(seconds=ttl),
                'type': cache_type.value
            }
            
            # Clean old entries if cache is too large
            if len(self.memory_cache) > 1000:
                self._cleanup_memory_cache()
            
            return True
            
        except Exception as e:
            logger.error(f"Cache set error: {e}")
            return False
    
    async def delete(self, key: str) -> bool:
        """Delete key from cache"""
        deleted = False
        
        # Delete from Redis
        if self.redis_client:
            try:
                await self.redis_client.delete(key)
                deleted = True
            except:
                pass
        
        # Delete from memory
        if key in self.memory_cache:
            del self.memory_cache[key]
            deleted = True
        
        if deleted:
            self.cache_stats["evictions"] += 1
        
        return deleted
    
    async def clear_pattern(self, pattern: str) -> int:
        """
        Clear all keys matching pattern
        
        Args:
            pattern: Pattern to match (e.g., "property:*")
            
        Returns:
            Number of keys deleted
        """
        count = 0
        
        # Clear from Redis
        if self.redis_client:
            try:
                keys = await self.redis_client.keys(pattern)
                if keys:
                    count += await self.redis_client.delete(*keys)
            except:
                pass
        
        # Clear from memory
        keys_to_delete = [k for k in self.memory_cache if k.startswith(pattern.replace('*', ''))]
        for key in keys_to_delete:
            del self.memory_cache[key]
            count += 1
        
        self.cache_stats["evictions"] += count
        return count
    
    def _cleanup_memory_cache(self):
        """Clean up expired entries from memory cache"""
        now = datetime.now()
        expired = [
            key for key, entry in self.memory_cache.items()
            if now >= entry['expires']
        ]
        
        for key in expired:
            del self.memory_cache[key]
        
        # If still too large, remove oldest entries
        if len(self.memory_cache) > 800:
            sorted_entries = sorted(
                self.memory_cache.items(),
                key=lambda x: x[1]['expires']
            )
            
            # Keep only newest 800 entries
            self.memory_cache = dict(sorted_entries[-800:])
    
    async def get_or_set(self, key: str, factory_func, cache_type: CacheType = CacheType.API, ttl_override: Optional[int] = None) -> Any:
        """
        Get from cache or compute and set
        
        Args:
            key: Cache key
            factory_func: Async function to compute value if not cached
            cache_type: Cache type
            ttl_override: Override TTL
            
        Returns:
            Cached or computed value
        """
        # Try to get from cache
        value = await self.get(key, cache_type)
        
        if value is not None:
            return value
        
        # Compute value
        value = await factory_func()
        
        # Cache it
        if value is not None:
            await self.set(key, value, cache_type, ttl_override)
        
        return value
    
    def get_stats(self) -> Dict[str, Any]:
        """Get cache statistics"""
        total_requests = self.cache_stats["hits"] + self.cache_stats["misses"]
        
        return {
            **self.cache_stats,
            "memory_entries": len(self.memory_cache),
            "hit_rate": self.cache_stats["hits"] / total_requests if total_requests > 0 else 0,
            "redis_connected": self.redis_client is not None
        }
    
    async def close(self):
        """Close cache connections"""
        if self.redis_client:
            await self.redis_client.close()
        
        self.memory_cache.clear()
        logger.info("Cache closed")


# Singleton instance
_cache_instance = None
_creating_cache = False

def get_cache() -> UnifiedCache:
    """Get cache singleton safely"""
    global _cache_instance, _creating_cache
    
    if _cache_instance is None and not _creating_cache:
        _creating_cache = True
        try:
            _cache_instance = UnifiedCache()
        finally:
            _creating_cache = False
    
    return _cache_instance