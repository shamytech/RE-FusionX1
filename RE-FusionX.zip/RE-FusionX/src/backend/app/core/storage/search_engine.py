"""
Fast Search Client
==================
High-performance search client for local data
"""

import duckdb
import pandas as pd
from pathlib import Path
from typing import Dict, Any, List, Optional, Union
from datetime import datetime, timedelta
import numpy as np

from app.core.logging import logger
from app.utils.location_utils import normalize_text, get_location_manager


class SearchEngine:
    """
    Fast search client using DuckDB for in-memory queries
    """
    
    def __init__(self, data_dir: Path):
        """Initialize fast search client"""
        self.data_dir = Path(data_dir)
        self.outputs_dir = self.data_dir / "outputs"
        self.conn = duckdb.connect(":memory:")
        
        # Ensure directories exist
        self.outputs_dir.mkdir(parents=True, exist_ok=True)
        (self.outputs_dir / "properties").mkdir(exist_ok=True)
        (self.outputs_dir / "market_data").mkdir(exist_ok=True)
        (self.outputs_dir / "news").mkdir(exist_ok=True)
        
        self._load_data()
    
    def _load_data(self):
        """Load all Parquet files into DuckDB"""
        # Load properties
        self._load_properties()
        
        # Load market data
        self._load_market_data()
        
        # Load news
        self._load_news()
        
        # Create indexes
        self._create_indexes()
    
    def _load_properties(self):
        """Load property data with smart hierarchical search"""
        properties_path = self.outputs_dir / "properties"
        
        if not properties_path.exists():
            logger.warning(f"Properties directory not found: {properties_path}")
            self._create_empty_properties_view()
            return
        
        # Collect all parquet files recursively
        parquet_files = []
        for parquet_file in properties_path.rglob("*.parquet"):
            # Skip index files
            if "index" not in str(parquet_file).lower():
                parquet_files.append(parquet_file)
        
        if parquet_files:
            try:
                # Convert paths to string with forward slashes
                file_list = [str(f).replace("\\", "/") for f in parquet_files]
                
                # Log what we're loading
                logger.info(f"Loading {len(file_list)} property files...")
                
                # Create view with all files
                if len(file_list) == 1:
                    query = f"""
                        CREATE OR REPLACE VIEW properties AS 
                        SELECT * FROM read_parquet('{file_list[0]}')
                    """
                else:
                    # Use list for multiple files
                    files_str = str(file_list).replace("'", '"')
                    query = f"""
                        CREATE OR REPLACE VIEW properties AS 
                        SELECT * FROM read_parquet({files_str}, union_by_name=true)
                    """
                
                self.conn.execute(query)
                
                # Verify and log
                count = self.conn.execute("SELECT COUNT(*) FROM properties").fetchone()[0]
                
                # Get location distribution
                location_stats = self.conn.execute("""
                    SELECT city, district, COUNT(*) as count 
                    FROM properties 
                    WHERE city IS NOT NULL 
                    GROUP BY city, district 
                    ORDER BY count DESC 
                    LIMIT 5
                """).fetchdf()
                
                logger.info(f"✅ Loaded {count} properties from {len(parquet_files)} files")
                if not location_stats.empty:
                    # Normalize Istanbul spelling in logs for consistency
                    def _normalize_city_name(name: str) -> str:
                        if not isinstance(name, str):
                            return name
                        n = name.replace('İ', 'I').replace('ı', 'i')
                        n = n.replace('İstanbul', 'Istanbul').replace('istanbul', 'Istanbul')
                        if n.lower() == 'istanbul':
                            return 'Istanbul'
                        return name
                    stats = location_stats.to_dict('records')
                    for row in stats:
                        if 'city' in row:
                            row['city'] = _normalize_city_name(row['city'])
                    logger.info(f"Top locations: {stats}")
                
            except Exception as e:
                logger.error(f"Could not load property files: {e}", exc_info=True)
                self._create_empty_properties_view()
        else:
            logger.info("No property parquet files found, creating empty view")
            self._create_empty_properties_view()

    def _load_market_data(self):
        """Load market data with error handling"""
        market_path = self.outputs_dir / "market_data"
        parquet_files = list(market_path.glob("**/*.parquet"))
        
        if parquet_files:
            try:
                market_pattern = str(market_path / "**" / "*.parquet").replace("\\", "/")
                self.conn.execute(f"""
                    CREATE OR REPLACE VIEW market_data AS 
                    SELECT * FROM read_parquet('{market_pattern}')
                """)
                
                count = self.conn.execute("SELECT COUNT(*) FROM market_data").fetchone()[0]
                logger.info(f"Loaded {count} market data points")
            except Exception as e:
                logger.warning(f"Could not load market data: {e}")
                self._create_empty_market_view()
        else:
            self._create_empty_market_view()
    
    def _load_news(self):
        """Load news data with error handling"""
        news_path = self.outputs_dir / "news"
        parquet_files = list(news_path.glob("*.parquet"))
        
        if parquet_files:
            try:
                news_pattern = str(news_path / "*.parquet").replace("\\", "/")
                self.conn.execute(f"""
                    CREATE OR REPLACE VIEW news AS 
                    SELECT * FROM read_parquet('{news_pattern}')
                """)
                
                count = self.conn.execute("SELECT COUNT(*) FROM news").fetchone()[0]
                logger.info(f"Loaded {count} news articles")
            except Exception as e:
                logger.warning(f"Could not load news data: {e}")
                self._create_empty_news_view()
        else:
            self._create_empty_news_view()
    
    def _create_empty_properties_view(self):
        """Create empty properties view with schema"""
        self.conn.execute("""
             CREATE OR REPLACE VIEW properties AS 
        SELECT 
            '' as listing_id,
            '' as title,
            '' as location,
            '' as city,
            '' as district,
            '' as neighborhood,
            0.0 as price,
            '' as price_raw,
            '' as property_type,
            '' as rooms,
            '' as floor_text,
            '' as area_text,
            0 as size,
            '' as url,
            '' as source,
            0 as scraped_at,
            0.0 as price_per_sqm,
            0 as room_count,
            '' as location_full,
            0 as floor,
            '' as image_url,
            '' as property_id
        WHERE 1=0
        """)
    
    def _create_empty_market_view(self):
        """Create empty market data view"""
        self.conn.execute("""
            CREATE OR REPLACE VIEW market_data AS 
            SELECT 
                '' as indicator_name,
                '' as location,
                0.0 as value,
                0.0 as change_percent,
                '' as trend,
                CURRENT_DATE as date
            WHERE 1=0
        """)
    
    def _create_empty_news_view(self):
        """Create empty news view"""
        self.conn.execute("""
            CREATE OR REPLACE VIEW news AS 
            SELECT 
                '' as article_id,
                '' as title,
                '' as content,
                '' as sentiment,
                CURRENT_TIMESTAMP as collected_at
            WHERE 1=0
        """)
    
    def _create_indexes(self):
        """Create indexes for fast searching"""
        try:
            # Check if we have data before creating summary views
            prop_count = self.conn.execute("SELECT COUNT(*) FROM properties").fetchone()[0]
            
            if prop_count > 0:
                self.conn.execute("""
                    CREATE OR REPLACE VIEW property_summary AS
                    SELECT 
                        city,
                        district,
                        COUNT(*) as count,
                        AVG(price) as avg_price,
                        MIN(price) as min_price,
                        MAX(price) as max_price,
                        AVG(price_per_sqm) as avg_price_per_sqm
                    FROM properties
                    GROUP BY city, district
                """)
            else:
                # Create empty summary view
                self.conn.execute("""
                    CREATE OR REPLACE VIEW property_summary AS
                    SELECT 
                        '' as city,
                        '' as district,
                        0 as count,
                        0.0 as avg_price,
                        0.0 as min_price,
                        0.0 as max_price,
                        0.0 as avg_price_per_sqm
                    WHERE 1=0
                """)
            
            # Market trends view
            market_count = self.conn.execute("SELECT COUNT(*) FROM market_data").fetchone()[0]
            
            if market_count > 0:
                self.conn.execute("""
                    CREATE OR REPLACE VIEW market_trends AS
                    SELECT 
                        location,
                        indicator_name,
                        date,
                        value,
                        change_percent,
                        trend
                    FROM market_data
                    WHERE date >= CURRENT_DATE - INTERVAL '90 days'
                    ORDER BY date DESC
                """)
            else:
                self.conn.execute("""
                    CREATE OR REPLACE VIEW market_trends AS
                    SELECT 
                        '' as location,
                        '' as indicator_name,
                        CURRENT_DATE as date,
                        0.0 as value,
                        0.0 as change_percent,
                        '' as trend
                    WHERE 1=0
                """)
                
        except Exception as e:
            logger.warning(f"Could not create indexes: {e}")   

    def refresh_properties_view(self) -> None:
        """Refresh the properties DuckDB view to include newly saved Parquet files"""
        try:
            self._load_properties()
            # Print new row count for certainty
            try:
                count = self.conn.execute("SELECT COUNT(*) FROM properties").fetchone()[0]
                logger.info(f"✅ Properties view refreshed (rows={count})")
            except Exception:
                logger.info("✅ Properties view refreshed")
        except Exception as e:
            logger.warning(f"Failed to refresh properties view: {e}")

    def search_properties(self, query: Optional[str] = None, filters: Optional[Dict[str, Any]] = None, limit: int = 100) -> pd.DataFrame:
        """
        Ultra-fast property search with proper Turkish character handling
        """
        try:
            # Get available columns
            columns_query = "SELECT * FROM properties LIMIT 1"
            sample = self.conn.execute(columns_query).fetchdf()
            
            if sample.empty:
                logger.warning("No data in properties table")
                return pd.DataFrame()
            
            available_columns = list(sample.columns)
            sql_parts = ["SELECT * FROM properties WHERE 1=1"]
            
            # Handle location filter
            if filters and filters.get("location"):
                location_str = filters["location"]
                location_manager = get_location_manager()
                
                # Parse location
                location_info = location_manager.parse_location(location_str)
                
                conditions = []
                
                # SQL normalization - comprehensive
                def create_normalize_sql(column_name):
                    """Create SQL for normalizing Turkish characters"""
                    return f"""
                        LOWER(
                            REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(
                            REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(
                                {column_name},
                                'İ', 'i'), 'I', 'i'), 'ı', 'i'), 'i̇', 'i'),
                                'Ğ', 'g'), 'ğ', 'g'),
                                'Ü', 'u'), 'ü', 'u'),
                                'Ş', 's'), 'ş', 's'),
                                'Ö', 'o'), 'ö', 'o'),
                                'Ç', 'c'), 'ç', 'c')
                        )
                    """
                
                # Python normalization for comparison values
                def normalize_for_sql(text):
                    if not text:
                        return ""
                    text = text.lower()
                    # Replace all variations of i
                    text = text.replace('İ', 'i').replace('I', 'i').replace('ı', 'i').replace('i̇', 'i')
                    # Replace other Turkish chars
                    text = text.replace('ğ', 'g').replace('Ğ', 'g')
                    text = text.replace('ü', 'u').replace('Ü', 'u')
                    text = text.replace('ş', 's').replace('Ş ','s')
                    text = text.replace('ö', 'o').replace('Ö', 'o')
                    text = text.replace('ç', 'c').replace('Ç', 'c')
                    return text
                
                # Build search conditions
                if location_info["city"]:
                    city_norm = normalize_for_sql(location_info["city"])
                    
                    if location_info["district"]:
                        district_norm = normalize_for_sql(location_info["district"])
                        
                        # Exact match
                        conditions.append(f"""
                            ({create_normalize_sql('city')} = '{city_norm}' 
                            AND {create_normalize_sql('district')} = '{district_norm}')
                        """)
                        
                        # Partial match
                        conditions.append(f"""
                            ({create_normalize_sql('city')} LIKE '%{city_norm}%' 
                            AND {create_normalize_sql('district')} LIKE '%{district_norm}%')
                        """)
                    else:
                        # City only
                        conditions.append(f"{create_normalize_sql('city')} = '{city_norm}'")
                        conditions.append(f"{create_normalize_sql('city')} LIKE '%{city_norm}%'")
                
                elif location_info["district"]:
                    # District only
                    district_norm = normalize_for_sql(location_info["district"])
                    conditions.append(f"{create_normalize_sql('district')} = '{district_norm}'")
                    conditions.append(f"{create_normalize_sql('district')} LIKE '%{district_norm}%'")
                
                else:
                    # Fallback: parse as text
                    location_norm = normalize_for_sql(location_str)
                    # Remove separators
                    location_norm = location_norm.replace('-', ' ').replace('/', ' ').strip()
                    parts = location_norm.split()
                    
                    for part in parts:
                        if len(part) > 2:
                            part_conditions = []
                            for field in ['city', 'district', 'neighborhood']:
                                if field in available_columns:
                                    part_conditions.append(f"{create_normalize_sql(field)} LIKE '%{part}%'")
                            
                            if part_conditions:
                                conditions.append(f"({' OR '.join(part_conditions)})")
                
                # Apply conditions
                if conditions:
                    sql_parts.append(f"AND ({' OR '.join(conditions)})")
                
                logger.debug(f"Search conditions for '{location_str}': {len(conditions)} conditions")
            
            # Handle text query
            if query:
                query_norm = normalize_for_sql(query) if 'normalize_for_sql' in locals() else query.lower()
                search_conditions = []
                
                for column in ['location', 'city', 'district', 'neighborhood', 'title']:
                    if column in available_columns:
                        search_conditions.append(f"{create_normalize_sql(column)} LIKE '%{query_norm}%'")
                
                if search_conditions:
                    sql_parts.append(f"AND ({' OR '.join(search_conditions)})")
            
            # Add other filters
            if filters:
                if 'price' in available_columns:
                    if filters.get("min_price"):
                        sql_parts.append(f"AND price >= {filters['min_price']}")
                    if filters.get("max_price"):
                        sql_parts.append(f"AND price <= {filters['max_price']}")
                
                if 'size' in available_columns:
                    if filters.get("min_size"):
                        sql_parts.append(f"AND size >= {filters['min_size']}")
                    if filters.get("max_size"):
                        sql_parts.append(f"AND size <= {filters['max_size']}")
                
                if 'rooms' in available_columns and filters.get("rooms"):
                    rooms = filters["rooms"]
                    if isinstance(rooms, list):
                        rooms_str = "', '".join(rooms)
                        sql_parts.append(f"AND rooms IN ('{rooms_str}')")
                    else:
                        sql_parts.append(f"AND rooms = '{rooms}'")
            
            # Order and limit
            if 'scraped_at' in available_columns:
                sql_parts.append("ORDER BY scraped_at DESC")
            
            sql_parts.append(f"LIMIT {limit}")
            
            # Execute
            query_sql = " ".join(sql_parts)
            logger.debug(f"SQL: {query_sql[:500]}...")
            
            result = self.conn.execute(query_sql).fetchdf()
            
            if not result.empty:
                logger.info(f"✅ Found {len(result)} properties")
            else:
                logger.info(f"❌ No properties found")
                self._debug_search_failure(filters.get("location", query))
            
            return result
            
        except Exception as e:
            logger.error(f"Search failed: {e}", exc_info=True)
            return pd.DataFrame()

    def _debug_search_failure(self, search_term: str):
        """Helper method to debug why search failed"""
        try:
            # عرض عينة من البيانات الموجودة
            sample_query = """
                SELECT DISTINCT city, district, COUNT(*) as count 
                FROM properties 
                GROUP BY city, district 
                ORDER BY count DESC 
                LIMIT 10
            """
            sample = self.conn.execute(sample_query).fetchdf()
            
            if not sample.empty:
                logger.info(f"💡 Available locations in database:")
                for _, row in sample.iterrows():
                    logger.info(f"  - {row['city']} / {row['district']}: {row['count']} properties")
                
                # اقتراح بديل
                logger.info(f"💡 Try searching for one of the above locations")
        except:
            pass

    def find_similar_properties(self, property_id: str, max_results: int = 20) -> pd.DataFrame:
        """Find similar properties using SQL"""
        try:
            # Get target property
            target = self.conn.execute(f"""
                SELECT * FROM properties 
                WHERE property_id = '{property_id}'
            """).fetchdf()
            
            if target.empty:
                return pd.DataFrame()
            
            target = target.iloc[0]
            
            # Find similar properties - استخدم الحقول الموجودة
            query = f"""
                SELECT 
                    *,
                    (
                        ABS(price - {target['price']}) / NULLIF({target['price']}, 0) * 0.3 +
                        ABS(size - {target['size']}) / NULLIF({target['size']}, 0) * 0.3 +
                        CASE WHEN rooms = '{target['rooms']}' THEN 0 ELSE 0.2 END +
                        CASE WHEN district = '{target['district']}' THEN 0 ELSE 0.2 END
                    ) AS difference_score
                FROM properties
                WHERE property_id != '{property_id}'
                AND city = '{target['city']}'
                ORDER BY difference_score
                LIMIT {max_results}
            """
            
            return self.conn.execute(query).fetchdf()
            
        except Exception as e:
            logger.warning(f"Similar properties search failed: {e}")
            return pd.DataFrame()

    def get_market_analysis(self, location: str, days_back: int = 30) -> Dict[str, Any]:
        """Get comprehensive market analysis with type handling"""
        try:
            # Check if we have data
            prop_count = self.conn.execute("SELECT COUNT(*) FROM properties").fetchone()[0]
            
            if prop_count == 0:
                return self._empty_market_analysis(location, days_back)
            
            # تطبيع اسم الموقع
            location_pattern = location.lower().replace("ı", "i").replace("ö", "o").replace("ü", "u").replace(" ", "")
            
            # استخدم CAST للتعامل مع أنواع البيانات المختلفة
            prop_stats_query = f"""
                SELECT 
                    COUNT(*) as total_properties,
                    AVG(price) as avg_price,
                    MEDIAN(price) as median_price,
                    STDDEV(price) as price_std,
                    AVG(price_per_sqm) as avg_price_per_sqm,
                    AVG(size) as avg_size
                FROM properties
                WHERE (
                    LOWER(REPLACE(REPLACE(REPLACE(location, 'ı', 'i'), 'ö', 'o'), 'ü', 'u')) LIKE '%{location_pattern}%' OR
                    LOWER(REPLACE(REPLACE(REPLACE(city, 'ı', 'i'), 'ö', 'o'), 'ü', 'u')) LIKE '%{location_pattern}%' OR
                    LOWER(REPLACE(REPLACE(REPLACE(district, 'ı', 'i'), 'ö', 'o'), 'ü', 'u')) LIKE '%{location_pattern}%'
                )
            """
            
            # لا نضيف فلتر التاريخ إذا كان يسبب مشاكل
            # أو نستخدم TRY_CAST للتعامل مع الأنواع المختلفة
            
            prop_stats = self.conn.execute(prop_stats_query).fetchdf()
            
            if not prop_stats.empty and prop_stats.iloc[0]['total_properties'] > 0:
                prop_stats_dict = prop_stats.iloc[0].to_dict()
            else:
                prop_stats_dict = self._empty_property_stats()
            
            return {
                "property_statistics": prop_stats_dict,
                "price_trends": [],  # مبسط لتجنب مشاكل التاريخ
                "market_indicators": [],
                "news_sentiment": [],
                "analysis_date": datetime.now().isoformat(),
                "location": location,
                "period_days": days_back
            }
            
        except Exception as e:
            logger.warning(f"Market analysis failed: {e}")
            return self._empty_market_analysis(location, days_back)

    def _empty_market_analysis(self, location: str, days_back: int) -> Dict[str, Any]:
        """Return empty market analysis structure"""
        return {
            "property_statistics": self._empty_property_stats(),
            "price_trends": [],
            "market_indicators": [],
            "news_sentiment": [],
            "analysis_date": datetime.now().isoformat(),
            "location": location,
            "period_days": days_back
        }
    
    def _empty_property_stats(self) -> Dict[str, Any]:
        """Return empty property statistics"""
        return {
            "total_properties": 0,
            "avg_price": 0.0,
            "median_price": 0.0,
            "price_std": 0.0,
            "avg_price_per_sqm": 0.0,
            "avg_size": 0.0
        }
    
    def get_investment_opportunities(self, budget: float, min_roi: float = 5.0) -> pd.DataFrame:
        """
        Find investment opportunities
        
        Args:
            budget: Investment budget
            min_roi: Minimum ROI percentage
            
        Returns:
            DataFrame with opportunities
        """
        try:
            # Check if we have data
            count = self.conn.execute("SELECT COUNT(*) FROM properties").fetchone()[0]
            
            if count == 0:
                return pd.DataFrame()
            
            query = f"""
                WITH district_stats AS (
                    SELECT 
                        district,
                        city,
                        AVG(price_per_sqm) as avg_price_per_sqm,
                        COUNT(*) as inventory
                    FROM properties
                    GROUP BY district, city
                ),
                opportunities AS (
                    SELECT 
                        p.*,
                        ds.avg_price_per_sqm as district_avg_price_per_sqm,
                        ((ds.avg_price_per_sqm - p.price_per_sqm) / NULLIF(p.price_per_sqm, 0) * 100) as discount_percent
                    FROM properties p
                    JOIN district_stats ds ON p.district = ds.district AND p.city = ds.city
                    WHERE p.price <= {budget}
                    AND p.investment_score >= {min_roi}
                    AND p.price_per_sqm < ds.avg_price_per_sqm * 0.9
                )
                SELECT * FROM opportunities
                ORDER BY discount_percent DESC, investment_score DESC
                LIMIT 50
            """
            
            return self.conn.execute(query).fetchdf()
            
        except Exception as e:
            logger.warning(f"Investment opportunities search failed: {e}")
            return pd.DataFrame()
