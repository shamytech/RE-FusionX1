"""
Storage Integration Layer for RE-FusionX
========================================
Unified integration layer that connects:
- Storage Manager
- Unified Cache  
- Session Manager
- Unified Conversation System

Author: RE-FusionX Team
Version: 1.0
"""

from typing import Dict, Any, List, Optional, Union
from datetime import datetime
import asyncio
from pathlib import Path

from app.core.logging import logger
from app.core.storage.storage_manager import StorageManager, get_storage_manager
from app.core.storage.unified_cache import UnifiedCache, CacheType, get_cache
from app.core.storage.session_manager import SessionManager, get_session_manager


class StorageIntegration:
    """
    🚀 Unified Storage Integration
    
    Single interface for all storage operations:
    - Property data storage and retrieval
    - Session and conversation management
    - Unified caching across all layers
    - Memory management
    - Data synchronization
    """
    
    def __init__(self):
        """Initialize storage integration"""
        self._storage_manager = None
        self._cache = None
        self._session_manager = None
        self._initialized = False
        
        logger.info("🚀 StorageIntegration initializing...")
    
    async def initialize(self) -> None:
        """Initialize all storage components"""
        if self._initialized:
            return
        
        try:
            # Initialize components
            from .storage_manager import get_storage_manager
            from .unified_cache import get_cache
            from .session_manager import get_session_manager
            
            self._storage_manager = get_storage_manager()
            self._cache = get_cache()
            self._session_manager = get_session_manager()
            
            self._initialized = True
            logger.info("✅ StorageIntegration initialized successfully")
            
        except Exception as e:
            logger.error(f"Failed to initialize StorageIntegration: {e}")
            raise
    
    @property
    def storage(self) -> StorageManager:
        """Get storage manager"""
        if not self._storage_manager:
            from .storage_manager import get_storage_manager
            self._storage_manager = get_storage_manager()
        return self._storage_manager
    
    @property
    def cache(self) -> UnifiedCache:
        """Get unified cache"""
        if not self._cache:
            from .unified_cache import get_cache
            self._cache = get_cache()
        return self._cache
    
    @property
    def sessions(self) -> SessionManager:
        """Get session manager"""
        if not self._session_manager:
            from .session_manager import get_session_manager
            self._session_manager = get_session_manager()
        return self._session_manager
    
    # Property operations
    async def get_properties(
        self,
        location: str,
        filters: Optional[Dict[str, Any]] = None,
        force_refresh: bool = False,
        session_id: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        """Get properties with integrated caching"""
        try:
            if session_id:
                await self._track_search_in_session(session_id, location, filters)
            
            properties = await self.storage.get_properties(
                location=location,
                filters=filters,
                force_refresh=force_refresh
            )
            
            logger.info(f"Retrieved {len(properties)} properties for {location}")
            return properties
            
        except Exception as e:
            logger.error(f"Failed to get properties: {e}")
            return []
    
    async def save_properties(
        self,
        properties: List[Dict[str, Any]],
        location: str,
        source: str = "scraper",
        session_id: Optional[str] = None
    ) -> bool:
        """Save properties with integrated caching"""
        try:
            success = await self.storage.save_properties(
                properties=properties,
                location=location,
                source=source
            )
            
            if success:
                await self._invalidate_location_cache(location)
                if session_id:
                    await self._track_data_update_in_session(session_id, location, len(properties))
                logger.info(f"Saved {len(properties)} properties for {location}")
            
            return success
            
        except Exception as e:
            logger.error(f"Failed to save properties: {e}")
            return False
    
    # Session operations
    async def create_session(
        self,
        user_data: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """Create new session"""
        try:
            session = await self.sessions.create_session(user_data)
            session_id = session["id"]
            await self._initialize_session_tracking(session_id)
            logger.info(f"Created session: {session_id}")
            return session
            
        except Exception as e:
            logger.error(f"Failed to create session: {e}")
            raise
    
    async def get_session(self, session_id: str) -> Optional[Dict[str, Any]]:
        """Get session data"""
        try:
            return await self.sessions.get_session(session_id)
        except Exception as e:
            logger.error(f"Failed to get session {session_id}: {e}")
            return None
    
    async def delete_session(self, session_id: str) -> bool:
        """Delete session and related data"""
        try:
            await self._clear_session_cache(session_id)
            success = await self.sessions.delete_session(session_id)
            if success:
                logger.info(f"Deleted session: {session_id}")
            return success
            
        except Exception as e:
            logger.error(f"Failed to delete session {session_id}: {e}")
            return False
    
    # Cache operations
    async def get_from_cache(
        self,
        key: str,
        cache_type: CacheType = CacheType.API
    ) -> Optional[Any]:
        """Get value from unified cache"""
        try:
            return await self.cache.get(key, cache_type)
        except Exception as e:
            logger.error(f"Cache get failed for key {key}: {e}")
            return None
    
    async def set_in_cache(
        self,
        key: str,
        value: Any,
        cache_type: CacheType = CacheType.API,
        ttl_override: Optional[int] = None
    ) -> bool:
        """Set value in unified cache"""
        try:
            return await self.cache.set(key, value, cache_type, ttl_override)
        except Exception as e:
            logger.error(f"Cache set failed for key {key}: {e}")
            return False
    
    # Statistics
    def get_comprehensive_statistics(self) -> Dict[str, Any]:
        """Get comprehensive statistics"""
        try:
            return {
                "storage": self.storage.get_statistics(),
                "cache": self.cache.get_stats(),
                "integration": {
                    "initialized": self._initialized,
                    "timestamp": datetime.utcnow().isoformat()
                }
            }
        except Exception as e:
            logger.error(f"Failed to get statistics: {e}")
            return {"error": str(e)}
    
    # Private helpers
    async def _track_search_in_session(
        self,
        session_id: str,
        location: str,
        filters: Optional[Dict[str, Any]]
    ) -> None:
        """Track search activity in session"""
        try:
            search_activity = {
                "type": "property_search",
                "location": location,
                "filters": filters,
                "timestamp": datetime.utcnow().isoformat()
            }
            
            await self.sessions.update_session(session_id, {
                "context": {"last_search": search_activity}
            })
            
        except Exception as e:
            logger.debug(f"Failed to track search in session: {e}")
    
    async def _track_data_update_in_session(
        self,
        session_id: str,
        location: str,
        count: int
    ) -> None:
        """Track data update in session"""
        try:
            update_activity = {
                "type": "data_update",
                "location": location,
                "count": count,
                "timestamp": datetime.utcnow().isoformat()
            }
            
            await self.sessions.update_session(session_id, {
                "context": {"last_update": update_activity}
            })
            
        except Exception as e:
            logger.debug(f"Failed to track update in session: {e}")
    
    async def _initialize_session_tracking(self, session_id: str) -> None:
        """Initialize session tracking"""
        try:
            tracking_key = self.cache.generate_key(CacheType.SESSION, f"tracking_{session_id}")
            
            tracking_data = {
                "session_id": session_id,
                "created_at": datetime.utcnow().isoformat(),
                "activities": [],
                "searches_count": 0,
                "analyses_count": 0
            }
            
            await self.cache.set(tracking_key, tracking_data, CacheType.SESSION)
            
        except Exception as e:
            logger.debug(f"Failed to initialize session tracking: {e}")
    
    async def _invalidate_location_cache(self, location: str) -> None:
        """Invalidate cache entries for a location"""
        try:
            patterns = [
                f"property:*{location}*",
                f"search:*{location}*",
                f"market:*{location}*"
            ]
            
            for pattern in patterns:
                await self.cache.clear_pattern(pattern)
                
        except Exception as e:
            logger.debug(f"Failed to invalidate location cache: {e}")
    
    async def _clear_session_cache(self, session_id: str) -> None:
        """Clear all cache entries for a session"""
        try:
            patterns = [
                f"session:{session_id}*",
                f"session:tracking_{session_id}*"
            ]
            
            for pattern in patterns:
                await self.cache.clear_pattern(pattern)
                
        except Exception as e:
            logger.debug(f"Failed to clear session cache: {e}")
    
    async def close(self) -> None:
        """Close all connections"""
        try:
            if self._cache:
                await self._cache.close()
            logger.info("StorageIntegration closed")
            
        except Exception as e:
            logger.error(f"Error closing StorageIntegration: {e}")


# Singleton
_integration_instance = None

async def get_storage_integration() -> StorageIntegration:
    """Get storage integration singleton"""
    global _integration_instance
    
    if _integration_instance is None:
        _integration_instance = StorageIntegration()
        await _integration_instance.initialize()
    
    return _integration_instance


# Add FastAPI integration methods to the existing StorageIntegration class
def _add_fastapi_methods():
    """Add FastAPI integration methods to StorageIntegration class"""
    
    @classmethod
    async def initialize_for_app(cls, app) -> None:
        """Initialize storage integration for FastAPI app"""
        try:
            integration = await get_storage_integration()
            app.state.storage_integration = integration
            logger.info("✅ StorageIntegration initialized for FastAPI app")
        except Exception as e:
            logger.error(f"Failed to initialize StorageIntegration for app: {e}")
            raise
    
    @classmethod
    async def cleanup(cls) -> None:
        """Cleanup storage integration resources"""
        global _integration_instance
        
        try:
            if _integration_instance:
                await _integration_instance.close()
                _integration_instance = None
            logger.info("✅ StorageIntegration cleanup completed")
        except Exception as e:
            logger.error(f"Error during StorageIntegration cleanup: {e}")
    
    @classmethod
    def verify_health(cls) -> Dict[str, Any]:
        """Verify health of storage integration"""
        try:
            global _integration_instance
            
            health_status = {
                "status": "healthy" if _integration_instance and _integration_instance._initialized else "not_initialized",
                "components": {
                    "storage_manager": "available" if _integration_instance and _integration_instance._storage_manager else "not_available",
                    "cache": "available" if _integration_instance and _integration_instance._cache else "not_available", 
                    "session_manager": "available" if _integration_instance and _integration_instance._session_manager else "not_available"
                },
                "timestamp": datetime.utcnow().isoformat()
            }
            
            return health_status
            
        except Exception as e:
            return {
                "status": "error",
                "error": str(e),
                "timestamp": datetime.utcnow().isoformat()
            }
    
    @classmethod
    def get_storage(cls):
        """Get storage manager instance"""
        global _integration_instance
        if _integration_instance:
            return _integration_instance.storage
        return None
    
    @classmethod
    def get_cache(cls):
        """Get cache instance"""
        global _integration_instance
        if _integration_instance:
            return _integration_instance.cache
        return None
    
    @classmethod
    def get_sessions(cls):
        """Get session manager instance"""
        global _integration_instance
        if _integration_instance:
            return _integration_instance.sessions
        return None
    
    # Add methods to the class
    StorageIntegration.initialize_for_app = initialize_for_app
    StorageIntegration.cleanup = cleanup
    StorageIntegration.verify_health = verify_health
    StorageIntegration.get_storage = get_storage
    StorageIntegration.get_cache = get_cache
    StorageIntegration.get_sessions = get_sessions

# Apply the methods
_add_fastapi_methods()