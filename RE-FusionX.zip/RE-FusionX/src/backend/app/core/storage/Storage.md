# 📚 **نظام التخزين والكاش الموحد - RE-FusionX**

## 📋 **جدول المحتويات**
1. [نظرة عامة](#نظرة-عامة)
2. [البنية المعمارية](#البنية-المعمارية)
3. [المكونات الرئيسية](#المكونات-الرئيسية)
4. [آلية العمل](#آلية-العمل)
5. [تدفق البيانات](#تدفق-البيانات)
6. [استراتيجية الكاش](#استراتيجية-الكاش)
7. [أمثلة الاستخدام](#أمثلة-الاستخدام)
8. [الأداء والتحسين](#الأداء-والتحسين)

---

## 🎯 **نظرة عامة**

نظام التخزين والكاش الموحد في RE-FusionX هو نظام متطور يدير جميع عمليات تخزين واسترجاع البيانات بكفاءة عالية، مستخدماً تقنيات متعددة المستويات للحصول على أفضل أداء.

### **المميزات الرئيسية:**
- 🚀 **سرعة فائقة** باستخدام DuckDB للاستعلامات
- 💾 **كاش ذكي** متعدد المستويات
- 📦 **تخزين مضغوط** بصيغة Parquet
- 🔄 **تحديث تلقائي** للبيانات القديمة
- 📊 **تحليلات فورية** على البيانات المخزنة

---

## 🏗️ **البنية المعمارية**

```mermaid
graph TB
    subgraph "Application Layer"
        A[Agents/Services] --> B[Storage Manager]
    end
    
    subgraph "Storage System"
        B --> C{Cache Check}
        C -->|Hit| D[Unified Cache]
        C -->|Miss| E[Search Engine]
        
        D --> F[Memory Cache]
        D --> G[Redis Cache]
        
        E --> H[DuckDB Engine]
        H --> I[Parquet Files]
        
        E -->|Not Found| J[Data Collectors]
        J --> K[Web Scrapers]
        J --> L[API Clients]
        
        K --> M[ParquetManager]
        L --> M
        M --> I
    end
    
    subgraph "Data Storage"
        I --> N[Properties Data]
        I --> O[Market Data]
        I --> P[News Data]
    end
    
    style A fill:#e1f5fe
    style B fill:#4fc3f7
    style D fill:#81c784
    style H fill:#ffb74d
    style I fill:#9575cd
```

---

## 🔧 **المكونات الرئيسية**

### **1. StorageManager** 📦
المدير المركزي لجميع عمليات التخزين

```python
class StorageManager:
    - get_properties()      # جلب العقارات
    - save_properties()     # حفظ العقارات
    - get_market_analysis() # تحليل السوق
    - search_similar()      # بحث عن عقارات مشابهة
```

### **2. UnifiedCache** 💾
نظام كاش موحد متعدد المستويات

```python
class UnifiedCache:
    - Memory Cache (L1)     # كاش في الذاكرة
    - Redis Cache (L2)      # كاش Redis
    - TTL Management        # إدارة انتهاء الصلاحية
    - Pattern Invalidation  # إبطال بالنمط
```

### **3. SearchEngine** 🔍
محرك بحث سريع باستخدام DuckDB

```python
class SearchEngine:
    - In-memory queries     # استعلامات في الذاكرة
    - SQL optimization      # تحسين SQL
    - Index management      # إدارة الفهارس
    - Aggregations         # تجميعات سريعة
```

### **4. ParquetManager** 📁
مدير ملفات Parquet للتخزين الدائم

```python
class ParquetManager:
    - Compression          # ضغط البيانات
    - Partitioning        # تقسيم البيانات
    - Schema validation   # التحقق من البنية
    - Metadata tracking   # تتبع البيانات الوصفية
```

---

## ⚙️ **آلية العمل**

### **تدفق جلب البيانات:**

```mermaid
sequenceDiagram
    participant User
    participant Agent
    participant StorageManager
    participant Cache
    participant SearchEngine
    participant DuckDB
    participant Scraper
    participant Parquet

    User->>Agent: طلب بيانات عقارات
    Agent->>StorageManager: get_properties(location)
    
    StorageManager->>Cache: تحقق من الكاش
    alt Cache Hit
        Cache-->>StorageManager: بيانات من الكاش
        StorageManager-->>Agent: إرجاع البيانات (سريع)
    else Cache Miss
        StorageManager->>SearchEngine: بحث في التخزين
        SearchEngine->>DuckDB: استعلام SQL
        DuckDB->>Parquet: قراءة الملفات
        
        alt Data Fresh
            Parquet-->>DuckDB: بيانات حديثة
            DuckDB-->>SearchEngine: نتائج
            SearchEngine-->>StorageManager: بيانات
            StorageManager->>Cache: حفظ في الكاش
            StorageManager-->>Agent: إرجاع البيانات
        else Data Stale/Not Found
            StorageManager->>Scraper: جمع بيانات جديدة
            Scraper-->>StorageManager: بيانات جديدة
            StorageManager->>Parquet: حفظ
            StorageManager->>Cache: تحديث الكاش
            StorageManager-->>Agent: إرجاع البيانات
        end
    end
    
    Agent-->>User: عرض النتائج
```

---

## 🔄 **تدفق البيانات**

### **1. دورة حياة البيانات:**

```mermaid
graph LR
    A[Collection] --> B[Validation]
    B --> C[Storage]
    C --> D[Indexing]
    D --> E[Caching]
    E --> F[Serving]
    F --> G[Analytics]
    
    G -->|Update Trigger| A
    
    style A fill:#4caf50
    style C fill:#2196f3
    style E fill:#ff9800
    style F fill:#9c27b0
```

### **2. هرمية التخزين:**

```mermaid
graph TD
    A[Hot Data - Memory Cache] --> B[Warm Data - Redis Cache]
    B --> C[Cold Data - DuckDB Views]
    C --> D[Archive - Parquet Files]
    
    A -->|< 1 hour| A1[عقارات محدثة]
    B -->|< 6 hours| B1[بيانات السوق]
    C -->|< 24 hours| C1[الأخبار]
    D -->|> 24 hours| D1[أرشيف]
    
    style A fill:#ff5252
    style B fill:#ff9800
    style C fill:#03a9f4
    style D fill:#607d8b
```

---

## 💡 **استراتيجية الكاش**

### **مستويات الكاش:**

| المستوى | التقنية | السرعة | السعة | TTL | الاستخدام |
|---------|---------|--------|-------|-----|-----------|
| L1 | Memory Dict | < 1ms | 1GB | 30 min | Hot queries |
| L2 | Redis | < 10ms | 10GB | 6 hours | Warm data |
| L3 | DuckDB | < 100ms | 100GB | 24 hours | Analytics |
| L4 | Parquet | < 1s | Unlimited | Permanent | Archive |

### **سياسات الإبطال:**

```python
# 1. Time-based (TTL)
cache.set(key, value, ttl=3600)  # ساعة واحدة

# 2. Pattern-based
cache.clear_pattern("property:istanbul:*")  # حذف كل عقارات اسطنبول

# 3. Event-based
on_new_data_arrival() -> cache.invalidate()  # عند وصول بيانات جديدة

# 4. Size-based (LRU)
if cache.size > MAX_SIZE:
    cache.evict_oldest()  # حذف الأقدم
```

---

## 📝 **أمثلة الاستخدام**

### **1. جلب البيانات مع الكاش:**

```python
async def get_istanbul_properties():
    storage = get_storage_manager()
    
    # أول طلب - من قاعدة البيانات
    properties = await storage.get_properties(
        location="istanbul",
        filters={"rooms": "3+1", "max_price": 5000000}
    )  # ~500ms
    
    # ثاني طلب - من الكاش
    properties = await storage.get_properties(
        location="istanbul",
        filters={"rooms": "3+1", "max_price": 5000000}
    )  # ~1ms ⚡
```

### **2. حفظ البيانات:**

```python
async def save_scraped_data(properties):
    storage = get_storage_manager()
    
    # حفظ في Parquet + تحديث الكاش
    success = await storage.save_properties(
        properties=properties,
        location="istanbul",
        source="emlakjet"
    )
    
    # البيانات الآن:
    # ✅ محفوظة في Parquet
    # ✅ مفهرسة في DuckDB
    # ✅ مخزنة في الكاش
```

### **3. تحليل السوق:**

```python
async def analyze_market():
    storage = get_storage_manager()
    
    # تحليل مع كاش ذكي
    analysis = await storage.get_market_analysis(
        location="istanbul",
        days_back=30
    )
    
    # النتيجة محفوظة في الكاش لـ 24 ساعة
    # الطلبات التالية فورية
```

---

## 📊 **الأداء والتحسين**

### **مقاييس الأداء:**

```mermaid
graph LR
    subgraph "Response Times"
        A[Cache Hit: 1-5ms]
        B[DuckDB Query: 50-200ms]
        C[Parquet Scan: 200-500ms]
        D[Web Scraping: 2-5s]
    end
    
    style A fill:#4caf50
    style B fill:#8bc34a
    style C fill:#ffc107
    style D fill:#ff5722
```

### **معدلات النجاح:**

| العملية | معدل Cache Hit | زمن الاستجابة | الحمل على النظام |
|---------|---------------|--------------|-----------------|
| بحث عقارات | 85% | 5ms (cache) / 200ms (db) | منخفض |
| تحليل سوق | 70% | 10ms (cache) / 500ms (compute) | متوسط |
| عقارات مشابهة | 60% | 50ms (cache) / 1s (search) | عالي |
| بيانات جديدة | 0% | 2-5s (scraping) | عالي جداً |

### **تحسينات الأداء:**

1. **Pre-warming**: تحميل البيانات الشائعة مسبقاً
2. **Batch Processing**: معالجة دفعات كبيرة معاً
3. **Async I/O**: قراءة/كتابة غير متزامنة
4. **Compression**: ضغط Snappy يقلل الحجم 70%
5. **Partitioning**: تقسيم حسب الشهر/المدينة

---

## 🔐 **الأمان والموثوقية**

### **آليات الحماية:**

```python
# 1. تحقق من صحة البيانات
validator.check_schema(data)

# 2. نسخ احتياطي تلقائي
backup_manager.schedule_daily_backup()

# 3. مراقبة الجودة
quality_monitor.check_freshness()
quality_monitor.detect_anomalies()

# 4. معالجة الأخطاء
try:
    data = await storage.get_properties()
except CacheError:
    # Fallback to database
    data = await direct_db_query()
```

---

## 📈 **المراقبة والإحصائيات**

### **لوحة المراقبة:**

```python
stats = storage.get_statistics()

# Cache Performance
print(f"Cache Hit Rate: {stats['cache_stats']['hit_rate']:.1%}")
print(f"Memory Usage: {stats['cache_stats']['memory_entries']} entries")

# Storage Metrics  
print(f"Total Properties: {stats['storage_stats']['properties']['total_count']}")
print(f"Storage Size: {stats['storage_stats']['storage']['total_size_mb']:.2f} MB")

# Performance Metrics
print(f"Cache Hits: {stats['performance_metrics']['cache_hits']}")
print(f"Storage Hits: {stats['performance_metrics']['storage_hits']}")
print(f"Scrape Requests: {stats['performance_metrics']['scrape_requests']}")
```

---

## 🚀 **خلاصة**

نظام التخزين والكاش الموحد في RE-FusionX يوفر:

- ⚡ **سرعة فائقة** عبر كاش متعدد المستويات
- 📦 **تخزين فعال** باستخدام Parquet
- 🔍 **بحث قوي** عبر DuckDB
- 🔄 **تحديث ذكي** للبيانات
- 📊 **تحليلات فورية** على البيانات الضخمة

النظام مصمم للتعامل مع ملايين العقارات بكفاءة عالية وزمن استجابة منخفض جداً.