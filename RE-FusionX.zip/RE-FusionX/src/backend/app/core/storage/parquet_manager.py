# app/core/storage/parquet_manager.py

"""
Data Output Manager - Enhanced Version
======================================
Manages data outputs with smart hierarchical organization
"""

import pandas as pd
import pyarrow as pa
import pyarrow.parquet as pq
import json
from pathlib import Path
from typing import Dict, Any, List, Optional, Union
from datetime import datetime, timedelta
import hashlib
import os

from app.core.logging import logger
from app.core.config import settings
from app.utils.location_utils import normalize_for_path, get_location_manager, normalize_text


class ParquetManager:
    """
    Manages data outputs with Parquet for efficient storage
    """
    
    def __init__(self, output_dir: Optional[Path] = None):
        """Initialize data output manager"""
        self.output_dir = output_dir or (Path(settings.DATA_DIR) / "outputs")
        self.output_dir.mkdir(parents=True, exist_ok=True)
        
        self.properties_dir = self.output_dir / "properties"
        self.market_data_dir = self.output_dir / "market_data"
        self.news_dir = self.output_dir / "news"
        
        # Schema definitions
        self.schemas = self._define_schemas()
        
        # Track saved data to prevent duplicates
        self._saved_data_cache = {}
    
    def _define_schemas(self) -> Dict[str, pa.Schema]:
        """Define Parquet schemas for different data types"""
        return {
            "properties": pa.schema([
                ("property_id", pa.string()),
                ("listing_id", pa.string()),
                ("source", pa.string()),
                ("title", pa.string()),
                ("price", pa.float64()),
                ("price_raw", pa.string()),
                ("currency", pa.string()),
                ("location", pa.string()),
                ("city", pa.string()),
                ("district", pa.string()),
                ("neighborhood", pa.string()),
                ("size", pa.float64()),
                ("rooms", pa.string()),
                ("room_count", pa.int32()),
                ("floor", pa.int32()),
                ("floor_text", pa.string()),
                ("area_text", pa.string()),
                ("property_type", pa.string()),
                ("url", pa.string()),
                ("image_url", pa.string()),
                ("scraped_at", pa.int64()),
                ("price_per_sqm", pa.float64()),
            ])
        }
    
    def _normalize_location_name(self, location: str) -> str:
        """
        Normalize location names for consistent file paths
        """
        return normalize_for_path(location)
    
    def _get_save_path(self, df: pd.DataFrame, search_location: str) -> Path:
        """
        Determine the best save path based on data content
        """
        # Priority 1: Use city from data if available
        if 'city' in df.columns and not df['city'].empty:
            cities = df['city'].dropna().unique()
            if len(cities) == 1:
                city = self._normalize_location_name(cities[0])
                
                # Check for district
                if 'district' in df.columns and not df['district'].empty:
                    districts = df['district'].dropna().unique()
                    if len(districts) == 1:
                        district = self._normalize_location_name(districts[0])
                        return self.properties_dir / "turkey" / city / district
                
                return self.properties_dir / "turkey" / city
        
        # Priority 2: Parse search location
        search_normalized = self._normalize_location_name(search_location)
        
        # Check if it's a known city
        known_cities = ['istanbul', 'ankara', 'izmir', 'antalya', 'bursa']
        for city in known_cities:
            if city in search_normalized:
                return self.properties_dir / "turkey" / city
        
        # Default: Use search location as is
        return self.properties_dir / "turkey" / search_normalized
    
    def _generate_data_hash(self, df: pd.DataFrame) -> str:
        """
        Generate hash to identify duplicate data
        """
        if df.empty:
            return ""
        
        # Use first few records' IDs to create a hash
        id_columns = ['listing_id', 'property_id', 'url']
        
        hash_string = ""
        for col in id_columns:
            if col in df.columns:
                # Take first 5 values
                values = df[col].head(5).dropna().tolist()
                if values:
                    hash_string += "".join(str(v) for v in values)
                    break
        
        if not hash_string and 'title' in df.columns:
            # Fallback to titles
            hash_string = "".join(df['title'].head(3).dropna().tolist())
        
        return hashlib.md5(hash_string.encode()).hexdigest() if hash_string else ""
    
    def save_properties1(self, properties: Union[List[Dict], pd.DataFrame], search_location: str, force_save: bool = False) -> Optional[Path]:
        """
        Save properties with intelligent deduplication and normalized location organization
        """
        try:
            # Convert to DataFrame
            if isinstance(properties, list):
                if not properties:
                    logger.warning("No properties to save")
                    return None
                df = pd.DataFrame(properties)
            else:
                df = properties.copy()
            
            if df.empty:
                logger.warning("Empty DataFrame, nothing to save")
                return None
            
            # Standardize schema
            df = self.standardize_dataframe(df)
            
            # تطبيع أسماء المدن باستخدام مدير المواقع
            location_manager = get_location_manager()
            
            if 'city' in df.columns:
                def normalize_city(city_name):
                    if pd.isna(city_name):
                        return city_name
                    # تحقق من صحة المدينة
                    if location_manager.is_valid_city(city_name):
                        # احصل على الاسم الصحيح
                        for city in location_manager.get_cities():
                            if normalize_text(city) == normalize_text(city_name):
                                return city
                    return city_name
                
                df['city'] = df['city'].apply(normalize_city)
                
            
            # Generate data hash
            data_hash = self._generate_data_hash(df)
            
            # Check for duplicates
            if not force_save and data_hash in self._saved_data_cache:
                existing_path = self._saved_data_cache[data_hash]
                logger.info(f"⚠️ Duplicate data detected, already saved at: {existing_path}")
                return existing_path
            
            # Determine save path - use normalized location for folder structure
            save_dir = self._get_save_path(df, search_location)
            save_dir.mkdir(parents=True, exist_ok=True)
            
            # Generate filename with timestamp
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            month_year = datetime.now().strftime('%Y_%m')
            filename = f"properties_{month_year}_{timestamp}.parquet"
            output_path = save_dir / filename
            
            # Check if similar file exists (same month)
            existing_files = list(save_dir.glob(f"properties_{month_year}_*.parquet"))
            
            if existing_files and not force_save:
                # Load most recent file and check similarity
                latest_file = max(existing_files, key=lambda p: p.stat().st_mtime)
                existing_df = pd.read_parquet(latest_file)
                
                # Compare data
                if self._is_similar_data(df, existing_df):
                    logger.info(f"📝 Updating existing file: {latest_file}")
                    # Merge data
                    combined_df = self._merge_dataframes(existing_df, df)
                    combined_df.to_parquet(latest_file, compression='snappy')
                    
                    # Update cache
                    self._saved_data_cache[data_hash] = latest_file
                    
                    logger.info(f"✅ Updated {len(combined_df)} properties in {latest_file}")
                    return latest_file
            
            # Save new file
            df.to_parquet(output_path, compression='snappy')
            
            # Update cache
            self._saved_data_cache[data_hash] = output_path
            
            # Log save details
            location_info = f"{save_dir.parent.name}/{save_dir.name}" if save_dir.parent.name != "properties" else save_dir.name
            logger.info(f"✅ Saved {len(df)} properties to {location_info}/{filename}")
            
            # Update index with normalized data
            self._update_property_index(df, search_location)
            
            return output_path
            
        except Exception as e:
            logger.error(f"Error saving properties: {e}", exc_info=True)
            return None

    def save_properties(self, properties: Union[List[Dict], pd.DataFrame], search_location: str, force_save: bool = False) -> Optional[Path]:
        """
        Save properties with intelligent deduplication and normalized location organization
        
        Args:
            properties: Properties to save
            search_location: Location used in search (was 'location' before)
            force_save: Force save even if duplicate detected
            
        Returns:
            Path to saved file or None
        """
        try:
            # Convert to DataFrame
            if isinstance(properties, list):
                if not properties:
                    logger.warning("No properties to save")
                    return None
                df = pd.DataFrame(properties)
            else:
                df = properties.copy()
            
            if df.empty:
                logger.warning("Empty DataFrame, nothing to save")
                return None
            
            # Standardize schema
            df = self.standardize_dataframe(df)
            
            # تطبيع أسماء المدن باستخدام مدير المواقع
            location_manager = get_location_manager()
            
            if 'city' in df.columns:
                def normalize_city(city_name):
                    if pd.isna(city_name):
                        return city_name
                    # تحقق من صحة المدينة
                    if location_manager.is_valid_city(city_name):
                        # احصل على الاسم الصحيح
                        for city in location_manager.get_cities():
                            if normalize_text(city) == normalize_text(city_name):
                                return city
                    return city_name
                
                df['city'] = df['city'].apply(normalize_city)
            
            # Generate data hash
            data_hash = self._generate_data_hash(df)
            
            # Check for duplicates
            if not force_save and data_hash in self._saved_data_cache:
                existing_path = self._saved_data_cache[data_hash]
                logger.info(f"⚠️ Duplicate data detected, already saved at: {existing_path}")
                return existing_path
            
            # Determine save path
            save_dir = self._get_save_path(df, search_location)
            save_dir.mkdir(parents=True, exist_ok=True)
            
            # Generate filename with timestamp
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            month_year = datetime.now().strftime('%Y_%m')
            filename = f"properties_{month_year}_{timestamp}.parquet"
            output_path = save_dir / filename
            
            # Check if similar file exists (same month)
            existing_files = list(save_dir.glob(f"properties_{month_year}_*.parquet"))
            
            if existing_files and not force_save:
                # Load most recent file and check similarity
                latest_file = max(existing_files, key=lambda p: p.stat().st_mtime)
                existing_df = pd.read_parquet(latest_file)
                
                # Compare data
                if self._is_similar_data(df, existing_df):
                    logger.info(f"📝 Updating existing file: {latest_file}")
                    # Merge data
                    combined_df = self._merge_dataframes(existing_df, df)
                    combined_df.to_parquet(latest_file, compression='snappy')
                    
                    # Update cache
                    self._saved_data_cache[data_hash] = latest_file
                    
                    logger.info(f"✅ Updated {len(combined_df)} properties in {latest_file}")
                    return latest_file
            
            # Save new file
            df.to_parquet(output_path, compression='snappy')
            
            # Update cache
            self._saved_data_cache[data_hash] = output_path
            
            # Log save details
            location_info = f"{save_dir.parent.name}/{save_dir.name}" if save_dir.parent.name != "properties" else save_dir.name
            logger.info(f"✅ Saved {len(df)} properties to {location_info}/{filename}")
            
            # Update index
            self._update_property_index(df, search_location)
            
            return output_path
            
        except Exception as e:
            logger.error(f"Error saving properties: {e}", exc_info=True)
            return None
        
    def _is_similar_data(self, df1: pd.DataFrame, df2: pd.DataFrame) -> bool:
        """
        Check if two DataFrames contain similar data
        """
        # Check if they have similar structure
        if set(df1.columns) != set(df2.columns):
            return False
        
        # Check overlap in listing IDs
        if 'listing_id' in df1.columns and 'listing_id' in df2.columns:
            ids1 = set(df1['listing_id'].dropna())
            ids2 = set(df2['listing_id'].dropna())
            
            if ids1 and ids2:
                overlap = len(ids1.intersection(ids2))
                return overlap > len(ids1) * 0.5  # More than 50% overlap
        
        return False
    
    def _merge_dataframes(self, existing_df: pd.DataFrame, new_df: pd.DataFrame) -> pd.DataFrame:
        """
        Merge two DataFrames, keeping unique records
        """
        # Combine DataFrames
        combined = pd.concat([existing_df, new_df], ignore_index=True)
        
        # Remove duplicates based on listing_id
        if 'listing_id' in combined.columns:
            combined = combined.drop_duplicates(subset=['listing_id'], keep='last')
        
        # Sort by scraped_at if available
        if 'scraped_at' in combined.columns:
            combined = combined.sort_values('scraped_at', ascending=False)
        
        return combined
    
    def _update_property_index(self, df: pd.DataFrame, location: str):
        """Update property search index"""
        index_path = self.output_dir / "properties" / "index" / "properties_index.parquet"
        index_path.parent.mkdir(parents=True, exist_ok=True)
        
        # Create index DataFrame with essential fields
        index_fields = ['property_id', 'listing_id', 'city', 'district', 'price', 'size', 'rooms']
        available_fields = [f for f in index_fields if f in df.columns]
        
        if not available_fields:
            return
        
        index_df = df[available_fields].copy()
        index_df['indexed_at'] = datetime.now()
        index_df['search_location'] = location
        
        # Append or create
        if index_path.exists():
            try:
                existing_index = pd.read_parquet(index_path)
                combined = pd.concat([existing_index, index_df], ignore_index=True)
                
                # Keep unique records
                if 'listing_id' in combined.columns:
                    combined = combined.drop_duplicates(subset=['listing_id'], keep='last')
                
                # Limit index size (keep last 10000 records)
                if len(combined) > 10000:
                    combined = combined.tail(10000)
                
                combined.to_parquet(index_path, compression='snappy')
            except Exception as e:
                logger.warning(f"Could not update index: {e}")
                index_df.to_parquet(index_path, compression='snappy')
        else:
            index_df.to_parquet(index_path, compression='snappy')
    
    def standardize_dataframe(self, df: pd.DataFrame) -> pd.DataFrame:
        """Standardize DataFrame schema before saving"""
        
        # Required columns with defaults
        column_defaults = {
            'listing_id': '',
            'property_id': '',
            'title': '',
            'location': '',
            'city': '',
            'district': '',
            'neighborhood': '',
            'price': 0.0,
            'price_raw': '',
            'property_type': '',
            'rooms': '',
            'floor_text': '',
            'area_text': '',
            'size': 0.0,
            'url': '',
            'source': 'unknown',
            'scraped_at': int(datetime.now().timestamp() * 1000),
            'price_per_sqm': 0.0,
            'room_count': 0,
            'floor': 0,
            'image_url': ''
        }
        
        # Add missing columns with defaults
        for col, default_value in column_defaults.items():
            if col not in df.columns:
                df[col] = default_value
                
        if 'scraped_at' in df.columns:
            # If empty or 0 or '', set to current timestamp
            mask = df['scraped_at'].isna() | (df['scraped_at'] == 0) | (df['scraped_at'] == '')
            if mask.any():
                df.loc[mask, 'scraped_at'] = int(datetime.now().timestamp() * 1000)
            
            # Ensure it's a number
            df['scraped_at'] = pd.to_numeric(df['scraped_at'], errors='coerce')
            df['scraped_at'] = df['scraped_at'].fillna(int(datetime.now().timestamp() * 1000))
            df['scraped_at'] = df['scraped_at'].astype('int64')
            
        
        # Generate property_id if missing
        if 'property_id' in df.columns and (df['property_id'].isna().all() or (df['property_id'] == '').all()):
            df['property_id'] = df.apply(
                lambda row: hashlib.md5(
                    f"{row.get('listing_id', '')}_{row.get('url', '')}_{row.get('title', '')}".encode()
                ).hexdigest()[:16],
                axis=1
            )
        
        # Ensure correct data types
        numeric_columns = ['price', 'size', 'price_per_sqm']
        for col in numeric_columns:
            if col in df.columns:
                df[col] = pd.to_numeric(df[col], errors='coerce').fillna(0)
        
        integer_columns = ['room_count', 'floor', 'scraped_at']
        for col in integer_columns:
            if col in df.columns:
                df[col] = pd.to_numeric(df[col], errors='coerce').fillna(0).astype('int64')
        
        # Keep only standard columns
        df = df[list(column_defaults.keys())]
        
        return df
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get statistics about stored data"""
        stats = {
            "properties": {},
            "storage": {}
        }
        
        # Count files and calculate size
        total_size = 0
        file_count = 0
        location_stats = {}
        
        for parquet_file in self.output_dir.rglob("*.parquet"):
            if "index" not in str(parquet_file):
                total_size += parquet_file.stat().st_size
                file_count += 1
                
                # Track by location
                parts = parquet_file.parts
                if "turkey" in parts:
                    idx = parts.index("turkey")
                    if idx + 1 < len(parts):
                        city = parts[idx + 1]
                        location_stats[city] = location_stats.get(city, 0) + 1
        
        stats["storage"] = {
            "total_files": file_count,
            "total_size_mb": round(total_size / (1024 * 1024), 2),
            "locations": location_stats,
            "output_directory": str(self.output_dir)
        }
        
        return stats
    
