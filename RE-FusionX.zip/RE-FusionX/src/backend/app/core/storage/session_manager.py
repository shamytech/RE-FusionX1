"""
Session Manager with Unified Cache
===================================
Manages user sessions using unified cache
"""

import uuid
from typing import Dict, Any, Optional, List
from datetime import datetime

from app.core.storage.unified_cache import get_cache, CacheType
from app.core.logging import logger


class SessionManager:
    """Manages user sessions with unified cache"""
    
    def __init__(self):
        """Initialize session manager"""
        self._cache = None
        self._storage = None
        self.default_ttl = 86400  # 24 hours
    
    
    @property
    def storage(self):
        """Lazy load storage"""
        if self._storage is None:
            from app.core.storage.integration import StorageIntegration
            self._storage = StorageIntegration.get_storage()
        return self._storage
    
    @property
    def cache(self):
        """Lazy load cache"""
        if self._cache is None:
            try:
                from app.core.storage.integration import StorageIntegration
                self._cache = StorageIntegration.get_cache()
                
                # If still None, try to get cache directly
                if self._cache is None:
                    from app.core.storage.unified_cache import get_cache
                    self._cache = get_cache()
                    
            except Exception as e:
                logger.error(f"Failed to get cache in SessionManager: {e}")
                # Fallback to direct cache initialization
                try:
                    from app.core.storage.unified_cache import UnifiedCache
                    self._cache = UnifiedCache()
                except Exception as e2:
                    logger.error(f"Failed to initialize fallback cache: {e2}")
                    self._cache = None
                    
        return self._cache
    
    async def create_session(
        self,
        user_data: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Create new session
        
        Args:
            user_data: Optional user data
            
        Returns:
            Session data with ID
        """
        session_id = str(uuid.uuid4())
        
        session = {
            "id": session_id,
            "created_at": datetime.now().isoformat(),
            "last_activity": datetime.now().isoformat(),
            "user_data": user_data or {},
            "conversation_history": [],
            "context": {},
            "preferences": {}
        }
        
        # Store in cache (with error handling)
        try:
            if self.cache is not None:
                cache_key = self.cache.generate_key(
                    CacheType.SESSION,
                    session_id
                )
                
                await self.cache.set(
                    cache_key,
                    session,
                    CacheType.SESSION
                )
            else:
                logger.warning(f"Cache not available, session {session_id} stored in memory only")
                # Store in local memory as fallback
                if not hasattr(self, '_local_sessions'):
                    self._local_sessions = {}
                self._local_sessions[session_id] = session
                
        except Exception as e:
            logger.error(f"Failed to store session in cache: {e}")
            # Store in local memory as fallback
            if not hasattr(self, '_local_sessions'):
                self._local_sessions = {}
            self._local_sessions[session_id] = session
        
        logger.info(f"Created session: {session_id}")
        return session
    
    async def get_session(
        self,
        session_id: str
    ) -> Optional[Dict[str, Any]]:
        """
        Get session data
        
        Args:
            session_id: Session ID
            
        Returns:
            Session data or None
        """
        session = None
        
        try:
            if self.cache is not None:
                cache_key = self.cache.generate_key(
                    CacheType.SESSION,
                    session_id
                )
                
                session = await self.cache.get(cache_key, CacheType.SESSION)
                
                if session:
                    # Update last activity
                    session["last_activity"] = datetime.now().isoformat()
                    
                    # Re-save with updated activity
                    await self.cache.set(
                        cache_key,
                        session,
                        CacheType.SESSION
                    )
            else:
                # Try local memory fallback
                if hasattr(self, '_local_sessions') and session_id in self._local_sessions:
                    session = self._local_sessions[session_id]
                    session["last_activity"] = datetime.now().isoformat()
                    
        except Exception as e:
            logger.error(f"Failed to get session from cache: {e}")
            # Try local memory fallback
            if hasattr(self, '_local_sessions') and session_id in self._local_sessions:
                session = self._local_sessions[session_id]
                session["last_activity"] = datetime.now().isoformat()
        
        return session
    
    async def update_session(
        self,
        session_id: str,
        updates: Dict[str, Any]
    ) -> bool:
        """
        Update session data
        
        Args:
            session_id: Session ID
            updates: Updates to apply
            
        Returns:
            Success status
        """
        session = await self.get_session(session_id)
        
        if not session:
            return False
        
        # Apply updates
        for key, value in updates.items():
            if key == "conversation_history":
                # Ensure conversation_history exists
                if "conversation_history" not in session:
                    session["conversation_history"] = []
                # Append to history
                session["conversation_history"].extend(value)
                # Keep only last 20 messages
                session["conversation_history"] = session["conversation_history"][-20:]
            elif key == "context":
                # Merge context
                session["context"].update(value)
            else:
                session[key] = value
        
        # Save updated session
        cache_key = self.cache.generate_key(
            CacheType.SESSION,
            session_id
        )
        
        return await self.cache.set(
            cache_key,
            session,
            CacheType.SESSION
        )
    
    async def add_message(
        self,
        session_id: str,
        role: str,
        content: str,
        metadata: Optional[Dict[str, Any]] = None
    ) -> bool:
        """
        Add message to session
        
        Args:
            session_id: Session ID
            role: Message role (user/assistant)
            content: Message content
            metadata: Optional metadata
            
        Returns:
            Success status
        """
        message = {
            "role": role,
            "content": content,
            "timestamp": datetime.now().isoformat(),
            "metadata": metadata or {}
        }
        
        return await self.update_session(
            session_id,
            {"conversation_history": [message]}
        )
    
    async def delete_session(self, session_id: str) -> bool:
        """
        Delete session
        
        Args:
            session_id: Session ID
            
        Returns:
            Success status
        """
        cache_key = self.cache.generate_key(
            CacheType.SESSION,
            session_id
        )
        
        return await self.cache.delete(cache_key)
    
    async def get_active_sessions(self) -> List[str]:
        """
        Get list of active session IDs
        
        Returns:
            List of session IDs
        """
        # This would need Redis SCAN or similar
        # For now, return empty list
        return []


# Singleton instance
_session_manager = None

def get_session_manager() -> SessionManager:
    """Get session manager singleton"""
    global _session_manager
    if _session_manager is None:
        _session_manager = SessionManager()
    return _session_manager
