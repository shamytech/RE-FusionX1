"""
Data Quality Monitor
====================
Monitors and ensures data quality
"""

from typing import Dict, Any, List
import pandas as pd
from datetime import datetime, timedelta
from pathlib import Path

from app.core.logging import logger


class QualityMonitor:
    """Monitors data quality and freshness"""
    
    def __init__(self, data_dir: Path):
        self.data_dir = data_dir
        self.quality_thresholds = {
            "completeness": 0.8,  # 80% fields filled
            "freshness_days": 7,   # Data older than 7 days needs update
            "duplicate_rate": 0.1,  # Max 10% duplicates
            "accuracy_score": 0.7   # Minimum accuracy score
        }
    
    def check_data_quality(self) -> Dict[str, Any]:
        """Comprehensive data quality check"""
        report = {
            "timestamp": datetime.now().isoformat(),
            "properties": self._check_properties_quality(),
            "market_data": self._check_market_quality(),
            "news": self._check_news_quality(),
            "recommendations": []
        }
        
        # Generate recommendations
        if report["properties"]["freshness_score"] < 0.5:
            report["recommendations"].append("Update property data - getting stale")
        
        if report["market_data"]["completeness_score"] < 0.7:
            report["recommendations"].append("Missing market indicators - fetch more data")
        
        return report
    
    def _check_properties_quality(self) -> Dict[str, Any]:
        """Check property data quality"""
        properties_dir = self.data_dir / "outputs" / "properties"
        
        if not properties_dir.exists():
            return {"error": "No property data found"}
        
        quality_metrics = {
            "total_files": 0,
            "total_records": 0,
            "completeness_score": 0,
            "freshness_score": 0,
            "duplicate_rate": 0,
            "missing_fields": []
        }
        
        all_properties = []
        
        for parquet_file in properties_dir.rglob("*.parquet"):
            if "index" not in str(parquet_file):
                df = pd.read_parquet(parquet_file)
                all_properties.append(df)
                quality_metrics["total_files"] += 1
        
        if all_properties:
            combined_df = pd.concat(all_properties, ignore_index=True)
            quality_metrics["total_records"] = len(combined_df)
            
            # Check completeness
            required_fields = ["price", "location", "size_sqm", "rooms"]
            completeness_scores = []
            
            for field in required_fields:
                if field in combined_df.columns:
                    filled_rate = combined_df[field].notna().mean()
                    completeness_scores.append(filled_rate)
                    if filled_rate < 0.8:
                        quality_metrics["missing_fields"].append(field)
            
            quality_metrics["completeness_score"] = np.mean(completeness_scores) if completeness_scores else 0
            
            # Check freshness
            if 'scraped_at' in combined_df.columns:
                combined_df['scraped_at'] = pd.to_datetime(combined_df['scraped_at'])
                latest_date = combined_df['scraped_at'].max()
                days_old = (datetime.now() - latest_date).days
                quality_metrics["freshness_score"] = max(0, 1 - (days_old / 7))
            
            # Check duplicates
            if 'property_id' in combined_df.columns:
                duplicate_rate = 1 - (combined_df['property_id'].nunique() / len(combined_df))
                quality_metrics["duplicate_rate"] = duplicate_rate
        
        return quality_metrics
    
    def _check_market_quality(self) -> Dict[str, Any]:
        """Check market data quality"""
        market_dir = self.data_dir / "outputs" / "market_data"
        
        if not market_dir.exists():
            return {"error": "No market data found"}
        
        quality_metrics = {
            "indicators_count": 0,
            "date_coverage": {},
            "completeness_score": 0
        }
        
        # Check available indicators
        indicators = set()
        dates = []
        
        for parquet_file in market_dir.rglob("*.parquet"):
            df = pd.read_parquet(parquet_file)
            if 'indicator_name' in df.columns:
                indicators.update(df['indicator_name'].unique())
            if 'date' in df.columns:
                dates.extend(pd.to_datetime(df['date']).tolist())
        
        quality_metrics["indicators_count"] = len(indicators)
        
        if dates:
            quality_metrics["date_coverage"] = {
                "start": min(dates).isoformat(),
                "end": max(dates).isoformat(),
                "days_covered": (max(dates) - min(dates)).days
            }
        
        # Score based on expected indicators
        expected_indicators = ["price_index", "sales_volume", "mortgage_rate"]
        found_indicators = sum(1 for ind in expected_indicators if ind in indicators)
        quality_metrics["completeness_score"] = found_indicators / len(expected_indicators)
        
        return quality_metrics
    
    def _check_news_quality(self) -> Dict[str, Any]:
        """Check news data quality"""
        news_dir = self.data_dir / "outputs" / "news"
        
        if not news_dir.exists():
            return {"error": "No news data found"}
        
        quality_metrics = {
            "total_articles": 0,
            "freshness_score": 0,
            "sentiment_balance": {}
        }
        
        for parquet_file in news_dir.glob("*.parquet"):
            df = pd.read_parquet(parquet_file)
            quality_metrics["total_articles"] += len(df)
            
            # Check sentiment distribution
            if 'sentiment' in df.columns:
                sentiment_counts = df['sentiment'].value_counts().to_dict()
                quality_metrics["sentiment_balance"] = sentiment_counts
            
            # Check freshness
            if 'published_date' in df.columns:
                df['published_date'] = pd.to_datetime(df['published_date'])
                latest = df['published_date'].max()
                days_old = (datetime.now() - latest).days
                quality_metrics["freshness_score"] = max(0, 1 - (days_old / 7))
        
        return quality_metrics