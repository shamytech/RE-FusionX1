# app/core/storage/storage_manager.py



"""

Unified Storage Manager for RE-FusionX

=======================================

Central storage management using Parquet and DuckDB

"""



from typing import Dict, Any, List, Optional, Union

from datetime import datetime, timedelta

from pathlib import Path

import pandas as pd

import duckdb

import hashlib 

import json 

import numpy as np

from app.core.storage.parquet_manager import ParquetManager

from app.core.storage.search_engine import SearchEngine

from app.core.storage.unified_cache import UnifiedCache, CacheType, get_cache

from app.core.logging import logger

from app.core.config import settings

from app.utils.location_utils import normalize_text, normalize_for_path





class StorageManager:

    """

    Unified storage manager for all data operations

    """

    

    def __init__(self):

        """Initialize storage manager"""

        self.data_dir = Path(settings.DATA_DIR) if hasattr(settings, 'DATA_DIR') else Path("backend/data")

        

        # Initialize components

        self._cache = None

        self.output_manager = ParquetManager(self.data_dir / "outputs")

        self.search_client = SearchEngine(self.data_dir)

        

        # Performance metrics

        self.metrics = {

            "cache_hits": 0,

            "storage_hits": 0,

            "scrape_requests": 0

        }

        logger.info("✅ StorageManager initialized")

    

    @property

    def cache(self):

        """Lazy load cache to avoid circular import"""

        if self._cache is None:

            from app.core.storage.unified_cache import UnifiedCache

            self._cache = UnifiedCache()

        return self._cache

    

    

    async def save_properties(self, properties: List[Dict[str, Any]], location: str, source: str = "scraper") -> bool:

        """

        Save properties to storage and cache - intelligent saving

        """

        if not properties:

            logger.warning("No properties to save")

            return False

        

        try:

            # Log what we're saving

            logger.info(f"Saving {len(properties)} properties from {source}")

            

            # Extract actual location from data

            actual_location = self._extract_actual_location(properties, location)

            

            # Check if this exact data was already saved

            data_signature = self._generate_data_signature(properties)

            cache_key = f"saved:{data_signature}"

            

            if await self.cache.get(cache_key, CacheType.PROPERTY):

                logger.info(f"✅ Data already saved (signature: {data_signature[:8]}...)")

                return True

            

            # Save to Parquet (will handle deduplication internally)

            output_path = self.output_manager.save_properties(

                properties,

                actual_location,

                force_save=False

            )

            

            if output_path:

                # Mark as saved in cache

                await self.cache.set(

                    cache_key,

                    {"path": str(output_path), "timestamp": datetime.now().isoformat()},

                    CacheType.PROPERTY,

                    ttl_override=86400  # Remember for 24 hours

                )

                

                # Update location cache

                location_cache_key = self.cache.generate_key(

                    CacheType.PROPERTY,

                    actual_location

                )

                await self.cache.set(

                    location_cache_key,

                    properties,

                    CacheType.PROPERTY

                )

                

                # Clear search cache for this location

                await self.cache.clear_pattern(f"search:*{location}*")

                await self.cache.clear_pattern(f"search:*{actual_location}*")
                
                
                # Refresh DuckDB properties view so new files are immediately visible
                try:
                    self.search_client.refresh_properties_view()
                except Exception as e:
                    logger.debug(f"Could not refresh properties view: {e}")
                
                logger.info(f"✅ Successfully saved to: {output_path}")

                return True

            else:

                logger.warning("Failed to save properties to Parquet")

                return False

                

        except Exception as e:

            logger.error(f"Failed to save properties: {e}", exc_info=True)

            return False

    

    def _extract_actual_location(self, properties: List[Dict], default_location: str) -> str:

        """

        Extract the most appropriate location from property data

        """

        if not properties:

            return default_location

        

        # Check first property for location info

        first_prop = properties[0]

        

        # Priority: city > district > location > default

        if first_prop.get('city'):

            return first_prop['city']

        elif first_prop.get('district'):

            return first_prop['district']

        elif first_prop.get('location'):

            return first_prop['location']

        else:

            return default_location

    

    def _generate_data_signature(self, properties: List[Dict]) -> str:

        """

        Generate a unique signature for the dataset

        """

        if not properties:

            return ""

        

        # Use first few properties' IDs to create signature

        signature_parts = []

        

        for i, prop in enumerate(properties[:5]):

            if prop.get('listing_id'):

                signature_parts.append(prop['listing_id'])

            elif prop.get('url'):

                signature_parts.append(prop['url'])

        

        if signature_parts:

            signature_string = "_".join(signature_parts)

            return hashlib.md5(signature_string.encode()).hexdigest()

        

        # Fallback: use count and first title

        fallback = f"{len(properties)}_{properties[0].get('title', '')}"

        return hashlib.md5(fallback.encode()).hexdigest()

    

    async def get_properties(self, location: str, filters: Optional[Dict[str, Any]] = None, force_refresh: bool = False) -> List[Dict[str, Any]]:

        """

        Get properties with intelligent caching and normalized search

        """

        # Normalize location for cache key

        location_normalized = normalize_for_path(location)

        

        # Generate cache key

        cache_key = self.cache.generate_key(

            CacheType.PROPERTY,

            location_normalized,

            filters

        )

        

        # 1. Check cache first

        if not force_refresh:

            cached = await self.cache.get(cache_key, CacheType.PROPERTY)

            if cached:

                self.metrics["cache_hits"] += 1

                logger.debug(f"✅ Cache hit for {location}: {len(cached)} properties")

                return cached

        

        # 2. Search in storage

        logger.debug(f"🔍 Searching storage for: {location}")

        

        try:

            stored_df = self.search_client.search_properties(

                filters={

                    "location": location,

                    **(filters or {})

                },

                limit=filters.get("limit", 100) if filters else 100

            )

            

            if not stored_df.empty:

                logger.info(f"✅ Found {len(stored_df)} properties from storage")

                

                # تحويل إلى قائمة

                properties = stored_df.to_dict('records')

                

                # التحقق من الحداثة

                is_fresh = self._is_data_fresh(stored_df)

                

                # حفظ في الكاش

                if is_fresh:

                    # كاش عادي للبيانات الحديثة

                    await self.cache.set(

                        cache_key,

                        properties,

                        CacheType.PROPERTY

                    )

                    logger.info(f"✅ Returning {len(properties)} fresh properties")

                else:

                    # كاش قصير للبيانات القديمة

                    await self.cache.set(

                        cache_key,

                        properties,

                        CacheType.PROPERTY,

                        ttl_override=1800  # 30 دقيقة

                    )

                    logger.info(f"⚠️ Returning {len(properties)} properties (may need update)")

                

                self.metrics["storage_hits"] += 1

                return properties

                

        except Exception as e:

            logger.error(f"Storage search failed: {e}")

        

        # 3. لا توجد بيانات

        logger.info(f"📦 No data found for {location}")

        self.metrics["scrape_requests"] += 1

        

        return []



    def _is_data_fresh(self, df: pd.DataFrame, max_age_hours: int = 24) -> bool:

        """Check if data is fresh enough"""

        if df.empty:

            return False

        

        # البحث عن عمود التوقيت

        time_columns = ['scraped_at', 'collected_at', 'timestamp', 'created_at']

        

        for col in time_columns:

            if col not in df.columns:

                continue

                

            try:

                # احصل على أحدث قيمة

                latest_value = df[col].max()

                

                if pd.isna(latest_value):

                    continue

                

                latest = None

                now = datetime.now()

                

                # تحويل القيمة

                if isinstance(latest_value, (int, float, np.integer, np.floating)):

                    # تحويل numpy types إلى Python native

                    latest_value = float(latest_value)

                    

                    # القاعدة الواضحة:

                    # - 10 أرقام = seconds

                    # - 13 أرقام = milliseconds

                    # - 16 أرقام = microseconds

                    # - 19 أرقام = nanoseconds

                    

                    if latest_value > 1e12:  # 13+ digits = milliseconds أو أكثر

                        # جرب milliseconds أولاً

                        latest = datetime.fromtimestamp(latest_value / 1000)

                        

                        # تحقق من المنطقية (يجب أن يكون بين 2020-2030)

                        if latest.year < 2020 or latest.year > 2030:

                            # ربما microseconds

                            latest = datetime.fromtimestamp(latest_value / 1e6)

                            

                            if latest.year < 2020 or latest.year > 2030:

                                # ربما nanoseconds

                                latest = datetime.fromtimestamp(latest_value / 1e9)

                                

                    elif latest_value > 1e9:  # 10+ digits = seconds

                        latest = datetime.fromtimestamp(latest_value)

                    else:

                        # رقم صغير جداً

                        logger.warning(f"Timestamp value too small: {latest_value}")

                        continue

                        

                elif isinstance(latest_value, str):

                    if latest_value.isdigit():

                        timestamp = float(latest_value)

                        if timestamp > 1e12:

                            latest = datetime.fromtimestamp(timestamp / 1000)

                        elif timestamp > 1e9:

                            latest = datetime.fromtimestamp(timestamp)

                    else:

                        latest = pd.to_datetime(latest_value).to_pydatetime()

                else:

                    # Pandas timestamp or datetime

                    latest = pd.to_datetime(latest_value).to_pydatetime()

                

                if latest:

                    # حساب العمر

                    age_seconds = (now - latest).total_seconds()

                    age_hours = age_seconds / 3600

                    

                    # التحقق

                    is_fresh = age_hours <= max_age_hours

                    

                    if is_fresh:

                        logger.info(f"✅ Data is fresh ({age_hours:.1f} hours old)")

                    else:

                        logger.info(f"⚠️ Data is stale ({age_hours:.1f} hours old, max={max_age_hours})")

                    

                    return is_fresh

                    

            except Exception as e:

                logger.error(f"Error checking timestamp in column {col}: {e}")

                continue

        

        logger.debug("No timestamp found, assuming fresh")

        return True



    async def search_similar_properties(self, reference_property: Dict[str, Any], limit: int = 20) -> List[Dict[str, Any]]:

        """

        Search for similar properties

        """

        # Generate cache key

        cache_key = self.cache.generate_key(

            CacheType.SEARCH,

            "similar",

            {

                "id": reference_property.get("property_id", ""),

                "location": reference_property.get("location", "")

            }

        )

        

        # Check cache

        cached = await self.cache.get(cache_key, CacheType.SEARCH)

        if cached:

            return cached

        

        # Search using DuckDB

        if reference_property.get("property_id"):

            similar_df = self.search_client.find_similar_properties(

                reference_property["property_id"],

                limit

            )

            

            if not similar_df.empty:

                similar = similar_df.to_dict('records')

                

                # Cache results

                await self.cache.set(

                    cache_key,

                    similar,

                    CacheType.SEARCH

                )

                

                return similar

        

        return []

    

    async def get_market_analysis(self, location: str, days_back: int = 30) -> Dict[str, Any]:

        """

        Get market analysis

        """

        # Generate cache key

        cache_key = self.cache.generate_key(

            CacheType.MARKET,

            f"analysis_{location}",

            {"days": days_back}

        )

        

        # Check cache

        cached = await self.cache.get(cache_key, CacheType.MARKET)

        if cached:

            return cached

        

        # Get from storage

        analysis = self.search_client.get_market_analysis(

            location,

            days_back

        )

        

        # Cache results

        if analysis:

            await self.cache.set(

                cache_key,

                analysis,

                CacheType.MARKET

            )

        

        return analysis

    

    async def cleanup_old_data(self, days_to_keep: int = 30) -> Dict[str, int]:

        """

        Clean up old data

        """

        stats = {

            "cache_cleared": 0,

            "files_deleted": 0

        }

        

        # Clear old cache entries

        stats["cache_cleared"] = await self.cache.clear_pattern("*")

        

        # Clean old Parquet files

        cutoff_date = datetime.now() - timedelta(days=days_to_keep)

        

        for parquet_file in (self.data_dir / "outputs").rglob("*.parquet"):

            if parquet_file.stat().st_mtime < cutoff_date.timestamp():

                parquet_file.unlink()

                stats["files_deleted"] += 1

        

        logger.info(f"Cleanup completed: {stats}")

        return stats

    

    def get_statistics(self) -> Dict[str, Any]:

        """Get storage statistics"""

        return {

            "performance_metrics": self.metrics,

            "cache_stats": self.cache.get_stats(),

            "storage_stats": self.output_manager.get_statistics()

        }





# Singleton instance

_storage_instance = None

_creating_instance = False



def get_storage_manager() -> StorageManager:

    """Get storage manager singleton safely"""

    global _storage_instance, _creating_instance

    

    if _storage_instance is None and not _creating_instance:

        _creating_instance = True

        try:

            _storage_instance = StorageManager()

        finally:

            _creating_instance = False

    

    return _storage_instance