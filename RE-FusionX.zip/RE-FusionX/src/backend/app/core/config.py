"""
Configuration management for RE-FusionX system.
Handles all environment variables and system configurations.
"""

import os
from typing import List, Optional, Dict, Any
from pathlib import Path
from pydantic import Field, field_validator
from pydantic_settings import BaseSettings
from functools import lru_cache
import secrets


class Settings(BaseSettings):
    """
    Application settings with validation and type checking.
    Uses Pydantic for robust configuration management.
    """
    
    # Application Details
    APP_NAME: str = "RE-FusionX"
    APP_VERSION: str = "2.0.0"
    APP_DESCRIPTION: str = "AI-Powered Turkish Real Estate Analysis System"
    
    # API Configuration
    API_V1_PREFIX: str = "/api/v1"
    DEBUG: bool = Field(default=False, alias="DEBUG")
    
    # Server Configuration
    HOST: str = Field(default="0.0.0.0", alias="HOST")
    PORT: int = Field(default=8000, alias="PORT")
    WORKERS: int = Field(default=4, alias="WORKERS")
    
    # Security
    SECRET_KEY: str = Field(default_factory=lambda: secrets.token_urlsafe(32))
    CORS_ORIGINS: List[str] = Field(default=["*"], alias="CORS_ORIGINS")
    
    # المسارات الأساسية للنموذج
    PROJECT_ROOT: Path = Path(r"D:\Phd\RE-FusionX\src\backend")
    DATA_DIR: Path = PROJECT_ROOT / "data"
    LLAMA_FACTORY_DIR: Path = PROJECT_ROOT / "src" / "LLaMA-Factory"
    
    # مسارات النموذج
    MODEL_BASE_PATH: Path = PROJECT_ROOT / "data" / "models" / "vision"
    MODEL_NAME: str = "models--Qwen--Qwen2.5-VL-32B-Instruct"
    MODEL_SNAPSHOT: str = "7cfb30d71a1f4f49a57592323337a4a4727301da"
    BASE_MODEL_PATH: Path = MODEL_BASE_PATH / MODEL_NAME / "snapshots" / MODEL_SNAPSHOT
    OUTPUT_DIR: Path = LLAMA_FACTORY_DIR / "output"
    LORA_OUTPUT_DIR: Path = OUTPUT_DIR / "qwen_real_estate_lora"
    MERGED_MODEL_DIR: Path = OUTPUT_DIR / "merged_model"
    
    
    
    # المسار الرئيسي للنموذج المُدرب
    QWEN_MODEL_PATH: Path = Field(
        default=OUTPUT_DIR / "merged_model",
        alias="QWEN_MODEL_PATH"
    )
    
    XGBOOST_MODEL_PATH: Path = Field(
        default=Path("data/models/xgboost_price_predictor.pkl"),
        alias="XGBOOST_MODEL_PATH"
    )
    
    # Database Configuration
    PROPERTY_DB_PATH: Path = Field(
        default=PROJECT_ROOT / "data" / "raw" / "structured" / "real_estate_data.json",
        alias="PROPERTY_DB_PATH"
    )
    REDIS_URL: Optional[str] = Field(default=None, alias="REDIS_URL")
    
    # Cache Configuration
    CACHE_TTL: int = Field(default=3600, alias="CACHE_TTL")  # 1 hour
    CACHE_ENABLED: bool = Field(default=True, alias="CACHE_ENABLED")
    
    # Model Configuration
    MAX_TOKENS: int = Field(default=2048, alias="MAX_TOKENS")
    TEMPERATURE: float = Field(default=0.7, alias="TEMPERATURE")
    TOP_P: float = Field(default=0.9, alias="TOP_P")
    USE_QUANTIZATION: bool = Field(default=True, alias="USE_QUANTIZATION")
    
    # Search API Keys
    SERP_API_KEY: Optional[str] = Field(default=None, alias="SERP_API_KEY")
    GOOGLE_API_KEY: Optional[str] = Field(default=None, alias="GOOGLE_API_KEY")
    GOOGLE_CSE_ID: Optional[str] = Field(default=None, alias="GOOGLE_CSE_ID")
    
    # Google Gemini
    GOOGLE_API_KEY: Optional[str] = Field(default=None, alias="GOOGLE_API_KEY")
    
     # OpenAI
    OPENAI_API_KEY: Optional[str] = Field(default=None, alias="OPENAI_API_KEY")
    
    # Groq (Free & Fast)
    GROQ_API_KEY: Optional[str] = Field(default=None, alias="GROQ_API_KEY")
    
    # Together AI
    TOGETHER_API_KEY: Optional[str] = Field(default=None, alias="TOGETHER_API_KEY")
    
    # AgentQL
    AGENTQL_API_KEY: Optional[str] = Field(default=None, alias="AGENTQL_API_KEY")
    
    # HuggingFace
    HUGGINGFACE_TOKEN: Optional[str] = Field(default=None, alias="HUGGINGFACE_TOKEN")
    
    # === Local Model Settings ===
    OLLAMA_HOST: str = Field(default="http://localhost:11434", alias="OLLAMA_HOST")
    MODEL_PRIORITY: str = Field(
        default="google,groq,ollama,together,openai",
        alias="MODEL_PRIORITY"
    )
    USE_GPU: bool = Field(default=True, alias="USE_GPU")
    GPU_LAYERS: int = Field(default=35, alias="GPU_LAYERS")
    SKIP_MODEL_LOADING: bool = Field(default=False, alias="SKIP_MODEL_LOADING")
    
    # === Scraping Settings ===
    ENABLE_AI_SCRAPING: bool = Field(default=True, alias="ENABLE_AI_SCRAPING")
    SCRAPING_TIMEOUT: int = Field(default=30, alias="SCRAPING_TIMEOUT")
    MAX_RETRIES_PER_TOOL: int = Field(default=2, alias="MAX_RETRIES_PER_TOOL")

    # Market data settings
    MARKET_DATA_UPDATE_INTERVAL: int = Field(default=6, alias="MARKET_DATA_UPDATE_INTERVAL")  # hours
    MARKET_DATA_CACHE_DIR: Path = Field(default=Path("backend/data/market_cache"), alias="MARKET_DATA_CACHE_DIR")
    MARKET_DATA_SOURCES: list[str] = Field(
        default=["sahibinden", "emlakjet", "hurriyetemlak", "zingat"],
        alias="MARKET_DATA_SOURCES"
    )

    # API Keys (if needed for some sources)
    MARKET_API_KEYS: dict[str, str] = Field(
        default_factory=lambda: {
            "tcmb": os.getenv("TCMB_API_KEY", ""),
            "tuik": os.getenv("TUIK_API_KEY", "")
        },
        alias="MARKET_API_KEYS"
    )
    
    # Geographic Configuration
    GEOPY_USER_AGENT: str = Field(
        default="re_fusionx_geo_analyzer",
        alias="GEOPY_USER_AGENT"
    )
    
    # Performance Configuration
    REQUEST_TIMEOUT: int = Field(default=30, alias="REQUEST_TIMEOUT")
    MAX_CONCURRENT_REQUESTS: int = Field(default=10, alias="MAX_CONCURRENT_REQUESTS")
    
    # Logging Configuration
    LOG_LEVEL: str = Field(default="INFO", alias="LOG_LEVEL")
    LOG_FORMAT: str = Field(
        default="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
        alias="LOG_FORMAT"
    )
    
    # Memory Configuration
    MAX_CONVERSATION_HISTORY: int = Field(default=10, alias="MAX_CONVERSATION_HISTORY")
    SESSION_TIMEOUT: int = Field(default=3600, alias="SESSION_TIMEOUT")  # 1 hour
    
    @field_validator("LOG_LEVEL", mode='before')
    @classmethod
    def validate_log_level(cls, v: str) -> str:
        """Validate log level is valid."""
        valid_levels = ["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"]
        if v.upper() not in valid_levels:
            raise ValueError(f"Log level must be one of {valid_levels}")
        return v.upper()
    
    @field_validator("REDIS_URL", mode='before')
    @classmethod
    def get_redis_url(cls, v: Optional[str]) -> Optional[str]:
        """Get Redis URL from environment if not provided."""
        if v is None:
            v = os.getenv("REDIS_URL")
        return v
    
    model_config = {
        "env_file": ".env",
        "env_file_encoding": "utf-8",
        "case_sensitive": True,
        "populate_by_name": True,
        "extra": "ignore"
    }


@lru_cache()
def get_settings() -> Settings:
    """
    Get cached settings instance.
    Uses LRU cache to ensure single instance.
    """
    return Settings()


# Export settings instance
settings = get_settings()
