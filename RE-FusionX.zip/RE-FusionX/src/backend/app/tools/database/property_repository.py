"""
Property Repository - Simplified Version
=========================================
Uses unified storage manager
"""

from typing import Dict, Any, List, Optional
import asyncio

from app.tools.base_tool import BaseTool
from app.core.logging import logger
from app.core.storage.integration import StorageIntegration
from app.core.storage.unified_cache import CacheType


class PropertyRepository(BaseTool):
    """Simplified property repository using unified storage"""
    
    def __init__(self):
        """Initialize property repository"""
        super().__init__(
            name="PropertyRepository",
            description="Property data operations"
        )
        
        # استخدام النظام الجديد
        self._storage = None
        self._cache = None

    @property
    def storage(self):
        """Lazy load storage"""
        if self._storage is None:
            from app.core.storage.integration import StorageIntegration
            self._storage = StorageIntegration.get_storage()
        return self._storage
    
    @property
    def cache(self):
        """Lazy load cache"""
        if self._cache is None:
            from app.core.storage.integration import StorageIntegration
            self._cache = StorageIntegration.get_cache()
        return self._cache
    
    def validate_input(self, **kwargs) -> bool:
        """Validate input"""
        return True
    
    async def execute(self, **kwargs) -> Dict[str, Any]:
        """Execute repository operation"""
        operation = kwargs.get('operation', 'search')
        
        if operation == 'search':
            return await self.search_properties(**kwargs)
        elif operation == 'similar':
            return await self.find_similar(**kwargs)
        elif operation == 'statistics':
            return await self.get_statistics(**kwargs)
        else:
            return {"error": f"Unknown operation: {operation}"}
    
    async def search_properties(self, **criteria) -> List[Dict[str, Any]]:
        """
        Search properties with caching
        
        Args:
            **criteria: Search criteria
            
        Returns:
            List of properties
        """
        location = criteria.get('location', 'Istanbul')
        filters = {
            k: v for k, v in criteria.items()
            if k not in ['location', 'operation']
        }
        
        # Generate cache key
        cache_key = self.cache.generate_key(
            CacheType.PROPERTY,
            f"search_{location}",
            filters
        )
        
        # Check cache first
        cached = await self.cache.get(cache_key, CacheType.PROPERTY)
        if cached:
            logger.debug(f"Repository: Cache hit for {location}")
            return cached
        
        # Use unified storage
        properties = await self.storage.get_properties(
            location=location,
            filters=filters
        )
        
        # If no properties found, return simulated data for testing
        if not properties:
            logger.info("No properties in storage, returning simulated data")
            properties = self._generate_simulated_properties(location, filters)
        
        # Cache the results
        if properties:
            await self.cache.set(cache_key, properties, CacheType.PROPERTY)
        
        return properties
    
    async def find_similar(
        self,
        property_data: Dict[str, Any],
        limit: int = 10
    ) -> Dict[str, Any]:
        """
        Find similar properties with caching
        
        Args:
            property_data: Reference property
            limit: Maximum results
            
        Returns:
            Similar properties with scores
        """
        # Generate cache key
        cache_key = self.cache.generate_key(
            CacheType.SEARCH,
            "similar",
            {
                "id": property_data.get("property_id", ""),
                "location": property_data.get("location", ""),
                "limit": limit
            }
        )
        
        # Check cache
        cached = await self.cache.get(cache_key, CacheType.SEARCH)
        if cached:
            return cached
        
        # Find similar properties
        similar = await self.storage.search_similar_properties(
            property_data,
            limit
        )
        
        result = {
            "reference_property": property_data,
            "similar_properties": similar,
            "total_found": len(similar)
        }
        
        # Cache the result
        await self.cache.set(cache_key, result, CacheType.SEARCH)
        
        return result
    
    async def get_statistics(
        self,
        location: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Get market statistics with caching
        
        Args:
            location: Optional location filter
            
        Returns:
            Market statistics
        """
        location = location or "Turkey"
        
        # Generate cache key
        cache_key = self.cache.generate_key(
            CacheType.MARKET,
            f"stats_{location}"
        )
        
        # Check cache
        cached = await self.cache.get(cache_key, CacheType.MARKET)
        if cached:
            return cached
        
        # Get statistics
        stats = await self.storage.get_market_analysis(
            location,
            days_back=30
        )
        
        # Cache the result
        if stats:
            await self.cache.set(cache_key, stats, CacheType.MARKET)
        
        return stats
    
    async def get_property(self, property_id: str) -> Optional[Dict[str, Any]]:
        """
        Get single property by ID
        
        Args:
            property_id: Property identifier
            
        Returns:
            Property data or None
        """
        # Generate cache key
        cache_key = self.cache.generate_key(
            CacheType.PROPERTY,
            f"prop_{property_id}"
        )
        
        # Check cache
        cached = await self.cache.get(cache_key, CacheType.PROPERTY)
        if cached:
            return cached
        
        # Search for the property
        properties = await self.search_properties(
            property_id=property_id,
            limit=1
        )
        
        if properties:
            property_data = properties[0]
            # Cache the result
            await self.cache.set(cache_key, property_data, CacheType.PROPERTY)
            return property_data
        
        return None
    
    def _generate_simulated_properties(
        self,
        location: str,
        filters: Dict[str, Any]
    ) -> List[Dict[str, Any]]:
        """Generate simulated properties for testing"""
        properties = []
        
        for i in range(min(filters.get('limit', 10), 10)):
            properties.append({
                "property_id": f"sim_{i+1}",
                "title": f"Property {i+1} in {location}",
                "location": location,
                "price": 3000000 + (i * 500000),
                "size": 100 + (i * 20),
                "size_sqm": 100 + (i * 20),
                "rooms": "3+1" if i % 2 == 0 else "2+1",
                "property_type": "Daire",
                "source": "simulated",
                "building_age": str(i % 10),
                "in_site": "Evet" if i % 3 == 0 else "Hayır"
            })
        
        return properties
