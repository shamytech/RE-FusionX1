"""
Similarity Finder Tool
======================
Finds similar properties based on features
"""

from typing import Dict, Any, List, Optional
import math
import asyncio

from app.tools.base_tool import BaseTool
from app.core.logging import logger
from app.core.storage.integration import StorageIntegration
from app.core.storage.unified_cache import CacheType


class SimilarityFinder(BaseTool):
    """Find similar properties based on features."""
    
    def __init__(self):
        """Initialize similarity finder."""
        super().__init__(
            name="SimilarityFinder",
            description="Find similar properties based on features"
        )
        
        # استخدام النظام الجديد
        self._storage = None
        self._cache = None

    @property
    def storage(self):
        """Lazy load storage"""
        if self._storage is None:
            from app.core.storage.integration import StorageIntegration
            self._storage = StorageIntegration.get_storage()
        return self._storage
    
    @property
    def cache(self):
        """Lazy load cache"""
        if self._cache is None:
            from app.core.storage.integration import StorageIntegration
            self._cache = StorageIntegration.get_cache()
        return self._cache
        
    
    def validate_input(self, **kwargs) -> bool:
        """Validate input."""
        return 'property_data' in kwargs or 'property_id' in kwargs
    
    async def execute(self, **kwargs) -> Dict[str, Any]:
        """
        Find similar properties with proper caching.
        """
        try:
            property_data = kwargs.get('property_data', {})
            property_id = kwargs.get('property_id')
            limit = kwargs.get('limit', 10)
            
            # If property_id provided, get property data first
            if property_id and not property_data:
                property_data = await self._get_property_by_id(property_id)
                if not property_data:
                    return {
                        "error": f"Property {property_id} not found",
                        "properties": [],
                        "similar_properties": []
                    }
            
            # Generate cache key
            cache_key = self.cache.generate_key(
                CacheType.SEARCH,
                "similarity",
                {
                    "id": property_data.get("property_id", ""),
                    "location": property_data.get("location", ""),
                    "type": property_data.get("property_type", ""),
                    "limit": limit
                }
            )
            
            # Check cache
            cached = await self.cache.get(cache_key, CacheType.SEARCH)
            if cached:
                logger.debug("Similarity finder: Cache hit")
                return cached
            
            # Try to get real properties from storage first
            similar_properties = await self._find_similar_from_storage(property_data, limit)
            
            # If no real data, use dummy properties
            if not similar_properties:
                logger.info("Using dummy properties for similarity search")
                dummy_properties = self._generate_dummy_properties(property_data)
                
                # Calculate similarity scores
                scored_properties = []
                for prop in dummy_properties:
                    score = self.calculate_similarity(property_data, prop)
                    scored_properties.append({
                        'property': prop,
                        'similarity_score': score
                    })
                
                # Sort by similarity
                scored_properties.sort(key=lambda x: x['similarity_score'], reverse=True)
                similar_properties = scored_properties[:limit]
            
            # Prepare result
            result = {
                "reference_property": self.summarize_property(property_data),
                "similar_properties": [
                    {
                        **self.summarize_property(item.get('property', item)),
                        'similarity_score': round(item.get('similarity_score', 0), 2)
                    }
                    for item in similar_properties
                ],
                "total_found": len(similar_properties),
                "properties": [item.get('property', item) for item in similar_properties]  # للتوافق
            }
            
            # Cache the result
            await self.cache.set(cache_key, result, CacheType.SEARCH)
            
            return result
            
        except Exception as e:
            logger.error(f"Similarity search failed: {e}", exc_info=True)
            return {
                "error": str(e),
                "properties": [],
                "similar_properties": []
            }
    
    async def _get_property_by_id(self, property_id: str) -> Optional[Dict[str, Any]]:
        """Get property by ID from storage"""
        try:
            # Try to get from storage
            properties = await self.storage.get_properties(
                location="",  # Search all locations
                filters={"property_id": property_id, "limit": 1}
            )
            
            if properties:
                return properties[0]
        except Exception as e:
            logger.error(f"Failed to get property by ID: {e}")
        
        return None
    
    async def _find_similar_from_storage(
        self,
        property_data: Dict[str, Any],
        limit: int
    ) -> List[Dict[str, Any]]:
        """Find similar properties from storage"""
        try:
            # Use storage's similar search
            similar = await self.storage.search_similar_properties(
                property_data,
                limit * 2  # Get more to filter
            )
            
            if similar:
                # Calculate similarity scores
                scored = []
                for prop in similar:
                    score = self.calculate_similarity(property_data, prop)
                    scored.append({
                        'property': prop,
                        'similarity_score': score
                    })
                
                # Sort and return top results
                scored.sort(key=lambda x: x['similarity_score'], reverse=True)
                return scored[:limit]
        
        except Exception as e:
            logger.debug(f"Storage similarity search failed: {e}")
        
        return []
    
    def _generate_dummy_properties(self, reference: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Generate dummy properties for testing."""
        location = reference.get('location', 'Istanbul')
        base_price = reference.get('price', 5000000) if reference.get('price') else 5000000
        
        # Ensure base_price is numeric
        if isinstance(base_price, str):
            try:
                base_price = float(base_price.replace(' TL', '').replace('.', '').replace(',', '.'))
            except:
                base_price = 5000000
        
        dummy_properties = []
        for i in range(20):
            # Vary properties around reference
            price_variation = base_price * (0.7 + (i * 0.03))
            size_variation = 100 + (i * 5)
            
            dummy_properties.append({
                "property_id": f"dummy_{i+1}",
                "id": f"prop_{i+1}",
                "title": f"Property {i+1} in {location}",
                "location": location if i % 3 == 0 else f"{location} - Nearby",
                "price": price_variation,
                "size": size_variation,
                "size_net": size_variation,
                "size_gross": size_variation + 20,
                "room_count": "3+1" if i % 2 == 0 else "2+1",
                "rooms": "3+1" if i % 2 == 0 else "2+1",
                "building_age": f"{i % 10}",
                "property_type": reference.get('property_type', 'Daire'),
                "in_site": "Evet" if i % 3 == 0 else "Hayır",
                "floor": i % 10,
                "total_floors": 12,
                "heating": "Merkezi" if i % 2 == 0 else "Kombi"
            })
        
        return dummy_properties
    
    def calculate_similarity(self, prop1: Dict[str, Any], prop2: Dict[str, Any]) -> float:
        """Calculate similarity score between two properties."""
        score = 0
        weights = {
            'location': 25,
            'size': 20,
            'rooms': 15,
            'price': 15,
            'age': 10,
            'features': 15
        }
        
        # Location similarity
        loc1 = str(prop1.get('location', '')).lower()
        loc2 = str(prop2.get('location', '')).lower()
        
        if loc1 == loc2:
            score += weights['location']
        elif loc1.split('-')[0].strip() == loc2.split('-')[0].strip():
            score += weights['location'] * 0.6
        
        # Size similarity
        size1 = self.extract_size(prop1)
        size2 = self.extract_size(prop2)
        
        if size1 and size2:
            size_diff = abs(size1 - size2) / max(size1, size2)
            if size_diff < 0.1:
                score += weights['size']
            elif size_diff < 0.2:
                score += weights['size'] * 0.5
        
        # Room similarity
        rooms1 = str(prop1.get('room_count', prop1.get('rooms', '')))
        rooms2 = str(prop2.get('room_count', prop2.get('rooms', '')))
        if rooms1 == rooms2:
            score += weights['rooms']
        
        # Price similarity
        price1 = self.extract_price(prop1)
        price2 = self.extract_price(prop2)
        
        if price1 and price2:
            price_diff = abs(price1 - price2) / max(price1, price2)
            if price_diff < 0.15:
                score += weights['price']
            elif price_diff < 0.25:
                score += weights['price'] * 0.5
        
        # Age similarity
        age1 = str(prop1.get('building_age', ''))
        age2 = str(prop2.get('building_age', ''))
        
        if age1 == age2:
            score += weights['age']
        elif self.similar_age_category(age1, age2):
            score += weights['age'] * 0.5
        
        # Feature similarity
        features_score = self.calculate_feature_similarity(prop1, prop2)
        score += weights['features'] * features_score
        
        return score
    
    def extract_size(self, prop: Dict[str, Any]) -> Optional[float]:
        """Extract size from property."""
        try:
            # Try multiple fields
            for field in ['size', 'size_net', 'size_gross', 'size_sqm']:
                if field in prop:
                    value = prop[field]
                    if isinstance(value, (int, float)):
                        return float(value)
                    else:
                        size_str = str(value)
                        size_str = size_str.replace(' m²', '').replace(' m', '').replace(',', '.')
                        return float(size_str)
        except Exception as e:
            logger.debug(f"Failed to extract size: {e}")
        return None
    
    def extract_price(self, prop: Dict[str, Any]) -> Optional[float]:
        """Extract price from property."""
        try:
            price = prop.get('price', 0)
            if isinstance(price, (int, float)):
                return float(price)
            else:
                price_str = str(price)
                return float(price_str.replace(' TL', '').replace('.', '').replace(',', '.'))
        except Exception as e:
            logger.debug(f"Failed to extract price: {e}")
        return None
    
    def similar_age_category(self, age1: str, age2: str) -> bool:
        """Check if ages are in similar category."""
        new_ages = ['0', 'Yeni', '1-4', '1', '2', '3', '4']
        medium_ages = ['5-10', '5', '6', '7', '8', '9', '10', '11-15']
        old_ages = ['16-20', '21-25', '26-30', '31+']
        
        for category in [new_ages, medium_ages, old_ages]:
            if age1 in category and age2 in category:
                return True
        
        return False
    
    def calculate_feature_similarity(self, prop1: Dict[str, Any], prop2: Dict[str, Any]) -> float:
        """Calculate feature similarity score."""
        score = 0
        count = 0
        
        # Compare boolean features
        features = ['in_site', 'credit_eligible', 'furnished', 'has_parking', 'has_elevator']
        
        for feature in features:
            if feature in prop1 and feature in prop2:
                count += 1
                if prop1[feature] == prop2[feature]:
                    score += 1
        
        # Compare heating
        if prop1.get('heating') and prop2.get('heating'):
            count += 1
            if prop1.get('heating') == prop2.get('heating'):
                score += 1
        
        return score / count if count > 0 else 0.5
    
    def summarize_property(self, prop: Dict[str, Any]) -> Dict[str, Any]:
        """Create property summary."""
        return {
            "location": prop.get('location', 'Unknown'),
            "price": prop.get('price', 'N/A'),
            "size": prop.get('size', prop.get('size_net', prop.get('size_gross', prop.get('size_sqm', 'N/A')))),
            "rooms": prop.get('room_count', prop.get('rooms', 'N/A')),
            "building_age": prop.get('building_age', 'N/A'),
            "property_type": prop.get('property_type', 'N/A'),
            "in_site": prop.get('in_site', 'N/A')
        }
