"""
Image analysis tool for property images.
Analyzes property images for condition and features.
"""

from typing import Dict, Any, List, Optional
from PIL import Image
import io

from app.tools.base_tool import BaseTool
from app.core.logging import logger


class ImageAnalyzer(BaseTool):
    """Analyze property images for insights."""
    
    def __init__(self, model_loader):
        """Initialize image analyzer."""
        super().__init__(
            name="ImageAnalyzer",
            description="Analyze property images for condition and features"
        )
        
        self.model_loader = model_loader
    
    def validate_input(self, **kwargs) -> bool:
        """Validate input."""
        return 'images' in kwargs
    
    async def execute(self, **kwargs) -> Dict[str, Any]:
        """
        Analyze property images.
        
        Args:
            images: List of images to analyze
            context: Property context information
            
        Returns:
            Image analysis results
        """
        images = kwargs.get('images', [])
        context = kwargs.get('context', {})
        
        if not images:
            return {"error": "No images provided"}
        
        # Analyze each image
        image_analyses = []
        for img in images:
            analysis = await self.analyze_single_image(img, context)
            image_analyses.append(analysis)
        
        # Aggregate results
        aggregated = self.aggregate_analyses(image_analyses)
        
        # Generate overall assessment
        assessment = self.generate_assessment(aggregated, context)
        
        return {
            "individual_analyses": image_analyses,
            "aggregated_results": aggregated,
            "assessment": assessment,
            "condition_score": aggregated.get('overall_condition', 5),
            "features": aggregated.get('detected_features', []),
            "recommendations": self.generate_recommendations(aggregated),
            "quality_indicators": aggregated.get('quality_indicators', {})
        }
    
    async def analyze_single_image(
        self,
        image: Any,
        context: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Analyze a single image."""
        try:
            # Get the model
            model = await self.model_loader.get_model()
            
            # Prepare prompt
            prompt = self.prepare_image_prompt(context)
            
            # Analyze with model
            analysis = await model.analyze_image(image, prompt)
            
            # Parse and structure results
            return self.parse_image_analysis(analysis)
            
        except Exception as e:
            logger.error(f"Image analysis failed: {e}")
            return self.get_fallback_analysis()
    
    def prepare_image_prompt(self, context: Dict[str, Any]) -> str:
        """Prepare prompt for image analysis."""
        return f"""Analyze this property image and provide:
1. Room type identification
2. Condition assessment (1-10 scale)
3. Visible features and amenities
4. Quality indicators
5. Any issues or concerns
6. Renovation needs

Context: {context.get('property_type', 'Residential property')} in {context.get('location', 'Turkey')}"""
    
    def parse_image_analysis(self, analysis: str) -> Dict[str, Any]:
        """Parse model's image analysis."""
        # This would parse the model's response
        # For now, returning structured data
        return {
            "room_type": "living_room",
            "condition": 7,
            "features": ["natural_light", "spacious", "modern_fixtures"],
            "issues": [],
            "quality": "good"
        }
    
    def get_fallback_analysis(self) -> Dict[str, Any]:
        """Fallback analysis when model fails."""
        return {
            "room_type": "unknown",
            "condition": 5,
            "features": [],
            "issues": ["unable_to_analyze"],
            "quality": "unknown"
        }
    
    def aggregate_analyses(
        self,
        analyses: List[Dict[str, Any]]
    ) -> Dict[str, Any]:
        """Aggregate multiple image analyses."""
        if not analyses:
            return {}
        
        # Calculate average condition
        conditions = [a.get('condition', 5) for a in analyses]
        avg_condition = sum(conditions) / len(conditions)
        
        # Collect all features
        all_features = []
        for analysis in analyses:
            all_features.extend(analysis.get('features', []))
        
        # Identify room types
        room_types = [a.get('room_type', 'unknown') for a in analyses]
        
        # Collect issues
        all_issues = []
        for analysis in analyses:
            all_issues.extend(analysis.get('issues', []))
        
        return {
            "overall_condition": round(avg_condition, 1),
            "detected_features": list(set(all_features)),
            "room_types_analyzed": list(set(room_types)),
            "identified_issues": list(set(all_issues)),
            "quality_indicators": self.calculate_quality_indicators(analyses),
            "image_count": len(analyses)
        }
    
    def calculate_quality_indicators(
        self,
        analyses: List[Dict[str, Any]]
    ) -> Dict[str, Any]:
        """Calculate quality indicators from analyses."""
        indicators = {
            "maintenance": "unknown",
            "modernity": "unknown",
            "spaciousness": "unknown",
            "lighting": "unknown"
        }
        
        # Check for specific features
        all_features = []
        for analysis in analyses:
            all_features.extend(analysis.get('features', []))
        
        if 'well_maintained' in all_features or 'clean' in all_features:
            indicators['maintenance'] = "excellent"
        elif 'needs_repair' in all_features:
            indicators['maintenance'] = "poor"
        else:
            indicators['maintenance'] = "good"
        
        if 'modern' in all_features or 'modern_fixtures' in all_features:
            indicators['modernity'] = "modern"
        elif 'dated' in all_features:
            indicators['modernity'] = "dated"
        else:
            indicators['modernity'] = "standard"
        
        if 'spacious' in all_features:
            indicators['spaciousness'] = "spacious"
        elif 'cramped' in all_features:
            indicators['spaciousness'] = "limited"
        else:
            indicators['spaciousness'] = "adequate"
        
        if 'natural_light' in all_features or 'bright' in all_features:
            indicators['lighting'] = "excellent"
        elif 'dark' in all_features:
            indicators['lighting'] = "poor"
        else:
            indicators['lighting'] = "good"
        
        return indicators
    
    def generate_assessment(
        self,
        aggregated: Dict[str, Any],
        context: Dict[str, Any]
    ) -> str:
        """Generate overall assessment."""
        condition = aggregated.get('overall_condition', 5)
        
        if condition >= 8:
            assessment = "Excellent condition property with high-quality finishes"
        elif condition >= 6:
            assessment = "Good condition property with standard maintenance"
        elif condition >= 4:
            assessment = "Fair condition property that may need some updates"
        else:
            assessment = "Property requires significant renovation"
        
        # Add specific observations
        features = aggregated.get('detected_features', [])
        if 'modern' in features or 'modern_fixtures' in features:
            assessment += ". Modern fixtures and finishes observed"
        
        issues = aggregated.get('identified_issues', [])
        if issues:
            assessment += f". Some issues identified: {', '.join(issues)}"
        
        return assessment
    
    def generate_recommendations(
        self,
        aggregated: Dict[str, Any]
    ) -> List[str]:
        """Generate recommendations based on analysis."""
        recommendations = []
        
        condition = aggregated.get('overall_condition', 5)
        issues = aggregated.get('identified_issues', [])
        
        if condition < 6:
            recommendations.append("Consider renovation budget in purchase decision")
        
        if 'needs_repair' in issues:
            recommendations.append("Get professional inspection before purchase")
        
        if condition >= 8:
            recommendations.append("Property appears move-in ready")
        
        quality = aggregated.get('quality_indicators', {})
        if quality.get('maintenance') == 'poor':
            recommendations.append("Factor in immediate maintenance costs")
        
        if quality.get('modernity') == 'dated':
            recommendations.append("Budget for modernization if desired")
        
        return recommendations
