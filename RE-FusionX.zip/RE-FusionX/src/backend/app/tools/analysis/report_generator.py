"""
Report generation tool.
Creates comprehensive analysis reports.
"""

from typing import Dict, Any, List, Optional
from datetime import datetime
import json

from app.tools.base_tool import BaseTool
from app.core.logging import logger


class ReportGenerator(BaseTool):
    """Generate comprehensive analysis reports."""
    
    def __init__(self):
        """Initialize report generator."""
        super().__init__(
            name="ReportGenerator",
            description="Generate comprehensive property analysis reports"
        )
        
        self.report_templates = self.load_templates()
    
    def load_templates(self) -> Dict[str, str]:
        """Load report templates."""
        return {
            "executive_summary": """
# Executive Summary

**Property**: {location}
**Type**: {property_type}
**Size**: {size}
**Price**: {price}

## Key Findings
{key_findings}

## Recommendation
{recommendation}
""",
            "detailed_analysis": """
# Detailed Property Analysis

## Property Overview
{property_overview}

## Valuation Analysis
{valuation_analysis}

## Market Context
{market_context}

## Investment Analysis
{investment_analysis}

## Risk Assessment
{risk_assessment}

## Recommendations
{recommendations}
""",
            "market_report": """
# Market Analysis Report

## Location: {location}
## Date: {date}

### Market Overview
{market_overview}

### Price Trends
{price_trends}

### Supply & Demand
{supply_demand}

### Future Outlook
{future_outlook}
"""
        }
    
    def validate_input(self, **kwargs) -> bool:
        """Validate input."""
        return 'report_type' in kwargs and 'data' in kwargs
    
    async def execute(self, **kwargs) -> Dict[str, Any]:
        """
        Generate report.
        
        Args:
            report_type: Type of report to generate
            data: Data for report generation
            format: Output format (text, html, json)
            
        Returns:
            Generated report
        """
        report_type = kwargs.get('report_type', 'executive_summary')
        data = kwargs.get('data', {})
        output_format = kwargs.get('format', 'text')
        
        # Generate report content
        if report_type == 'executive_summary':
            content = self.generate_executive_summary(data)
        elif report_type == 'detailed_analysis':
            content = self.generate_detailed_analysis(data)
        elif report_type == 'market_report':
            content = self.generate_market_report(data)
        elif report_type == 'comparison':
            content = self.generate_comparison_report(data)
        else:
            content = self.generate_custom_report(data)
        
        # Format output
        if output_format == 'html':
            formatted = self.format_as_html(content)
        elif output_format == 'json':
            formatted = self.format_as_json(content)
        else:
            formatted = content
        
        return {
            "report_type": report_type,
            "content": formatted,
            "format": output_format,
            "generated_at": datetime.utcnow().isoformat(),
            "metadata": self.generate_metadata(data)
        }
    
    def generate_executive_summary(self, data: Dict[str, Any]) -> str:
        """Generate executive summary report."""
        template = self.report_templates['executive_summary']
        
        # Extract key information
        property_data = data.get('property_data', {})
        analysis = data.get('analysis', {})
        
        # Prepare key findings
        key_findings = []
        
        if analysis.get('valuation'):
            price = analysis['valuation'].get('estimated_value', 'N/A')
            key_findings.append(f"• Estimated value: {price}")
        
        if analysis.get('market_analysis'):
            position = analysis['market_analysis'].get('market_position', 'N/A')
            key_findings.append(f"• Market position: {position}")
        
        if analysis.get('investment_metrics'):
            score = analysis['investment_metrics'].get('investment_score', 'N/A')
            key_findings.append(f"• Investment score: {score}/10")
        
        # Prepare recommendation
        recommendation = self.generate_recommendation(analysis)
        
        # Fill template
        report = template.format(
            location=property_data.get('location', 'N/A'),
            property_type=property_data.get('property_type', 'N/A'),
            size=property_data.get('size', 'N/A'),
            price=property_data.get('price', 'N/A'),
            key_findings='\n'.join(key_findings),
            recommendation=recommendation
        )
        
        return report
    
    def generate_detailed_analysis(self, data: Dict[str, Any]) -> str:
        """Generate detailed analysis report."""
        template = self.report_templates['detailed_analysis']
        
        # Prepare sections
        sections = {
            'property_overview': self.create_property_overview(data),
            'valuation_analysis': self.create_valuation_analysis(data),
            'market_context': self.create_market_context(data),
            'investment_analysis': self.create_investment_analysis(data),
            'risk_assessment': self.create_risk_assessment(data),
            'recommendations': self.create_recommendations(data)
        }
        
        return template.format(**sections)
    
    def generate_market_report(self, data: Dict[str, Any]) -> str:
        """Generate market analysis report."""
        template = self.report_templates['market_report']
        
        market_data = data.get('market_data', {})
        
        return template.format(
            location=data.get('location', 'N/A'),
            date=datetime.now().strftime('%Y-%m-%d'),
            market_overview=self.create_market_overview(market_data),
            price_trends=self.create_price_trends(market_data),
            supply_demand=self.create_supply_demand(market_data),
            future_outlook=self.create_future_outlook(market_data)
        )
    
    def generate_comparison_report(self, data: Dict[str, Any]) -> str:
        """Generate property comparison report."""
        properties = data.get('properties', [])
        
        if len(properties) < 2:
            return "Insufficient properties for comparison"
        
        report = "# Property Comparison Report\n\n"
        
        # Create comparison table
        report += "## Comparison Table\n\n"
        report += "| Feature | " + " | ".join([f"Property {i+1}" for i in range(len(properties))]) + " |\n"
        report += "|---------|" + "|".join(["----------" for _ in properties]) + "|\n"
        
        # Add comparison rows
        features = ['location', 'price', 'size', 'rooms', 'building_age']
        for feature in features:
            row = f"| {feature.title()} | "
            for prop in properties:
                value = prop.get(feature, 'N/A')
                row += f"{value} | "
            report += row + "\n"
        
        # Add analysis
        report += "\n## Comparative Analysis\n\n"
        report += self.analyze_comparison(properties)
        
        return report
    
    def generate_custom_report(self, data: Dict[str, Any]) -> str:
        """Generate custom report."""
        report = "# Property Analysis Report\n\n"
        
        # Add available data sections
        for key, value in data.items():
            if isinstance(value, dict):
                report += f"## {key.replace('_', ' ').title()}\n\n"
                for sub_key, sub_value in value.items():
                    report += f"**{sub_key.replace('_', ' ').title()}**: {sub_value}\n"
                report += "\n"
            elif isinstance(value, list):
                report += f"## {key.replace('_', ' ').title()}\n\n"
                for item in value:
                    report += f"• {item}\n"
                report += "\n"
            else:
                report += f"**{key.replace('_', ' ').title()}**: {value}\n\n"
        
        return report
    
    def generate_recommendation(self, analysis: Dict[str, Any]) -> str:
        """Generate recommendation based on analysis."""
        score = analysis.get('investment_metrics', {}).get('investment_score', 5)
        
        if score >= 8:
            return "**STRONG BUY** - Excellent investment opportunity with high potential returns"
        elif score >= 6:
            return "**BUY** - Good investment opportunity with solid fundamentals"
        elif score >= 4:
            return "**HOLD** - Fair value property, consider based on personal needs"
        else:
            return "**CAUTION** - Carefully evaluate before proceeding"
    
    def create_property_overview(self, data: Dict[str, Any]) -> str:
        """Create property overview section."""
        prop = data.get('property_data', {})
        
        overview = f"""
Location: {prop.get('location', 'N/A')}
Type: {prop.get('property_type', 'N/A')}
Size: {prop.get('size', 'N/A')}
Rooms: {prop.get('rooms', 'N/A')}
Floor: {prop.get('floor', 'N/A')}
Building Age: {prop.get('building_age', 'N/A')}
Heating: {prop.get('heating', 'N/A')}
In Site: {prop.get('in_site', 'N/A')}
"""
        return overview
    
    def create_valuation_analysis(self, data: Dict[str, Any]) -> str:
        """Create valuation analysis section."""
        valuation = data.get('analysis', {}).get('valuation', {})
        
        return f"""
Estimated Value: {valuation.get('estimated_value', 'N/A')}
Value Range: {valuation.get('value_range', 'N/A')}
Confidence Level: {valuation.get('confidence_level', 'N/A')}
Price per m²: {valuation.get('price_per_sqm', 'N/A')}
"""
    
    def create_market_context(self, data: Dict[str, Any]) -> str:
        """Create market context section."""
        market = data.get('analysis', {}).get('market_analysis', {})
        
        return f"""
Market Position: {market.get('market_position', 'N/A')}
Comparable Properties: {market.get('comparable_properties', 'N/A')}
Average Similar Price: {market.get('average_similar_price', 'N/A')}
Price Deviation: {market.get('price_deviation', 'N/A')}%
"""
    
    def create_investment_analysis(self, data: Dict[str, Any]) -> str:
        """Create investment analysis section."""
        investment = data.get('analysis', {}).get('investment_metrics', {})
        
        return f"""
Investment Score: {investment.get('investment_score', 'N/A')}/10
ROI Potential: {investment.get('roi_potential', 'N/A')}
Rental Yield: {investment.get('rental_yield', 'N/A')}
Appreciation Forecast: {investment.get('appreciation_forecast', 'N/A')}
"""
    
    def create_risk_assessment(self, data: Dict[str, Any]) -> str:
        """Create risk assessment section."""
        return """
• Market Risk: Moderate - Subject to economic conditions
• Location Risk: Low - Established area with good infrastructure
• Liquidity Risk: Low - High demand area
• Regulatory Risk: Low - Clear legal framework
"""
    
    def create_recommendations(self, data: Dict[str, Any]) -> str:
        """Create recommendations section."""
        recs = data.get('analysis', {}).get('recommendations', [])
        
        if recs:
            return '\n'.join([f"• {rec}" for rec in recs])
        
        return "• Conduct thorough property inspection\n• Verify all documentation\n• Consider market timing"
    
    def create_market_overview(self, market_data: Dict[str, Any]) -> str:
        """Create market overview."""
        return f"""
Current market conditions show {market_data.get('trend_direction', 'stable')} trends
with {market_data.get('demand_level', 'moderate')} demand levels.
Average price per m²: {market_data.get('avg_price_per_sqm', 'N/A')}
Market velocity: {market_data.get('market_velocity', 'moderate')}
"""
    
    def create_price_trends(self, market_data: Dict[str, Any]) -> str:
        """Create price trends section."""
        return f"""
Month-over-month change: {market_data.get('price_change_mom', 'N/A')}%
Year-over-year change: {market_data.get('price_change_yoy', 'N/A')}%
3-month forecast: {market_data.get('forecast_3m', 'N/A')}%
6-month forecast: {market_data.get('forecast_6m', 'N/A')}%
"""
    
    def create_supply_demand(self, market_data: Dict[str, Any]) -> str:
        """Create supply and demand section."""
        return f"""
Total listings: {market_data.get('total_listings', 'N/A')}
New listings (monthly): {market_data.get('new_listings_month', 'N/A')}
Sold properties (monthly): {market_data.get('sold_properties_month', 'N/A')}
Average days on market: {market_data.get('average_days_on_market', 'N/A')}
Buyer/Seller ratio: {market_data.get('buyer_seller_ratio', 'N/A')}
"""
    
    def create_future_outlook(self, market_data: Dict[str, Any]) -> str:
        """Create future outlook section."""
        return f"""
Based on current trends and economic indicators, the market is expected to
show {market_data.get('trend_direction', 'stable')} movement with
{market_data.get('forecast_12m', 'N/A')}% projected annual growth.
Investment rating: {market_data.get('investment_rating', 'B+')}
"""
    
    def analyze_comparison(self, properties: List[Dict[str, Any]]) -> str:
        """Analyze property comparison."""
        # Find best value
        best_value_idx = 0
        best_price = float('inf')
        
        for i, prop in enumerate(properties):
            try:
                price = float(prop.get('price', '0').replace(' TL', '').replace('.', ''))
                if price < best_price:
                    best_price = price
                    best_value_idx = i
            except:
                pass
        
        analysis = f"Property {best_value_idx + 1} offers the best value at {best_price:,.0f} TL.\n"
        analysis += "Consider location, size, and condition when making final decision."
        
        return analysis
    
    def format_as_html(self, content: str) -> str:
        """Convert markdown content to HTML."""
        # Simple markdown to HTML conversion
        html = content.replace('# ', '<h1>').replace('\n\n', '</h1>\n')
        html = html.replace('## ', '<h2>').replace('\n\n', '</h2>\n')
        html = html.replace('**', '<strong>').replace('**', '</strong>')
        html = html.replace('• ', '<li>').replace('\n', '</li>\n')
        
        return f"<html><body>{html}</body></html>"
    
    def format_as_json(self, content: str) -> Dict[str, Any]:
        """Convert content to JSON format."""
        sections = content.split('\n\n')
        
        json_report = {
            "title": sections[0] if sections else "Report",
            "sections": []
        }
        
        for section in sections[1:]:
            lines = section.split('\n')
            json_report["sections"].append({
                "title": lines[0] if lines else "",
                "content": lines[1:] if len(lines) > 1 else []
            })
        
        return json_report
    
    def generate_metadata(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Generate report metadata."""
        return {
            "generated_at": datetime.utcnow().isoformat(),
            "data_sources": list(data.keys()),
            "report_version": "1.0",
            "generator": "RE-FusionX Report Generator"
        }
