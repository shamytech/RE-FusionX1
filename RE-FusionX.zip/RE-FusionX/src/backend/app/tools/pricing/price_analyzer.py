"""
Advanced price analysis tool.
Provides detailed price analysis and market adjustments.
"""

from typing import Dict, Any, List, Optional
from datetime import datetime

from app.tools.base_tool import BaseTool
from app.core.logging import logger


class PriceAnalyzer(BaseTool):
    """Advanced price analysis tool."""
    
    def __init__(self):
        """Initialize price analyzer."""
        super().__init__(
            name="PriceAnalyzer",
            description="Advanced price analysis with market adjustments"
        )
        
        self.market_data = self.load_market_data()
    
    def load_market_data(self) -> Dict[str, Any]:
        """Load market data for analysis."""
        return {
            "istanbul": {
                "avg_price_per_sqm": 42000,
                "growth_rate": 0.15,
                "demand_level": "high",
                "districts": {
                    "kadıköy": {"multiplier": 1.3, "trend": "increasing"},
                    "beşiktaş": {"multiplier": 1.4, "trend": "stable"},
                    "şişli": {"multiplier": 1.35, "trend": "increasing"},
                    "bakırköy": {"multiplier": 1.2, "trend": "increasing"},
                    "üsküdar": {"multiplier": 1.1, "trend": "stable"}
                }
            },
            "ankara": {
                "avg_price_per_sqm": 25000,
                "growth_rate": 0.12,
                "demand_level": "medium",
                "districts": {
                    "çankaya": {"multiplier": 1.3, "trend": "stable"},
                    "keçiören": {"multiplier": 0.9, "trend": "increasing"}
                }
            },
            "izmir": {
                "avg_price_per_sqm": 28000,
                "growth_rate": 0.13,
                "demand_level": "medium-high",
                "districts": {
                    "konak": {"multiplier": 1.2, "trend": "stable"},
                    "karşıyaka": {"multiplier": 1.15, "trend": "increasing"}
                }
            }
        }
    
    def validate_input(self, **kwargs) -> bool:
        """Validate input for price analysis."""
        return 'property_data' in kwargs or 'initial_prediction' in kwargs
    
    async def execute(self, **kwargs) -> Dict[str, Any]:
        """
        Execute price analysis.
        
        Args:
            property_data: Property information
            initial_prediction: Initial price prediction
            
        Returns:
            Enhanced price analysis
        """
        property_data = kwargs.get('property_data', {})
        initial_prediction = kwargs.get('initial_prediction', {})
        
        # Get base price
        base_price = initial_prediction.get('price', 0)
        if not base_price:
            base_price = self.estimate_base_price(property_data)
        
        # Apply market adjustments
        market_adjustment = self.calculate_market_adjustment(property_data)
        
        # Apply location premium
        location_premium = self.calculate_location_premium(property_data)
        
        # Apply feature adjustments
        feature_adjustment = self.calculate_feature_adjustment(property_data)
        
        # Apply time adjustment
        time_adjustment = self.calculate_time_adjustment(property_data)
        
        # Calculate final price
        final_price = base_price * (1 + market_adjustment + location_premium + 
                                   feature_adjustment + time_adjustment)
        
        # Calculate price factors
        price_factors = self.identify_price_factors(
            property_data,
            market_adjustment,
            location_premium,
            feature_adjustment
        )
        
        # Generate price range
        price_range = self.generate_price_range(final_price, property_data)
        
        return {
            "final_price": round(final_price, -3),
            "base_price": base_price,
            "market_adjustment": market_adjustment,
            "location_premium": location_premium,
            "feature_adjustment": feature_adjustment,
            "time_adjustment": time_adjustment,
            "price_range": price_range,
            "price_factors": price_factors,
            "confidence": self.calculate_analysis_confidence(property_data)
        }
    
    def estimate_base_price(self, property_data: Dict[str, Any]) -> float:
        """Estimate base price from property data."""
        # Extract location
        location = property_data.get('location', '').lower()
        
        # Get city data
        city_data = None
        for city, data in self.market_data.items():
            if city in location:
                city_data = data
                break
        
        if not city_data:
            city_data = {"avg_price_per_sqm": 25000}  # Default
        
        # Get size
        size_str = str(property_data.get('size', '100'))
        size = float(size_str.replace(' m²', '').replace(',', '.'))
        
        # Calculate base price
        base_price = size * city_data["avg_price_per_sqm"]
        
        return base_price
    
    def calculate_market_adjustment(self, property_data: Dict[str, Any]) -> float:
        """Calculate market-based adjustment."""
        location = property_data.get('location', '').lower()
        
        # Find city
        for city, data in self.market_data.items():
            if city in location:
                # Check demand level
                demand = data.get('demand_level', 'medium')
                
                if demand == 'high':
                    return 0.1  # 10% premium
                elif demand == 'medium-high':
                    return 0.05  # 5% premium
                elif demand == 'low':
                    return -0.05  # 5% discount
        
        return 0  # No adjustment
    
    def calculate_location_premium(self, property_data: Dict[str, Any]) -> float:
        """Calculate location-based premium."""
        location = property_data.get('location', '').lower()
        
        # Check for city and district
        for city, data in self.market_data.items():
            if city in location:
                districts = data.get('districts', {})
                
                for district, district_data in districts.items():
                    if district in location:
                        multiplier = district_data.get('multiplier', 1.0)
                        return multiplier - 1  # Convert to adjustment
        
        return 0  # No premium
    
    def calculate_feature_adjustment(self, property_data: Dict[str, Any]) -> float:
        """Calculate adjustment based on property features."""
        adjustment = 0
        
        # Building age
        age = property_data.get('building_age', '')
        if 'yeni' in str(age).lower() or '0' in str(age):
            adjustment += 0.1  # 10% for new building
        elif any(x in str(age) for x in ['20', '25', '30']):
            adjustment -= 0.05  # 5% discount for old building
        
        # Site amenities
        if property_data.get('in_site') == 'Evet':
            adjustment += 0.08  # 8% for site amenities
        
        # Heating system
        heating = property_data.get('heating', '')
        if 'merkezi' in heating.lower():
            adjustment += 0.03  # 3% for central heating
        elif 'kombi' in heating.lower():
            adjustment += 0.02  # 2% for combi
        
        # Floor
        floor = property_data.get('floor', 1)
        if isinstance(floor, (int, float)) and floor > 5:
            adjustment += 0.02  # 2% for high floor
        elif str(floor).lower() in ['zemin', 'bodrum']:
            adjustment -= 0.03  # 3% discount for ground/basement
        
        # Credit eligibility
        if property_data.get('credit_eligible') == 'Krediye Uygun':
            adjustment += 0.05  # 5% for mortgage eligibility
        
        return adjustment
    
    def calculate_time_adjustment(self, property_data: Dict[str, Any]) -> float:
        """Calculate time-based market adjustment."""
        # This would typically use real market data
        # For now, using a simple seasonal adjustment
        
        month = datetime.now().month
        
        # Spring/Summer premium (March-August)
        if 3 <= month <= 8:
            return 0.02  # 2% premium in peak season
        else:
            return -0.01  # 1% discount in off-season
    
    def identify_price_factors(
        self,
        property_data: Dict[str, Any],
        market_adj: float,
        location_prem: float,
        feature_adj: float
    ) -> List[Dict[str, Any]]:
        """Identify key factors affecting price."""
        factors = []
        
        # Location factor
        if location_prem != 0:
            factors.append({
                "factor": "Location Premium",
                "impact": f"{location_prem*100:+.1f}%",
                "description": f"District value adjustment for {property_data.get('location', 'location')}"
            })
        
        # Market factor
        if market_adj != 0:
            factors.append({
                "factor": "Market Conditions",
                "impact": f"{market_adj*100:+.1f}%",
                "description": "Current market demand and supply dynamics"
            })
        
        # Feature factors
        if feature_adj != 0:
            factors.append({
                "factor": "Property Features",
                "impact": f"{feature_adj*100:+.1f}%",
                "description": "Combined effect of amenities and characteristics"
            })
        
        # Size factor
        size = property_data.get('size', '')
        if size:
            factors.append({
                "factor": "Property Size",
                "impact": "Primary",
                "description": f"{size} total area"
            })
        
        # Age factor
        age = property_data.get('building_age', '')
        if age:
            if 'yeni' in str(age).lower() or '0' in str(age):
                factors.append({
                    "factor": "New Construction",
                    "impact": "+10%",
                    "description": "Premium for brand new property"
                })
        
        return factors
    
    def generate_price_range(
        self,
        final_price: float,
        property_data: Dict[str, Any]
    ) -> Dict[str, float]:
        """Generate realistic price range."""
        # Base variance
        variance = 0.08  # 8% base variance
        
        # Adjust variance based on market volatility
        location = property_data.get('location', '').lower()
        
        if 'istanbul' in location:
            variance += 0.02  # More volatile market
        
        # Calculate range
        min_price = final_price * (1 - variance)
        max_price = final_price * (1 + variance)
        
        return {
            "minimum": round(min_price, -3),
            "maximum": round(max_price, -3),
            "most_likely": round(final_price, -3),
            "negotiable_range": f"{variance*100:.0f}%"
        }
    
    def calculate_analysis_confidence(self, property_data: Dict[str, Any]) -> float:
        """Calculate confidence in the analysis."""
        confidence = 0.6  # Base confidence
        
        # Check data completeness
        important_fields = ['location', 'size', 'rooms', 'building_age', 'floor']
        provided_fields = sum(1 for field in important_fields if property_data.get(field))
        
        confidence += (provided_fields / len(important_fields)) * 0.2
        
        # Check location specificity
        location = property_data.get('location', '')
        if '-' in location:  # Has district information
            confidence += 0.1
        
        # Check for market data availability
        location_lower = location.lower()
        for city in self.market_data.keys():
            if city in location_lower:
                confidence += 0.1
                break
        
        return min(0.95, confidence)
