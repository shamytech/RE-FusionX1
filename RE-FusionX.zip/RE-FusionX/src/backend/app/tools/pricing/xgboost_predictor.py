# app/tools/pricing/xgboost_predictor.py
"""
XGBoost model for property price prediction.
Uses machine learning for accurate price estimation.
"""

import pickle
import numpy as np
import pandas as pd
from typing import Dict, Any, Optional
from pathlib import Path
import asyncio
from app.tools.base_tool import BaseTool
from app.core.config import settings
from app.core.logging import logger


class XGBoostPredictor(BaseTool):
    """XGBoost-based price prediction tool."""
    
    def __init__(self):
        """Initialize XGBoost predictor."""
        super().__init__(
            name="XGBoostPredictor",
            description="Machine learning model for property price prediction",
        )
        
        self.model = None
        self.feature_columns = None
        self.scaler = None
        self.is_loaded = False  # ✅ إضافة flag للتحقق
        self.load_model()
    
    def load_model(self):
        """Load the trained XGBoost model with proper fallback."""
        try:
            # تحديد المسار بشكل آمن
            if hasattr(settings, 'XGBOOST_MODEL_PATH'):
                model_path = settings.XGBOOST_MODEL_PATH
            else:
                # استخدام مسار افتراضي
                model_path = Path("data/models/xgboost_price_predictor.pkl")
            
            # تحويل إلى Path object
            if isinstance(model_path, str):
                model_path = Path(model_path)
            
            # التحقق من وجود الملف
            if 1!=1:#model_path.exists():
                with open(model_path, 'rb') as f:
                    model_data = pickle.load(f)
                    
                    # ✅ معالجة أفضل لأنواع البيانات المختلفة
                    if isinstance(model_data, dict):
                        self.model = model_data.get('model')
                        self.feature_columns = model_data.get('features', [])
                        self.scaler = model_data.get('scaler')
                    else:
                        # إذا كان النموذج مباشرة
                        self.model = model_data
                        self.feature_columns = []
                    
                    # ✅ التحقق من صحة النموذج
                    if hasattr(self.model, 'predict'):
                        self.is_loaded = True
                        logger.info(f"✅ XGBoost model loaded successfully from {model_path}")
                    else:
                        logger.warning("Invalid model object, using fallback")
                        self.use_fallback_model()
            else:
                logger.warning(f"XGBoost model not found at {model_path}, using fallback")
                self.use_fallback_model()
                
        except Exception as e:
            logger.error(f"Failed to load XGBoost model: {e}")
            self.use_fallback_model()

    def use_fallback_model(self):
        """Use a simple fallback price calculation."""
        self.model = None
        self.is_loaded = False
        self.feature_columns = [
            'size_net', 'room_count', 'floor', 'building_age_years',
            'location_score', 'has_parking', 'has_elevator', 'in_site'
        ]
        logger.info("🔄 Using fallback price calculation model")
    
    def validate_input(self, **kwargs) -> bool:
        """Validate input for price prediction."""
        property_data = kwargs.get('property_data')
        
        if not property_data:
            return False
        
        # فقط الموقع مطلوب كحد أدنى
        if not property_data.get('location') and not property_data.get('city'):
            logger.warning("Missing location information for prediction")
            return False
        
        return True
    
    async def execute(self, **kwargs) -> Dict[str, Any]:
        """Execute price prediction with improved error handling."""
        try:
            property_data = kwargs.get('property_data', {})
            
            # التحقق من البيانات
            if not property_data:
                logger.warning("No property data provided for prediction")
                return self._get_default_prediction({})
            
            # تحضير الميزات
            features = self.prepare_features(property_data)
            
            # التنبؤ
            if self.is_loaded and self.model:
                try:
                    prediction = self.predict_with_model(features)
                    method = "xgboost"
                except Exception as e:
                    logger.error(f"Model prediction failed: {e}")
                    prediction = self.predict_with_fallback(features, property_data)
                    method = "fallback_after_error"
            else:
                logger.info("Using fallback prediction (no model available)")
                prediction = self.predict_with_fallback(features, property_data)
                method = "rule_based_fallback"
            
            # حساب الثقة والنطاق السعري
            confidence = self.calculate_confidence(features, property_data)
            price_range = self.calculate_price_range(prediction, confidence)
            
            # ✅ إضافة تفاصيل الحساب للـ fallback
            result = {
                "success": True,
                "predicted_price": prediction,
                "confidence": confidence,
                "price_range": price_range,
                "model": method,
                "features_used": list(features.keys())
            }
            
            # إضافة تفاصيل إضافية إذا كان fallback
            if method != "xgboost":
                result["calculation_details"] = {
                    "base_price_per_sqm": self._get_base_price_per_sqm(features.get('location_score', 5)),
                    "size": features.get('size_net', 100),
                    "type_multiplier": 1.0,  # يمكن تحسينها
                    "age_multiplier": self._get_age_multiplier(features.get('building_age_years', 10)),
                    "room_multiplier": 1.0 + (features.get('room_count', 2) - 2) * 0.05
                }
            
            return result
            
        except Exception as e:
            logger.error(f"Price prediction failed: {e}", exc_info=True)
            fallback = self._get_default_prediction(kwargs.get('property_data', {}))
            fallback["success"] = True
            return fallback

    def _get_base_price_per_sqm(self, location_score: float) -> float:
        """Get base price per sqm based on location score."""
        if location_score >= 8:
            return 45000
        elif location_score >= 6:
            return 30000
        else:
            return 20000

    def _get_age_multiplier(self, age: float) -> float:
        """Get age multiplier for price calculation."""
        if age == 0:
            return 1.2
        elif age < 5:
            return 1.1
        elif age < 10:
            return 1.0
        elif age < 20:
            return 0.9
        else:
            return 0.8

    def _get_default_prediction(self, property_data: Dict[str, Any]) -> Dict[str, Any]:
        """Get default prediction when all else fails."""
        location = str(property_data.get('location', '')).lower()
        city = str(property_data.get('city', '')).lower()
        district = str(property_data.get('district', '')).lower()
        
        # دمج معلومات الموقع
        full_location = f"{location} {city} {district}".lower()
        
        # تحديد السعر الافتراضي حسب المدينة والمنطقة
        if 'istanbul' in full_location or 'İstanbul' in full_location:
            if 'kadıköy' in full_location or 'kadikoy' in full_location:
                base_price = 5000000
            elif 'beşiktaş' in full_location or 'besiktas' in full_location:
                base_price = 5500000
            elif 'şişli' in full_location or 'sisli' in full_location:
                base_price = 5200000
            else:
                base_price = 4000000
        elif 'ankara' in full_location:
            base_price = 2800000
        elif 'izmir' in full_location or 'İzmir' in full_location:
            base_price = 3200000
        elif 'antalya' in full_location:
            base_price = 3500000
        else:
            base_price = 2500000
        
        # تعديل حسب الحجم
        size = property_data.get('size', 120)
        try:
            if isinstance(size, str):
                size_num = float(str(size).replace(' m²', '').replace('m2', '').replace(',', '.'))
            else:
                size_num = float(size)
            
            price_per_sqm = base_price / 120
            adjusted_price = price_per_sqm * size_num
        except:
            adjusted_price = base_price
        
        # تعديل حسب عدد الغرف
        rooms = property_data.get('rooms', '2+1')
        if isinstance(rooms, str):
            if '4+' in rooms or '5+' in rooms:
                adjusted_price *= 1.15
            elif '3+' in rooms:
                adjusted_price *= 1.05
            elif '1+' in rooms or 'stüdyo' in rooms.lower():
                adjusted_price *= 0.85
        
        # تعديل حسب عمر البناء
        age = property_data.get('building_age', 10)
        if isinstance(age, (int, float)):
            if age <= 2:
                adjusted_price *= 1.15
            elif age <= 5:
                adjusted_price *= 1.05
            elif age > 20:
                adjusted_price *= 0.85
        
        final_price = round(adjusted_price)
        
        return {
            "success": True,
            "predicted_price": final_price,
            "confidence": 0.5,
            "price_range": {
                "min": round(final_price * 0.85),
                "max": round(final_price * 1.15)
            },
            "model": "default_fallback",
            "features_used": ["location", "size", "rooms", "building_age"],
            "calculation_details": {
                "base_price": base_price,
                "size_adjustment": size_num if 'size_num' in locals() else 120,
                "location": full_location
            }
        }

    def prepare_features(self, property_data: Dict[str, Any]) -> Dict[str, float]:
        """Prepare features for the model with safe defaults."""
        features = {}
        
        # Size features
        try:
            size_str = str(property_data.get('size', '100'))
            size = float(size_str.replace(' m²', '').replace(' m', '').replace('m2', '').replace(',', '.'))
            features['size_net'] = max(20, min(1000, size))  # حدود معقولة
        except:
            features['size_net'] = 100
        
        # Room features
        try:
            rooms = property_data.get('rooms', '2+1')
            if isinstance(rooms, str) and '+' in rooms:
                main_rooms = int(rooms.split('+')[0])
                features['room_count'] = max(1, min(10, main_rooms))
            else:
                features['room_count'] = 2
        except:
            features['room_count'] = 2
        
        # Floor features
        try:
            floor = property_data.get('floor', 1)
            if isinstance(floor, str):
                if 'zemin' in floor.lower() or 'giriş' in floor.lower():
                    features['floor'] = 0
                elif 'bodrum' in floor.lower():
                    features['floor'] = -1
                elif 'çatı' in floor.lower():
                    features['floor'] = 99  # علامة للطابق العلوي
                else:
                    # استخراج الرقم
                    digits = ''.join(filter(str.isdigit, floor))
                    features['floor'] = int(digits) if digits else 1
            else:
                features['floor'] = int(floor)
        except:
            features['floor'] = 1
        
        # Building age
        age = property_data.get('building_age', property_data.get('age', 10))
        features['building_age_years'] = self.parse_building_age(age)
        
        # Location score
        location = property_data.get('location', '')
        city = property_data.get('city', '')
        district = property_data.get('district', '')
        full_location = f"{location} {city} {district}"
        features['location_score'] = self.calculate_location_score(full_location)
        
        # Boolean features
        features['has_parking'] = 1 if property_data.get('has_parking') else 0
        features['has_elevator'] = 1 if property_data.get('has_elevator') else 0
        features['in_site'] = 1 if property_data.get('in_site') == 'Evet' else 0
        
        # Heating type
        heating = property_data.get('heating', '')
        features['has_central_heating'] = 1 if 'merkezi' in str(heating).lower() else 0
        features['has_combi'] = 1 if 'kombi' in str(heating).lower() else 0
        
        return features
    
    def parse_building_age(self, age: Any) -> float:
        """Parse building age to years safely."""
        if age is None:
            return 10
        
        # إذا كان رقم مباشر
        if isinstance(age, (int, float)):
            return float(age)
        
        age_str = str(age).lower()
        
        # كلمات خاصة
        if 'yeni' in age_str or 'sıfır' in age_str:
            return 0
        elif '0' == age_str.strip():
            return 0
        
        # نطاقات
        age_ranges = {
            '0-1': 0.5, '1-4': 2.5, '1-5': 3,
            '5-10': 7.5, '5-7': 6,
            '11-15': 13, '10-15': 12.5,
            '16-20': 18, '15-20': 17.5,
            '21-25': 23, '20-25': 22.5,
            '26-30': 28, '25-30': 27.5,
            '31+': 35, '30+': 35
        }
        
        for range_str, value in age_ranges.items():
            if range_str in age_str:
                return value
        
        # محاولة استخراج رقم
        try:
            digits = ''.join(filter(str.isdigit, age_str))
            if digits:
                return min(50, float(digits))  # حد أقصى 50 سنة
        except:
            pass
        
        return 10  # قيمة افتراضية
    
    def calculate_location_score(self, location: str) -> float:
        """Calculate location score (0-10)."""
        location_lower = location.lower()
        
        # المدن الرئيسية
        city_scores = {
            'istanbul': 8, 'İstanbul': 8,
            'ankara': 7,
            'izmir': 7, 'İzmir': 7,
            'antalya': 6.5,
            'bursa': 6,
            'kocaeli': 6,
            'adana': 5,
            'konya': 5
        }
        
        base_score = 4  # قيمة افتراضية
        for city, score in city_scores.items():
            if city in location_lower:
                base_score = score
                break
        
        # المناطق المميزة
        premium_districts = [
            'kadıköy', 'kadikoy', 'beşiktaş', 'besiktas', 
            'şişli', 'sisli', 'bebek', 'etiler', 'levent',
            'çankaya', 'cankaya', 'alsancak', 'karşıyaka',
            'nişantaşı', 'nisantasi', 'bağdat', 'bagdat'
        ]
        
        for district in premium_districts:
            if district in location_lower:
                base_score += 1.5
                break
        
        # المناطق الجيدة
        good_districts = [
            'bakırköy', 'bakirköy', 'üsküdar', 'uskudar',
            'ataşehir', 'atasehir', 'maltepe', 'kartal',
            'pendik', 'tuzla', 'sarıyer', 'sariyer'
        ]
        
        for district in good_districts:
            if district in location_lower:
                base_score += 0.5
                break
        
        return min(10, max(1, base_score))
    
    def predict_with_model(self, features: Dict[str, float]) -> float:
        """Make prediction using XGBoost model."""
        try:
            # إنشاء DataFrame
            df = pd.DataFrame([features])
            
            # التأكد من وجود جميع الأعمدة المطلوبة
            if self.feature_columns:
                for col in self.feature_columns:
                    if col not in df.columns:
                        df[col] = 0
                
                # اختيار وترتيب الأعمدة
                df = df[self.feature_columns]
            
            # تطبيق التحجيم إذا كان متاحاً
            if self.scaler:
                df_scaled = self.scaler.transform(df)
            else:
                df_scaled = df.values
            
            # التنبؤ
            prediction = self.model.predict(df_scaled)[0]
            
            return float(prediction)
            
        except Exception as e:
            logger.error(f"Model prediction error: {e}")
            raise
    
    def predict_with_fallback(self, features: Dict[str, float], property_data: Dict[str, Any]) -> float:
        """Enhanced fallback price calculation."""
        # السعر الأساسي لكل متر مربع حسب الموقع
        location_score = features.get('location_score', 5)
        base_price_per_sqm = self._get_base_price_per_sqm(location_score)
        
        # حساب السعر الأساسي
        size = features.get('size_net', 100)
        base_price = size * base_price_per_sqm
        
        # تعديل العمر
        age = features.get('building_age_years', 10)
        age_multiplier = self._get_age_multiplier(age)
        
        # تعديل الطابق
        floor = features.get('floor', 1)
        if floor == -1:  # bodrum
            floor_multiplier = 0.85
        elif floor == 0:  # zemin
            floor_multiplier = 0.95
        elif floor == 99:  # çatı katı
            floor_multiplier = 0.9
        elif floor > 10:
            floor_multiplier = 1.05
        elif floor > 5:
            floor_multiplier = 1.02
        else:
            floor_multiplier = 1.0
        
        # تعديل الغرف
        rooms = features.get('room_count', 2)
        room_multiplier = 1.0 + (rooms - 2) * 0.05
        
        # تعديل المميزات
        features_multiplier = 1.0
        if features.get('has_parking'):
            features_multiplier += 0.05
        if features.get('has_elevator'):
            features_multiplier += 0.03
        if features.get('in_site'):
            features_multiplier += 0.08
        if features.get('has_central_heating'):
            features_multiplier += 0.02
        
        # حساب السعر النهائي
        final_price = (
            base_price * 
            age_multiplier * 
            floor_multiplier * 
            room_multiplier * 
            features_multiplier
        )
        
        return round(final_price, -3)  # تقريب لأقرب 1000
    
    def calculate_confidence(self, features: Dict[str, float], property_data: Dict[str, Any]) -> float:
        """Calculate prediction confidence."""
        confidence = 0.5  # ثقة أساسية
        
        # زيادة الثقة للبيانات الكاملة
        feature_count = len([v for v in features.values() if v != 0])
        if feature_count >= 8:
            confidence += 0.2
        elif feature_count >= 6:
            confidence += 0.1
        
        # زيادة الثقة لتوفر النموذج
        if self.is_loaded and self.model:
            confidence += 0.25
        
        # زيادة الثقة لدقة الموقع
        if features.get('location_score', 0) > 6:
            confidence += 0.05
        
        return min(0.95, max(0.3, confidence))
    
    def calculate_price_range(self, prediction: float, confidence: float) -> Dict[str, float]:
        """Calculate price range based on confidence."""
        # عدم اليقين بناءً على الثقة
        uncertainty = (1 - confidence) * 0.20  # حد أقصى 20% عدم يقين
        
        min_price = prediction * (1 - uncertainty)
        max_price = prediction * (1 + uncertainty)
        
        return {
            "min": round(min_price, -3),
            "max": round(max_price, -3)
        }
