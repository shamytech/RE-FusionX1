"""
Property search tool.
Searches for properties based on various criteria.
"""

from typing import Dict, Any, List, Optional
import asyncio
from datetime import datetime

from app.tools.base_tool import BaseTool
from app.tools.database.property_repository import PropertyRepository
from app.core.logging import logger
from app.core.storage.integration import StorageIntegration
from app.core.storage.unified_cache import CacheType
from app.core.storage.session_manager import get_session_manager

class PropertySearcher(BaseTool):
    """Advanced property search tool."""
    
    def __init__(self):
        """Initialize property searcher."""
        super().__init__(
            name="PropertySearcher",
            description="Search for properties with advanced filters"
        )
        
        self.repository = PropertyRepository()
        self.storage = StorageIntegration()
        self._cache = None
    
    @property
    def storage(self):
        """Lazy load storage"""
        if self._storage is None:
            from app.core.storage.integration import StorageIntegration
            self._storage = StorageIntegration.get_storage()
        return self._storage
    
    @property
    def cache(self):
        """Lazy load cache"""
        if self._cache is None:
            from app.core.storage.integration import StorageIntegration
            self._cache = StorageIntegration.get_cache()
        return self._cache
    
    def validate_input(self, **kwargs) -> bool:
        """Validate search input."""
        return True  # Accept any search criteria
    
    async def execute(self, **kwargs) -> Dict[str, Any]:
        """
        Execute property search using new storage system
        """
        # Build search criteria
        criteria = self.build_search_criteria(**kwargs)
        
        # Generate cache key
        cache_key = self.cache.generate_key(
            CacheType.SEARCH,
            "property_search",
            criteria
        )
        
        # Check cache first
        cached_results = await self.cache.get(cache_key, CacheType.SEARCH)
        if cached_results:
            logger.info("Returning cached search results")
            return cached_results
        
        # Search in storage
        location = criteria.get('location', 'Istanbul')
        
        # Get properties from storage
        properties = await self.storage.get_properties(
            location=location,
            filters={
                'property_type': criteria.get('property_type'),
                'min_price': criteria.get('min_price'),
                'max_price': criteria.get('max_price'),
                'min_size': criteria.get('min_size'),
                'max_size': criteria.get('max_size'),
                'rooms': criteria.get('rooms'),
                'limit': criteria.get('limit', 20)
            }
        )
        
        # If no results, try fetching fresh data
        if not properties:
            logger.info(f"No properties found in storage for {location}, attempting fresh fetch")
            properties = await self._fetch_fresh_properties(criteria)
            
            # Save to storage if found
            if properties:
                await self.storage.save_properties(
                    properties,
                    location,
                    'property_searcher'
                )
        
        # Enhance results
        enhanced_results = await self.enhance_results(properties, criteria)
        
        # Generate insights
        insights = self.generate_search_insights(enhanced_results, criteria)
        
        # Prepare response
        response = {
            "criteria": criteria,
            "total_results": len(enhanced_results),
            "properties": enhanced_results[:criteria.get('limit', 20)],
            "insights": insights,
            "search_metadata": {
                "timestamp": datetime.utcnow().isoformat(),
                "source": "storage_system"
            }
        }
        
        # Cache the results
        await self.cache.set(cache_key, response, CacheType.SEARCH)
        
        return response
    
    async def _fetch_fresh_properties(self, criteria: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Fetch fresh properties if not in storage"""
        try:
            from app.data_collectors.real_estate.sources.emlakjet import EmlakjetScraper
            
            scraper = EmlakjetScraper()
            location = criteria.get('location', 'Istanbul')
            
            async with scraper:
                result = await scraper.collect(
                    location=location,
                    property_type=criteria.get('property_type', 'daire'),
                    max_pages=2
                )
            
            if result and result.get('success'):
                return result.get('properties', [])
        
        except Exception as e:
            logger.error(f"Failed to fetch fresh properties: {e}")
        
        return []
    
    def build_search_criteria(self, **kwargs) -> Dict[str, Any]:
        """Build structured search criteria."""
        criteria = {
            'location': kwargs.get('location'),
            'property_type': kwargs.get('property_type'),
            'rooms': kwargs.get('rooms'),
            'min_price': kwargs.get('min_price'),
            'max_price': kwargs.get('max_price'),
            'min_size': kwargs.get('min_size'),
            'max_size': kwargs.get('max_size'),
            'building_age': kwargs.get('building_age'),
            'in_site': kwargs.get('in_site'),
            'features': kwargs.get('features', []),
            'sort_by': kwargs.get('sort_by', 'price'),
            'sort_order': kwargs.get('sort_order', 'asc'),
            'limit': kwargs.get('limit', 20),
            'offset': kwargs.get('offset', 0)
        }
        
        return {k: v for k, v in criteria.items() if v is not None}
    
    async def enhance_results(self, properties: List[Dict[str, Any]], criteria: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Enhance search results with additional data."""
        enhanced = []
        
        for prop in properties:
            # Add price per square meter
            try:
                price = float(prop.get('price', 0))
                size = float(prop.get('size', 1))
                prop['price_per_sqm'] = round(price / size) if size > 0 else 0
            except:
                prop['price_per_sqm'] = 0
            
            # Add match score
            prop['match_score'] = self.calculate_match_score(prop, criteria)
            
            # Add summary
            prop['summary'] = self.generate_property_summary(prop)
            
            enhanced.append(prop)
        
        # Sort by match score
        enhanced.sort(key=lambda x: x['match_score'], reverse=True)
        
        return enhanced
    
    def calculate_match_score(self, property_data: Dict[str, Any], criteria: Dict[str, Any]) -> float:
        """Calculate match score."""
        score = 50.0
        
        # Location match
        if criteria.get('location'):
            if criteria['location'].lower() in str(property_data.get('location', '')).lower():
                score += 20
        
        # Price range match
        if criteria.get('min_price') or criteria.get('max_price'):
            price = property_data.get('price', 0)
            min_price = criteria.get('min_price', 0)
            max_price = criteria.get('max_price', float('inf'))
            
            if min_price <= price <= max_price:
                score += 15
        
        # Size match
        if criteria.get('min_size') or criteria.get('max_size'):
            size = property_data.get('size', 0)
            min_size = criteria.get('min_size', 0)
            max_size = criteria.get('max_size', float('inf'))
            
            if min_size <= size <= max_size:
                score += 10
        
        # Room match
        if criteria.get('rooms'):
            if property_data.get('rooms') == criteria['rooms']:
                score += 10
        
        return min(100, score)
    
    def generate_property_summary(self, prop: Dict[str, Any]) -> str:
        """Generate property summary."""
        parts = []
        
        if prop.get('rooms'):
            parts.append(str(prop['rooms']))
        
        if prop.get('size'):
            parts.append(f"{prop['size']}m²")
        
        if prop.get('location'):
            parts.append(str(prop['location']))
        
        if prop.get('price'):
            parts.append(f"{prop['price']:,.0f} TL")
        
        return " | ".join(parts)
    
    def generate_search_insights(self, results: List[Dict[str, Any]], criteria: Dict[str, Any]) -> Dict[str, Any]:
        """Generate search insights."""
        if not results:
            return {
                "summary": "No properties found matching your criteria",
                "suggestions": ["Try broadening your search criteria", "Adjust price range"]
            }
        
        prices = [p.get('price', 0) for p in results if p.get('price')]
        sizes = [p.get('size', 0) for p in results if p.get('size')]
        
        return {
            "total_found": len(results),
            "price_range": {
                "min": min(prices) if prices else 0,
                "max": max(prices) if prices else 0,
                "average": sum(prices) / len(prices) if prices else 0
            },
            "size_range": {
                "min": min(sizes) if sizes else 0,
                "max": max(sizes) if sizes else 0,
                "average": sum(sizes) / len(sizes) if sizes else 0
            },
            "best_matches": [
                {
                    "property_id": i,
                    "match_score": prop.get('match_score', 0),
                    "summary": prop.get('summary', '')
                }
                for i, prop in enumerate(results[:3])
            ],
            "recommendations": self.generate_recommendations(results, criteria)
        }
    
    def generate_recommendations(self, results: List[Dict[str, Any]], criteria: Dict[str, Any]) -> List[str]:
        """Generate recommendations."""
        recommendations = []
        
        if len(results) < 5:
            recommendations.append("Limited results - consider expanding search area")
        
        if len(results) > 50:
            recommendations.append("Many options available - use filters to narrow down")
        
        if results and results[0].get('match_score', 0) > 80:
            recommendations.append(f"Excellent match found: {results[0].get('summary', '')}")
        
        return recommendations
    
    async def search_properties(
            self,
            criteria: Dict[str, Any]
        ) -> List[Dict[str, Any]]:
        """Search properties based on criteria."""
        # Use repository for basic search
        results = await self.repository.search_properties(**criteria)
        
        # Apply additional filters
        if criteria.get('features'):
            results = self.filter_by_features(results, criteria['features'])
        
        # Sort results
        results = self.sort_results(
            results,
            criteria.get('sort_by', 'price'),
            criteria.get('sort_order', 'asc')
        )
        
        return results
    
    def filter_by_features(
            self,
            properties: List[Dict[str, Any]],
            required_features: List[str]
        ) -> List[Dict[str, Any]]:
        """Filter properties by required features."""
        filtered = []
        
        for prop in properties:
            prop_features = prop.get('property_features', {})
            
            # Flatten all features
            all_features = []
            for category, features in prop_features.items():
                if isinstance(features, list):
                    all_features.extend([str(f).lower() for f in features])
            
            # Check if all required features are present
            has_all = all(
                any(req.lower() in feat for feat in all_features)
                for req in required_features
            )
            
            if has_all:
                filtered.append(prop)
        
        return filtered
    
    def sort_results(
            self,
            properties: List[Dict[str, Any]],
            sort_by: str,
            order: str
        ) -> List[Dict[str, Any]]:
        """Sort search results."""
        reverse = (order == 'desc')
        
        if sort_by == 'price':
            def get_price(prop):
                try:
                    price_str = prop.get('price', '0')
                    return float(price_str.replace(' TL', '').replace('.', '').replace(',', '.'))
                except:
                    return 0
            
            return sorted(properties, key=get_price, reverse=reverse)
        
        elif sort_by == 'size':
            def get_size(prop):
                try:
                    size_str = prop.get('size_net', prop.get('size_gross', '0'))
                    return float(size_str.replace(' m²', '').replace(',', '.'))
                except:
                    return 0
            
            return sorted(properties, key=get_size, reverse=reverse)
        
        elif sort_by == 'age':
            def get_age(prop):
                age = prop.get('building_age', '99')
                if 'Yeni' in age or '0' in age:
                    return 0
                try:
                    return int(age.split('-')[0])
                except:
                    return 99
            
            return sorted(properties, key=get_age, reverse=reverse)
        
        return properties
    
 
   


   