"""
Web search tool for real-time information.
Fetches current market data and news from the web.
"""

import aiohttp
import asyncio
from typing import Dict, Any, List, Optional
from datetime import datetime

from app.tools.base_tool import BaseTool
from app.core.config import settings
from app.core.logging import logger
from app.core.storage.integration import StorageIntegration
from app.core.storage.unified_cache import CacheType

class WebSearcher(BaseTool):
    """Web search tool for real-time information."""
    
    def __init__(self):
        """Initialize web searcher."""
        super().__init__(
            name="WebSearcher",
            description="Search web for real-time market information"
        )
        
        self.search_api_key = settings.SERP_API_KEY
        self.google_api_key = settings.GOOGLE_API_KEY
        self.google_cse_id = settings.GOOGLE_CSE_ID
        self._storage = None
        self._cache = None
    
    @property
    def storage(self):
        """Lazy load storage"""
        if self._storage is None:
            from app.core.storage.integration import StorageIntegration
            self._storage = StorageIntegration.get_storage()
        return self._storage
    
    @property
    def cache(self):
        """Lazy load cache"""
        if self._cache is None:
            from app.core.storage.integration import StorageIntegration
            self._cache = StorageIntegration.get_cache()
        return self._cache
    
    def validate_input(self, **kwargs) -> bool:
        """Validate search input."""
        return 'query' in kwargs
    
    async def execute(self, **kwargs) -> Dict[str, Any]:
        """
        Execute web search with caching
        """
        query = kwargs.get('query', '')
        search_type = kwargs.get('search_type', 'general')
        
        # Generate cache key
        cache_key = self.cache.generate_key(
            CacheType.API,
            f"web_search_{search_type}",
            {"query": query}
        )
        
        # Check cache first (shorter TTL for web searches)
        cached = await self.cache.get(cache_key, CacheType.API)
        if cached:
            logger.info(f"Using cached web search results for: {query}")
            return cached
        
        # Enhance query
        enhanced_query = self.enhance_query(query, search_type)
        
        # Perform search
        if self.google_api_key and self.google_cse_id:
            results = await self.google_search(enhanced_query)
        elif self.search_api_key:
            results = await self.serp_api_search(enhanced_query)
        else:
            results = await self.fallback_search(enhanced_query)
        
        # Process results
        processed_results = self.process_results(results, search_type)
        
        # Extract insights
        insights = self.extract_insights(processed_results, search_type)
        
        # Prepare response
        response = {
            "query": query,
            "enhanced_query": enhanced_query,
            "results": processed_results,
            "insights": insights,
            "timestamp": datetime.utcnow().isoformat()
        }
        
        # Cache the results (30 minutes for web searches)
        await self.cache.set(
            cache_key,
            response,
            CacheType.API,
            ttl_override=1800  # 30 minutes
        )
        
        # Store important news if it's news search
        if search_type == 'news' and processed_results:
            await self._store_news_data(processed_results, query)
        
        return response
    
    async def _store_news_data(self, news_items: List[Dict[str, Any]], query: str):
        """Store important news data in storage system"""
        try:
            # Filter high relevance news
            important_news = [
                item for item in news_items
                if item.get('relevance', 0) > 0.7
            ]
            
            if important_news:
                # This could be extended to save news to a specific collection
                logger.info(f"Stored {len(important_news)} important news items")
        except Exception as e:
            logger.error(f"Failed to store news data: {e}")
    
    def enhance_query(self, query: str, search_type: str) -> str:
        """Enhance search query for better results."""
        if search_type == 'news':
            return f"{query} Turkey real estate news {datetime.now().year}"
        elif search_type == 'market':
            return f"{query} Turkey property market analysis prices trends"
        elif search_type == 'legal':
            return f"{query} Turkey real estate law regulations"
        else:
            return f"{query} Turkey emlak gayrimenkul"
    
    async def google_search(self, query: str) -> List[Dict[str, Any]]:
        """Search using Google Custom Search API."""
        try:
            url = "https://www.googleapis.com/customsearch/v1"
            params = {
                'key': self.google_api_key,
                'cx': self.google_cse_id,
                'q': query,
                'num': 10
            }
            
            async with aiohttp.ClientSession() as session:
                async with session.get(url, params=params) as response:
                    if response.status == 200:
                        data = await response.json()
                        return data.get('items', [])
        except Exception as e:
            logger.error(f"Google search failed: {e}")
        
        return []
    
    async def serp_api_search(self, query: str) -> List[Dict[str, Any]]:
        """Search using SERP API."""
        # Implementation would go here
        return []
    
    async def fallback_search(self, query: str) -> List[Dict[str, Any]]:
        """Fallback search using predefined data."""
        # Check if we have any stored data related to the query
        try:
            # Try to get related properties from storage
            properties = await self.storage.get_properties(
                location=query.split()[0],  # Simple extraction
                filters={'limit': 5}
            )
            
            if properties:
                return [
                    {
                        "title": f"Property in {prop.get('location', 'Turkey')}",
                        "snippet": f"{prop.get('rooms', 'N/A')} rooms, {prop.get('size', 'N/A')}m², {prop.get('price', 'N/A')} TL",
                        "link": prop.get('url', '#'),
                        "source": "Local Storage"
                    }
                    for prop in properties[:3]
                ]
        except Exception as e:
            logger.debug(f"Fallback storage search failed: {e}")
        
        # Return simulated results
        return [
            {
                "title": "Turkish Real Estate Market Report 2024",
                "snippet": "Property prices in Turkey continue to rise with 15% annual growth...",
                "link": "https://example.com/market-report",
                "source": "Market Analysis"
            },
            {
                "title": "Istanbul Property Investment Guide",
                "snippet": "Best districts for investment in Istanbul include Kadıköy, Beşiktaş...",
                "link": "https://example.com/investment-guide",
                "source": "Investment Guide"
            }
        ]
    
    def process_results(self, results: List[Dict[str, Any]], search_type: str) -> List[Dict[str, Any]]:
        """Process and filter search results."""
        processed = []
        
        for result in results[:10]:
            processed_result = {
                "title": result.get('title', ''),
                "snippet": result.get('snippet', ''),
                "link": result.get('link', ''),
                "source": self.extract_source(result.get('link', '')),
                "relevance": self.calculate_relevance(result, search_type)
            }
            
            if processed_result['relevance'] > 0.3:
                processed.append(processed_result)
        
        processed.sort(key=lambda x: x['relevance'], reverse=True)
        
        return processed
    
    def extract_source(self, url: str) -> str:
        """Extract source domain from URL."""
        try:
            from urllib.parse import urlparse
            domain = urlparse(url).netloc
            return domain.replace('www.', '')
        except:
            return 'Unknown'
    
    def calculate_relevance(self, result: Dict[str, Any], search_type: str) -> float:
        """Calculate relevance score."""
        relevance = 0.5
        
        title = result.get('title', '').lower()
        snippet = result.get('snippet', '').lower()
        
        keywords = ['turkey', 'turkish', 'emlak', 'property', 'real estate', 'gayrimenkul']
        
        for keyword in keywords:
            if keyword in title:
                relevance += 0.1
            if keyword in snippet:
                relevance += 0.05
        
        if search_type == 'market':
            market_keywords = ['price', 'trend', 'analysis', 'market', 'investment']
            for keyword in market_keywords:
                if keyword in title or keyword in snippet:
                    relevance += 0.1
        
        return min(1.0, relevance)
    
    def extract_insights(self, results: List[Dict[str, Any]], search_type: str) -> List[str]:
        """Extract key insights from search results."""
        insights = []
        
        if search_type == 'market':
            for result in results:
                snippet = result.get('snippet', '').lower()
                if 'increase' in snippet or 'growth' in snippet:
                    insights.append("Market shows positive growth trends")
                    break
                elif 'decrease' in snippet or 'decline' in snippet:
                    insights.append("Market showing signs of correction")
                    break
        
        for result in results[:3]:
            snippet = result.get('snippet', '')
            import re
            percentages = re.findall(r'\d+%', snippet)
            if percentages:
                insights.append(f"Key statistic found: {percentages[0]} change mentioned")
        
        if not insights:
            insights.append("Current market information available - review search results")
        
        return insights
