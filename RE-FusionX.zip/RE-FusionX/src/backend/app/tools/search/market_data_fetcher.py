"""
Market Data Fetcher Tool
Fetches and manages real estate market data
"""

from pathlib import Path
from typing import Dict, Any, Optional, List
from datetime import datetime, timedelta
import pandas as pd
import asyncio
from app.tools.base_tool import BaseTool
from app.core.config import settings
from app.core.logging import logger
from app.utils.location_utils import get_location_manager, normalize_text
from app.core.storage.integration import StorageIntegration
from app.core.storage.unified_cache import CacheType

try:
    from app.core.storage.search_engine import SearchEngine
    from app.core.storage.parquet_manager import ParquetManager
    from app.data_collectors.base.collector_manager import CollectorManager
    COLLECTORS_AVAILABLE = True
    logger.info("Data collectors loaded successfully")
except ImportError as e:
    # Fallback if data_collectors not available
    SearchEngine = None
    ParquetManager = None
    CollectorManager = None
    COLLECTORS_AVAILABLE = False
    logger.warning(f"Data collectors not available: {e}")


class MarketDataFetcher(BaseTool):
    """Tool for fetching and managing market data"""
    
    def __init__(self):
        super().__init__(
            name="MarketDataFetcher",
            description="Fetch real estate market data"
        )
        
        self.market_cache = {}
        
        # Initialize data clients if available
        self.data_dir = Path(settings.DATA_DIR) if hasattr(settings, 'DATA_DIR') else Path("data")
        
        self.search_client = None
        self.output_manager = None
        self.collector_manager = None
        self._storage = None
        self._cache = None
        
        
        if SearchEngine:
            try:
                self.search_client = SearchEngine(self.data_dir)
                logger.info("SearchEngine initialized successfully")
            except Exception as e:
                logger.warning(f"Failed to initialize SearchEngine: {e}")
        
        if ParquetManager:
            try:
                self.output_manager = ParquetManager()
                logger.info("ParquetManager initialized successfully")
            except Exception as e:
                logger.warning(f"Failed to initialize ParquetManager: {e}")
        
        if CollectorManager:
            try:
                # ✅ حل المشكلة: تجاهل CacheManager واستخدام None مؤقتاً
                # CollectorManager سيتم تطويره لاحقاً
                self.collector_manager = None  # مؤقتاً حتى يتم تطوير CollectorManager
                logger.info("CollectorManager disabled temporarily (will be developed later)")
            except Exception as e:
                logger.warning(f"CollectorManager initialization skipped: {e}")
                self.collector_manager = None

    @property
    def storage(self):
        """Lazy load storage"""
        if self._storage is None:
            from app.core.storage.integration import StorageIntegration
            self._storage = StorageIntegration.get_storage()
        return self._storage
    
    @property
    def cache(self):
        """Lazy load cache"""
        if self._cache is None:
            from app.core.storage.integration import StorageIntegration
            self._cache = StorageIntegration.get_cache()
        return self._cache

    
    def validate_input(self, **kwargs) -> bool:
        """Validate input for market data fetching."""
        return True  # يقبل جميع المدخلات
    
    async def execute(self, **kwargs) -> Dict[str, Any]:
        """
        Execute market data fetching using new storage system
        """
        location = kwargs.get('location', 'Turkey')
        property_type = kwargs.get('property_type')
        use_cache = kwargs.get('use_cache', True)
        
        # Generate cache key
        cache_key = self.cache.generate_key(
            CacheType.MARKET,
            f"market_data_{location}",
            {"type": property_type}
        )
        
        # Check cache first
        if use_cache:
            cached_data = await self.cache.get(cache_key, CacheType.MARKET)
            if cached_data and self._is_data_fresh(cached_data):
                logger.info(f"Using cached market data for {location}")
                return cached_data
        
        # Get from storage
        logger.info(f"Fetching market data for {location} from storage")
        
        # Get properties from storage
        properties = await self.storage.get_properties(
            location=location,
            filters={'property_type': property_type} if property_type else None
        )
        
        # Get market analysis
        market_analysis = await self.storage.get_market_analysis(
            location=location,
            days_back=30
        )
        
        if properties or market_analysis:
            # Create response
            market_data = {
                'location': location,
                'properties': properties[:100] if properties else [],
                'market_analysis': market_analysis,
                'statistics': self._analyze_properties(properties) if properties else {},
                'timestamp': datetime.now().isoformat(),
                'source': 'storage_system'
            }
            
            # Cache the result
            await self.cache.set(cache_key, market_data, CacheType.MARKET)
            
            return market_data
        
        # If no data in storage, fetch fresh
        logger.info(f"No stored data for {location}, fetching fresh data")
        fresh_data = await self._fetch_fresh_data(location, property_type)
        
        # Save to storage if we got data
        if fresh_data and fresh_data.get('properties'):
            await self.storage.save_properties(
                fresh_data['properties'],
                location,
                'market_data_fetcher'
            )
        
        # Cache the result
        await self.cache.set(cache_key, fresh_data, CacheType.MARKET)
        
        return fresh_data
    
    async def _fetch_fresh_data(self, location: str, property_type: Optional[str]) -> Dict[str, Any]:
        """Fetch fresh data using scraper"""
        try:
            from app.data_collectors.real_estate.sources.emlakjet import EmlakjetScraper
            
            scraper = EmlakjetScraper()
            
            async with scraper:
                result = await scraper.collect(
                    location=location,
                    property_type=property_type or "daire",
                    max_pages=3
                )
            
            if result and result.get('success'):
                properties = result.get('properties', [])
                
                return {
                    'location': location,
                    'properties': properties,
                    'market_analysis': self._analyze_properties(properties),
                    'timestamp': datetime.now().isoformat(),
                    'source': 'emlakjet_scraper'
                }
        
        except Exception as e:
            logger.error(f"Error fetching fresh data: {e}")
        
        return self._get_fallback_data(location)
    
    def _analyze_properties(self, properties: List[Dict]) -> Dict[str, Any]:
        """Analyze properties for statistics"""
        if not properties:
            return {}
        
        prices = [p.get('price', 0) for p in properties if p.get('price')]
        sizes = [p.get('size', 0) for p in properties if p.get('size')]
        
        return {
            'total_properties': len(properties),
            'avg_price': sum(prices) / len(prices) if prices else 0,
            'min_price': min(prices) if prices else 0,
            'max_price': max(prices) if prices else 0,
            'avg_size': sum(sizes) / len(sizes) if sizes else 0,
            'price_per_sqm': sum(prices) / sum(sizes) if prices and sizes else 0
        }
    
    def _is_data_fresh(self, data: Dict) -> bool:
        """Check if data is fresh enough"""
        if not data.get('timestamp'):
            return False
        
        try:
            data_time = datetime.fromisoformat(data['timestamp'])
            age = datetime.now() - data_time
            return age < timedelta(hours=24)
        except:
            return False
    
    def _get_fallback_data(self, location: str) -> Dict[str, Any]:
        """Get fallback data when nothing available"""
        location_manager = get_location_manager()
        location_info = location_manager.parse_location(location)
        
        fallback_stats = {
            'İstanbul': {'avg_price': 5000000, 'avg_price_per_sqm': 35000},
            'Ankara': {'avg_price': 2800000, 'avg_price_per_sqm': 20000},
            'İzmir': {'avg_price': 3200000, 'avg_price_per_sqm': 28000}
        }
        
        city_key = location_info.get('city', 'İstanbul')
        stats = fallback_stats.get(city_key, fallback_stats['İstanbul'])
        
        return {
            'location': location,
            'market_analysis': {
                'property_statistics': stats,
                'analysis_date': datetime.now().isoformat(),
                'data_quality': 'simulated'
            },
            'properties': [],
            'timestamp': datetime.now().isoformat(),
            'source': 'fallback_simulation'
        }
    
    async def get_market_trends(self, location: str, days: int = 30) -> Dict[str, Any]:
        """Get market trends using storage system"""
        # Generate cache key
        cache_key = self.cache.generate_key(
            CacheType.MARKET,
            f"trends_{location}",
            {"days": days}
        )
        
        # Check cache
        cached = await self.cache.get(cache_key, CacheType.MARKET)
        if cached:
            return cached
        
        # Get from storage
        analysis = await self.storage.get_market_analysis(location, days)
        
        trends = {
            'location': location,
            'period_days': days,
            'trends': analysis.get('price_trends', []) if analysis else [],
            'statistics': analysis.get('property_statistics', {}) if analysis else {},
            'timestamp': datetime.now().isoformat(),
            'source': 'storage_analysis'
        }
        
        # Cache result
        await self.cache.set(cache_key, trends, CacheType.MARKET)
        
        return trends
  
    async def _get_local_data(self, location: str, property_type: Optional[str]) -> Optional[Dict]:
        """Get data from local storage"""
        if not self.search_client:
            return None
        
        try:
            # Get market analysis
            market_data = self.search_client.get_market_analysis(
                location=location,
                days_back=30
            )
            
            if not market_data:
                return None
            
            # Get property statistics
            properties = self.search_client.search_properties(
                query=location,
                filters={'property_type': property_type} if property_type else {},
                limit=100
            )
            
            return {
                'location': location,
                'market_analysis': market_data,
                'properties': properties.to_dict('records') if not properties.empty else [],
                'timestamp': datetime.now().isoformat(),
                'source': 'local_cache'
            }
            
        except Exception as e:
            logger.error(f"Error getting local data: {e}")
            return None
    
    async def _save_fresh_data(self, data: Dict, location: str):
        """Save fresh data to storage"""
        if not self.output_manager:
            return
        
        try:
            # Save to appropriate format
            if 'properties' in data:
                self.output_manager.save_properties(
                    pd.DataFrame(data['properties']),
                    location.lower()
                )
            
            if 'market_analysis' in data:
                self.output_manager.save_market_analysis(
                    data['market_analysis'],
                    location.lower()
                )
                
        except Exception as e:
            logger.error(f"Error saving data: {e}")

    async def get_investment_opportunities(self, budget: float, location: Optional[str] = None) -> List[Dict[str, Any]]:
        """Get investment opportunities within budget"""
        
        if self.search_client:
            try:
                opportunities = self.search_client.get_investment_opportunities(
                    budget=budget,
                    min_roi=5.0
                )
                
                if not opportunities.empty:
                    return opportunities.to_dict('records')
                    
            except Exception as e:
                logger.warning(f"Failed to get opportunities: {e}")
        
        # Return simulated opportunities
        return [
            {
                'title': f'Investment Property in {location or "Turkey"}',
                'price': budget * 0.9,
                'expected_roi': 7.5,
                'location': location or 'Istanbul',
                'type': 'Apartment',
                'size': 120,
                'recommendation': 'Good investment potential'
            }
        ]
