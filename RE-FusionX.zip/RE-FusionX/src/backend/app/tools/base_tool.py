"""
Base tool class for all tools in the system.
Provides common functionality for tool implementations.
"""

from abc import ABC, abstractmethod
from typing import Dict, Any, Optional, List
from datetime import datetime
import asyncio

from app.core.logging import LoggerMixin, logger
from app.core.exceptions import REFusionXException


class BaseTool(ABC, LoggerMixin):
    """Abstract base class for all tools."""
    
    def __init__(self, name: str, description: str):
        """
        Initialize base tool.
        
        Args:
            name: Tool name
            description: Tool description
        """
        self.name = name
        self.description = description
        self.metrics = {
            "executions": 0,
            "failures": 0,
            "total_execution_time": 0,
            "last_execution": None
        }
    
    @abstractmethod
    async def execute(self, **kwargs) -> Any:
        """
        Execute the tool with given parameters.
        
        Args:
            **kwargs: Tool-specific parameters
            
        Returns:
            Tool execution result
        """
        pass
    
    @abstractmethod
    def validate_input(self, **kwargs) -> bool:
        """
        Validate input parameters.
        
        Args:
            **kwargs: Parameters to validate
            
        Returns:
            True if valid
        """
        pass
    
    async def safe_execute(self, **kwargs) -> Dict[str, Any]:
        """
        Safely execute tool with error handling.
        
        Args:
            **kwargs: Tool parameters
            
        Returns:
            Execution result with metadata
        """
        start_time = datetime.utcnow()
        
        try:
            # Validate input
            if not self.validate_input(**kwargs):
                raise REFusionXException(
                    f"Invalid input for tool {self.name}",
                    error_code="TOOL_VALIDATION_ERROR"
                )
            
            # Execute tool
            result = await self.execute(**kwargs)
            
            # Update metrics
            execution_time = (datetime.utcnow() - start_time).total_seconds()
            self.update_metrics(execution_time, success=True)
            
            return {
                "success": True,
                "result": result,
                "execution_time": execution_time,
                "tool": self.name
            }
            
        except Exception as e:
            execution_time = (datetime.utcnow() - start_time).total_seconds()
            self.update_metrics(execution_time, success=False)
            
            self.logger.error(f"Tool {self.name} execution failed: {e}", exc_info=True)
            
            return {
                "success": False,
                "error": str(e),
                "execution_time": execution_time,
                "tool": self.name
            }
    
    def update_metrics(self, execution_time: float, success: bool):
        """
        Update tool metrics.
        
        Args:
            execution_time: Time taken to execute
            success: Whether execution was successful
        """
        self.metrics["executions"] += 1
        self.metrics["total_execution_time"] += execution_time
        
        if not success:
            self.metrics["failures"] += 1
        
        self.metrics["last_execution"] = datetime.utcnow().isoformat()
        
        if self.metrics["executions"] > 0:
            self.metrics["average_execution_time"] = (
                self.metrics["total_execution_time"] / self.metrics["executions"]
            )
            self.metrics["failure_rate"] = (
                self.metrics["failures"] / self.metrics["executions"]
            )
    
    def get_metrics(self) -> Dict[str, Any]:
        """Get tool metrics."""
        return {
            "tool_name": self.name,
            "description": self.description,
            "metrics": self.metrics
        }
