"""
Sample Data Generator
=====================
Generates comprehensive sample data for testing
"""

from typing import List, Dict, Any


import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import random
import json
from pathlib import Path
from faker import Faker

from app.core.storage.parquet_manager import ParquetManager


class SampleDataGenerator:
    """Generates realistic sample data for Turkish real estate"""
    
    def __init__(self):
        self.faker = Faker('tr_TR')
        self.output_manager = ParquetManager()
        
        # Turkish real estate data
        self.cities = {
            "Istanbul": {
                "districts": ["Kadıköy", "Beşiktaş", "Şişli", "Bakırköy", "Ataşehir", 
                            "Başakşehir", "Beylikdüzü", "Sarıyer", "Üsküdar", "Fatih"],
                "price_multiplier": 1.5
            },
            "Ankara": {
                "districts": ["Çankaya", "Keçiören", "Yenimahalle", "Mamak", "Etimesgut"],
                "price_multiplier": 1.0
            },
            "Izmir": {
                "districts": ["Konak", "Karşıyaka", "Bornova", "Bayraklı", "Buca"],
                "price_multiplier": 1.2
            },
            "Antalya": {
                "districts": ["Muratpaşa", "Konyaaltı", "Lara", "Kepez"],
                "price_multiplier": 1.3
            }
        }
        
        self.property_types = ["Daire", "Villa", "Residence", "Müstakil Ev"]
        self.room_configs = ["1+1", "2+1", "3+1", "4+1", "5+1"]
        self.heating_types = ["Merkezi", "Kombi", "Yerden Isıtma", "Klima"]
        self.features = ["Otopark", "Asansör", "Balkon", "Güvenlik", "Havuz", "Spor Salonu", "Bahçe"]
    
    def generate_properties(self, count: int = 1000, city: str = "Istanbul") -> List[Dict[str, Any]]:
        """Generate sample property data"""
        properties = []
        city_data = self.cities.get(city, self.cities["Istanbul"])
        
        for i in range(count):
            district = random.choice(city_data["districts"])
            property_type = random.choice(self.property_types)
            rooms = random.choice(self.room_configs)
            
            # Calculate base price
            base_price = random.randint(500000, 5000000)
            price = base_price * city_data["price_multiplier"]
            
            # Size based on rooms
            room_num = int(rooms.split('+')[0])
            base_size = room_num * 30 + random.randint(20, 50)
            
            # Building age
            building_age = random.randint(0, 30)
            if building_age == 0:
                building_age_text = "Sıfır"
            else:
                building_age_text = f"{building_age} yaşında"
            
            # تحويل التواريخ إلى milliseconds timestamp
            now = datetime.now()
            listing_date = now - timedelta(days=random.randint(1, 90))
            
            # تحويل إلى milliseconds timestamp
            listing_date_ms = int(listing_date.timestamp() * 1000)
            scraped_at_ms = int(now.timestamp() * 1000)
            updated_at_ms = int(now.timestamp() * 1000)
            
            # Generate property
            prop = {
                "property_id": f"PROP_{city[:3]}_{i:06d}",
                "source": random.choice(["sahibinden", "emlakjet", "hurriyetemlak"]),
                "title": f"{district} {rooms} {property_type}",
                "price": price,
                "currency": "TL",
                "location": f"{city} - {district}",
                "city": city,
                "district": district,
                "neighborhood": self.faker.street_name(),
                "latitude": 41.0082 + random.uniform(-0.5, 0.5),
                "longitude": 28.9784 + random.uniform(-0.5, 0.5),
                "size_sqm": base_size,
                "size_gross": base_size + random.randint(10, 20),
                "size_net": base_size - random.randint(5, 10),
                "rooms": rooms,
                "room_count": room_num,
                "bathrooms": min(2, room_num // 2 + 1),
                "building_age": building_age,
                "floor": random.randint(1, 10),
                "total_floors": random.randint(5, 15),
                "property_type": property_type,
                "heating_type": random.choice(self.heating_types),
                "furnished": random.choice([True, False]),
                "in_site": random.choice([True, False]),
                "has_parking": random.choice([True, False]),
                "has_elevator": building_age < 20,
                "has_balcony": random.choice([True, False]),
                "has_garden": property_type == "Villa",
                "credit_eligible": random.choice([True, False]),
                "features": random.sample(self.features, random.randint(2, 5)),
                "description": self.faker.text(200),
                "images": [f"https://example.com/image_{j}.jpg" for j in range(random.randint(5, 10))],
                "url": f"https://example.com/property/{i}",
                "seller_type": random.choice(["owner", "agent", "developer"]),
                "seller_name": self.faker.name(),
                "phone": self.faker.phone_number(),
                "listing_date": pd.Timestamp(listing_date_ms, unit='ms'),  # استخدام pd.Timestamp
                "scraped_at": pd.Timestamp(scraped_at_ms, unit='ms'),
                "updated_at": pd.Timestamp(updated_at_ms, unit='ms'),
                "price_per_sqm": price / base_size,
                "market_comparison": random.choice(["below_market", "at_market", "above_market"]),
                "investment_score": random.uniform(5, 10),
                "metadata": json.dumps({"generated": True, "batch": i // 100})
            }
            
            properties.append(prop)
        
        return properties


    def generate_market_data(self, days: int = 90) -> List[Dict[str, Any]]:
        """Generate sample market data"""
        market_data = []
        indicators = [
            ("price_index", "index", 100),
            ("sales_volume", "units", 10000),
            ("mortgage_rate", "%", 3.5),
            ("construction_permits", "units", 500),
            ("foreign_investment", "million_usd", 100)
        ]
        
        for city in self.cities.keys():
            for day in range(days):
                date = datetime.now().date() - timedelta(days=day)
                
                for indicator_name, unit, base_value in indicators:
                    # Generate realistic fluctuation
                    value = base_value * (1 + np.sin(day / 30) * 0.1 + random.uniform(-0.05, 0.05))
                    
                    market_data.append({
                        "indicator_id": f"IND_{indicator_name}_{city}_{date}",
                        "indicator_name": indicator_name,
                        "category": "market",
                        "location": city,
                        "value": value,
                        "unit": unit,
                        "date": date,
                        "period": "daily",
                        "change_value": value - base_value,
                        "change_percent": ((value - base_value) / base_value) * 100,
                        "trend": "increasing" if value > base_value else "decreasing",
                        "source": "TCMB",
                        "confidence": 0.95,
                        "collected_at": pd.Timestamp.now().floor('ms')  # تحويل إلى milliseconds
                    })
        
        return market_data

    def generate_news(self, count: int = 100) -> List[Dict[str, Any]]:
        """Generate sample news articles"""
        articles = []
        
        topics = [
            "Konut satışları rekor kırdı",
            "Mortgage faizleri düştü",
            "Yabancı yatırımcı ilgisi arttı",
            "Yeni metro hattı değerleri artırdı",
            "İnşaat maliyetleri yükseldi"
        ]
        
        sentiments = ["positive", "negative", "neutral"]
        sources = ["Hurriyet Emlak", "Sabah", "Bloomberg HT", "Emlak Kulisi"]
        
        for i in range(count):
            published_date = datetime.now() - timedelta(days=random.randint(1, 30))
            
            article = {
                "article_id": f"NEWS_{i:06d}",
                "url": f"https://news.example.com/article/{i}",
                "title": random.choice(topics) + f" - {self.faker.city()}",
                "summary": self.faker.text(150),
                "content": self.faker.text(500),
                "source": random.choice(sources),
                "author": self.faker.name(),
                "language": "tr",
                "category": "real_estate",
                "tags": ["emlak", "konut", "yatırım"],
                "sentiment": random.choice(sentiments),
                "sentiment_score": random.uniform(-1, 1),
                "relevance_score": random.uniform(0.5, 1.0),
                "published_date": pd.Timestamp(published_date).floor('ms'),  # تحويل إلى milliseconds
                "collected_at": pd.Timestamp.now().floor('ms'),  # تحويل إلى milliseconds
                "images": [f"https://news.example.com/image_{j}.jpg" for j in range(random.randint(1, 3))],
                "keywords": ["emlak", "konut", "fiyat", "yatırım"]
            }
            
            articles.append(article)
        
        return articles
 
    def generate_and_save_all(self):
        """Generate and save all sample data"""
        # Generate properties for each city
        for city in self.cities.keys():
            properties = self.generate_properties(500, city)
            self.output_manager.save_properties(properties, city)
            print(f"Generated {len(properties)} properties for {city}")
        
        # Generate market data
        market_data = self.generate_market_data(90)
        self.output_manager.save_market_data(market_data, "indicators")
        print(f"Generated {len(market_data)} market data points")
        
        # Generate news
        news = self.generate_news(100)
        self.output_manager.save_news(news)
        print(f"Generated {len(news)} news articles")
        
        # Print statistics
        stats = self.output_manager.get_statistics()
        print("\nData Statistics:")
        print(json.dumps(stats, indent=2))


# Generate sample data
if __name__ == "__main__":
    generator = SampleDataGenerator()
    generator.generate_and_save_all()