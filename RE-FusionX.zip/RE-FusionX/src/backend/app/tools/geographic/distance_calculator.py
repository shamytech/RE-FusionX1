"""
Distance calculation tool for geographic analysis.
Calculates distances between properties and points of interest.
"""

from typing import Dict, Any, List, Tuple, Optional
from geopy.geocoders import Nominatim
from geopy.distance import geodesic
import asyncio

from app.tools.base_tool import BaseTool
from app.core.config import settings
from app.core.logging import logger


class DistanceCalculator(BaseTool):
    """Calculate distances between geographic points."""
    
    def __init__(self):
        """Initialize distance calculator."""
        super().__init__(
            name="DistanceCalculator",
            description="Calculate distances between locations"
        )
        
        self.geolocator = Nominatim(
            user_agent=settings.GEOPY_USER_AGENT,
            timeout=10
        )
        
        # Cache for geocoded locations
        self.location_cache = {}
        
        # Important POIs in Turkey
        self.poi_coordinates = self.load_poi_coordinates()
    
    def load_poi_coordinates(self) -> Dict[str, Tuple[float, float]]:
        """Load coordinates of important points of interest."""
        return {
            # Istanbul
            "istanbul_center": (41.0082, 28.9784),
            "istanbul_airport": (41.2753, 28.7519),
            "sabiha_gokcen_airport": (40.8986, 29.3092),
            "taksim_square": (41.0370, 28.9851),
            "sultanahmet": (41.0054, 28.9768),
            
            # Ankara
            "ankara_center": (39.9334, 32.8597),
            "ankara_airport": (40.1281, 32.9951),
            "kizilay": (39.9208, 32.8541),
            
            # Izmir
            "izmir_center": (38.4192, 27.1287),
            "izmir_airport": (38.2924, 27.1570),
            "konak_square": (38.4189, 27.1287),
            
            # Antalya
            "antalya_center": (36.8969, 30.7133),
            "antalya_airport": (36.8987, 30.8005),
        }
    
    def validate_input(self, **kwargs) -> bool:
        """Validate input for distance calculation."""
        return 'location' in kwargs or ('origin' in kwargs and 'destination' in kwargs)
    
    async def execute(self, **kwargs) -> Dict[str, Any]:
        """
        Execute distance calculations.
        
        Args:
            location: Primary location
            destinations: List of destinations to calculate distance to
            
        Returns:
            Distance calculation results
        """
        location = kwargs.get('location')
        destinations = kwargs.get('destinations', [])
        
        # Get coordinates for main location
        main_coords = await self.geocode_location(location)
        
        if not main_coords:
            return {
                "error": f"Could not geocode location: {location}",
                "distances": {}
            }
        
        # Calculate distances to POIs
        poi_distances = self.calculate_poi_distances(main_coords, location)
        
        # Calculate distances to custom destinations
        custom_distances = {}
        if destinations:
            for dest in destinations:
                dest_coords = await self.geocode_location(dest)
                if dest_coords:
                    distance = geodesic(main_coords, dest_coords).kilometers
                    custom_distances[dest] = round(distance, 2)
        
        # Find nearest amenities
        nearest_amenities = self.find_nearest_amenities(main_coords)
        
        return {
            "location": location,
            "coordinates": main_coords,
            "poi_distances": poi_distances,
            "custom_distances": custom_distances,
            "nearest_amenities": nearest_amenities,
            "accessibility_score": self.calculate_accessibility_score(poi_distances)
        }
    
    async def geocode_location(self, location: str) -> Optional[Tuple[float, float]]:
        """
        Geocode a location string to coordinates.
        
        Args:
            location: Location string
            
        Returns:
            Tuple of (latitude, longitude) or None
        """
        # Check cache first
        if location in self.location_cache:
            return self.location_cache[location]
        
        try:
            # Add Turkey to location for better results
            if "turkey" not in location.lower() and "türkiye" not in location.lower():
                location_with_country = f"{location}, Turkey"
            else:
                location_with_country = location
            
            # Geocode location
            result = self.geolocator.geocode(location_with_country)
            
            if result:
                coords = (result.latitude, result.longitude)
                self.location_cache[location] = coords
                return coords
            
            logger.warning(f"Could not geocode location: {location}")
            return None
            
        except Exception as e:
            logger.error(f"Geocoding error for {location}: {e}")
            return None
    
    def calculate_poi_distances(
        self,
        coords: Tuple[float, float],
        location: str
    ) -> Dict[str, float]:
        """
        Calculate distances to major POIs.
        
        Args:
            coords: Location coordinates
            location: Location string for context
            
        Returns:
            Dictionary of POI distances
        """
        distances = {}
        location_lower = location.lower()
        
        # Determine relevant POIs based on location
        relevant_pois = []
        
        if 'istanbul' in location_lower or 'İstanbul' in location:
            relevant_pois = [
                'istanbul_center', 'istanbul_airport', 'sabiha_gokcen_airport',
                'taksim_square', 'sultanahmet'
            ]
        elif 'ankara' in location_lower:
            relevant_pois = ['ankara_center', 'ankara_airport', 'kizilay']
        elif 'izmir' in location_lower or 'İzmir' in location:
            relevant_pois = ['izmir_center', 'izmir_airport', 'konak_square']
        elif 'antalya' in location_lower:
            relevant_pois = ['antalya_center', 'antalya_airport']
        else:
            # Calculate distance to major city centers
            relevant_pois = ['istanbul_center', 'ankara_center', 'izmir_center']
        
        # Calculate distances
        for poi in relevant_pois:
            if poi in self.poi_coordinates:
                poi_coords = self.poi_coordinates[poi]
                distance = geodesic(coords, poi_coords).kilometers
                poi_name = poi.replace('_', ' ').title()
                distances[poi_name] = round(distance, 2)
        
        return distances
    
    def find_nearest_amenities(
        self,
        coords: Tuple[float, float]
    ) -> Dict[str, Any]:
        """
        Find nearest amenities (simulated).
        
        Args:
            coords: Location coordinates
            
        Returns:
            Nearest amenities information
        """
        # This would typically query a POI database
        # For now, returning simulated data
        
        return {
            "metro_station": {
                "distance": 0.8,
                "walking_time": "10 minutes"
            },
            "bus_stop": {
                "distance": 0.2,
                "walking_time": "3 minutes"
            },
            "hospital": {
                "distance": 2.5,
                "driving_time": "8 minutes"
            },
            "school": {
                "distance": 1.2,
                "walking_time": "15 minutes"
            },
            "shopping_center": {
                "distance": 3.0,
                "driving_time": "10 minutes"
            },
            "park": {
                "distance": 0.5,
                "walking_time": "6 minutes"
            }
        }
    
    def calculate_accessibility_score(self, poi_distances: Dict[str, float]) -> float:
        """
        Calculate accessibility score based on distances.
        
        Args:
            poi_distances: Dictionary of POI distances
            
        Returns:
            Accessibility score (0-10)
        """
        score = 10.0
        
        # Check distance to center
        center_distances = [
            dist for name, dist in poi_distances.items()
            if 'center' in name.lower()
        ]
        
        if center_distances:
            min_center_dist = min(center_distances)
            
            if min_center_dist < 5:
                score = 10
            elif min_center_dist < 10:
                score = 8
            elif min_center_dist < 20:
                score = 6
            elif min_center_dist < 30:
                score = 4
            else:
                score = 2
        
        # Bonus for airport proximity
        airport_distances = [
            dist for name, dist in poi_distances.items()
            if 'airport' in name.lower()
        ]
        
        if airport_distances:
            min_airport_dist = min(airport_distances)
            if min_airport_dist < 20:
                score = min(10, score + 1)
        
        return score
