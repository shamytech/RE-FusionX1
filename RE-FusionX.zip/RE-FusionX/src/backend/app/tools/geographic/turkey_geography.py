"""
Turkey geography data and analysis tool.
Provides comprehensive geographic information for Turkish locations.
"""

from typing import Dict, Any, List, Optional, Tuple

from app.tools.base_tool import BaseTool
from app.core.logging import logger


class TurkeyGeography(BaseTool):
    """Turkey-specific geographic information tool."""
    
    def __init__(self):
        """Initialize Turkey geography tool."""
        super().__init__(
            name="TurkeyGeography",
            description="Comprehensive Turkish geographic data and analysis"
        )
        
        self.cities_data = self.load_cities_data()
        self.regions_data = self.load_regions_data()
    
    def load_cities_data(self) -> Dict[str, Any]:
        """Load comprehensive Turkish cities data."""
        return {
            "Istanbul": {
                "region": "Marmara",
                "tier": "A+",
                "population": 15840900,
                "area_km2": 5461,
                "coordinates": (41.0082, 28.9784),
                "economic_importance": 10,
                "tourism_score": 10,
                "districts_count": 39,
                "key_districts": {
                    "Kadıköy": {"tier": "A+", "type": "residential/commercial"},
                    "Beşiktaş": {"tier": "A+", "type": "business/residential"},
                    "Şişli": {"tier": "A", "type": "business/commercial"},
                    "Bakırköy": {"tier": "A", "type": "residential"},
                    "Ataşehir": {"tier": "A", "type": "business/residential"},
                    "Üsküdar": {"tier": "B+", "type": "residential/historical"},
                    "Fatih": {"tier": "B", "type": "historical/tourist"},
                    "Beyoğlu": {"tier": "A", "type": "tourist/commercial"},
                    "Sarıyer": {"tier": "A", "type": "residential/luxury"},
                    "Esenyurt": {"tier": "C", "type": "residential/developing"}
                }
            },
            "Ankara": {
                "region": "Central Anatolia",
                "tier": "A",
                "population": 5747325,
                "area_km2": 25632,
                "coordinates": (39.9334, 32.8597),
                "economic_importance": 9,
                "tourism_score": 6,
                "districts_count": 25,
                "key_districts": {
                    "Çankaya": {"tier": "A", "type": "diplomatic/residential"},
                    "Keçiören": {"tier": "B", "type": "residential"},
                    "Yenimahalle": {"tier": "B", "type": "residential"},
                    "Mamak": {"tier": "C", "type": "residential"},
                    "Etimesgut": {"tier": "B", "type": "residential/developing"}
                }
            },
            "Izmir": {
                "region": "Aegean",
                "tier": "A",
                "population": 4425789,
                "area_km2": 11891,
                "coordinates": (38.4192, 27.1287),
                "economic_importance": 8,
                "tourism_score": 8,
                "districts_count": 30,
                "key_districts": {
                    "Konak": {"tier": "A", "type": "central/commercial"},
                    "Karşıyaka": {"tier": "A", "type": "residential/coastal"},
                    "Bornova": {"tier": "B+", "type": "residential/university"},
                    "Buca": {"tier": "B", "type": "residential"},
                    "Alsancak": {"tier": "A+", "type": "commercial/entertainment"}
                }
            },
            "Bursa": {
                "region": "Marmara",
                "tier": "A",
                "population": 3147818,
                "area_km2": 10819,
                "coordinates": (40.1826, 29.0665),
                "economic_importance": 7,
                "tourism_score": 7,
                "districts_count": 17
            },
            "Antalya": {
                "region": "Mediterranean",
                "tier": "A",
                "population": 2619832,
                "area_km2": 20177,
                "coordinates": (36.8969, 30.7133),
                "economic_importance": 7,
                "tourism_score": 10,
                "districts_count": 19
            },
            "Adana": {
                "region": "Mediterranean",
                "tier": "B",
                "population": 2263373,
                "area_km2": 13844,
                "coordinates": (37.0000, 35.3213),
                "economic_importance": 6,
                "tourism_score": 5,
                "districts_count": 15
            },
            "Konya": {
                "region": "Central Anatolia",
                "tier": "B",
                "population": 2296347,
                "area_km2": 38873,
                "coordinates": (37.8667, 32.4833),
                "economic_importance": 6,
                "tourism_score": 6,
                "districts_count": 31
            }
        }
    
    def load_regions_data(self) -> Dict[str, Any]:
        """Load Turkish regions data."""
        return {
            "Marmara": {
                "cities": ["Istanbul", "Bursa", "Kocaeli", "Sakarya", "Balıkesir", "Çanakkale", "Edirne", "Kırklareli", "Tekirdağ", "Yalova", "Bilecik"],
                "economic_importance": 10,
                "population_percentage": 30,
                "characteristics": ["industrial", "commercial", "tourism", "agriculture"]
            },
            "Aegean": {
                "cities": ["Izmir", "Aydın", "Denizli", "Manisa", "Muğla", "Afyonkarahisar", "Kütahya", "Uşak"],
                "economic_importance": 8,
                "population_percentage": 13,
                "characteristics": ["tourism", "agriculture", "industry", "coastal"]
            },
            "Mediterranean": {
                "cities": ["Antalya", "Adana", "Mersin", "Hatay", "Kahramanmaraş", "Osmaniye", "Isparta", "Burdur"],
                "economic_importance": 7,
                "population_percentage": 13,
                "characteristics": ["tourism", "agriculture", "coastal", "trade"]
            },
            "Central Anatolia": {
                "cities": ["Ankara", "Konya", "Kayseri", "Eskişehir", "Sivas", "Yozgat", "Aksaray", "Niğde", "Nevşehir", "Kırıkkale", "Kırşehir", "Çankırı", "Karaman"],
                "economic_importance": 8,
                "population_percentage": 16,
                "characteristics": ["government", "industry", "agriculture", "education"]
            },
            "Black Sea": {
                "cities": ["Samsun", "Trabzon", "Ordu", "Giresun", "Rize", "Artvin", "Zonguldak", "Bartın", "Karabük", "Amasya", "Tokat", "Çorum", "Sinop", "Kastamonu", "Düzce", "Bolu"],
                "economic_importance": 5,
                "population_percentage": 10,
                "characteristics": ["agriculture", "fishing", "tourism", "mining"]
            },
            "Eastern Anatolia": {
                "cities": ["Erzurum", "Malatya", "Van", "Elazığ", "Ağrı", "Muş", "Bitlis", "Kars", "Erzincan", "Bingöl", "Ardahan", "Iğdır", "Tunceli", "Hakkari"],
                "economic_importance": 4,
                "population_percentage": 8,
                "characteristics": ["agriculture", "livestock", "winter tourism"]
            },
            "Southeastern Anatolia": {
                "cities": ["Gaziantep", "Şanlıurfa", "Diyarbakır", "Mardin", "Batman", "Siirt", "Şırnak", "Adıyaman", "Kilis"],
                "economic_importance": 5,
                "population_percentage": 10,
                "characteristics": ["industry", "agriculture", "historical tourism", "trade"]
            }
        }
    
    def validate_input(self, **kwargs) -> bool:
        """Validate input for geography tool."""
        return 'location' in kwargs
    
    async def execute(self, **kwargs) -> Dict[str, Any]:
        """
        Execute geographic analysis.
        
        Args:
            location: Location to analyze
            
        Returns:
            Geographic information and analysis
        """
        location = kwargs.get('location', '')
        
        # Parse location
        city, district, neighborhood = self.parse_location(location)
        
        # Get city data
        city_data = self.get_city_data(city)
        
        # Get district data if available
        district_data = self.get_district_data(city, district)
        
        # Get region data
        region_data = self.get_region_data(city_data.get('region'))
        
        # Calculate location metrics
        metrics = self.calculate_location_metrics(city_data, district_data)
        
        return {
            "city": city,
            "district": district,
            "neighborhood": neighborhood,
            "tier": district_data.get('tier') if district_data else city_data.get('tier'),
            "region": city_data.get('region'),
            "coordinates": city_data.get('coordinates'),
            "city_data": city_data,
            "district_data": district_data,
            "region_data": region_data,
            "metrics": metrics,
            "economic_importance": city_data.get('economic_importance', 5),
            "tourism_score": city_data.get('tourism_score', 5)
        }
    
    def parse_location(self, location: str) -> Tuple[str, str, str]:
        """Parse location string into components."""
        parts = [p.strip() for p in location.replace(',', '-').split('-')]
        
        city = None
        district = None
        neighborhood = None
        
        # Try to identify city
        for part in parts:
            for city_name in self.cities_data.keys():
                if city_name.lower() in part.lower():
                    city = city_name
                    break
            if city:
                break
        
        # If city found, try to identify district
        if city and len(parts) > 1:
            city_info = self.cities_data.get(city, {})
            key_districts = city_info.get('key_districts', {})
            
            for part in parts:
                for district_name in key_districts.keys():
                    if district_name.lower() in part.lower():
                        district = district_name
                        break
                if district:
                    break
        
        # Remaining part might be neighborhood
        if len(parts) > 2:
            neighborhood = parts[-1] if parts[-1] != district and parts[-1] != city else None
        
        return city or "Unknown", district or "", neighborhood or ""
    
    def get_city_data(self, city: str) -> Dict[str, Any]:
        """Get city data."""
        return self.cities_data.get(city, {
            "tier": "C",
            "region": "Unknown",
            "economic_importance": 5,
            "tourism_score": 5,
            "population": 0,
            "coordinates": (39.0, 35.0)  # Center of Turkey
        })
    
    def get_district_data(self, city: str, district: str) -> Optional[Dict[str, Any]]:
        """Get district data if available."""
        if city in self.cities_data and district:
            city_info = self.cities_data[city]
            key_districts = city_info.get('key_districts', {})
            
            if district in key_districts:
                return key_districts[district]
        
        return None
    
    def get_region_data(self, region: str) -> Dict[str, Any]:
        """Get region data."""
        return self.regions_data.get(region, {
            "economic_importance": 5,
            "population_percentage": 10,
            "characteristics": []
        })
    
    def calculate_location_metrics(
        self,
        city_data: Dict[str, Any],
        district_data: Optional[Dict[str, Any]]
    ) -> Dict[str, Any]:
        """Calculate various location metrics."""
        metrics = {}
        
        # Economic score
        economic_score = city_data.get('economic_importance', 5)
        if district_data and district_data.get('tier') in ['A+', 'A']:
            economic_score = min(10, economic_score + 1)
        metrics['economic_score'] = economic_score
        
        # Investment potential
        tier = district_data.get('tier') if district_data else city_data.get('tier', 'C')
        tier_scores = {'A+': 10, 'A': 8, 'B+': 7, 'B': 6, 'C': 4, 'D': 2}
        metrics['investment_potential'] = tier_scores.get(tier, 5)
        
        # Livability score
        livability = 5
        if city_data.get('tourism_score', 0) >= 7:
            livability += 1
        if city_data.get('population', 0) < 5000000:
            livability += 1  # Less crowded
        if district_data and 'residential' in district_data.get('type', ''):
            livability += 2
        metrics['livability_score'] = min(10, livability)
        
        # Growth potential
        if district_data and 'developing' in district_data.get('type', ''):
            metrics['growth_potential'] = 'High'
        elif tier in ['A+', 'A']:
            metrics['growth_potential'] = 'Stable'
        else:
            metrics['growth_potential'] = 'Moderate'
        
        return metrics
