"""
Location analysis tool.
Analyzes location quality and characteristics.
"""

from typing import Dict, Any, List, Optional, Tuple
import json

from app.tools.base_tool import BaseTool
from app.core.logging import logger


class LocationAnalyzer(BaseTool):
    """Analyze location characteristics and quality."""
    
    def __init__(self):
        """Initialize location analyzer."""
        super().__init__(
            name="LocationAnalyzer",
            description="Analyze location quality and characteristics"
        )
        
        self.location_data = self.load_location_data()
    
    def load_location_data(self) -> Dict[str, Any]:
        """Load location data for Turkish cities and districts."""
        return {
            "istanbul": {
                "kadıköy": {
                    "grade": "A+",
                    "income_level": "high",
                    "population_density": "high",
                    "infrastructure": "excellent",
                    "amenities": ["metro", "ferry", "shopping", "restaurants", "parks"],
                    "characteristics": ["coastal", "cultural", "vibrant", "expensive"]
                },
                "beşiktaş": {
                    "grade": "A+",
                    "income_level": "high",
                    "population_density": "high",
                    "infrastructure": "excellent",
                    "amenities": ["metro", "ferry", "shopping", "business", "universities"],
                    "characteristics": ["central", "business hub", "expensive", "prestigious"]
                },
                "şişli": {
                    "grade": "A",
                    "income_level": "high",
                    "population_density": "very high",
                    "infrastructure": "excellent",
                    "amenities": ["metro", "shopping", "business", "hospitals"],
                    "characteristics": ["commercial", "modern", "busy", "central"]
                },
                "bakırköy": {
                    "grade": "A",
                    "income_level": "medium-high",
                    "population_density": "high",
                    "infrastructure": "very good",
                    "amenities": ["metro", "shopping", "coastal", "parks"],
                    "characteristics": ["family-friendly", "coastal", "established"]
                },
                "esenyurt": {
                    "grade": "C",
                    "income_level": "medium-low",
                    "population_density": "very high",
                    "infrastructure": "developing",
                    "amenities": ["metrobus", "shopping", "schools"],
                    "characteristics": ["affordable", "crowded", "developing", "distant"]
                }
            },
            "ankara": {
                "çankaya": {
                    "grade": "A",
                    "income_level": "high",
                    "population_density": "medium",
                    "infrastructure": "excellent",
                    "amenities": ["metro", "shopping", "parks", "embassies"],
                    "characteristics": ["diplomatic", "green", "prestigious", "quiet"]
                },
                "keçiören": {
                    "grade": "B",
                    "income_level": "medium",
                    "population_density": "high",
                    "infrastructure": "good",
                    "amenities": ["metro", "shopping", "schools"],
                    "characteristics": ["residential", "family-friendly", "conservative"]
                }
            },
            "izmir": {
                "konak": {
                    "grade": "A",
                    "income_level": "medium-high",
                    "population_density": "high",
                    "infrastructure": "very good",
                    "amenities": ["metro", "ferry", "shopping", "historical"],
                    "characteristics": ["central", "historical", "coastal", "touristic"]
                },
                "karşıyaka": {
                    "grade": "A",
                    "income_level": "medium-high",
                    "population_density": "medium",
                    "infrastructure": "very good",
                    "amenities": ["ferry", "shopping", "parks", "coastal"],
                    "characteristics": ["coastal", "modern", "family-friendly", "green"]
                }
            }
        }
    
    def validate_input(self, **kwargs) -> bool:
        """Validate input for location analysis."""
        return 'location_data' in kwargs or 'location' in kwargs
    
    async def execute(self, **kwargs) -> Dict[str, Any]:
        """
        Execute location analysis.
        
        Args:
            location_data: Location information
            
        Returns:
            Location analysis results
        """
        location_data = kwargs.get('location_data', {})
        location_str = kwargs.get('location', location_data.get('full_location', ''))
        
        # Parse location
        city, district = self.parse_location(location_str)
        
        # Get district data
        district_info = self.get_district_info(city, district)
        
        # Analyze location quality
        quality_analysis = self.analyze_location_quality(district_info)
        
        # Analyze demographics
        demographics = self.analyze_demographics(city, district, district_info)
        
        # Analyze amenities
        amenities_analysis = self.analyze_amenities(district_info)
        
        # Calculate scores
        scores = self.calculate_location_scores(
            district_info,
            quality_analysis,
            amenities_analysis
        )
        
        return {
            "city": city,
            "district": district,
            "grade": district_info.get('grade', 'C'),
            "quality_analysis": quality_analysis,
            "demographics": demographics,
            "amenities": amenities_analysis,
            "scores": scores,
            "growth_potential": self.assess_growth_potential(district_info),
            "investment_suitability": self.assess_investment_suitability(scores)
        }
    
    def parse_location(self, location: str) -> Tuple[str, str]:
        """Parse location string to extract city and district."""
        location_lower = location.lower()
        
        # Try to find city
        city = None
        for city_name in self.location_data.keys():
            if city_name in location_lower:
                city = city_name
                break
        
        # Try to find district
        district = None
        if city:
            city_data = self.location_data.get(city, {})
            for district_name in city_data.keys():
                if district_name in location_lower:
                    district = district_name
                    break
        
        return city or "unknown", district or "unknown"
    
    def get_district_info(self, city: str, district: str) -> Dict[str, Any]:
        """Get district information."""
        if city in self.location_data:
            city_data = self.location_data[city]
            if district in city_data:
                return city_data[district]
        
        # Return default data
        return {
            "grade": "C",
            "income_level": "medium",
            "population_density": "medium",
            "infrastructure": "average",
            "amenities": [],
            "characteristics": []
        }
    
    def analyze_location_quality(self, district_info: Dict[str, Any]) -> Dict[str, Any]:
        """Analyze overall location quality."""
        grade = district_info.get('grade', 'C')
        
        quality_descriptions = {
            "A+": "Premium location with excellent infrastructure and high property values",
            "A": "High-quality location with very good infrastructure and strong demand",
            "B": "Good location with solid infrastructure and moderate demand",
            "C": "Average location with basic infrastructure and standard demand",
            "D": "Below average location with limited infrastructure"
        }
        
        return {
            "grade": grade,
            "description": quality_descriptions.get(grade, "Standard location"),
            "income_level": district_info.get('income_level', 'medium'),
            "infrastructure": district_info.get('infrastructure', 'average'),
            "characteristics": district_info.get('characteristics', [])
        }
    
    def analyze_demographics(
        self,
        city: str,
        district: str,
        district_info: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Analyze demographic information."""
        return {
            "population_density": district_info.get('population_density', 'medium'),
            "income_level": district_info.get('income_level', 'medium'),
            "family_friendly": "family-friendly" in district_info.get('characteristics', []),
            "student_population": "universities" in ' '.join(district_info.get('amenities', [])),
            "expat_friendly": grade in ['A+', 'A'] if (grade := district_info.get('grade')) else False,
            "demographic_trend": "growing" if district_info.get('grade') in ['A+', 'A', 'B'] else "stable"
        }
    
    def analyze_amenities(self, district_info: Dict[str, Any]) -> Dict[str, Any]:
        """Analyze available amenities."""
        amenities = district_info.get('amenities', [])
        
        return {
            "transportation": {
                "metro": "metro" in amenities,
                "metrobus": "metrobus" in amenities,
                "ferry": "ferry" in amenities,
                "accessibility": "excellent" if any(t in amenities for t in ['metro', 'metrobus']) else "good"
            },
            "education": {
                "schools": "schools" in amenities,
                "universities": "universities" in amenities,
                "quality": "high" if district_info.get('grade') in ['A+', 'A'] else "standard"
            },
            "shopping": {
                "available": "shopping" in amenities,
                "variety": "high" if district_info.get('grade') in ['A+', 'A'] else "moderate"
            },
            "healthcare": {
                "hospitals": "hospitals" in amenities,
                "accessibility": "good" if "hospitals" in amenities else "moderate"
            },
            "recreation": {
                "parks": "parks" in amenities,
                "coastal": "coastal" in district_info.get('characteristics', []),
                "restaurants": "restaurants" in amenities
            }
        }
    
    def calculate_location_scores(
        self,
        district_info: Dict[str, Any],
        quality_analysis: Dict[str, Any],
        amenities_analysis: Dict[str, Any]
    ) -> Dict[str, float]:
        """Calculate various location scores."""
        scores = {}
        
        # Overall quality score
        grade_scores = {"A+": 10, "A": 8.5, "B": 7, "C": 5.5, "D": 4}
        scores["quality"] = grade_scores.get(district_info.get('grade', 'C'), 5)
        
        # Accessibility score
        transport = amenities_analysis["transportation"]
        if transport["metro"] or transport["metrobus"]:
            scores["accessibility"] = 9
        elif transport["ferry"]:
            scores["accessibility"] = 7
        else:
            scores["accessibility"] = 5
        
        # Livability score
        livability = 5
        if "parks" in district_info.get('amenities', []):
            livability += 1
        if "shopping" in district_info.get('amenities', []):
            livability += 1
        if "family-friendly" in district_info.get('characteristics', []):
            livability += 1
        if district_info.get('infrastructure') in ['excellent', 'very good']:
            livability += 2
        scores["livability"] = min(10, livability)
        
        # Investment score
        investment = 5
        if district_info.get('grade') in ['A+', 'A']:
            investment += 3
        elif district_info.get('grade') == 'B':
            investment += 1
        if "developing" in district_info.get('characteristics', []):
            investment += 2
        scores["investment"] = min(10, investment)
        
        return scores
    
    def assess_growth_potential(self, district_info: Dict[str, Any]) -> str:
        """Assess growth potential of the location."""
        characteristics = district_info.get('characteristics', [])
        
        if "developing" in characteristics:
            return "High - Area under active development"
        elif district_info.get('grade') in ['A+', 'A']:
            return "Stable - Established premium area"
        elif district_info.get('grade') == 'B':
            return "Moderate - Steady appreciation expected"
        else:
            return "Variable - Depends on infrastructure development"
    
    def assess_investment_suitability(self, scores: Dict[str, float]) -> str:
        """Assess investment suitability."""
        avg_score = sum(scores.values()) / len(scores)
        
        if avg_score >= 8:
            return "Excellent - Prime investment location"
        elif avg_score >= 6.5:
            return "Good - Solid investment opportunity"
        elif avg_score >= 5:
            return "Moderate - Consider for long-term investment"
        else:
            return "Limited - Better opportunities may exist elsewhere"
