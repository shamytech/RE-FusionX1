# app/main.py

"""
Main application entry point for RE-FusionX.
Configures and launches the FastAPI application with all components.
"""

import os
import asyncio
from contextlib import asynccontextmanager
from typing import Dict, Any
import uuid
from pathlib import Path
import warnings
from datetime import datetime

from fastapi import FastAPI, Request, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.gzip import GZipMiddleware
from fastapi.middleware.trustedhost import TrustedHostMiddleware
from fastapi.responses import JSONResponse, FileResponse
from fastapi.staticfiles import StaticFiles
import uvicorn
import subprocess
import webbrowser
import sys

from app.api.websocket import handlers
from app.core.config import settings
from app.core.logging import logger, request_id_var, print_startup_banner, console
from app.core.exceptions import REFusionXException
from app.api.v1.endpoints import analysis, chat, properties, health, locations
from app.api.websocket.connection_manager import ConnectionManager
from app.models.llm.model_loader import ModelLoader

# استخدام النظام الجديد للتخزين
from app.core.storage.storage_manager import get_storage_manager
from app.core.storage.session_manager import get_session_manager
from app.core.storage.unified_cache import get_cache
from app.core.storage.integration import StorageIntegration
from dotenv import load_dotenv
load_dotenv()
# Suppress warnings
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'
os.environ['TRANSFORMERS_VERBOSITY'] = 'error'
os.environ['TOKENIZERS_PARALLELISM'] = 'false'
warnings.filterwarnings('ignore')

# Disable tqdm progress bars
import tqdm
tqdm.tqdm.disable = True


# Global instances
model_loader: ModelLoader = None
connection_manager: ConnectionManager = None

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Manage application lifecycle."""
    global model_loader, connection_manager
    
    # Check if model loading should be skipped
    skip_model_loading = os.getenv("SKIP_MODEL_LOADING", "false").lower() == "true"
    
    logger.info("Starting RE-FusionX application...")
    logger.info(f"Model loading: {'DISABLED' if skip_model_loading else 'ENABLED'}")
    
    try:
        # Initialize model loader conditionally
        if skip_model_loading:
            logger.info("⚠️  Skipping model initialization (SKIP_MODEL_LOADING=true)")
            model_loader = None
        else:
            logger.info("🔄 Initializing model loader...")
            model_loader = ModelLoader()
            await model_loader.initialize()
            logger.info("✅ Model loader initialized successfully")
        
        # Initialize storage system using integration
        StorageIntegration.initialize_for_app(app)
        
        # Initialize WebSocket manager
        connection_manager = ConnectionManager()
        app.state.connection_manager = connection_manager
        app.state.model_loader = model_loader
        
        # Verify storage health
        health = StorageIntegration.verify_health()
        logger.info(f"Storage health: {health}")
        
        logger.info("✅ RE-FusionX application started successfully!")
        
        logger.info("")
        logger.info("🌐 Access the application:")
        logger.info("   ⚙️  Backend Interface: http://localhost:8000")
        logger.info("   📘 API Documentation: http://localhost:8000/api/docs")
        
        # ✅ شغّل الفرونت إند src/frontend
        try:
            frontend_path = Path(__file__).parent.parent.parent / "frontend"
            subprocess.Popen(
                ["python", "-m", "http.server", "3000"],
                cwd=frontend_path
            )
            logger.info("   🖥️  Web Interface: http://localhost:3000")
        except Exception as fe:
            logger.warning(f"⚠️ Failed to auto-start frontend server: {fe}")
        
        # ✅ فتح المتصفح تلقائيًا
        try:
            webbrowser.open("http://localhost:3000")
        except:
            pass
        
        
        
        yield
        
    except Exception as e:
        logger.error(f"Failed to start application: {e}", exc_info=True)
        raise
    finally:
        # Cleanup
        logger.info("Shutting down RE-FusionX application...")
        
        # Cleanup storage
        await StorageIntegration.cleanup()
        
        if connection_manager:
            await connection_manager.disconnect_all()
        
        logger.info("RE-FusionX application shut down complete.")
        

def create_application() -> FastAPI:
    """
    Create and configure FastAPI application.
    
    Returns:
        Configured FastAPI application instance
    """
    app = FastAPI(
        title=settings.APP_NAME,
        description=settings.APP_DESCRIPTION,
        version=settings.APP_VERSION,
        lifespan=lifespan,
        docs_url="/api/docs" if settings.DEBUG else None,
        redoc_url="/api/redoc" if settings.DEBUG else None,
        openapi_url="/api/openapi.json" if settings.DEBUG else None
    )
    
    # Configure CORS
    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.CORS_ORIGINS,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )
    
    # Add compression
    app.add_middleware(GZipMiddleware, minimum_size=1000)
    
    # Add trusted host protection
    if not settings.DEBUG:
        app.add_middleware(
            TrustedHostMiddleware,
            allowed_hosts=["*"]  # Configure based on your domain
        )
    
    # Add request ID middleware
    @app.middleware("http")
    async def add_request_id(request: Request, call_next):
        """Add unique request ID to each request."""
        request_id = str(uuid.uuid4())
        request_id_var.set(request_id)
        
        response = await call_next(request)
        response.headers["X-Request-ID"] = request_id
        
        return response
    
    # Add request logging middleware
    @app.middleware("http")
    async def log_requests(request: Request, call_next):
        """Log all incoming requests."""
        logger.info(
            f"Request received",
            extra={
                "method": request.method,
                "path": request.url.path,
                "client": request.client.host if request.client else "unknown"
            }
        )
        
        response = await call_next(request)
        
        logger.info(
            f"Request completed",
            extra={
                "method": request.method,
                "path": request.url.path,
                "status_code": response.status_code
            }
        )
        
        return response
    
    # Global exception handler
    @app.exception_handler(REFusionXException)
    async def custom_exception_handler(request: Request, exc: REFusionXException):
        """Handle custom exceptions."""
        logger.error(
            f"Application exception: {exc.message}",
            extra={"error_code": exc.error_code, "details": exc.details}
        )
        
        return JSONResponse(
            status_code=400,
            content=exc.to_dict()
        )
    
    @app.exception_handler(Exception)
    async def global_exception_handler(request: Request, exc: Exception):
        """Handle unexpected exceptions."""
        logger.error(
            f"Unexpected error: {str(exc)}",
            exc_info=True
        )
        
        return JSONResponse(
            status_code=500,
            content={
                "error": "INTERNAL_SERVER_ERROR",
                "message": "An unexpected error occurred. Please try again later.",
                "details": {"request_id": request_id_var.get()}
            }
        )
    
    # Mount static files
    project_root = Path(__file__).parent.parent.parent.parent
    frontend_js_path = project_root / "frontend" / "js"
    
    if frontend_js_path.exists():
        app.mount(
            "/js",
            StaticFiles(directory=str(frontend_js_path)),
            name="static"
        )
    else:
        logger.warning(f"Frontend JS directory not found at {frontend_js_path}")
    
    # Include API routers
    app.include_router(
        health.router,
        prefix="/api/v1/health",
        tags=["Health"]
    )
    
    app.include_router(
        analysis.router,
        prefix="/api/v1/analysis",
        tags=["Analysis"]
    )
    
    app.include_router(
        chat.router,
        prefix="/api/v1/chat",
        tags=["Chat"]
    )
    
    app.include_router(
        properties.router,
        prefix="/api/v1/properties",
        tags=["Properties"]
    )
    
    app.include_router(
        locations.router,
        prefix="/api/v1/locations",
        tags=["Locations"]
    )
    
    # Root endpoint
    @app.get("/")
    async def root():
        """Root endpoint providing API information."""
        return {
            "name": settings.APP_NAME,
            "version": settings.APP_VERSION,
            "description": settings.APP_DESCRIPTION,
            "status": "operational",
            "documentation": "/api/docs" if settings.DEBUG else None
        }
    
    
    @app.websocket("/ws/{session_id}")
    async def websocket_endpoint(
        websocket: WebSocket,
        session_id: str
    ):
        """WebSocket endpoint for real-time communication."""
        try:
            await websocket.accept()
            
            # Check if model is available
            model_loader = getattr(app.state, 'model_loader', None)
            if model_loader is None:
                logger.warning(f"WebSocket connection {session_id}: Model loader not available")
                await websocket.send_json({
                    "type": "warning",
                    "message": "Model is not loaded. Some features may be limited.",
                    "timestamp": datetime.utcnow().isoformat()
                })
            
            await handlers.websocket_endpoint(
                websocket,
                session_id,
                app.state.connection_manager,
                model_loader
            )
        except WebSocketDisconnect:
            logger.info(f"WebSocket disconnected for session {session_id}")
        except Exception as e:
            logger.error(f"WebSocket error: {e}", exc_info=True)
            try:
                await websocket.close(code=1011, reason="Internal server error")
            except:
                pass
    
    return app


# Create application instance
app = create_application()


if __name__ == "__main__":
    """Run the application directly."""
    if settings.DEBUG:
        print_startup_banner()
    
    uvicorn.run(
        "app.main:app",
        host=settings.HOST,
        port=settings.PORT,
        reload=settings.DEBUG,
        workers=1 if settings.DEBUG else settings.WORKERS,
        log_level=settings.LOG_LEVEL.lower()
    )
