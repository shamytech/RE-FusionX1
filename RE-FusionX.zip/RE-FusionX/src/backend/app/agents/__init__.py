# app/agents/__init__.py
"""
Agents module - New Architecture Only
Exports all available agents for the system
"""

from app.core.logging import logger
from app.core.conversation.conversation_manager import get_conversation_manager

# New Architecture Agents
try:
    from app.agents.base_agent import BaseAgent, DataAgent, ProcessingAgent, AgentType
    logger.info("✅ Base agents loaded")
except ImportError as e:
    logger.warning(f"Base agents not available: {e}")

try:
    from app.agents.orchestrator import AgentOrchestrator
    logger.info("✅ AgentOrchestrator loaded")
except ImportError as e:
    logger.warning(f"AgentOrchestrator not available: {e}")

# Processing Agents
try:
    from app.agents.unified_conversation_agent import UnifiedConversationAgent
    logger.info("✅ UnifiedConversationAgent loaded")
except ImportError as e:
    logger.warning(f"UnifiedConversationAgent not available: {e}")

try:
    from app.agents.response_formatter_agent import ResponseFormatterAgent
    logger.info("✅ ResponseFormatterAgent loaded")
except ImportError as e:
    logger.warning(f"ResponseFormatterAgent not available: {e}")

# Data Agents
try:
    from app.agents.property_data_agent import PropertyDataAgent
    logger.info("✅ PropertyDataAgent loaded")
except ImportError as e:
    logger.warning(f"PropertyDataAgent not available: {e}")

try:
    from app.agents.market_data_agent import MarketDataAgent
    logger.info("✅ MarketDataAgent loaded")
except ImportError as e:
    logger.warning(f"MarketDataAgent not available: {e}")

try:
    from app.agents.location_data_agent import LocationDataAgent
    logger.info("✅ LocationDataAgent loaded")
except ImportError as e:
    logger.warning(f"LocationDataAgent not available: {e}")

try:
    from app.agents.market_comparison_agent import MarketComparisonDataAgent
    logger.info("✅ MarketComparisonDataAgent loaded")
except ImportError as e:
    logger.warning(f"MarketComparisonDataAgent not available: {e}")

# Export all available agents
__all__ = [
    # Base classes
    'BaseAgent',
    'DataAgent', 
    'ProcessingAgent',
    'AgentType',
    
    # Orchestrator
    'AgentOrchestrator',
    
    # Processing Agents
    'IntentExtractorAgent',
    'ResponseFormatterAgent',
    
    # Data Agents
    'PropertyDataAgent',
    'MarketDataAgent',
    'LocationDataAgent',
    'MarketComparisonDataAgent'
]

logger.info(f"📦 Agents module loaded with {len(__all__)} exports")
