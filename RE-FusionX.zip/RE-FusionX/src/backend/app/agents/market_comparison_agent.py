# app/agents/market_comparison_data_agent.py
"""
Market Comparison Data Agent - Data + Useful Calculations
يجلب البيانات ويجري حسابات مفيدة لكن لا يحلل أو يوصي
الغرض: جلب بيانات المقارنة وحساب المقاييس الإحصائية
المدخلات: بيانات العقار المستهدف للمقارنة
المخرجات: إحصائيات مقارنة دقيقة بدون تحليل

مصادر البيانات:
  - PostgreSQL: عقارات المنطقة
  - Market Analysis Table: تحليلات جاهزة
  - Cache: نتائج سابقة

الحسابات:
  1. درجة التشابه (Similarity Score)
  2. الإحصائيات الوصفية (mean, median, std dev, quartiles)
  3. Z-Score والترتيب المئوي
  4. توزيع الأسعار بالفئات
  5. مقاييس العقارات المشابهة

"""

from typing import Dict, Any, List, Optional
from datetime import datetime
import statistics

from app.agents.base_agent import DataAgent
from app.core.logging import agent_logger, logger
from app.core.storage.integration import StorageIntegration
from app.core.storage.unified_cache import CacheType


class MarketComparisonDataAgent(DataAgent):
    """
    Market Comparison Data Agent
    يجلب البيانات ويجري حسابات إحصائية مفيدة
    لكن لا يقدم تحليلات أو توصيات - هذا دور Qwen
    """
    
    def __init__(self, model_loader=None):
        super().__init__(
            name="MarketComparisonDataAgent",
            description="Fetches comparison data and performs statistical calculations",
            capabilities=[
                "Fetch similar properties",
                "Calculate price statistics",
                "Compute price differences",
                "Generate comparison metrics"
            ],
            data_sources=["storage", "cache", "scrapers"]
        )
        
        self.model_loader = model_loader
        self._storage = None
        self._cache = None
        
        agent_logger.agent_start(self.name, "Market comparison data agent initialized")
    
    @property
    def storage(self):
        """Lazy load storage"""
        if self._storage is None:
            self._storage = StorageIntegration.get_storage()
        return self._storage
    
    @property
    def cache(self):
        """Lazy load cache"""
        if self._cache is None:
            self._cache = StorageIntegration.get_cache()
        return self._cache
    
    async def validate_input(self, input_data: Dict[str, Any]) -> bool:
        """التحقق من وجود بيانات العقار المطلوبة"""
        property_data = input_data.get("property_data", {})
        
        has_location = bool(
            property_data.get("location") or 
            property_data.get("city") or 
            property_data.get("district")
        )
        
        if not has_location:
            agent_logger.warning(self.name, "No location provided for comparison")
        
        return has_location
    
    async def fetch_data(
        self,
        criteria: Dict[str, Any],
        context: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        جلب البيانات وإجراء الحسابات المفيدة
        
        Returns:
            البيانات مع الحسابات الإحصائية (بدون تحليل أو توصيات)
        """
        property_data = criteria.get("property_data", {})
        comparison_type = criteria.get("comparison_type", "full")
        limit = criteria.get("limit", 20)
        
        agent_logger.agent_action(self.name, "Fetching and calculating comparison data", {
            "comparison_type": comparison_type,
            "limit": limit
        })
        
        result = {}
        
        # 1. جلب العقارات المشابهة
        similar_properties = await self._fetch_similar_properties(property_data, limit)
        result["similar_properties"] = similar_properties
        result["similar_count"] = len(similar_properties)
        
        # 2. جلب وحساب إحصائيات الأسعار
        area_stats = await self._fetch_and_calculate_area_statistics(property_data)
        result["area_statistics"] = area_stats
        
        # 3. حساب مقاييس المقارنة
        if property_data.get("price"):
            result["price_comparison"] = self._calculate_price_comparison(
                property_data.get("price"),
                area_stats
            )
        
        # 4. حساب توزيع الأسعار
        result["price_distribution"] = self._calculate_price_distribution(
            area_stats.get("all_prices", [])
        )
        
        # 5. حساب مقاييس العقارات المشابهة
        if similar_properties:
            result["similar_properties_metrics"] = self._calculate_similar_metrics(
                similar_properties
            )
        
        # 6. إضافة metadata
        result["metadata"] = {
            "fetch_timestamp": datetime.utcnow().isoformat(),
            "location": self._extract_location(property_data),
            "property_type": property_data.get("property_type"),
            "target_property": {
                "size": property_data.get("size"),
                "rooms": property_data.get("rooms"),
                "age": property_data.get("building_age"),
                "price": property_data.get("price")
            },
            "data_completeness": self._calculate_completeness(result)
        }
        
        agent_logger.agent_result(self.name, {
            "metrics_calculated": list(result.keys()),
            "similar_found": result.get("similar_count", 0)
        }, success=True)
        
        return result
    
    async def _fetch_similar_properties(
        self, 
        property_data: Dict[str, Any], 
        limit: int
    ) -> List[Dict[str, Any]]:
        """جلب العقارات المشابهة مع حساب التشابه"""
        
        location = self._extract_location(property_data)
        
        filters = {
            "property_type": property_data.get("property_type"),
            "limit": limit * 2
        }
        
        # إضافة نطاقات للبحث
        if property_data.get("size"):
            size = float(property_data["size"])
            filters["min_size"] = size * 0.7
            filters["max_size"] = size * 1.3
        
        if property_data.get("rooms"):
            filters["rooms"] = property_data["rooms"]
        
        # جلب من Storage
        properties = await self.storage.get_properties(
            location=location,
            filters=filters
        )
        
        # حساب درجة التشابه لكل عقار
        similar = []
        for prop in properties[:limit]:
            similarity_score = self._calculate_similarity_score(property_data, prop)
            
            similar.append({
                "property_id": prop.get("property_id", prop.get("listing_id")),
                "location": prop.get("location"),
                "city": prop.get("city"),
                "district": prop.get("district"),
                "price": prop.get("price"),
                "size": prop.get("size"),
                "rooms": prop.get("rooms"),
                "building_age": prop.get("building_age"),
                "floor": prop.get("floor"),
                "property_type": prop.get("property_type"),
                "price_per_sqm": prop.get("price") / prop.get("size") if prop.get("size", 0) > 0 else 0,
                "similarity_score": similarity_score,
                "url": prop.get("url"),
                "source": prop.get("source", "storage")
            })
        
        # ترتيب حسب درجة التشابه
        similar.sort(key=lambda x: x["similarity_score"], reverse=True)
        
        return similar
    
    async def _fetch_and_calculate_area_statistics(
        self, 
        property_data: Dict[str, Any]
    ) -> Dict[str, Any]:
        """جلب وحساب إحصائيات المنطقة"""
        
        location = self._extract_location(property_data)
        
        # جلب عقارات المنطقة
        area_properties = await self.storage.get_properties(
            location=location,
            filters={
                "property_type": property_data.get("property_type"),
                "limit": 200  # عينة أكبر للإحصائيات
            }
        )
        
        # استخراج البيانات
        prices = []
        sizes = []
        prices_per_sqm = []
        ages = []
        
        for prop in area_properties:
            price = prop.get("price")
            size = prop.get("size")
            age = prop.get("building_age")
            
            if price:
                prices.append(price)
            if size:
                sizes.append(size)
            if price and size and size > 0:
                prices_per_sqm.append(price / size)
            if age is not None:
                ages.append(age)
        
        # حساب الإحصائيات
        stats = {
            "all_prices": prices,  # البيانات الخام للنموذج
            "all_sizes": sizes,
            "sample_count": len(area_properties),
            "location": location
        }
        
        # إحصائيات الأسعار
        if prices:
            stats["price_statistics"] = {
                "mean": statistics.mean(prices),
                "median": statistics.median(prices),
                "min": min(prices),
                "max": max(prices),
                "std_dev": statistics.stdev(prices) if len(prices) > 1 else 0,
                "variance": statistics.variance(prices) if len(prices) > 1 else 0,
                "q1": statistics.quantiles(prices, n=4)[0] if len(prices) > 3 else min(prices),
                "q3": statistics.quantiles(prices, n=4)[2] if len(prices) > 3 else max(prices),
                "iqr": 0  # سيتم حسابه
            }
            stats["price_statistics"]["iqr"] = stats["price_statistics"]["q3"] - stats["price_statistics"]["q1"]
        
        # إحصائيات الأحجام
        if sizes:
            stats["size_statistics"] = {
                "mean": statistics.mean(sizes),
                "median": statistics.median(sizes),
                "min": min(sizes),
                "max": max(sizes),
                "std_dev": statistics.stdev(sizes) if len(sizes) > 1 else 0
            }
        
        # إحصائيات السعر لكل متر مربع
        if prices_per_sqm:
            stats["price_per_sqm_statistics"] = {
                "mean": statistics.mean(prices_per_sqm),
                "median": statistics.median(prices_per_sqm),
                "min": min(prices_per_sqm),
                "max": max(prices_per_sqm),
                "std_dev": statistics.stdev(prices_per_sqm) if len(prices_per_sqm) > 1 else 0
            }
        
        # إحصائيات الأعمار
        if ages:
            stats["age_statistics"] = {
                "mean": statistics.mean(ages),
                "median": statistics.median(ages),
                "min": min(ages),
                "max": max(ages)
            }
        
        return stats
    
    def _calculate_price_comparison(
        self,
        target_price: float,
        area_stats: Dict[str, Any]
    ) -> Dict[str, Any]:
        """حساب مقاييس مقارنة السعر"""
        
        price_stats = area_stats.get("price_statistics", {})
        
        if not price_stats:
            return {"status": "no_data"}
        
        mean_price = price_stats.get("mean", 0)
        median_price = price_stats.get("median", 0)
        std_dev = price_stats.get("std_dev", 0)
        
        comparison = {
            "target_price": target_price,
            "difference_from_mean": target_price - mean_price if mean_price else 0,
            "difference_from_median": target_price - median_price if median_price else 0,
            "percentage_from_mean": ((target_price - mean_price) / mean_price * 100) if mean_price else 0,
            "percentage_from_median": ((target_price - median_price) / median_price * 100) if median_price else 0,
            "z_score": ((target_price - mean_price) / std_dev) if std_dev else 0,
            "percentile_rank": self._calculate_percentile_rank(target_price, area_stats.get("all_prices", []))
        }
        
        return comparison
    
    def _calculate_price_distribution(self, prices: List[float]) -> Dict[str, Any]:
        """حساب توزيع الأسعار"""
        
        if not prices:
            return {"status": "no_data"}
        
        # تحديد الفئات
        ranges = [
            (0, 2000000, "0-2M"),
            (2000000, 4000000, "2M-4M"),
            (4000000, 6000000, "4M-6M"),
            (6000000, 8000000, "6M-8M"),
            (8000000, 10000000, "8M-10M"),
            (10000000, float('inf'), "10M+")
        ]
        
        distribution = {}
        for min_val, max_val, label in ranges:
            count = sum(1 for p in prices if min_val <= p < max_val)
            percentage = (count / len(prices)) * 100 if prices else 0
            distribution[label] = {
                "count": count,
                "percentage": round(percentage, 2)
            }
        
        return distribution
    
    def _calculate_similar_metrics(self, similar_properties: List[Dict[str, Any]]) -> Dict[str, Any]:
        """حساب مقاييس العقارات المشابهة"""
        
        if not similar_properties:
            return {"status": "no_similar"}
        
        prices = [p["price"] for p in similar_properties if p.get("price")]
        sizes = [p["size"] for p in similar_properties if p.get("size")]
        ages = [p["building_age"] for p in similar_properties if p.get("building_age") is not None]
        
        metrics = {
            "count": len(similar_properties),
            "average_similarity_score": statistics.mean([p.get("similarity_score", 0) for p in similar_properties])
        }
        
        if prices:
            metrics["price_range"] = {
                "min": min(prices),
                "max": max(prices),
                "mean": statistics.mean(prices),
                "median": statistics.median(prices)
            }
        
        if sizes:
            metrics["size_range"] = {
                "min": min(sizes),
                "max": max(sizes),
                "mean": statistics.mean(sizes)
            }
        
        if ages:
            metrics["age_range"] = {
                "min": min(ages),
                "max": max(ages),
                "mean": statistics.mean(ages)
            }
        
        return metrics
    
    def _calculate_similarity_score(self, prop1: Dict, prop2: Dict) -> float:
        """حساب درجة التشابه بين عقارين"""
        
        score = 0.0
        weights = {
            "size": 0.3,
            "rooms": 0.25,
            "age": 0.2,
            "type": 0.15,
            "location": 0.1
        }
        
        # التشابه في الحجم
        if prop1.get("size") and prop2.get("size"):
            size_diff_ratio = abs(prop1["size"] - prop2["size"]) / max(prop1["size"], prop2["size"])
            score += (1 - size_diff_ratio) * weights["size"]
        
        # التشابه في الغرف
        if prop1.get("rooms") == prop2.get("rooms"):
            score += weights["rooms"]
        
        # التشابه في العمر
        if prop1.get("building_age") is not None and prop2.get("building_age") is not None:
            age_diff = abs(prop1["building_age"] - prop2["building_age"])
            if age_diff <= 2:
                score += weights["age"]
            elif age_diff <= 5:
                score += weights["age"] * 0.5
        
        # التشابه في النوع
        if prop1.get("property_type") == prop2.get("property_type"):
            score += weights["type"]
        
        # التشابه في الموقع
        if prop1.get("district") == prop2.get("district"):
            score += weights["location"]
        
        return min(1.0, score)
    
    def _calculate_percentile_rank(self, value: float, data: List[float]) -> float:
        """حساب الترتيب المئوي"""
        if not data:
            return 0
        
        count_below = sum(1 for x in data if x < value)
        count_equal = sum(1 for x in data if x == value)
        
        percentile = ((count_below + 0.5 * count_equal) / len(data)) * 100
        return round(percentile, 2)
    
    def _extract_location(self, property_data: Dict[str, Any]) -> str:
        """استخراج الموقع من بيانات العقار"""
        if property_data.get("location"):
            return property_data["location"]
        
        city = property_data.get("city", "")
        district = property_data.get("district", "")
        
        if city and district:
            return f"{city} - {district}"
        elif city:
            return city
        elif district:
            return district
        
        return "Istanbul"
    
    def _calculate_completeness(self, data: Dict[str, Any]) -> float:
        """حساب اكتمال البيانات"""
        total_fields = 0
        filled_fields = 0
        
        important_fields = [
            "similar_properties",
            "area_statistics",
            "price_comparison",
            "price_distribution",
            "similar_properties_metrics"
        ]
        
        for field in important_fields:
            total_fields += 1
            if field in data and data[field]:
                if isinstance(data[field], dict):
                    if data[field].get("status") != "no_data":
                        filled_fields += 1
                elif isinstance(data[field], list):
                    if data[field]:
                        filled_fields += 1
                else:
                    filled_fields += 1
        
        return filled_fields / total_fields if total_fields > 0 else 0

'''
الغرض: جلب بيانات المقارنة وحساب المقاييس الإحصائية
المدخلات: بيانات العقار المستهدف للمقارنة
المخرجات: إحصائيات مقارنة دقيقة بدون تحليل

مصادر البيانات:
  - PostgreSQL: عقارات المنطقة
  - Market Analysis Table: تحليلات جاهزة
  - Cache: نتائج سابقة

الحسابات:
  1. درجة التشابه (Similarity Score)
  2. الإحصائيات الوصفية (mean, median, std dev, quartiles)
  3. Z-Score والترتيب المئوي
  4. توزيع الأسعار بالفئات
  5. مقاييس العقارات المشابهة


# المدخل
{
  "property_data": {
    "location": "Istanbul - Kadıköy",
    "size": 150,
    "rooms": "3+1",
    "building_age": 5,
    "price": 5500000  # السعر المستهدف للمقارنة
  },
  "comparison_type": "full",
  "limit": 20
}

# المخرج
{
  "similar_properties": [
    // 20 عقار مع درجات التشابه
  ],
  "similar_count": 20,
  "area_statistics": {
    "all_prices": [4500000, 4800000, 5100000, ...],  # البيانات الخام
    "all_sizes": [140, 145, 150, ...],
    "sample_count": 87,
    "location": "Istanbul - Kadıköy",
    "price_statistics": {
      "mean": 5125000,
      "median": 5050000,
      "min": 4200000,
      "max": 6500000,
      "std_dev": 485000,
      "variance": 235225000000,
      "q1": 4750000,  # الربع الأول
      "q3": 5450000,  # الربع الثالث
      "iqr": 700000   # المدى الربعي
    },
    "size_statistics": {
      "mean": 148,
      "median": 150,
      "min": 120,
      "max": 180,
      "std_dev": 12.5
    },
    "price_per_sqm_statistics": {
      "mean": 34662,
      "median": 34500,
      "min": 30000,
      "max": 40000,
      "std_dev": 2150
    },
    "age_statistics": {
      "mean": 6.2,
      "median": 5,
      "min": 0,
      "max": 25
    }
  },
  "price_comparison": {
    "target_price": 5500000,
    "difference_from_mean": 375000,
    "difference_from_median": 450000,
    "percentage_from_mean": 7.32,
    "percentage_from_median": 8.91,
    "z_score": 0.77,  # (5500000-5125000)/485000
    "percentile_rank": 72.5  # أعلى من 72.5% من العقارات
  },
  "price_distribution": {
    "0-2M": {"count": 0, "percentage": 0},
    "2M-4M": {"count": 3, "percentage": 3.45},
    "4M-6M": {"count": 71, "percentage": 81.61},
    "6M-8M": {"count": 13, "percentage": 14.94},
    "8M-10M": {"count": 0, "percentage": 0},
    "10M+": {"count": 0, "percentage": 0}
  },
  "similar_properties_metrics": {
    "count": 20,
    "average_similarity_score": 0.78,
    "price_range": {
      "min": 4600000,
      "max": 5800000,
      "mean": 5150000,
      "median": 5100000
    },
    "size_range": {
      "min": 135,
      "max": 165,
      "mean": 149
    },
    "age_range": {
      "min": 2,
      "max": 8,
      "mean": 5.1
    }
  },
  "metadata": {
    "fetch_timestamp": "2024-01-15T10:31:00Z",
    "location": "Istanbul - Kadıköy",
    "property_type": "Apartment",
    "target_property": {
      "size": 150,
      "rooms": "3+1",
      "age": 5,
      "price": 5500000
    },
    "data_completeness": 0.95
  }
}

'''