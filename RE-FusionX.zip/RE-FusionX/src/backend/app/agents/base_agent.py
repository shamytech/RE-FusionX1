# D:\Phd\RE-FusionX\src\backend\app\agents\base_agent.py
"""
Base Agent for RE-FusionX System - Updated with DataAgent
Unified base for all agents with data/processing separation
"""

from abc import ABC, abstractmethod
from typing import Dict, Any, List, Optional
from datetime import datetime
from enum import Enum

from app.core.logging import logger, agent_logger


class AgentType(Enum):
    """Agent types in the system"""
    CONVERSATION = "conversation"      # General chat
    PROPERTY = "property"              # Property analysis
    MARKET = "market"                  # Market analysis
    LOCATION = "location"              # Location analysis
    XGBOOST = "xgboost"               # ML model
    VISUAL = "visual"                  # Image analysis
    ECONOMIC = "economic"              # Economic indicators
    NEWS = "news"                      # Market news
    INTENT = "intent"                  # Intent extraction
    DATA = "data"                      # Data fetching


class BaseAgent(ABC):
    """
    Base agent - all agents inherit from this class
    """
    
    def __init__(
        self, 
        name: str, 
        agent_type: AgentType,
        description: str,
        capabilities: List[str] = None
    ):
        """
        Initialize base agent
        
        Args:
            name: Agent name
            agent_type: Agent type
            description: Agent description
            capabilities: Agent capabilities
        """
        self.name = name
        self.agent_type = agent_type
        self.description = description
        self.capabilities = capabilities or []
        self.tools = {}
        self.status = "idle"
        self.metrics = {
            "requests_processed": 0,
            "success_rate": 0,
            "average_response_time": 0
        }
    
    @abstractmethod
    async def validate_input(self, input_data: Dict[str, Any]) -> bool:
        """
        Validate input data
        Each agent defines what data it needs
        """
        pass
    
    @abstractmethod
    async def process(
        self,
        input_data: Dict[str, Any],
        context: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Process request - main agent task
        """
        pass
    
    def register_tool(self, name: str, tool: Any):
        """Register tool for agent"""
        self.tools[name] = tool
        logger.debug(f"Tool {name} registered for agent {self.name}")
    
    async def execute_tool(self, tool_name: str, **kwargs) -> Dict[str, Any]:
        """Execute registered tool"""
        if tool_name not in self.tools:
            logger.error(f"Tool {tool_name} not found for agent {self.name}")
            return {"error": f"Tool {tool_name} not found"}
        
        try:
            tool = self.tools[tool_name]
            result = await tool.execute(**kwargs)
            return result
        except Exception as e:
            logger.error(f"Tool {tool_name} execution failed: {e}")
            return {"error": str(e)}
    
    def format_response(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Format final response"""
        return {
            "agent": self.name,
            "agent_type": self.agent_type.value,
            "result": data,
            "timestamp": datetime.utcnow().isoformat(),
            "status": self.status,
            "capabilities": self.capabilities
        }
    
    def set_status(self, status: str):
        """Update agent status"""
        self.status = status
        logger.debug(f"Agent {self.name} status: {status}")
    
    def get_info(self) -> Dict[str, Any]:
        """Agent information"""
        return {
            "name": self.name,
            "type": self.agent_type.value,
            "description": self.description,
            "capabilities": self.capabilities,
            "tools": list(self.tools.keys()),
            "status": self.status,
            "metrics": self.metrics
        }


class DataAgent(BaseAgent):
    """
    Data Agent - Base class for agents that fetch and return data only
    These agents DO NOT generate responses, only structured data
    """
    
    def __init__(
        self,
        name: str,
        description: str,
        capabilities: List[str] = None,
        data_sources: List[str] = None
    ):
        """
        Initialize data agent
        
        Args:
            name: Agent name
            description: Agent description
            capabilities: Agent capabilities
            data_sources: Data sources this agent uses
        """
        super().__init__(
            name=name,
            agent_type=AgentType.DATA,
            description=description,
            capabilities=capabilities
        )
        
        self.data_sources = data_sources or []
        
        agent_logger.agent_start(name, "DataAgent initialized", {
            "data_sources": len(self.data_sources)
        })
    
    def format_data_response(
        self,
        data: Dict[str, Any],
        source: str = "unknown",
        confidence: float = 1.0
    ) -> Dict[str, Any]:
        """
        Format data response consistently
        
        Args:
            data: The actual data
            source: Data source
            confidence: Confidence level (0-1)
            
        Returns:
            Formatted data response
        """
        return {
            "data": data,
            "source": source,
            "confidence": confidence,
            "data_timestamp": datetime.utcnow().isoformat(),
            "agent": self.name,
            "type": "data_only"
        }
    
    def validate_data_quality(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Validate data quality and completeness
        
        Args:
            data: Data to validate
            
        Returns:
            Validation result with quality score
        """
        quality_score = 1.0
        missing_fields = []
        issues = []
        
        # Check for None or empty values
        for key, value in data.items():
            if value is None:
                missing_fields.append(key)
                quality_score -= 0.1
            elif isinstance(value, str) and not value.strip():
                missing_fields.append(key)
                quality_score -= 0.05
            elif isinstance(value, (list, dict)) and not value:
                issues.append(f"Empty {key}")
                quality_score -= 0.05
        
        quality_score = max(0, quality_score)
        
        return {
            "quality_score": quality_score,
            "is_complete": len(missing_fields) == 0,
            "missing_fields": missing_fields,
            "issues": issues
        }
    
    @abstractmethod
    async def fetch_data(
        self,
        criteria: Dict[str, Any],
        context: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Fetch data based on criteria
        Must be implemented by each data agent
        
        Args:
            criteria: Search/fetch criteria
            context: Optional context
            
        Returns:
            Fetched data
        """
        pass
    
    async def process(
        self,
        input_data: Dict[str, Any],
        context: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Process request - fetch and return data only
        
        Args:
            input_data: Input data with criteria
            context: Optional context
            
        Returns:
            Data-only response
        """
        try:
            agent_logger.agent_action(self.name, "Fetching data", {
                "criteria": list(input_data.keys())
            })
            
            # Fetch data
            data = await self.fetch_data(input_data, context)
            
            # Validate quality
            quality = self.validate_data_quality(data)
            
            # Format response
            response = self.format_data_response(
                data=data,
                source=self.data_sources[0] if self.data_sources else "internal",
                confidence=quality["quality_score"]
            )
            
            agent_logger.agent_result(self.name, {
                "data_points": len(data),
                "quality_score": quality["quality_score"]
            }, success=True)
            
            return self.format_response(response)
            
        except Exception as e:
            error_msg = f"Data fetch failed: {str(e)}"
            agent_logger.error(self.name, error_msg)
            
            return self.format_response({
                "error": error_msg,
                "data": {},
                "type": "data_error"
            })


class ProcessingAgent(BaseAgent):
    """
    Processing Agent - Base class for agents that process and transform data
    These agents can generate responses but primarily process information
    """
    
    def __init__(
        self,
        name: str,
        agent_type: AgentType,
        description: str,
        capabilities: List[str] = None
    ):
        """
        Initialize processing agent
        """
        super().__init__(
            name=name,
            agent_type=agent_type,
            description=description,
            capabilities=capabilities
        )
        
        agent_logger.agent_start(name, "ProcessingAgent initialized", {
            "type": agent_type.value
        })
    
    @abstractmethod
    async def transform_data(
        self,
        data: Dict[str, Any],
        transformation_type: str = "default"
    ) -> Dict[str, Any]:
        """
        Transform data according to agent's purpose
        
        Args:
            data: Input data
            transformation_type: Type of transformation
            
        Returns:
            Transformed data
        """
        pass
