# app/agents/response_formatter_agent.py
"""
Response Formatter Agent - Formats final responses using Qwen
Takes collected data from all agents and generates user-friendly responses

الغرض: تنسيق الرد النهائي باستخدام Qwen
المدخلات: البيانات المجمعة من جميع الوكلاء
المخرجات: رد منسق وودود للمستخدم

العملية:
1. استقبال البيانات من جميع الوكلاء
2. إنشاء prompt لـ Qwen
3. توليد الرد النهائي
4. تنسيق الرد حسب اللغة
"""

from typing import Dict, Any, List, Optional
from datetime import datetime
import json

from app.agents.base_agent import ProcessingAgent, AgentType
from app.core.logging import agent_logger, logger
from app.core.constants import SystemInfo
from app.agents.smart_response_generator import SmartResponseGenerator


class ResponseFormatterAgent(ProcessingAgent):
    """
    Response Formatter Agent - يولد الردود النهائية باستخدام Qwen
    يأخذ البيانات من جميع الوكلاء ويحولها لرد مفهوم للمستخدم
    """
    
    def __init__(self, model_loader=None):
        """Initialize Response Formatter Agent"""
        super().__init__(
            name="ResponseFormatterAgent",
            agent_type=AgentType.CONVERSATION,
            description="Formats final responses using Qwen model",
            capabilities=[
                "Generate natural language responses",
                "Format data into user-friendly text",
                "Multi-language support (EN/TR/AR)",
                "Context-aware response generation",
                "Professional real estate terminology"
            ]
        )
        
        self.model_loader = model_loader
        self.smart_generator = SmartResponseGenerator(model_loader)
        agent_logger.agent_start(self.name, "Response formatter initialized", {
            "has_model": bool(model_loader)
        })
    
    async def validate_input(self, input_data: Dict[str, Any]) -> bool:
        """Validate input has required data"""
        has_data = bool(input_data.get("agent_data") or input_data.get("data"))
        has_query = bool(input_data.get("user_query") or input_data.get("message"))
        
        is_valid = has_data or has_query
        
        if not is_valid:
            agent_logger.warning(self.name, "Invalid input - no data or query provided")
        
        return is_valid
    
    async def transform_data(self, data: Dict[str, Any], transformation_type: str = "format") -> Dict[str, Any]:
        """Keep data as is for Qwen to analyze"""
        return data
    
    async def generate_smart_info_request(
        self,
        message_type: str,
        intent: str,
        completeness: Dict[str, Any],
        entities: Dict[str, Any],
        conversation_history: List[Dict] = None,
        language: str = "en"
    ) -> str:
        """
        توليد طلب معلومات ذكي ومتكيف باستخدام SmartResponseGenerator
        
        Args:
            message_type: نوع الرسالة
            intent: النية المستخرجة  
            completeness: معلومات الاكتمال
            entities: الكيانات المستخرجة
            conversation_history: تاريخ المحادثة
            language: اللغة
            
        Returns:
            رد ذكي ومتكيف
        """
        
        try:
            agent_logger.info("ResponseFormatterAgent", f"🧠 Generating smart info request", {
                "message_type": message_type,
                "intent": intent,
                "completion_pct": completeness.get("completion_percentage", 0),
                "entities_count": len(entities) if entities else 0
            })
            
            # استخدام المولد الذكي
            smart_response = await self.smart_generator.generate_context_aware_response(
                message_type=message_type,
                intent=intent,
                completeness=completeness,
                entities=entities,
                conversation_history=conversation_history,
                language=language
            )
            
            agent_logger.info("ResponseFormatterAgent", f"✅ Smart response generated", {
                "response_length": len(smart_response),
                "has_system_signature": SystemInfo.NAME in smart_response
            })
            
            return smart_response
            
        except Exception as e:
            agent_logger.error("ResponseFormatterAgent", f"❌ Smart response generation failed: {e}")
            
            # Fallback للطريقة القديمة
            return self._generate_fallback_info_request(completeness, entities, language)
    
    async def process(self, input_data: Dict[str, Any], context: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Process and format the final response using Qwen
        """
        try:
            # معالجة خاصة لأسئلة التحليل المحفوظ
            if input_data.get("context_type") == "analysis_question":
                prompt = input_data.get("prompt", "")
                
                # استخدام Qwen للإجابة
                if self.model_loader:
                    qwen_response = await self._generate_qwen_response(
                        prompt,
                        context
                    )
                    
                    if qwen_response:
                        return self.format_response({
                            "response": qwen_response,
                            "type": "analysis_answer"
                        })
                
                # Fallback
                return self.format_response({
                    "response": "Please provide more details about your question.",
                    "type": "fallback"
                })
            
            # Validate input
            if not await self.validate_input(input_data):
                return self.format_response({
                    "response": "I need more information to help you with your request.",
                    "type": "error"
                })
            
            # Extract components
            agent_data = input_data.get("agent_data", input_data.get("data", {}))
            user_query = input_data.get("user_query", input_data.get("message", ""))
            intent = input_data.get("intent", "general_inquiry")
            language = input_data.get("language", "en")
            
            agent_logger.agent_action(self.name, "Formatting response", {
                "intent": intent,
                "language": language,
                "data_sources": list(agent_data.keys()) if isinstance(agent_data, dict) else []
            })
            
            # Generate response with Qwen
            if self.model_loader:
                response_text = await self._generate_with_qwen(
                    user_query,
                    agent_data,  # Pass raw data
                    intent,
                    language,
                    context
                )
            else:
                # Simple fallback if no model
                response_text = self._generate_fallback_response(agent_data, intent, language)
            
            # Format final response
            result = {
                "response": response_text,
                "intent": intent,
                "language": language,
                "data_sources": list(agent_data.keys()) if isinstance(agent_data, dict) else [],
                "formatted_at": datetime.utcnow().isoformat()
            }
            
            agent_logger.agent_result(self.name, {
                "response_length": len(response_text),
                "method": "qwen" if self.model_loader else "fallback"
            }, success=True)
            
            return self.format_response(result)
            
        except Exception as e:
            error_msg = f"Response formatting failed: {str(e)}"
            agent_logger.error(self.name, error_msg)
            
            return self.format_response({
                "response": "I apologize, but I encountered an error while formatting the response. Please try again.",
                "error": error_msg,
                "type": "error"
            })
    
    async def _generate_with_qwen(
        self, 
        user_query: str, 
        data: Dict[str, Any], 
        intent: str, 
        language: str, 
        context: Optional[Dict[str, Any]] = None
    ) -> str:
        """
        Generate response using Qwen model - LET QWEN DO ALL THE WORK
        """
        try:
            # Create comprehensive prompt
            prompt = self._create_smart_prompt(user_query, data, intent, language)
            
            # Get model
            model = await self.model_loader.get_model()
            
            # Generate response
            response = await model.generate(
                prompt,
                max_tokens=1024,
                temperature=0.7
            )
            
            # Clean response
            if isinstance(response, dict):
                response = response.get("response", str(response))
            
            return str(response).strip()
            
        except Exception as e:
            agent_logger.error(self.name, f"Qwen generation failed: {e}")
            # Fallback to simple response
            return self._generate_fallback_response(data, intent, language)
    
    def _create_smart_prompt(self, user_query: str, data: Dict[str, Any], intent: str, language: str) -> str:
        """
        Create a smart prompt that lets Qwen analyze everything
        Enhanced with completeness and follow-up awareness
        """
        # Language instruction - الكود الموجود
        lang_instruction = {
            "en": "Respond in English",
            "tr": "Türkçe olarak yanıtla",
            "ar": "أجب باللغة العربية"
        }.get(language, "Respond in English")
        
        # إضافة جديدة: استخراج معلومات الاكتمال والمتابعة
        completeness_info = ""
        if "completeness" in data:
            comp = data["completeness"]
            if isinstance(comp, dict):
                if not comp.get("is_complete", False):
                    missing = comp.get("missing_fields", [])
                    suggestions = comp.get("suggestions", [])
                    completeness_info = f"""
    INFORMATION COMPLETENESS:
    - Completion: {comp.get('completion_percentage', 0):.1f}%
    - Missing fields: {', '.join(missing) if missing else 'None'}
    - Ready for analysis: {comp.get('is_complete', False)}

    IMPORTANT: Since information is incomplete:
    1. Work with available data
    2. Provide ranges instead of exact values where needed
    3. Mention what additional info would improve accuracy
    4. Be helpful and constructive
    5. If user said they can't provide more info, respect that
    """
        
        follow_up_info = ""
        if data.get("is_follow_up"):
            follow_up_info = """
    CONTEXT AWARENESS:
    - This is a FOLLOW-UP message in an ongoing conversation
    - User may be referring to previously discussed information
    - Don't repeat everything from the beginning
    - Address the specific point raised
    - Maintain conversational continuity
    """
        
        # إضافة جديدة: معلومات السياق إذا كانت متوفرة
        context_info = ""
        if "context" in data and isinstance(data["context"], dict):
            if data["context"].get("previous_analysis"):
                context_info = """
    PREVIOUS ANALYSIS CONTEXT:
    - Previous analysis is available in the conversation
    - User is continuing from that analysis
    - Build upon previous insights
    """
        
        # Convert data to clean JSON for Qwen - الكود الموجود
        data_json = json.dumps(data, indent=2, ensure_ascii=False, default=str)
        
        # Optional: build alternative suggestions if budget is below market
        alternative_hint = ""
        try:
            # Extract budget and market stats if present
            budget = None
            market_stats = None
            if isinstance(data, dict):
                prop = data.get("property", {}) or {}
                info = prop.get("property_info", {}) or {}
                budget = info.get("budget") or info.get("price") or None
                market = data.get("market", {}) or {}
                stats = market.get("statistics", {}) or {}
                # unify keys if nested variants exist
                if not stats:
                    stats = market.get("property_statistics", {}) or {}
                market_stats = stats
            below_market = False
            if budget and market_stats:
                avg_price = market_stats.get("average_price") or market_stats.get("avg_price")
                median_price = market_stats.get("median_price") or market_stats.get("median_price", 0)
                ref_price = avg_price or median_price
                if ref_price and isinstance(ref_price, (int, float)) and budget < ref_price:
                    below_market = True
            if below_market:
                alternative_hint = (
                    "\nALTERNATIVE SUGGESTIONS GUIDELINE:\n"
                    "- Offer two practical alternatives when budget is below market average:\n"
                    "  1) Nearby more affordable district/neighborhood.\n"
                    "  2) Slightly smaller size with similar specs.\n"
                    "- Keep them data-grounded and concise.\n"
                )
        except Exception:
            pass

        # Enhanced prompt with all context
        prompt = f"""You are an expert Turkish real estate analyst. {lang_instruction}.

    USER QUERY: {user_query}
    INTENT: {intent}
    {follow_up_info}
    {context_info}
    {completeness_info}

    DATA FROM AGENTS:
    {data_json}

    ENHANCED ANALYSIS RULES:

    1. CONTEXT AWARENESS:
    - Recognize if this is a follow-up message
    - Don't repeat information unnecessarily
    - Reference previous context naturally
    - Handle "I can't adjust budget" type responses empathetically

    2. INFORMATION COMPLETENESS:
    - Work with available information
    - If incomplete, acknowledge limitations gracefully
    - Provide ranges when exact values aren't possible
    - Suggest what info would help, but don't demand it

    3. BUDGET ANALYSIS:
    - Extract user's budget from the data
    - Compare with actual market prices in the data
    - Calculate gaps using correct math
    - ALWAYS show both gaps clearly:
      • Gap vs Average = (average_price - budget)
      • Gap vs Median  = (median_price - budget)
    - Do NOT mislabel gaps; specify whether it is vs average or vs median
    - If budget < minimum price, be honest but constructive
    - If user can't adjust budget, focus on alternatives

    4. DATA-DRIVEN RECOMMENDATIONS:
    - Use ONLY information present in the data
    - Calculate all percentages from actual data
    - Be precise with numbers from the data
    - Acknowledge when making estimates

    5. CONVERSATIONAL TONE:
    - Maintain natural dialogue flow
    - Be empathetic to constraints
    - Offer practical solutions
    - Don't be repetitive or robotic

    6. RESPONSE STRUCTURE:
    - Start appropriately (follow-up vs new)
    - Present key findings clearly
    - Provide actionable insights
    - End with helpful next steps

    7. ALTERNATIVES (WHEN BUDGET BELOW MARKET):
    - If user's budget is below market average/median, propose TWO actionable alternatives:
      1) Nearby district/neighborhood that is more affordable.
      2) Slightly smaller size (m²) but similar configuration.
    - Keep suggestions realistic and grounded in available data.

    8. SYSTEM SIGNATURE:
    - Always end responses with professional system signature
    - Use actual system information: {SystemInfo.NAME} v{SystemInfo.VERSION}
    - Include developer: {SystemInfo.DEVELOPER}
    - Specialization: {SystemInfo.SPECIALIZATION}
    - Format: "Best regards, [System Name] v[Version] - [Specialization] by [Developer]"

    {alternative_hint}

    {lang_instruction}

    Generate your response based on the context and data provided:"""
        
        return prompt
    
    def _generate_fallback_response(self, data: Dict[str, Any], intent: str, language: str) -> str:
        """
        Generate a simple fallback response when Qwen is not available
        """
        # Extract basic info
        property_data = data.get("property", {})
        market_data = data.get("market", {})
        location_data = data.get("location", {})
        
        response_parts = []
        
        # Basic header
        response_parts.append("## Real Estate Analysis\n")
        
        # Property info if available
        if property_data and "property_info" in property_data:
            info = property_data["property_info"]
            response_parts.append("**Property Details:**")
            response_parts.append(f"• Location: {info.get('location', 'N/A')}")
            response_parts.append(f"• Size: {info.get('size', 'N/A')} m²")
            response_parts.append(f"• Rooms: {info.get('rooms', 'N/A')}")
            
            budget = info.get('budget') or info.get('price')
            if budget:
                response_parts.append(f"• Budget: {budget:,.0f} TL\n")
        
        # Market data if available
        if property_data and "price_data" in property_data:
            price_data = property_data["price_data"]
            response_parts.append("\n**Market Overview:**")
            
            avg_price = price_data.get('average_price', 0)
            min_price = price_data.get('min_price', 0)
            
            if avg_price:
                response_parts.append(f"• Average Price: {avg_price:,.0f} TL")
            if min_price:
                response_parts.append(f"• Minimum Price: {min_price:,.0f} TL")
            
            # Check budget feasibility
            if budget and min_price and budget < min_price:
                gap = min_price - budget
                response_parts.append(f"\n⚠️ **Budget Alert:** Your budget is {gap:,.0f} TL below the minimum market price.")
        
        # Location info if available
        if location_data and "location_info" in location_data:
            loc_info = location_data["location_info"]
            response_parts.append("\n**Location:**")
            response_parts.append(f"• District: {loc_info.get('district', 'N/A')}")
            response_parts.append(f"• City: {loc_info.get('city', 'N/A')}")
        
        # Add note about limited analysis
        response_parts.append("\n*Note: Full analysis requires AI model to be loaded.*")
        
        # Add system signature
        response_parts.append(f"\n---")
        response_parts.append(f"Best regards,")
        response_parts.append(f"**{SystemInfo.NAME} v{SystemInfo.VERSION}**")
        response_parts.append(f"{SystemInfo.SPECIALIZATION}")
        response_parts.append(f"by {SystemInfo.DEVELOPER}")
        
        return "\n".join(response_parts)

    def _generate_fallback_info_request(
        self, 
        completeness: Dict[str, Any], 
        entities: Dict[str, Any], 
        language: str = "en"
    ) -> str:
        """رد احتياطي لطلب المعلومات"""
        
        completion_pct = completeness.get("completion_percentage", 0)
        critical_missing = completeness.get("critical_missing", [])
        
        if completion_pct < 20:
            return ("Hello! I'm your Turkish real estate assistant. "
                   "To provide accurate analysis, I'll need some details about the property you're interested in. "
                   "What can you tell me about your requirements?")
        else:
            missing_text = "I need a bit more information: "
            if "location" in critical_missing:
                missing_text += "which district, "
            if "financial" in critical_missing:
                missing_text += "your budget range, "
            if "property" in critical_missing:
                missing_text += "property size, "
            
            return missing_text.rstrip(", ") + ". Then I can provide detailed analysis!"
