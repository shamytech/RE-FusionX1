"""
Unified Conversation Agent for RE-FusionX
=========================================
Single agent that replaces and unifies:
- Context Manager Agent
- Intent Extractor Agent

This agent provides:
✅ Complete conversation analysis in one LLM call
✅ Unified session and memory management  
✅ Progressive information gathering
✅ Context-aware intent extraction
✅ Intelligent agent routing

Author: RE-FusionX Team
Version: 1.0
"""

from typing import Dict, Any, List, Optional
from datetime import datetime
from app.agents.base_agent import ProcessingAgent, AgentType
from app.core.logging import agent_logger, logger
from app.core.conversation.conversation_manager import get_conversation_manager
from app.core.conversation.session_context import Intent, ConversationPhase


class UnifiedConversationAgent(ProcessingAgent):
    """
    🚀 Unified Conversation Agent
    
    Replaces both Context Manager and Intent Extractor with:
    - Single LLM call for complete analysis
    - Unified memory and session management
    - Progressive information tracking
    - Context-aware processing
    - Intelligent agent routing
    """
    
    def __init__(self, model_loader=None):
        """Initialize unified conversation agent"""
        super().__init__(
            name="UnifiedConversationAgent",
            agent_type=AgentType.CONVERSATION,
            description="Unified conversation analysis and memory management",
            capabilities=[
                "🧠 Complete conversation analysis in one LLM call",
                "💾 Unified session and memory management",
                "📈 Progressive information gathering",
                "🎯 Context-aware intent extraction", 
                "🔄 Intelligent agent routing",
                "🌐 Multi-language support (EN/TR/AR)",
                "⚡ High-performance caching",
                "🔍 Advanced context understanding"
            ]
        )
        
        # Initialize conversation manager
        self.conversation_manager = get_conversation_manager(model_loader)
        
        agent_logger.agent_start(self.name, "Unified Conversation Agent initialized", {
            "replaces": ["ContextManagerAgent", "IntentExtractorAgent"],
            "capabilities": len(self.capabilities),
            "unified_system": True
        })
    
    async def validate_input(self, input_data: Dict[str, Any]) -> bool:
        """Validate input has required fields"""
        required_fields = ["message", "session_id"]
        
        for field in required_fields:
            if not input_data.get(field):
                agent_logger.warning(self.name, f"Missing required field: {field}")
                return False
        
        return True
    
    async def transform_data(
        self, 
        data: Dict[str, Any], 
        transformation_type: str = "conversation"
    ) -> Dict[str, Any]:
        """Transform data for conversation processing"""
        # Ensure session_id exists
        if not data.get("session_id"):
            import uuid
            data["session_id"] = str(uuid.uuid4())
        
        # Ensure role is set
        if not data.get("role"):
            data["role"] = "user"
        
        return data
    
    async def process(
        self,
        input_data: Dict[str, Any],
        context: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        🎯 MAIN PROCESSING METHOD
        
        Performs complete conversation analysis including:
        1. Session management
        2. Context analysis
        3. Intent extraction
        4. Entity recognition
        5. Information completeness assessment
        6. Agent routing decisions
        7. Next steps determination
        
        Args:
            input_data: Contains message, session_id, role, etc.
            context: Additional context data
            
        Returns:
            Complete conversation analysis with next steps
        """
        try:
            # Extract required data
            message = input_data.get("message", "")
            session_id = input_data.get("session_id")
            role = input_data.get("role", "user")
            metadata = input_data.get("metadata", {})
            
            # Add context to metadata
            if context:
                metadata.update(context)
            
            agent_logger.agent_action(self.name, "Processing conversation", {
                "session_id": session_id,
                "message_length": len(message),
                "role": role,
                "has_metadata": bool(metadata)
            })
            
            # فحص إذا كان لدينا سياق محفوظ
            # فحص إذا كان لدينا سياق محفوظ
            has_cached_context = input_data.get("has_cached_context", False)
            cached_property = metadata.get("cached_property") if metadata else None
            cached_analysis = metadata.get("cached_analysis") if metadata else None

            if has_cached_context and cached_property:
                # لدينا تحليل كامل - لا نحتاج لحساب completeness
                agent_logger.info(self.name, "📊 Processing with cached context", {
                    "property_location": cached_property.get("location"),
                    "has_analysis": bool(cached_analysis)
                })
                
                # تحديث metadata بدلاً من context مباشرة
                metadata["information_completeness"] = {
                    "overall_score": 1.0,
                    "completion_percentage": 100,
                    "category_scores": {
                        "location": 1.0,
                        "property": 1.0,
                        "financial": 1.0
                    },
                    "missing_categories": [],
                    "is_sufficient": True
                }
                metadata["ready_for_analysis"] = True
                
                # حفظ بيانات العقار المحفوظة
                metadata["property"] = cached_property.get("property", {})
                metadata["location"] = cached_property.get("location", {})
                metadata["financial"] = cached_property.get("financial", {})

            
            # Process message with conversation manager
            result = await self.conversation_manager.process_message(
                message=message,
                session_id=session_id,
                role=role,
                metadata=metadata
            )
            
            # Debug: Check result structure
            logger.debug(f"ConversationManager result keys: {list(result.keys())}")
            if "analysis" in result:
                logger.debug(f"Analysis keys: {list(result['analysis'].keys())}")
            
            # Enhance result with agent-specific formatting
            enhanced_result = self._enhance_result_for_orchestrator(result)
            
            agent_logger.agent_result(self.name, {
                "session_id": session_id,
                "conversation_phase": result.get("conversation_phase"),
                "ready_for_analysis": result.get("ready_for_analysis"),
                "required_agents": len(result.get("required_agents", [])),
                "next_action": result.get("next_steps", {}).get("action")
            }, success=True)
            
            return self.format_response(enhanced_result)
            
        except Exception as e:
            error_msg = f"Unified conversation processing failed: {str(e)}"
            agent_logger.error(self.name, error_msg)
            
            return self.format_response({
                "session_id": input_data.get("session_id", "unknown"),
                "message_processed": False,
                "error": error_msg,
                "analysis": {
                    "intent": {"primary_intent": "general_inquiry", "confidence": 0.0},
                    "extracted_information": {},
                    "context_signals": {}
                },
                "next_steps": {
                    "action": "error",
                    "message": "I encountered an issue processing your message. Please try again.",
                    "required_agents": ["conversation"]
                },
                "conversation_phase": "initial",
                "ready_for_analysis": False,
                "timestamp": datetime.utcnow().isoformat()
            })
    
    def _enhance_result_for_orchestrator(self, result: Dict[str, Any]) -> Dict[str, Any]:
        """
        Enhance result for orchestrator compatibility
        
        Ensures the result has all fields expected by the orchestrator
        and other system components.
        """
        try:
            logger.debug(f"_enhance_result_for_orchestrator input: {list(result.keys())}")
            enhanced = result.copy()
            
            # Ensure analysis structure exists (for compatibility with old system)
            if "analysis" not in enhanced:
                enhanced["analysis"] = {}
            
            analysis = enhanced["analysis"]
            
            # Extract intent information from analysis result
            if "intent" not in analysis:
                # Try to get from analysis result first
                if "analysis_result" in enhanced:
                    intent_data = enhanced["analysis_result"].get("intent", {})
                    if isinstance(intent_data, dict):
                        analysis["intent"] = intent_data.get("primary_intent", "general_inquiry")
                    else:
                        analysis["intent"] = intent_data or "general_inquiry"
                elif "context_summary" in enhanced:
                    context_summary = enhanced["context_summary"]
                    if "conversation_flow" in context_summary:
                        recent_intents = context_summary["conversation_flow"].get("recent_intents", [])
                        if recent_intents:
                            analysis["intent"] = recent_intents[-1]
                        else:
                            analysis["intent"] = "general_inquiry"
                    else:
                        analysis["intent"] = "general_inquiry"
                else:
                    analysis["intent"] = "general_inquiry"
            
            # Extract entities (for compatibility)
            if "entities" not in analysis and "context_summary" in enhanced:
                extracted_info = enhanced["context_summary"].get("extracted_information", {})
                analysis["entities"] = extracted_info
            
            # Extract completeness information
            if "completeness" not in analysis and "context_summary" in enhanced:
                analysis_status = enhanced["context_summary"].get("analysis_status", {})
                completeness_info = analysis_status.get("information_completeness", {})
                analysis["completeness"] = completeness_info
                
                # Also add at root level for Orchestrator compatibility
                enhanced["completeness"] = completeness_info
                enhanced["ready_for_analysis"] = enhanced.get("ready_for_analysis", False)
            
            # Add required_agents based on intent
            if "required_agents" not in analysis:
                intent_data = analysis.get("intent", "general_inquiry")
                
                # Extract intent string from dict if needed
                if isinstance(intent_data, dict):
                    intent_str = intent_data.get("primary_intent", "general_inquiry")
                else:
                    intent_str = intent_data or "general_inquiry"
                
                # Intent to agents mapping
                intent_agent_map = {
                    "property_search": ["property_data", "market_data", "location_data"],
                    "property_valuation": ["property_data", "market_data", "location_data"],
                    "market_comparison": ["property_data", "market_data", "market_comparison_data"],
                    "market_trends": ["market_data", "location_data"],
                    "investment_advice": ["property_data", "market_data", "location_data"],
                    "location_analysis": ["location_data", "market_data"],
                    "constraint_update": ["property_data", "market_data"],
                    "alternatives_request": ["property_data", "market_data", "location_data"],
                    "general_inquiry": [],
                    "greeting": [],
                    "help": []
                }
                
                analysis["required_agents"] = intent_agent_map.get(intent_str, [])
        
            # Ensure cumulative_information exists (for memory compatibility)
            if "cumulative_information" not in enhanced and "context_summary" in enhanced:
                enhanced["cumulative_information"] = enhanced["context_summary"].get("extracted_information", {})
            
            # Add method used for tracking
            analysis["method_used"] = "unified_system"
            
            # Ensure required fields exist
            required_fields = {
                "session_id": enhanced.get("session_id", "unknown"),
                "message_processed": enhanced.get("message_processed", True),
                "conversation_phase": enhanced.get("conversation_phase", "initial"),
                "ready_for_analysis": enhanced.get("ready_for_analysis", False),
                "required_agents": enhanced.get("required_agents", []),
                "timestamp": enhanced.get("timestamp", datetime.utcnow().isoformat())
            }
            
            for field, default_value in required_fields.items():
                if field not in enhanced:
                    enhanced[field] = default_value
            
            # Ensure next_steps has required structure
            if "next_steps" not in enhanced:
                enhanced["next_steps"] = {
                    "action": "gather_information",
                    "message": "Please provide more details.",
                    "required_agents": ["conversation"]
                }
            
            next_steps = enhanced["next_steps"]
            if "required_agents" not in next_steps:
                next_steps["required_agents"] = enhanced.get("required_agents", ["conversation"])
            
            logger.debug(f"_enhance_result_for_orchestrator output: {list(enhanced.keys())}")
            return enhanced
            
        except Exception as e:
            logger.error(f"Error in _enhance_result_for_orchestrator: {e}")
            logger.error(f"Input result: {result}")
            import traceback
            traceback.print_exc()
            raise
    
    async def get_session_summary(self, session_id: str) -> Optional[Dict[str, Any]]:
        """
        Get session summary
        
        Args:
            session_id: Session ID
            
        Returns:
            Session summary or None
        """
        try:
            return await self.conversation_manager.get_session_summary(session_id)
        except Exception as e:
            agent_logger.error(self.name, f"Failed to get session summary: {e}")
            return None
    
    async def delete_session(self, session_id: str) -> bool:
        """
        Delete session
        
        Args:
            session_id: Session ID
            
        Returns:
            Success status
        """
        try:
            return await self.conversation_manager.delete_session(session_id)
        except Exception as e:
            agent_logger.error(self.name, f"Failed to delete session: {e}")
            return False
    
    async def get_conversation_insights(self, session_id: str) -> Dict[str, Any]:
        """
        Get conversation insights and recommendations
        
        Args:
            session_id: Session ID
            
        Returns:
            Insights and recommendations
        """
        try:
            summary = await self.get_session_summary(session_id)
            if not summary:
                return {"insights": [], "recommendations": []}
            
            insights = []
            recommendations = []
            
            # Analyze information completeness
            analysis_status = summary.get("analysis_status", {})
            completeness = analysis_status.get("information_completeness", {})
            
            if not completeness.get("is_sufficient", False):
                missing = completeness.get("missing_categories", [])
                insights.append(f"Information is incomplete. Missing: {', '.join(missing)}")
                recommendations.append("gather_more_information")
            
            # Analyze conversation flow
            conversation_flow = summary.get("conversation_flow", {})
            recent_intents = conversation_flow.get("recent_intents", [])
            
            if "constraint_update" in recent_intents:
                insights.append("User has expressed constraints or limitations")
                recommendations.append("handle_constraints")
            
            if "alternatives_request" in recent_intents:
                insights.append("User is requesting alternative options")
                recommendations.append("provide_alternatives")
            
            # Check for progressive updates
            if analysis_status.get("progressive_updates_detected", False):
                insights.append("User is refining their requirements progressively")
                recommendations.append("track_changes")
            
            return {
                "insights": insights,
                "recommendations": recommendations,
                "session_phase": summary.get("session_info", {}).get("phase", "initial"),
                "readiness_score": completeness.get("overall_score", 0.0)
            }
            
        except Exception as e:
            agent_logger.error(self.name, f"Failed to get insights: {e}")
            return {"insights": [], "recommendations": []}
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get agent statistics"""
        base_stats = super().get_statistics()
        
        # Add conversation manager statistics
        system_stats = {"conversation_manager": "active"}
        
        return {
            **base_stats,
            "unified_system": system_stats,
            "features": {
                "unified_analysis": True,
                "session_management": True,
                "progressive_tracking": True,
                "multi_language": True,
                "intelligent_caching": True
            }
        }


# Factory function for easy instantiation
def create_unified_conversation_agent(model_loader=None) -> UnifiedConversationAgent:
    """Create unified conversation agent"""
    return UnifiedConversationAgent(model_loader)


"""
Migration Guide from Old System:
================================

OLD SYSTEM (2 separate agents):
```python
# Context Manager
context_result = await context_manager.process({
    "message": message,
    "conversation_history": history
})

# Intent Extractor  
intent_result = await intent_extractor.process({
    "message": message
})

# Manual merging required
combined_result = merge_results(context_result, intent_result)
```

NEW SYSTEM (1 unified agent):
```python
# Single call does everything
result = await unified_agent.process({
    "message": message,
    "session_id": session_id,
    "role": "user"
})

# Complete result with:
# - Intent analysis
# - Context understanding  
# - Entity extraction
# - Session management
# - Agent routing
# - Next steps
```

Benefits:
- ✅ 50% fewer LLM calls = faster + cheaper
- ✅ No data duplication between systems
- ✅ Unified session management
- ✅ Better context preservation
- ✅ Simplified orchestration
- ✅ Consistent caching strategy
"""
