# D:\Phd\RE-FusionX\src\backend\app\agents\market_data_agent.py
"""
Market Data Agent - Fetches market data only
Returns structured market data without analysis or recommendations

# الغرض: جلب بيانات السوق العامة
# المدخلات: الموقع + نوع البيانات
# المخرجات: إحصائيات وتحليلات السوق

الوظائف:
- إحصائيات السوق العامة
- اتجاهات الأسعار
- مؤشرات العرض والطلب
- المؤشرات الاقتصادية

مثال المخرجات:
{
  "statistics": {"average_price": 4500000},
  "trends": {"current_trend": "increasing"},
  "economic_indicators": {"inflation": 65%}
}

"""

from typing import Dict, Any, List, Optional
from datetime import datetime, timedelta

from app.agents.base_agent import DataAgent
from app.core.logging import agent_logger, logger
from app.core.storage.integration import StorageIntegration
from app.core.storage.unified_cache import CacheType


class MarketDataAgent(DataAgent):
    """
    Market Data Agent - Fetches market-related data only
    No analysis, no recommendations, just raw market data
    """
    
    def __init__(self, model_loader=None):
        super().__init__(
            name="MarketDataAgent",
            description="Fetches market data, trends, and statistics",
            capabilities=[
                "Market statistics retrieval",
                "Price trend data",
                "Supply and demand metrics",
                "Historical price data",
                "Market activity indicators"
            ],
            data_sources=["storage", "market_apis", "economic_indicators"]
        )
        
        self.model_loader = model_loader
        self._storage = None
        self._cache = None
        
        agent_logger.agent_start(self.name, "Market data agent initialized", {
            "sources": self.data_sources
        })
    
    @property
    def storage(self):
        """Lazy load storage"""
        if self._storage is None:
            try:
                from app.core.storage.integration import StorageIntegration
                self._storage = StorageIntegration.get_storage()
                
                # Fallback if StorageIntegration fails
                if self._storage is None:
                    from app.core.storage.storage_manager import get_storage_manager
                    self._storage = get_storage_manager()
                    
            except Exception as e:
                logger.error(f"Failed to get storage in MarketDataAgent: {e}")
                # Create a mock storage to prevent crashes
                from unittest.mock import Mock
                self._storage = Mock()
                self._storage.get_properties = lambda **kwargs: []
                self._storage.get_market_data = lambda **kwargs: {}
                
        return self._storage
    
    @property
    def cache(self):
        """Lazy load cache"""
        if self._cache is None:
            try:
                from app.core.storage.integration import StorageIntegration
                self._cache = StorageIntegration.get_cache()
                
                # Fallback if StorageIntegration fails
                if self._cache is None:
                    from app.core.storage.unified_cache import get_cache
                    self._cache = get_cache()
                    
            except Exception as e:
                logger.error(f"Failed to get cache in MarketDataAgent: {e}")
                # Create a mock cache to prevent crashes
                from unittest.mock import Mock
                self._cache = Mock()
                self._cache.generate_key = lambda cache_type, key: f"{cache_type}:{key}"
                self._cache.get = lambda key, cache_type=None: None
                self._cache.set = lambda key, value, cache_type=None: None
                
        return self._cache
    
    async def validate_input(self, input_data: Dict[str, Any]) -> bool:
        """Validate input has location"""
        has_location = bool(input_data.get("location"))
        
        if not has_location:
            agent_logger.warning(self.name, "No location provided for market data")
        
        return has_location
    
    async def fetch_data(
        self,
        criteria: Dict[str, Any],
        context: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Fetch market data based on criteria
        
        Args:
            criteria: Search criteria with location and filters
            context: Optional context
            
        Returns:
            Raw market data only
        """
        # Handle location properly - could be string or dict
        location_data = criteria.get("location", "Turkey")
        if isinstance(location_data, dict):
            # Extract string from dict
            if location_data.get("city"):
                location = location_data["city"]
            elif location_data.get("district"):
                location = location_data["district"]
            else:
                location = "Turkey"
        else:
            location = str(location_data) if location_data else "Turkey"
            
        data_type = criteria.get("data_type", "full")  # full, trends, statistics, activity
        time_range = criteria.get("time_range", "current")  # current, 3m, 6m, 1y
        
        agent_logger.agent_action(self.name, "Fetching market data", {
            "location": location,
            "data_type": data_type,
            "time_range": time_range
        })
        
        result = {}
        
        # 1. Get market statistics
        if data_type in ["full", "statistics"]:
            result["statistics"] = await self._fetch_market_statistics(location)
        
        # 2. Get price trends
        if data_type in ["full", "trends"]:
            result["trends"] = await self._fetch_price_trends(location, time_range)
        
        # 3. Get market activity
        if data_type in ["full", "activity"]:
            result["activity"] = await self._fetch_market_activity(location)
        
        # 4. Get supply and demand
        if data_type in ["full", "supply_demand"]:
            result["supply_demand"] = await self._fetch_supply_demand(location)
        
        # 5. Get economic indicators
        if data_type in ["full", "economic"]:
            result["economic_indicators"] = await self._fetch_economic_indicators()
        
        # Add richer diagnostics for visibility
        stats_summary = {}
        try:
            stats = result.get("statistics", {})
            if stats:
                stats_summary = {
                    "total_listings": stats.get("total_listings", 0),
                    "average_price": stats.get("average_price", 0),
                    "median_price": stats.get("median_price", 0)
                }
        except Exception:
            pass
        agent_logger.info(self.name, "📈 Market data fetched", {
            "sections": list(result.keys()),
            "location": location,
            "stats": stats_summary
        })
        
        return result
    
    async def _fetch_market_statistics(self, location: str) -> Dict[str, Any]:
        """Fetch market statistics for location"""
        
        # Check cache
        cache_key = self.cache.generate_key(
            CacheType.MARKET,
            f"stats_{location}"
        )
        
        cached = await self.cache.get(cache_key, CacheType.MARKET)
        if cached:
            return cached
        
        # Get from storage
        properties = await self.storage.get_properties(
            location=location,
            filters={"limit": 1000}  # Get sample for statistics
        )
        
        if properties:
            prices = [p.get("price", 0) for p in properties if p.get("price")]
            sizes = [p.get("size", 0) for p in properties if p.get("size")]
            ages = [p.get("building_age", 0) for p in properties if p.get("building_age") is not None]
            
            stats = {
                "total_listings": len(properties),
                "average_price": sum(prices) / len(prices) if prices else 0,
                "median_price": sorted(prices)[len(prices)//2] if prices else 0,
                "price_std_dev": self._calculate_std_dev(prices),
                "average_size": sum(sizes) / len(sizes) if sizes else 0,
                "average_age": sum(ages) / len(ages) if ages else 0,
                "price_per_sqm": self._calculate_avg_price_per_sqm(prices, sizes),
                "property_types": self._count_property_types(properties),
                "room_distribution": self._count_room_types(properties),
                "data_timestamp": datetime.utcnow().isoformat()
            }
            
            await self.cache.set(cache_key, stats, CacheType.MARKET)  # 1 hour cache
            return stats
        
        # Return empty statistics
        return {
            "total_listings": 0,
            "average_price": 0,
            "median_price": 0,
            "price_std_dev": 0,
            "average_size": 0,
            "average_age": 0,
            "price_per_sqm": 0,
            "property_types": {},
            "room_distribution": {},
            "data_timestamp": datetime.utcnow().isoformat()
        }
    
    async def _fetch_price_trends(self, location: str, time_range: str) -> Dict[str, Any]:
        """Fetch price trend data"""
        
        # For now, return simulated trend data
        # In production, this would fetch historical data
        
        trends = {
            "current_trend": "increasing",  # increasing, decreasing, stable
            "monthly_change_pct": 1.5,
            "quarterly_change_pct": 4.5,
            "yearly_change_pct": 18.5,
            "trend_strength": 0.7,  # 0-1 confidence
            "volatility": "medium",  # low, medium, high
            "forecast_3m": 5.0,  # % change expected
            "forecast_6m": 10.0,
            "forecast_12m": 20.0,
            "historical_data": self._generate_historical_data(time_range),
            "analysis_date": datetime.utcnow().isoformat()
        }
        
        return trends
    
    async def _fetch_market_activity(self, location: str) -> Dict[str, Any]:
        """Fetch market activity indicators"""
        
        # Get recent properties
        properties = await self.storage.get_properties(
            location=location,
            filters={"limit": 100}
        )
        
        activity = {
            "new_listings_24h": 0,  # Would need timestamp tracking
            "new_listings_7d": 0,
            "new_listings_30d": len(properties),  # Approximate
            "average_days_on_market": 45,  # Default estimate
            "absorption_rate": 0.65,  # Properties sold / listed
            "listing_views": 0,  # Would need tracking
            "inquiry_rate": 0,  # Would need tracking
            "market_velocity": "normal",  # slow, normal, fast
            "buyer_activity": "moderate",  # low, moderate, high
            "seller_activity": "moderate"
        }
        
        # Determine market velocity based on listing count
        if len(properties) > 500:
            activity["market_velocity"] = "fast"
            activity["buyer_activity"] = "high"
        elif len(properties) < 50:
            activity["market_velocity"] = "slow"
            activity["buyer_activity"] = "low"
        
        return activity
    
    async def _fetch_supply_demand(self, location: str) -> Dict[str, Any]:
        """Fetch supply and demand metrics"""
        
        properties = await self.storage.get_properties(
            location=location,
            filters={"limit": 1000}
        )
        
        # Calculate supply metrics
        total_supply = len(properties)
        
        # Group by price ranges
        price_ranges = {
            "under_2m": 0,
            "2m_4m": 0,
            "4m_6m": 0,
            "6m_10m": 0,
            "over_10m": 0
        }
        
        for prop in properties:
            price = prop.get("price", 0)
            if price < 2000000:
                price_ranges["under_2m"] += 1
            elif price < 4000000:
                price_ranges["2m_4m"] += 1
            elif price < 6000000:
                price_ranges["4m_6m"] += 1
            elif price < 10000000:
                price_ranges["6m_10m"] += 1
            else:
                price_ranges["over_10m"] += 1
        
        supply_demand = {
            "total_supply": total_supply,
            "supply_by_price": price_ranges,
            "months_of_inventory": total_supply / 100 if total_supply > 0 else 0,  # Estimate
            "market_balance": self._determine_market_balance(total_supply),
            "demand_level": "moderate",  # Would need actual demand data
            "supply_trend": "stable",
            "demand_trend": "increasing",
            "price_pressure": "upward" if total_supply < 200 else "neutral"
        }
        
        return supply_demand
    
    async def _fetch_economic_indicators(self) -> Dict[str, Any]:
        """Fetch economic indicators affecting real estate"""
        
        # These would come from economic APIs in production
        indicators = {
            "inflation_rate": 65.0,  # Turkey current inflation
            "interest_rate": 45.0,  # Central bank rate
            "mortgage_rate": 3.5,  # Monthly mortgage rate
            "usd_try_rate": 32.5,  # Exchange rate
            "construction_cost_index": 180.5,  # Base 100
            "consumer_confidence": 72.3,  # Index
            "gdp_growth": 4.5,  # Annual %
            "unemployment_rate": 9.2,  # %
            "foreign_investment": "moderate",  # low, moderate, high
            "economic_outlook": "stable",  # negative, stable, positive
            "last_updated": datetime.utcnow().isoformat()
        }
        
        return indicators
    
    def _calculate_std_dev(self, values: List[float]) -> float:
        """Calculate standard deviation"""
        if not values or len(values) < 2:
            return 0
        
        mean = sum(values) / len(values)
        variance = sum((x - mean) ** 2 for x in values) / len(values)
        return variance ** 0.5
    
    def _calculate_avg_price_per_sqm(self, prices: List[float], sizes: List[float]) -> float:
        """Calculate average price per square meter"""
        if not prices or not sizes:
            return 0
        
        valid_pairs = [(p, s) for p, s in zip(prices, sizes) if s > 0]
        if not valid_pairs:
            return 0
        
        price_per_sqm = [p / s for p, s in valid_pairs]
        return sum(price_per_sqm) / len(price_per_sqm)
    
    def _count_property_types(self, properties: List[Dict[str, Any]]) -> Dict[str, int]:
        """Count properties by type"""
        types = {}
        for prop in properties:
            prop_type = prop.get("property_type", "Unknown")
            types[prop_type] = types.get(prop_type, 0) + 1
        return types
    
    def _count_room_types(self, properties: List[Dict[str, Any]]) -> Dict[str, int]:
        """Count properties by room configuration"""
        rooms = {}
        for prop in properties:
            room_count = prop.get("rooms", "Unknown")
            rooms[room_count] = rooms.get(room_count, 0) + 1
        return rooms
    
    def _determine_market_balance(self, supply_count: int) -> str:
        """Determine market balance based on supply"""
        if supply_count < 100:
            return "seller's market"
        elif supply_count > 500:
            return "buyer's market"
        else:
            return "balanced market"
    
    def _generate_historical_data(self, time_range: str) -> List[Dict[str, Any]]:
        """Generate historical price data points"""
        
        # Simulated data - would be real historical data in production
        data_points = []
        
        if time_range == "3m":
            periods = 3
        elif time_range == "6m":
            periods = 6
        elif time_range == "1y":
            periods = 12
        else:
            periods = 1
        
        base_price = 5000000
        for i in range(periods):
            date = datetime.utcnow() - timedelta(days=30 * (periods - i))
            price = base_price * (1 + (i * 0.015))  # 1.5% monthly growth
            
            data_points.append({
                "date": date.isoformat(),
                "average_price": price,
                "volume": 100 + (i * 10)
            })
        
        return data_points


'''
الغرض: جلب بيانات السوق العامة والمؤشرات الاقتصادية
المدخلات: الموقع ونوع البيانات المطلوبة
المخرجات: إحصائيات السوق والاتجاهات

مصادر البيانات:
  - PostgreSQL: بيانات السوق
  - Economic APIs: المؤشرات الاقتصادية
  - Historical Data: البيانات التاريخية

الحسابات:
  1. إحصائيات السوق الحالية
  2. اتجاهات الأسعار (شهري/ربعي/سنوي)
  3. مؤشرات النشاط
  4. العرض والطلب
  5. المؤشرات الاقتصادية


# المدخل
{
  "location": "Istanbul",
  "data_type": "full",
  "time_range": "6m"
}

# المخرج
{
  "statistics": {
    "total_listings": 3847,
    "average_price": 4850000,
    "median_price": 4600000,
    "price_std_dev": 1250000,
    "average_size": 135,
    "average_age": 8.5,
    "price_per_sqm": 35926,
    "property_types": {
      "Apartment": 2890,
      "Villa": 425,
      "House": 532
    },
    "room_distribution": {
      "1+1": 450,
      "2+1": 1250,
      "3+1": 1680,
      "4+1": 467
    },
    "data_timestamp": "2024-01-15T10:32:00Z"
  },
  "trends": {
    "current_trend": "increasing",
    "monthly_change_pct": 2.1,
    "quarterly_change_pct": 6.5,
    "yearly_change_pct": 28.3,
    "trend_strength": 0.75,
    "volatility": "medium",
    "forecast_3m": 6.8,
    "forecast_6m": 14.2,
    "forecast_12m": 31.5,
    "historical_data": [
      {"date": "2023-07-15", "average_price": 3780000, "volume": 3200},
      {"date": "2023-08-15", "average_price": 3850000, "volume": 3350},
      // ... more data points
    ],
    "analysis_date": "2024-01-15T10:32:00Z"
  },
  "activity": {
    "new_listings_24h": 45,
    "new_listings_7d": 312,
    "new_listings_30d": 1250,
    "average_days_on_market": 42,
    "absorption_rate": 0.68,
    "listing_views": 0,  # يحتاج tracking
    "inquiry_rate": 0,
    "market_velocity": "fast",
    "buyer_activity": "high",
    "seller_activity": "moderate"
  },
  "supply_demand": {
    "total_supply": 3847,
    "supply_by_price": {
      "under_2m": 215,
      "2m_4m": 1456,
      "4m_6m": 1532,
      "6m_10m": 544,
      "over_10m": 100
    },
    "months_of_inventory": 3.2,
    "market_balance": "balanced market",
    "demand_level": "high",
    "supply_trend": "decreasing",
    "demand_trend": "increasing",
    "price_pressure": "upward"
  },
  "economic_indicators": {
    "inflation_rate": 64.8,
    "interest_rate": 45.0,
    "mortgage_rate": 3.49,
    "usd_try_rate": 32.45,
    "construction_cost_index": 182.3,
    "consumer_confidence": 71.8,
    "gdp_growth": 4.2,
    "unemployment_rate": 9.1,
    "foreign_investment": "moderate",
    "economic_outlook": "cautiously optimistic",
    "last_updated": "2024-01-15T10:32:00Z"
  }
}

'''