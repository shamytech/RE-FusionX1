"""
Smart Response Generator - نظام ردود ذكية ومتكيفة
========================================================

يستخدم LLM لتوليد ردود طبيعية ومتكيفة حسب:
- مستوى اكتمال المعلومات
- السياق والتاريخ
- نوع الاستعلام
- التفاعل السابق

بدلاً من القوالب الثابتة، نحصل على ردود شبه بشرية ومتنوعة.
"""

import json
from typing import Dict, Any, List, Optional
from datetime import datetime

from app.core.logging import agent_logger
from app.utils.location_utils import get_location_manager
from app.core.constants import SystemInfo


class SmartResponseGenerator:
    """مولد الردود الذكية باستخدام LLM"""
    
    def __init__(self, model_loader=None):
        self.model_loader = model_loader
        
    async def generate_context_aware_response(
        self,
        message_type: str,
        intent: str,
        completeness: Dict[str, Any],
        entities: Dict[str, Any],
        conversation_history: List[Dict] = None,
        language: str = "en",
        context: Optional[Dict[str, Any]] = None 
    ) -> str:
        """
        توليد رد ذكي ومتكيف حسب السياق
        
        Args:
            message_type: نوع الرسالة (greeting, property_search, etc.)
            intent: النية المستخرجة
            completeness: معلومات الاكتمال
            entities: الكيانات المستخرجة
            conversation_history: تاريخ المحادثة
            language: اللغة
        """
        
        try:
            # تحديد نوع الرد المطلوب
            response_strategy = self._determine_response_strategy(
                message_type, intent, completeness, entities, conversation_history
            )
            
            agent_logger.info("SmartResponseGenerator", f"📝 Response strategy: {response_strategy['type']}", {
                "completion_pct": completeness.get("completion_percentage", 0),
                "missing_critical": len(completeness.get("critical_missing", [])),
                "strategy": response_strategy['type']
            })
            
            # فحص إذا كان لدينا تحليل محفوظ
            cached_analysis = context.get("cached_analysis") if context else None
            cached_property = context.get("cached_property") if context else None
            has_complete_analysis = context.get("has_complete_analysis", False) if context else False

            if has_complete_analysis and cached_analysis and cached_property:
                agent_logger.info("SmartResponseGenerator", "📊 Using cached analysis context", {
                    "has_analysis": True,
                    "property_location": cached_property.get("location", "N/A")
                })
                
                # استخراج الرسالة الأصلية من السياق أو من conversation_history
                original_message = ""
                if conversation_history and len(conversation_history) > 0:
                    original_message = conversation_history[-1].get("message", "").lower()
                
                # تحديد استراتيجية خاصة للتحليل المحفوظ
                if any(word in original_message for word in ["can't", "cannot", "budget", "expensive", "afford", "cheaper"]):
                    response_strategy = {
                        "type": "constraint_with_analysis",
                        "tone": "understanding",
                        "action": "provide_alternatives",
                        "has_complete_analysis": True,
                        "cached_analysis": cached_analysis,
                        "cached_property": cached_property
                    }
                elif any(word in original_message for word in ["alternative", "other", "different", "else", "options"]):
                    response_strategy = {
                        "type": "alternatives_with_analysis",
                        "tone": "helpful",
                        "action": "suggest_alternatives",
                        "has_complete_analysis": True,
                        "cached_analysis": cached_analysis,
                        "cached_property": cached_property
                    }
                elif any(word in original_message for word in ["investment", "roi", "rental", "worth", "good deal"]):
                    response_strategy = {
                        "type": "investment_question_with_analysis",
                        "tone": "analytical",
                        "action": "explain_investment_potential",
                        "has_complete_analysis": True,
                        "cached_analysis": cached_analysis,
                        "cached_property": cached_property
                    }
                else:
                    response_strategy = {
                        "type": "question_about_analysis",
                        "tone": "informative",
                        "action": "answer_with_context",
                        "has_complete_analysis": True,
                        "cached_analysis": cached_analysis,
                        "cached_property": cached_property
                    }
                
                agent_logger.info("SmartResponseGenerator", f"📊 Cached analysis strategy: {response_strategy['type']}")
            
            # إذا كانت الاستراتيجية طلباً أولياً شاملاً، تجنب التكرار إن كان قد أُرسل سابقاً
            if response_strategy.get("type") == "comprehensive_initial_request":
                history_flags = self._analyze_conversation_history(conversation_history)
                if history_flags.get("initial_template_sent", False):
                    # تحوّل إلى رد تقدمي بدل تكرار الرسالة الأولية
                    progressive_strategy = {
                        "type": "progressive_acknowledgment",
                        "tone": "encouraging",
                        "action": "acknowledge_and_request_next",
                        "newly_added": history_flags.get("newly_added_info", [])
                    }
                    return self._build_progressive_request(
                        progressive_strategy, completeness, entities, language
                    )
                return self._build_initial_info_request(entities, language)

            # إن كانت الاستراتيجية مركزة لكن تمّت إضافة معلومة جديدة الآن، قدّم ردّاً تقدمياً اعترافاً بالمعلومة
            if response_strategy.get("type") == "focused_completion_request":
                history_flags = self._analyze_conversation_history(conversation_history)
                if history_flags.get("recent_info_added", False):
                    progressive_strategy = {
                        "type": "progressive_acknowledgment",
                        "tone": "encouraging",
                        "action": "acknowledge_and_request_next",
                        "newly_added": history_flags.get("newly_added_info", [])
                    }
                    return self._build_progressive_request(
                        progressive_strategy, completeness, entities, language
                    )

            # إذا كانت الاستراتيجية تقدمية، ابنِ ردّاً ذكياً يعلّق على المعلومة ويعرض الحقول الباقية بشكل منظم
            if response_strategy.get("type") == "progressive_acknowledgment":
                return self._build_progressive_request(response_strategy, completeness, entities, language)

            # إنشاء prompt ذكي
            # معالجة خاصة للتحليل المحفوظ
            if response_strategy.get("has_complete_analysis"):
                return await self._handle_cached_analysis_response(
                    response_strategy, 
                    completeness, 
                    entities, 
                    language,
                    context
                )

            # إنشاء prompt ذكي للحالات العادية
            smart_prompt = self._create_smart_prompt(
                response_strategy, message_type, intent, completeness, 
                entities, conversation_history, language
            )
            
            # توليد الرد باستخدام LLM
            if self.model_loader and hasattr(self.model_loader, 'load_qwen_model'):
                model = self.model_loader.load_qwen_model()
                if model:
                    response = await model.generate_text(smart_prompt)
                    return self._post_process_response(response)
            
            # Fallback إذا لم يكن النموذج متاحاً
            return self._generate_fallback_smart_response(response_strategy, completeness, entities, language)
            
        except Exception as e:
            agent_logger.error("SmartResponseGenerator", f"❌ Error generating smart response: {e}")
            # Try fallback smart response first
            try:
                return self._generate_fallback_smart_response(response_strategy, completeness, entities, language)
            except Exception as fallback_error:
                agent_logger.error("SmartResponseGenerator", f"❌ Fallback also failed: {fallback_error}")
                return self._generate_emergency_fallback(message_type, intent)
    
    def _determine_response_strategy(
        self, 
        message_type: str, 
        intent: str, 
        completeness: Dict[str, Any],
        entities: Dict[str, Any],
        conversation_history: List[Dict] = None
    ) -> Dict[str, Any]:
        """تحديد استراتيجية الرد الذكي"""
        
        completion_pct = completeness.get("completion_percentage", 0)
        critical_missing = completeness.get("critical_missing", [])
        missing_categories = completeness.get("missing_categories", [])
        
        # تحليل التاريخ للمحادثة
        history_analysis = self._analyze_conversation_history(conversation_history)
        
        # 1. تحية بسيطة
        if message_type == "greeting" and intent == "general_inquiry" and completion_pct < 10:
            return {
                "type": "simple_greeting",
                "tone": "friendly",
                "action": "greet_only"
            }
        
        # تحديد إذا كان هناك معلومات عقارية محددة
        has_specific_property_info = (
            entities.get("property", {}).get("size") or
            entities.get("property", {}).get("rooms") or
            entities.get("location", {}).get("city") or
            entities.get("location", {}).get("district") or
            entities.get("financial", {}).get("budget")
        )
        
        # 2. أول استعلام عقاري - رد شامل (حتى لو وُجدت معلومة عامة واحدة مثل المدينة)
        if intent == "property_search" and completion_pct < 35:
            info_bits = 0
            if entities.get("location", {}).get("city") or entities.get("location", {}).get("district"):
                info_bits += 1
            if entities.get("property", {}).get("size"):
                info_bits += 1
            if entities.get("property", {}).get("rooms"):
                info_bits += 1
            if entities.get("financial", {}).get("budget"):
                info_bits += 1
            if entities.get("property", {}).get("type") or entities.get("property", {}).get("property_type"):
                info_bits += 1
            # إذا كان لدينا 0-1 من العناصر الأساسية أو صُنّفت الرسالة كاستعلام أولي → أظهر رسالة الطلب الشامل
            if info_bits <= 1 or message_type == "initial_property_inquiry":
                return {
                    "type": "comprehensive_initial_request",
                    "tone": "professional_welcoming",
                    "action": "request_all_info",
                    "priority": "very_high"
                }
        
        # 3. معلومة جديدة مضافة - رد تقديري (أولوية عالية جداً)
        # إذا كان هناك معلومات محددة أو completion > 20%
        # المجال التقدمي: وسّعناه حتى <85 لضمان الاعتراف بالمعلومة الجديدة قبل الإغلاق
        if (intent == "property_search" and completion_pct > 5 and completion_pct < 85 and 
            (has_specific_property_info or history_analysis.get("recent_info_added", False) or message_type == "progressive_info_addition")):
            return {
                "type": "progressive_acknowledgment",
                "tone": "encouraging",
                "action": "acknowledge_and_request_next",
                "newly_added": history_analysis.get("newly_added_info", [])
            }
        
        # 4. معلومات شبه مكتملة - رد مركز
        if intent == "property_search" and 50 < completion_pct < 85:
            return {
                "type": "focused_completion_request",
                "tone": "efficient",
                "action": "request_specific_missing",
                "missing_items": critical_missing
            }
        
        # 5. معلومات مكتملة - تحليل كامل
        if completion_pct >= 85:
            return {
                "type": "full_analysis_ready",
                "tone": "analytical",
                "action": "provide_analysis"
            }
        
        # افتراضي
        return {
            "type": "standard_info_request",
            "tone": "helpful",
            "action": "request_missing_info"
        }
    
    def _analyze_conversation_history(self, history: List[Dict] = None) -> Dict[str, Any]:
        """تحليل تاريخ المحادثة لاستخراج الأنماط"""
        
        if not history or len(history) < 2:
            return {
                "has_previous_property_discussion": False,
                "recent_info_added": False,
                "newly_added_info": [],
                "conversation_stage": "initial",
                "initial_template_sent": False
            }
        
        # تحليل الرسائل الأخيرة
        recent_messages = history[-3:] if len(history) >= 3 else history
        
        has_property_discussion = any(
            "property" in msg.get("content", "").lower() or 
            "apartment" in msg.get("content", "").lower()
            for msg in history
        )
        
        # هل أُرسلت الرسالة الأولية المنظمة سابقاً؟
        initial_template_sent = any(
            (m.get("role") in ["assistant", "system"]) and (
                "For Accurate Analysis, I Need" in m.get("content", "") or
                "📋 For Accurate Analysis" in m.get("content", "")
            )
            for m in history
        )

        # تحديد المعلومات المضافة حديثاً
        last_user_msg = None
        for msg in reversed(history):
            if msg.get("role") == "user":
                last_user_msg = msg.get("content", "")
                break
        
        # كشف المعلومات الجديدة بطريقة ذكية
        newly_added = self._detect_newly_added_info(last_user_msg) if last_user_msg else []
        
        return {
            "has_previous_property_discussion": has_property_discussion,
            "recent_info_added": len(newly_added) > 0,
            "newly_added_info": newly_added,
            "conversation_stage": "progressive" if len(history) > 2 else "initial",
            "total_exchanges": len([msg for msg in history if msg.get("role") == "user"]),
            "initial_template_sent": initial_template_sent
        }
    
    def _detect_newly_added_info(self, user_message: str) -> List[str]:
        """كشف ذكي للمعلومات الجديدة في رسالة المستخدم باستخدام أنماط متقدمة"""
        
        if not user_message:
            return []
        
        newly_added = []
        content_lower = user_message.lower().strip()
        
        # 1. كشف الغرف - أنماط متقدمة
        room_patterns = ["room", "bedroom", "+1", "+2", "+3", "+4", "+5", "studio", "1br", "2br", "3br"]
        if any(pattern in content_lower for pattern in room_patterns):
            newly_added.append("rooms")
        
        # 2. كشف المساحة - أرقام + كلمات دالة (دقيق أكثر)
        size_words = ["m2", "m²", "meter", "square", "size", "sqm", "space"]
        has_size_word = any(word in content_lower for word in size_words)
        
        # تجنب كلمة "area" إذا كانت في سياق موقع
        if "area" in content_lower and not any(loc_word in content_lower for loc_word in ["prefer", "location", "district"]):
            has_size_word = True
        
        # البحث عن أرقام تدل على المساحة (50-500)
        import re
        size_numbers = re.findall(r'\b(\d{2,3})\b', user_message)
        has_reasonable_size = any(50 <= int(num) <= 500 for num in size_numbers if num.isdigit())
        
        if has_size_word or has_reasonable_size:
            newly_added.append("size")
        
        # 3. كشف الموقع - استخدام LocationManager + أنماط إضافية
        location_detected = False
        
        # أولاً: استخدام LocationManager
        try:
            from app.core.location.location_manager import get_location_manager
            lm = get_location_manager()
            parsed = lm.parse_location(user_message)
            if parsed.get("city") or parsed.get("district") or parsed.get("neighborhood"):
                newly_added.append("location")
                location_detected = True
        except Exception:
            pass
        
        # ثانياً: كشف أنماط لغوية للموقع
        if not location_detected:
            location_indicators = [
                "prefer", "area", "district", "neighborhood", "location", "city", 
                "in ", "at ", "near", "around", "close to", "vicinity"
            ]
            # إذا كانت الرسالة تحتوي على مؤشر موقع + كلمة قد تكون اسم مكان
            has_location_indicator = any(indicator in content_lower for indicator in location_indicators)
            # أي كلمة تبدأ بحرف كبير قد تكون اسم مكان
            has_proper_noun = any(word[0].isupper() for word in user_message.split() if len(word) > 3)
            
            if has_location_indicator and (has_proper_noun or len(user_message.split()) <= 4):
                newly_added.append("location")
        
        # 4. كشف الميزانية - أنماط دقيقة جداً
        budget_keywords = ["budget", "price", "cost", "afford", "spend", "pay", "invest"]
        has_budget_keyword = any(word in content_lower for word in budget_keywords)
        
        # كشف وحدات العملة بدقة (تجنب "m" في "room" أو "m²")
        currency_patterns = [
            "million", "tl", "lira", "thousand", 
            r"\b\d+\s*k\b",  # رقم + k
            r"\b\d+\s*m\b"   # رقم + m (ليس m² أو room)
        ]
        has_currency_unit = any(re.search(pattern, content_lower) for pattern in currency_patterns)
        
        # فقط إذا كان هناك كلمة ميزانية صريحة أو وحدة عملة مع رقم
        if has_budget_keyword or has_currency_unit:
            newly_added.append("budget")
        
        return newly_added
    
    def _create_smart_prompt(
        self,
        strategy: Dict[str, Any],
        message_type: str,
        intent: str,
        completeness: Dict[str, Any],
        entities: Dict[str, Any],
        conversation_history: List[Dict] = None,
        language: str = "en"
    ) -> str:
        """إنشاء prompt ذكي للـ LLM"""
        
        # معلومات السياق
        context_info = {
            "strategy_type": strategy["type"],
            "tone": strategy["tone"],
            "action": strategy["action"],
            "completion_percentage": completeness.get("completion_percentage", 0),
            "missing_critical": completeness.get("critical_missing", []),
            "collected_entities": entities,
            "conversation_stage": self._analyze_conversation_history(conversation_history).get("conversation_stage", "initial")
        }
        
        prompt = f"""You are RE-FusionX, a professional Turkish real estate assistant. Generate a natural, context-aware response.

CONTEXT ANALYSIS:
- Response Strategy: {strategy['type']}
- Tone: {strategy['tone']} 
- Action Required: {strategy['action']}
- Information Completeness: {completeness.get('completion_percentage', 0):.1f}%
- Missing Critical Info: {completeness.get('critical_missing', [])}
- Collected So Far: {list(entities.keys()) if entities else 'None'}

RESPONSE GUIDELINES BY STRATEGY:

1. SIMPLE_GREETING: Just a friendly greeting, no property questions
2. COMPREHENSIVE_INITIAL_REQUEST: Welcome + explain why details matter + request all info
3. PROGRESSIVE_ACKNOWLEDGMENT: Acknowledge new info + ask for next specific item
4. FOCUSED_COMPLETION_REQUEST: Focus on remaining critical missing items only
5. FULL_ANALYSIS_READY: Ready to provide complete analysis

TURKISH REAL ESTATE CONTEXT:
- Prices vary 300-500% between Istanbul districts
- Location (district) is most critical factor
- Size, rooms, budget are essential for analysis
- Property type affects investment strategy

TONE REQUIREMENTS:
- Natural and conversational (not template-like)
- Professional but friendly
- Acknowledge progress when info is added
- Be specific about why each detail matters
- Vary language - don't repeat same phrases

CURRENT STRATEGY: {strategy['type']}
REQUIRED ACTION: {strategy['action']}

Generate a response that feels natural and human-like, appropriate for this stage of the conversation."""

        if strategy.get("newly_added"):
            prompt += f"\n\nNEWLY ADDED INFO: {strategy['newly_added']} - Acknowledge this specifically!"
        
        return prompt
    
    def _post_process_response(self, response: str) -> str:
        """معالجة الرد بعد التوليد"""
        
        # إزالة JSON أو تنسيقات غير مرغوبة
        if response.startswith('{') and response.endswith('}'):
            try:
                parsed = json.loads(response)
                response = parsed.get("response", response)
            except:
                pass
        
        # إضافة توقيع النظام
        if not any(name in response for name in [SystemInfo.NAME, "RE-FusionX"]):
            response += f"\n\n---\n**{SystemInfo.NAME} v{SystemInfo.VERSION}** - {SystemInfo.SPECIALIZATION}\nby {SystemInfo.DEVELOPER}"
        
        return response.strip()

    def _build_initial_info_request(self, entities: Dict[str, Any], language: str = "en") -> str:
        """بناء رسالة الطلب الأولي المنظمة ديناميكياً (بنفس الأقسام والأيقونات)."""
        # نجمع ما توفر لإظهاره في Information Collected
        loc = entities.get("location", {}) if isinstance(entities, dict) else {}
        prop = entities.get("property", {}) if isinstance(entities, dict) else {}
        fin = entities.get("financial", {}) if isinstance(entities, dict) else {}

        collected = []
        if loc.get("city"): collected.append(f"• City: {loc.get('city')}")
        if loc.get("district"): collected.append(f"• District: {loc.get('district')}")
        if prop.get("type") or prop.get("property_type"): collected.append(f"• Property Type: {prop.get('type') or prop.get('property_type')}")
        if prop.get("rooms"): collected.append(f"• Room Configuration: {prop.get('rooms')}")
        if prop.get("size"): collected.append(f"• Property Size: {prop.get('size')} m²")
        if fin.get("budget"): collected.append(f"• Budget Range: {fin.get('budget'):,} TL")

        header = "🏠 Real Estate Search Assistant - RE-FusionX v2.0.0"
        parts = [header]
        if collected:
            parts.append("\n✅ Information Collected:")
            parts.append("\n" + "\n".join(collected))

        parts.append("\n\n📋 For Accurate Analysis, I Need:")
        parts.append(
            "\n1. 📐 Property Size: Square meters"
            "\n2. 🏠 Room Configuration: (e.g., 2+1, 3+1, 4+1)"
            "\n3. 🏢 Property Type: Apartment, Villa, Commercial, etc."
            "\n4. 💰 Budget Range: Your investment budget (crucial for property recommendations)"
            "\n5. 🎯 Investment Purpose: Buy, rent, or invest (affects analysis approach)"
        )

        parts.append("\n\n❓ Why These Details Matter:")
        parts.append(
            "\n• Accurate Price Analysis: Market values change significantly by area and property specifications"
            "\n• Targeted Recommendations: Finding properties that match your exact needs"
            "\n• Investment Strategy: Different areas offer different ROI potential"
            "\n• Negotiation Power: Knowing market ranges helps in price discussions"
        )

        parts.append(
            "\n\n💡 You can provide details gradually - I'll build our analysis step by step, or give me everything at once for a comprehensive evaluation."
        )
        parts.append(
            "\n\nExample: \"I'm looking for a 3+1 apartment, around 120m², budget 6-8 million TL, in Kadıköy or Beşiktaş, for family living.\""
        )

        return "\n".join(parts)

    def _build_progressive_request(
        self,
        strategy: Dict[str, Any],
        completeness: Dict[str, Any],
        entities: Dict[str, Any],
        language: str = "en"
    ) -> str:
        """بناء رد تقدمي ذكي: تعليق على المعلومة الجديدة + قائمة منظمة بالحقول الباقية."""
        newly_added = strategy.get("newly_added", []) if isinstance(strategy, dict) else []
        prop = entities.get("property", {}) if isinstance(entities, dict) else {}
        loc = entities.get("location", {}) if isinstance(entities, dict) else {}
        fin = entities.get("financial", {}) if isinstance(entities, dict) else {}

        # 1) تعليق سياقي موجز
        if "size" in newly_added and prop.get("size"):
            s = prop.get("size")
            if isinstance(s, (int, float)) and s >= 150:
                ack = f"Excellent! {s} m² is very spacious — great for families."
            elif isinstance(s, (int, float)) and s >= 100:
                ack = f"Great choice! {s} m² is a comfortable size for most families."
            else:
                ack = f"Good! {s} m² is practical and efficient."
        elif "rooms" in newly_added and prop.get("rooms"):
            r = str(prop.get("rooms"))
            if "3+1" in r:
                ack = "Excellent room layout — 3+1 suits families very well."
            elif "2+1" in r:
                ack = "Great — 2+1 is popular with strong demand."
            else:
                ack = f"Noted your room preference ({r})."
        elif "location" in newly_added:
            if loc.get("district"):
                ack = f"Excellent location choice — {loc.get('district')} is a strong district."
            elif loc.get("city"):
                ack = f"Great — {loc.get('city')} has many promising districts."
            else:
                ack = "Perfect location choice!"
        elif "budget" in newly_added and fin.get("budget"):
            ack = "Good budget range — this helps narrow the search effectively."
        else:
            # إذا لم نكشف معلومة محددة، استخدم رد عام
            ack = "Perfect! I've noted that information."

        # 2) قائمة دقيقة بالحقول الباقية بناء على الموجود فعلياً
        missing_lines = []
        
        # فحص الموقع
        if not (loc.get("district") or loc.get("neighborhood")):
            # إذا لم يكن لدينا مدينة أصلاً
            if not loc.get("city"):
                missing_lines.append("- 📍 City and District")
            else:
                # لدينا مدينة لكن نحتاج منطقة/حي
                missing_lines.append("- 📍 District/Neighborhood")
        
        # فحص خصائص العقار
        if not prop.get("size"):
            missing_lines.append("- 📐 Property Size (m²)")
        if not prop.get("rooms"):
            missing_lines.append("- 🏠 Room Configuration (e.g., 2+1, 3+1)")
        
        # فحص الميزانية
        if not (fin.get("budget") or fin.get("budget_min") or fin.get("budget_max")):
            missing_lines.append("- 💰 Budget Range")

        if not missing_lines:
            missing_lines.append("- Any additional details that would help")

        return f"{ack}\n\nI still need:\n" + "\n".join(missing_lines)
    
    def _generate_fallback_smart_response(
        self, 
        strategy: Dict[str, Any], 
        completeness: Dict[str, Any], 
        entities: Dict[str, Any],
        language: str = "en"
    ) -> str:
        """رد احتياطي ذكي بدون LLM"""
        
        completion_pct = completeness.get("completion_percentage", 0)
        critical_missing = completeness.get("critical_missing", [])
        
        if strategy["type"] == "simple_greeting":
            return "Hello! 👋 I'm your Turkish real estate assistant. How can I help you today?"
        
        elif strategy["type"] == "comprehensive_initial_request":
            return """🏠 Real Estate Search Assistant - RE-FusionX v2.0.0

Thank you for your interest in Turkish real estate! I understand you're looking for properties.

📋 For Accurate Analysis, I Need:

1. 📍 Location Details: Specific district/neighborhood (essential for accurate pricing)
2. 📐 Property Size: Square meters
3. 🏠 Room Configuration: (e.g., 2+1, 3+1, 4+1)
4. 🏢 Property Type: Apartment, Villa, Commercial, etc.
5. 💰 Budget Range: Your investment budget (crucial for property recommendations)
6. 🎯 Investment Purpose: Buy, rent, or invest (affects analysis approach)

🎯 Why These Details Matter:

Turkish real estate prices vary dramatically by location - even within the same city, prices can differ by 300-500% between districts. Property size, layout, and your budget are equally crucial for:

• Accurate Price Analysis: Market values change significantly by area and property specifications
• Targeted Recommendations: Finding properties that match your exact needs
• Investment Strategy: Different areas offer different ROI potential
• Negotiation Power: Knowing market ranges helps in price discussions

💡 You can provide details gradually - I'll build our analysis step by step, or give me everything at once for a comprehensive evaluation.

Example: "I'm looking for a 3+1 apartment, around 120m², budget 6-8 million TL, in Kadıköy or Beşiktaş, for family living.\""""
        
        elif strategy["type"] == "progressive_acknowledgment":
            # استخدام الطريقة المحسّنة الجديدة
            return self._build_progressive_request(strategy, completeness, entities, language)
        
        elif strategy["type"] == "focused_completion_request":
            missing_text = "I just need a few more details: "
            if "location" in critical_missing:
                missing_text += "specific district, "
            if "financial" in critical_missing:
                missing_text += "budget range, "
            if "property" in critical_missing:
                missing_text += "property size, "
            
            return missing_text.rstrip(", ") + " - then I can provide accurate analysis!"
        
        # افتراضي
        return f"I have {completion_pct:.0f}% of the needed information. Could you provide the missing details for a complete analysis?"
    
    def _generate_emergency_fallback(self, message_type: str, intent: str) -> str:
        """رد طوارئ في حالة فشل كل شيء"""
        
        if message_type == "greeting":
            return "Hello! I'm here to help with Turkish real estate. What can I assist you with?"
        
        return "I'm your Turkish real estate assistant. Please tell me about the property you're interested in!"
    
    async def _handle_cached_analysis_response(
    self,
    response_strategy: Dict[str, Any],
    completeness: Dict[str, Any],
    entities: Dict[str, Any],
    language: str,
    context: Dict[str, Any]
) -> str:
        """
        Handle responses when we have cached analysis
        """
        try:
            cached_analysis = response_strategy.get("cached_analysis", {})
            cached_property = response_strategy.get("cached_property", {})
            strategy_type = response_strategy.get("type")
            
            if strategy_type == "constraint_with_analysis":
                # المستخدم يذكر قيود (مثل الميزانية)
                budget = entities.get("search_criteria", {}).get("budget")
                estimated_price = cached_analysis.get("price_estimation", {}).get("estimated_price", 0)
                
                if budget and estimated_price:
                    if budget < estimated_price * 0.8:
                        if language == "en":
                            return f"""I understand your budget constraint of ₺{budget:,.0f}. The analyzed property is priced at ₺{estimated_price:,.0f}, which is above your range.

    **Here's what I recommend:**

    1. **Similar Properties in Budget:** Based on the market analysis, properties with similar features in nearby areas like {self._get_cheaper_areas(cached_property.get('location', ''))} typically cost 20-30% less.

    2. **Negotiation Potential:** The current market shows {cached_analysis.get('market_analysis', {}).get('negotiation_margin', '5-10%')} negotiation room. You might bring it closer to ₺{estimated_price * 0.9:,.0f}.

    3. **Alternative Options:** Consider:
    • Slightly smaller units (10-15 m² less) can save 15-20%
    • Buildings 5+ years older typically cost 10-15% less
    • One floor lower can save 5-8%

    Would you like me to search for specific alternatives within your budget?"""
                        else:
                            return self._translate_response(response, language)
                            
            elif strategy_type == "alternatives_with_analysis":
                # المستخدم يطلب بدائل
                similar_props = cached_analysis.get("similar_properties", [])
                if similar_props:
                    if language == "en":
                        response = f"""Based on your interest in the {cached_property.get('rooms', 'N/A')} property in {cached_property.get('location', 'N/A')}, here are excellent alternatives:

    **Top Alternatives:**
    """
                        for i, prop in enumerate(similar_props[:3], 1):
                            response += f"""
    {i}. **{prop.get('district', 'N/A')}** - {prop.get('rooms', 'N/A')} ({prop.get('size', 'N/A')} m²)
    • Price: ₺{prop.get('price', 0):,.0f} ({self._compare_price(prop.get('price', 0), cached_analysis.get('price_estimation', {}).get('estimated_price', 0))})
    • Key Feature: {prop.get('key_feature', 'Modern building')}
    • Match Score: {prop.get('similarity_score', 0)*100:.0f}%
    """
                        response += "\nWould you like detailed analysis for any of these?"
                        return response
                        
            elif strategy_type == "investment_question_with_analysis":
                # سؤال عن الاستثمار
                investment_data = cached_analysis.get("investment_analysis", {})
                if language == "en":
                    return f"""**Investment Analysis for This Property:**

    📊 **Investment Score:** {investment_data.get('investment_score', 'N/A')}/10

    **Key Investment Metrics:**
    • **Rental Yield:** {investment_data.get('rental_yield', 'N/A')}% annually
    • **Expected ROI:** {investment_data.get('roi_potential', 'N/A')}
    • **Payback Period:** {investment_data.get('payback_period', 'N/A')} years
    • **5-Year Appreciation:** {investment_data.get('appreciation_forecast', '+15-20%')}

    **Investment Verdict:** {self._get_investment_verdict(investment_data.get('investment_score', 0))}

    The area shows {cached_analysis.get('market_analysis', {}).get('growth_forecast', 'stable')} growth potential with {cached_analysis.get('market_analysis', {}).get('demand_level', 'moderate')} demand.

    Would you like a comparison with other investment options in your budget range?"""
                    
            else:
                # سؤال عام عن التحليل
                return await self._generate_contextual_analysis_response(
                    cached_analysis, cached_property, entities, language
                )
                
        except Exception as e:
            agent_logger.error("SmartResponseGenerator", f"Error handling cached analysis: {e}")
            return self._generate_fallback_smart_response(response_strategy, completeness, entities, language)

    def _get_cheaper_areas(self, current_location: str) -> str:
        """Get cheaper alternative areas"""
        # This would ideally use a database of area relationships
        area_alternatives = {
            "Kadıköy": "Maltepe or Kartal",
            "Beşiktaş": "Kağıthane or Eyüp",
            "Şişli": "Kağıthane or Sarıyer",
            "Bakırköy": "Küçükçekmece or Başakşehir"
        }
        return area_alternatives.get(current_location, "nearby developing areas")

    def _compare_price(self, price1: float, price2: float) -> str:
        """Compare two prices and return a description"""
        if price1 < price2 * 0.9:
            return f"{((price2 - price1) / price2 * 100):.0f}% cheaper"
        elif price1 > price2 * 1.1:
            return f"{((price1 - price2) / price2 * 100):.0f}% more expensive"
        else:
            return "similarly priced"

    def _get_investment_verdict(self, score: float) -> str:
        """Get investment verdict based on score"""
        if score >= 8:
            return "Excellent investment opportunity with high growth potential"
        elif score >= 6:
            return "Good investment with moderate returns expected"
        elif score >= 4:
            return "Fair investment, consider for long-term holding"
        else:
            return "Higher risk investment, thorough due diligence recommended"

    async def _generate_contextual_analysis_response(
        self,
        cached_analysis: Dict[str, Any],
        cached_property: Dict[str, Any],
        entities: Dict[str, Any],
        language: str
    ) -> str:
        """Generate contextual response about the analysis"""
        try:
            # Use the model if available
            if self.model_loader:
                prompt = f"""Based on this property analysis, answer the user's question:
                
    Property: {cached_property.get('rooms', 'N/A')} in {cached_property.get('location', 'N/A')}
    Price: ₺{cached_analysis.get('price_estimation', {}).get('estimated_price', 0):,.0f}
    Investment Score: {cached_analysis.get('investment_analysis', {}).get('investment_score', 'N/A')}/10

    Provide a helpful, concise response in {language}."""
                
                # Generate response using model
                response = await self.model_loader.generate_response(prompt)
                return response
                
        except Exception as e:
            agent_logger.error("SmartResponseGenerator", f"Error generating contextual response: {e}")
            
        # Fallback response
        if language == "en":
            return f"""Based on the comprehensive analysis of this {cached_property.get('rooms', 'property')} in {cached_property.get('location', 'Istanbul')}:

    • Estimated Value: ₺{cached_analysis.get('price_estimation', {}).get('estimated_price', 0):,.0f}
    • Market Position: {cached_analysis.get('market_analysis', {}).get('market_position', 'Competitive')}
    • Investment Potential: {cached_analysis.get('investment_analysis', {}).get('roi_potential', 'Moderate')}

    What specific aspect would you like to know more about?"""
        else:
            return self._translate_response(response, language)

