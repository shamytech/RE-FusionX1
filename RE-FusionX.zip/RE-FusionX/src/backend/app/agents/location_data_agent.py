# D:\Phd\RE-FusionX\src\backend\app\agents\location_data_agent.py
"""
Location Data Agent - Fetches location data only
Returns structured location data without analysis

# الغرض: جلب بيانات الموقع
# المدخلات: اسم الموقع
# المخرجات: معلومات جغرافية وخدمات

الوظائف:
- الخدمات القريبة
- المسافات للأماكن المهمة
- البيانات الديموغرافية
- البنية التحتية

مثال المخرجات:
{
  "amenities": {"schools": [...], "hospitals": [...]},
  "distances": {"metro": 500, "seaside": 800},
  "demographics": {"income_level": "high"}
}

"""

from typing import Dict, Any, List, Optional
from datetime import datetime

from app.agents.base_agent import DataAgent
from app.core.logging import agent_logger, logger
from app.utils.location_utils import get_location_manager
from app.core.storage.integration import StorageIntegration
from app.core.storage.unified_cache import CacheType


class LocationDataAgent(DataAgent):
    """
    Location Data Agent - Fetches location-related data only
    No analysis, no recommendations, just location facts
    """
    
    def __init__(self, model_loader=None):
        super().__init__(
            name="LocationDataAgent",
            description="Fetches location data, amenities, and geographic information",
            capabilities=[
                "Location details retrieval",
                "Amenity information",
                "Distance calculations",
                "Demographic data",
                "Infrastructure information",
                "Points of interest"
            ],
            data_sources=["geographic_db", "amenity_apis", "demographic_data"]
        )
        
        self.model_loader = model_loader
        self._storage = None
        self._cache = None
        self.location_manager = get_location_manager()
        
        agent_logger.agent_start(self.name, "Location data agent initialized", {
            "sources": self.data_sources
        })
    
    @property
    def storage(self):
        """Lazy load storage"""
        if self._storage is None:
            self._storage = StorageIntegration.get_storage()
        return self._storage
    
    @property
    def cache(self):
        """Lazy load cache"""
        if self._cache is None:
            self._cache = StorageIntegration.get_cache()
        return self._cache
    
    async def validate_input(self, input_data: Dict[str, Any]) -> bool:
        """Validate input has location information"""
        has_location = bool(
            input_data.get("location") or 
            input_data.get("city") or 
            input_data.get("district") or
            input_data.get("coordinates")
        )
        
        if not has_location:
            agent_logger.warning(self.name, "No location information provided")
        
        return has_location
    
    async def fetch_data(self, criteria: Dict[str, Any], context: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Fetch location data based on criteria
        """
        try:
            # agent_logger.info(self.name, f"🔍 DEBUG - Input criteria: {criteria}")  # علّق هذا
            
            location = criteria.get("location", "")
            city = criteria.get("city", "")
            district = criteria.get("district", "")
            coordinates = criteria.get("coordinates")
            data_type = criteria.get("data_type", "full")
            
            # Build location string
            if not location and (city or district):
                location = f"{city} - {district}" if city and district else city or district
            
            if not location:
                location = "Istanbul"
            
            agent_logger.agent_action(self.name, "Fetching location data", {
                "location": location,
                "data_type": data_type,
                "has_coordinates": bool(coordinates)
            })
            
            result = {}
            
            # 1. Get basic location information
            if data_type in ["full", "basic"]:
                result["location_info"] = await self._fetch_location_info(location, city, district)
            
            # 2. Get amenities
            if data_type in ["full", "amenities"]:
                result["amenities"] = await self._fetch_amenities(location, coordinates)
            
            # 3. Get distances
            if data_type in ["full", "distances"]:
                result["distances"] = await self._fetch_distances(location, coordinates)
            
            # 4. Get demographic data
            if data_type in ["full", "demographics"]:
                result["demographics"] = await self._fetch_demographics(location)
            
            # 5. Get infrastructure
            if data_type in ["full", "infrastructure"]:
                result["infrastructure"] = await self._fetch_infrastructure(location)
            
            # 6. Get points of interest
            if data_type in ["full", "poi"]:
                result["points_of_interest"] = await self._fetch_poi(location, coordinates)
            
            agent_logger.info(self.name, "📍 Location data fetched", {
                "sections": list(result.keys()),
                "location": location
            })
            
            return result
        
        except Exception as e:
            logger.error(f"Location data fetch error: {str(e)}", exc_info=True)
            # إرجاع بيانات افتراضية بدلاً من رفع خطأ
            return {
                "location_info": {
                    "city": "Istanbul",
                    "district": criteria.get("district", "Kadıköy"),
                    "city_tier": 1,
                    "error": f"Using default data due to: {str(e)}"
                },
                "amenities": {},
                "distances": {
                    "city_center": 10000,
                    "nearest_metro": 1000
                }
            }

    async def _fetch_location_info(self, location: str, city: str, district: str) -> Dict[str, Any]:
        """Fetch basic location information"""
        
        # Parse location with location manager
        location_info = self.location_manager.parse_location(location)
        
        # Override with specific values if provided
        if city:
            location_info["city"] = city
        if district:
            location_info["district"] = district
        
        # ✅ تعريف city_name قبل استخدامه
        city_name = location_info.get("city", "Istanbul")
        
        # استخدم بيانات ثابتة أو من قاعدة البيانات
        city_data = {
            "region": "Marmara" if city_name.lower() in ["istanbul", "bursa", "kocaeli"] else "Unknown",
            "population": 15000000 if city_name.lower() == "istanbul" else 1000000,
            "area": 5461 if city_name.lower() == "istanbul" else 1000,
            "elevation": 100,
            "climate": "temperate",
            "economic_importance": "high" if city_name.lower() in ["istanbul", "ankara", "izmir"] else "medium",
            "tourism_level": "high" if city_name.lower() in ["istanbul", "antalya"] else "moderate",
            "coordinates": {"lat": 41.0082, "lon": 28.9784} if city_name.lower() == "istanbul" else {},
            "postal_codes": []
        }
        
        info = {
            "city": location_info.get("city"),
            "district": location_info.get("district"),
            "neighborhood": location_info.get("neighborhood"),
            "region": city_data.get("region", "Unknown"),
            "city_tier": self._determine_city_tier(location_info.get("city")),
            "population": city_data.get("population", 0),
            "area_sqkm": city_data.get("area", 0),
            "elevation_m": city_data.get("elevation", 0),
            "climate": city_data.get("climate", "temperate"),
            "economic_importance": city_data.get("economic_importance", "medium"),
            "tourism_level": city_data.get("tourism_level", "moderate"),
            "coordinates": city_data.get("coordinates", {}),
            "postal_codes": city_data.get("postal_codes", [])
        }
        
        return info

    async def _fetch_amenities(self, location: str, coordinates: Optional[Dict[str, Any]]) -> Dict[str, Any]:
        """Fetch nearby amenities"""
        
        try:
            # Check cache - استخدم string بسيط بدلاً من CacheType
            cache_key = f"location:amenities:{location}"
            
            # جرب الحصول من الكاش
            try:
                cached = await self.cache.get(cache_key)
                if cached:
                    return cached
            except:
                pass  # تجاهل أخطاء الكاش
            
            # Default amenities structure
            amenities = {
                "education": {
                    "schools": [],
                    "universities": [],
                    "libraries": []
                },
                "healthcare": {
                    "hospitals": [],
                    "clinics": [],
                    "pharmacies": []
                },
                "shopping": {
                    "malls": [],
                    "markets": [],
                    "stores": []
                },
                "transportation": {
                    "metro_stations": [],
                    "bus_stops": [],
                    "airports": []
                },
                "recreation": {
                    "parks": [],
                    "sports_facilities": [],
                    "entertainment": []
                },
                "services": {
                    "banks": [],
                    "post_offices": [],
                    "government_offices": []
                }
            }
            
            # Add sample data based on location
            location_lower = location.lower()
            if "kadıköy" in location_lower or "kadikoy" in location_lower:
                amenities["transportation"]["metro_stations"] = [
                    {"name": "Kadıköy Metro", "distance_m": 500},
                    {"name": "Ayrılık Çeşmesi", "distance_m": 1200}
                ]
                amenities["shopping"]["malls"] = [
                    {"name": "Akasya AVM", "distance_m": 3000},
                    {"name": "Capitol AVM", "distance_m": 4500}
                ]
                amenities["education"]["universities"] = [
                    {"name": "Marmara University", "distance_m": 2500}
                ]
                amenities["healthcare"]["hospitals"] = [
                    {"name": "Acıbadem Kadıköy", "distance_m": 1200}
                ]
            elif "beşiktaş" in location_lower or "besiktas" in location_lower:
                amenities["transportation"]["metro_stations"] = [
                    {"name": "Beşiktaş Metro", "distance_m": 400}
                ]
                amenities["shopping"]["malls"] = [
                    {"name": "Zorlu Center", "distance_m": 2000}
                ]
            
            # حاول حفظ في الكاش
            try:
                # استخدم set بسيط بدون CacheType
                await self.cache.set(
                    cache_key,
                    amenities,
                    ttl_override=86400  # 24 hours
                )
            except:
                pass  # تجاهل أخطاء الكاش
            
            return amenities
            
        except Exception as e:
            logger.error(f"Error in _fetch_amenities: {str(e)}")
            # Return default structure on error
            return {
                "education": {"schools": [], "universities": [], "libraries": []},
                "healthcare": {"hospitals": [], "clinics": [], "pharmacies": []},
                "shopping": {"malls": [], "markets": [], "stores": []},
                "transportation": {"metro_stations": [], "bus_stops": [], "airports": []},
                "recreation": {"parks": [], "sports_facilities": [], "entertainment": []},
                "services": {"banks": [], "post_offices": [], "government_offices": []}
            }

    async def _fetch_distances(self, location: str, coordinates: Optional[Dict[str, Any]]) -> Dict[str, Any]:
        """Fetch distances to key points"""
        
        distances = {
            "city_center": 0,
            "nearest_metro": 0,
            "nearest_hospital": 0,
            "nearest_school": 0,
            "nearest_mall": 0,
            "airport": 0,
            "seaside": 0,
            "main_highway": 0
        }
        
        # Sample distances based on location
        if "kadıköy" in location.lower():
            distances.update({
                "city_center": 8500,  # meters
                "nearest_metro": 500,
                "nearest_hospital": 1200,
                "nearest_school": 300,
                "nearest_mall": 3000,
                "airport": 35000,  # Sabiha Gökçen
                "seaside": 800,
                "main_highway": 2000
            })
        elif "beşiktaş" in location.lower():
            distances.update({
                "city_center": 5000,
                "nearest_metro": 400,
                "nearest_hospital": 1000,
                "nearest_school": 400,
                "nearest_mall": 2000,
                "airport": 40000,  # Istanbul Airport
                "seaside": 500,
                "main_highway": 1500
            })
        else:
            # Default distances
            distances.update({
                "city_center": 10000,
                "nearest_metro": 1500,
                "nearest_hospital": 2000,
                "nearest_school": 800,
                "nearest_mall": 5000,
                "airport": 45000,
                "seaside": 10000,
                "main_highway": 3000
            })
        
        return distances
    
    async def _fetch_demographics(self, location: str) -> Dict[str, Any]:
        """Fetch demographic data"""
        
        demographics = {
            "population_density": 0,
            "average_age": 35,
            "household_size": 3.2,
            "income_level": "medium",  # low, medium, high
            "education_level": "high",  # low, medium, high
            "employment_rate": 0.65,
            "foreign_residents_pct": 5.0,
            "growth_rate": 2.5,  # annual %
            "urbanization_level": "high",  # low, medium, high
            "socioeconomic_score": 7.0  # 1-10
        }
        
        # Adjust based on location
        if "kadıköy" in location.lower() or "beşiktaş" in location.lower():
            demographics.update({
                "population_density": 15000,  # per sqkm
                "income_level": "high",
                "education_level": "high",
                "employment_rate": 0.75,
                "foreign_residents_pct": 8.0,
                "socioeconomic_score": 8.5
            })
        elif "fatih" in location.lower():
            demographics.update({
                "population_density": 20000,
                "income_level": "medium",
                "education_level": "medium",
                "employment_rate": 0.60,
                "foreign_residents_pct": 15.0,
                "socioeconomic_score": 6.5
            })
        
        return demographics
    
    async def _fetch_infrastructure(self, location: str) -> Dict[str, Any]:
        """Fetch infrastructure information"""
        
        infrastructure = {
            "public_transport": {
                "metro_lines": [],
                "bus_routes": 0,
                "ferry_lines": [],
                "tram_lines": []
            },
            "utilities": {
                "electricity": "stable",
                "water": "reliable",
                "gas": "available",
                "internet": "fiber available"
            },
            "roads": {
                "main_roads": [],
                "traffic_level": "moderate",  # low, moderate, high
                "parking": "limited"  # abundant, moderate, limited
            },
            "development": {
                "new_projects": 0,
                "urban_renewal": False,
                "infrastructure_investment": "moderate"
            }
        }
        
        # Adjust based on location
        if "kadıköy" in location.lower():
            infrastructure["public_transport"]["metro_lines"] = ["M4"]
            infrastructure["public_transport"]["bus_routes"] = 25
            infrastructure["public_transport"]["ferry_lines"] = ["Kadıköy-Eminönü", "Kadıköy-Beşiktaş"]
            infrastructure["roads"]["traffic_level"] = "high"
            infrastructure["development"]["new_projects"] = 5
        
        return infrastructure
    
    async def _fetch_poi(self, location: str, coordinates: Optional[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Fetch points of interest"""
        
        poi = []
        
        # Add POIs based on location
        if "kadıköy" in location.lower():
            poi = [
                {"name": "Moda Beach", "type": "recreation", "distance_m": 1500},
                {"name": "Bagdat Avenue", "type": "shopping", "distance_m": 2000},
                {"name": "Fenerbahce Park", "type": "park", "distance_m": 3000},
                {"name": "Kadıköy Market", "type": "market", "distance_m": 500},
                {"name": "Süreyya Opera House", "type": "culture", "distance_m": 800}
            ]
        elif "beşiktaş" in location.lower():
            poi = [
                {"name": "Dolmabahce Palace", "type": "tourism", "distance_m": 1000},
                {"name": "Vodafone Park", "type": "sports", "distance_m": 1500},
                {"name": "Zorlu Center", "type": "shopping", "distance_m": 2000},
                {"name": "Yıldız Park", "type": "park", "distance_m": 2500},
                {"name": "Bosphorus Shore", "type": "recreation", "distance_m": 500}
            ]
        
        return poi
    
    def _determine_city_tier(self, city: str) -> int:
        """Determine city tier (1-5, 1 being major city)"""
        
        tier_1 = ["istanbul", "ankara", "izmir"]
        tier_2 = ["bursa", "antalya", "adana", "konya", "gaziantep"]
        tier_3 = ["kayseri", "mersin", "eskişehir", "diyarbakır", "samsun"]
        
        city_lower = city.lower() if city else ""
        
        if city_lower in tier_1:
            return 1
        elif city_lower in tier_2:
            return 2
        elif city_lower in tier_3:
            return 3
        else:
            return 4  # Smaller cities
        
'''

الغرض: جلب بيانات الموقع والخدمات والبنية التحتية
المدخلات: اسم الموقع أو الإحداثيات
المخرجات: معلومات جغرافية وخدمات محيطة

مصادر البيانات:
  - Geographic Database: بيانات المدن والمناطق
  - Amenity APIs: الخدمات القريبة
  - Demographic Database: البيانات السكانية
  - Infrastructure DB: البنية التحتية

العمليات:
  1. تحليل الموقع الجغرافي
  2. حساب المسافات للخدمات
  3. جمع البيانات الديموغرافية
  4. تقييم البنية التحتية

# المدخل
{
  "city": "Istanbul",
  "district": "Kadıköy",
  "data_type": "full"
}

# المخرج
{
  "location_info": {
    "city": "Istanbul",
    "district": "Kadıköy",
    "neighborhood": null,
    "region": "Marmara",
    "city_tier": 1,  # مدينة رئيسية
    "population": 520000,  # سكان المنطقة
    "area_sqkm": 25,
    "elevation_m": 30,
    "climate": "temperate",
    "economic_importance": "high",
    "tourism_level": "high",
    "coordinates": {"lat": 40.9892, "lon": 29.0341},
    "postal_codes": ["34710", "34714", "34716"]
  },
  "amenities": {
    "education": {
      "schools": [
        {"name": "Kadıköy Anadolu Lisesi", "distance_m": 450, "rating": 4.5},
        {"name": "Saint Joseph", "distance_m": 800, "rating": 4.7}
      ],
      "universities": [
        {"name": "Marmara University", "distance_m": 2500, "campus": "Medicine"}
      ],
      "libraries": [
        {"name": "Kadıköy Public Library", "distance_m": 600}
      ]
    },
    "healthcare": {
      "hospitals": [
        {"name": "Acıbadem Kadıköy", "distance_m": 1200, "type": "private"},
        {"name": "Göztepe Training Hospital", "distance_m": 3500, "type": "public"}
      ],
      "clinics": [/* 5 clinics */],
      "pharmacies": [/* 12 pharmacies */]
    },
    "shopping": {
      "malls": [
        {"name": "Akasya AVM", "distance_m": 3000, "stores": 250},
        {"name": "Capitol AVM", "distance_m": 4500, "stores": 150}
      ],
      "markets": [/* local markets */],
      "stores": [/* chain stores */]
    },
    "transportation": {
      "metro_stations": [
        {"name": "Kadıköy Metro", "line": "M4", "distance_m": 500},
        {"name": "Ayrılık Çeşmesi", "line": "M4", "distance_m": 1200}
      ],
      "bus_stops": [/* 8 stops */],
      "ferry_terminals": [
        {"name": "Kadıköy İskelesi", "routes": ["Eminönü", "Beşiktaş"], "distance_m": 700}
      ]
    },
    "recreation": {
      "parks": [
        {"name": "Moda Coastal Park", "distance_m": 1500, "area_sqm": 25000},
        {"name": "Fenerbahçe Park", "distance_m": 3000, "area_sqm": 45000}
      ],
      "sports_facilities": [/* gyms, stadiums */],
      "entertainment": [/* cinemas, theaters */]
    }
  },
  "distances": {
    "city_center": 8500,
    "nearest_metro": 500,
    "nearest_hospital": 1200,
    "nearest_school": 450,
    "nearest_mall": 3000,
    "airport": 35000,  # Sabiha Gökçen
    "seaside": 800,
    "main_highway": 2000,
    "bosphorus_bridge": 12000
  },
  "demographics": {
    "population_density": 20800,  # per sqkm
    "average_age": 38,
    "household_size": 2.8,
    "income_level": "high",
    "education_level": "high",
    "employment_rate": 0.72,
    "foreign_residents_pct": 8.5,
    "growth_rate": 1.8,
    "urbanization_level": "high",
    "socioeconomic_score": 8.7  # 1-10
  },
  "infrastructure": {
    "public_transport": {
      "metro_lines": ["M4"],
      "bus_routes": 28,
      "ferry_lines": ["Kadıköy-Eminönü", "Kadıköy-Beşiktaş", "Kadıköy-Üsküdar"],
      "tram_lines": ["T3 Moda Tramvay"]
    },
    "utilities": {
      "electricity": "stable",
      "water": "reliable",
      "gas": "available",
      "internet": "fiber available",
      "avg_internet_speed": "100 Mbps"
    },
    "roads": {
      "main_roads": ["Bağdat Caddesi", "Söğütlüçeşme Caddesi"],
      "traffic_level": "high",
      "parking": "limited",
      "bike_lanes": true
    },
    "development": {
      "new_projects": 7,
      "urban_renewal": true,
      "infrastructure_investment": "high",
      "green_spaces_ratio": 0.18
    }
  },
  "points_of_interest": [
    {"name": "Moda Beach", "type": "recreation", "distance_m": 1500},
    {"name": "Bağdat Avenue", "type": "shopping", "distance_m": 2000},
    {"name": "Kadıköy Market", "type": "market", "distance_m": 500},
    {"name": "Süreyya Opera House", "type": "culture", "distance_m": 800},
    {"name": "Fenerbahçe Stadium", "type": "sports", "distance_m": 3500}
  ]
}

'''
