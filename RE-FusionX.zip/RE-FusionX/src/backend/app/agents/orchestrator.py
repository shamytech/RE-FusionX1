# app/agents/orchestrator.py
"""
Agent Orchestrator - New Architecture Only
Coordinates between IntentExtractor, DataAgents, and ResponseFormatter

الغرض: تنسيق وإدارة تدفق العمل بين جميع الوكلاء
المدخلات: رسالة المستخدم + السياق (اختياري)
المخرجات: الرد النهائي المُنسق من Qwen

الدور الرئيسي:
  - المنسق المركزي للنظام
  - يدير تدفق البيانات بين الوكلاء
  - يضمن التسلسل الصحيح للعمليات
  - يعالج الأخطاء ويوفر fallbacks

التقنيات المستخدمة:
  - Async/Await للمعالجة المتوازية
  - Lazy Loading للموارد
  - Error Handling الشامل
  - Structured Logging

الموارد المُدارة:
  - Storage Integration (PostgreSQL)
  - Cache Integration (Redis)
  - WebSocket Manager (real-time updates)
  - Model Loader (Qwen)

"""

from typing import Dict, Any, List, Optional
from datetime import datetime
import uuid

from app.agents.base_agent import BaseAgent, AgentType
from app.core.logging import logger, agent_logger
from app.core.storage.integration import StorageIntegration
from app.core.conversation.conversation_manager import get_conversation_manager
from app.core.constants import SystemInfo


class AgentOrchestrator:
    """
    Orchestrator for new agent architecture only
    Flow: IntentExtractor → DataAgents → ResponseFormatter → Qwen
    """
    
    def __init__(
        self, 
        agents: Optional[Dict[str, BaseAgent]] = None, 
        websocket_manager: Optional[Any] = None, 
        model_loader: Optional[Any] = None
    ):
        self.agents = agents or {}
        self.ws_manager = websocket_manager
        self.model_loader = model_loader
        
        self._storage = None
        self._cache = None
        
        # Initialize all agents if model_loader provided
        if self.model_loader:
            self._initialize_agents()
        
        agent_logger.info("Orchestrator", f"🎯 Initialized with {len(self.agents)} agents", {
            "agents": list(self.agents.keys())
        })

    @property
    def storage(self):
        """Lazy load storage"""
        if self._storage is None:
            self._storage = StorageIntegration.get_storage()
        return self._storage
    
    @property
    def cache(self):
        """Lazy load cache"""
        if self._cache is None:
            self._cache = StorageIntegration.get_cache()
        return self._cache
    
    def _initialize_agents(self):
        """Initialize all agents - Updated to use unified system"""
        
        # 1. Unified Conversation Agent (replaces Intent Extractor + Context Manager)
        try:
            from app.agents.unified_conversation_agent import UnifiedConversationAgent
            self.agents['conversation'] = UnifiedConversationAgent(self.model_loader)
            agent_logger.info("Orchestrator", "✅ UnifiedConversationAgent loaded (replaces Intent+Context)")
        except Exception as e:
            logger.error(f"❌ UnifiedConversationAgent failed to load: {e}")
            # No fallback needed - UnifiedConversationAgent is required
            logger.critical("❌ UnifiedConversationAgent is required for system operation!")
            raise e
        
        # 2. Response Formatter Agent
        try:
            from app.agents.response_formatter_agent import ResponseFormatterAgent
            self.agents['response_formatter'] = ResponseFormatterAgent(self.model_loader)
            agent_logger.info("Orchestrator", "✅ ResponseFormatterAgent loaded")
        except Exception as e:
            logger.error(f"❌ ResponseFormatterAgent failed to load: {e}")
        
        # 3. Property Data Agent
        try:
            from app.agents.property_data_agent import PropertyDataAgent
            self.agents['property_data'] = PropertyDataAgent(self.model_loader)
            agent_logger.info("Orchestrator", "✅ PropertyDataAgent loaded")
        except Exception as e:
            logger.warning(f"PropertyDataAgent not available: {e}")
        
        # 4. Market Data Agent
        try:
            from app.agents.market_data_agent import MarketDataAgent
            self.agents['market_data'] = MarketDataAgent(self.model_loader)
            agent_logger.info("Orchestrator", "✅ MarketDataAgent loaded")
        except Exception as e:
            logger.warning(f"MarketDataAgent not available: {e}")
        
        # 5. Location Data Agent
        try:
            from app.agents.location_data_agent import LocationDataAgent
            self.agents['location_data'] = LocationDataAgent(self.model_loader)
            agent_logger.info("Orchestrator", "✅ LocationDataAgent loaded")
        except Exception as e:
            logger.warning(f"LocationDataAgent not available: {e}")
        
        # 6. Market Comparison Data Agent
        try:
            from app.agents.market_comparison_agent import MarketComparisonDataAgent
            self.agents['market_comparison_data'] = MarketComparisonDataAgent(self.model_loader)
            agent_logger.info("Orchestrator", "✅ MarketComparisonDataAgent loaded")
        except Exception as e:
            logger.warning(f"MarketComparisonDataAgent not available: {e}")
    
    async def process(self, input_data: Dict[str, Any], context: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Main processing method - New Architecture Only
        Enhanced with follow-up handling and completeness checking
        """
        try:
            message = input_data.get("message", "")
            
            if not message:
                return self._create_error_response("No message provided")
            
            # إضافة جديدة: استخراج معلومات المتابعة
            is_follow_up = input_data.get("is_follow_up", False)
            
            # إضافة جديدة: فحص التحليل المحفوظ
            has_cached_analysis = context and context.get("has_complete_analysis", False)
            cached_analysis = context.get("cached_analysis") if context else None
            cached_property = context.get("cached_property") if context else None
            
            # إضافة logging للتحقق من البيانات
            logger.debug(f"Cache detection - has_cached_analysis: {has_cached_analysis}")
            logger.debug(f"Cache detection - cached_analysis type: {type(cached_analysis)}")
            logger.debug(f"Cache detection - cached_property type: {type(cached_property)}")
            if cached_analysis:
                logger.debug(f"Cache detection - cached_analysis keys: {list(cached_analysis.keys()) if isinstance(cached_analysis, dict) else 'N/A'}")
            
            agent_logger.agent_action("Orchestrator", "🚀 Processing request", {
                "message_length": len(message),
                "has_context": bool(context),
                "is_follow_up": is_follow_up,
                "has_cached_analysis": has_cached_analysis  # إضافة جديدة
            })
            
            # Check for conversation agent (replaces intent_extractor)
            if 'conversation' not in self.agents and 'intent_extractor' not in self.agents:
                return self._create_error_response("Conversation processing not available")
            
            if 'response_formatter' not in self.agents:
                return self._create_error_response("Response formatter not available")
            
            # إضافة جديدة: إذا كان هناك تحليل محفوظ، تعامل معه بذكاء
            if has_cached_analysis and cached_analysis:
                agent_logger.info("Orchestrator", "📊 Using cached analysis for intelligent response")
                
                # استخراج النية والكيانات الجديدة من الرسالة
                conversation_agent = self.agents.get('conversation') or self.agents.get('intent_extractor')
                
                temp_context = context.copy() if context else {}
                temp_context["is_follow_up"] = is_follow_up

                extraction_result = await conversation_agent.process(
                    {
                        "message": message,
                        "session_id": context.get("session_id"),
                        "has_cached_context": True  # مؤشر للوكيل
                    },
                    {
                        **temp_context,
                        "cached_property": cached_property,
                        "cached_analysis": cached_analysis
                    }
                )
                
                extracted_data = extraction_result.get("result", {})
                analysis = extracted_data.get("analysis", {})
                intent = analysis.get("intent", {}).get("primary_intent", "general_inquiry")
                new_entities = analysis.get("entities", {})
                
                agent_logger.info("Orchestrator", f"📊 Cached analysis intent: {intent}", {
                    "new_entities": new_entities
                })
                
                # معالجة القيود والتحديثات
                if intent == "constraint_update" or "budget" in new_entities.get("search_criteria", {}):
                    # المستخدم يضع قيود جديدة (مثل الميزانية)
                    return await self._handle_constraint_with_cached_analysis(
                        message, cached_analysis, cached_property, new_entities, context
                    )
                elif intent == "alternatives_request" or "alternative" in message.lower() or "other" in message.lower():
                    # المستخدم يطلب بدائل
                    return await self._handle_alternatives_with_cached_analysis(
                        message, cached_analysis, cached_property, new_entities, context
                    )
                else:
                    # سؤال عام عن التحليل المحفوظ - استخدم الكود الأصلي
                    response_data = await self._get_model_response_for_analysis(
                        message, cached_analysis, cached_property, context
                    )
                    
                    return {
                        "result": response_data,
                        "metadata": {
                            "intent": "analysis_discussion",
                            "agents_used": ["cached_analysis", "model"],
                            "completeness": 1.0,
                            "has_complete_analysis": True
                        }
                    }


            
            # === Step 1: Extract Intent and Entities ===
            agent_logger.info("Orchestrator", "📋 Step 1: Extracting intent")
            
            # Use conversation agent (preferred) or fallback to intent_extractor
            conversation_agent = self.agents.get('conversation') or self.agents.get('intent_extractor')
                        
            # ========== فحص التحليل المحفوظ من الكاش أولاً ==========
            if not has_cached_analysis:  # فقط إذا لم نجده في context
                try:
                    from app.services.analysis_service import AnalysisService
                    analysis_service = AnalysisService(model_loader=None)  # للقراءة فقط
                    cached_context = await analysis_service.get_chat_context(context.get("session_id"))
                    
                    if cached_context and cached_context.get("has_analysis"):
                        has_cached_analysis = True
                        cached_analysis = cached_context.get("analysis_results")
                        cached_property = cached_context.get("property_data")
                        
                        agent_logger.info("Orchestrator", "📊 Found cached analysis in service", {
                            "session_id": context.get("session_id"),
                            "property_location": cached_property.get("location") if cached_property else None
                        })
                        
                        # ===== معالجة فورية للتحليل المحفوظ =====
                        agent_logger.info("Orchestrator", "📊 Processing with cached analysis immediately")
                        
                        # استخراج النية من الرسالة الجديدة
                        temp_context = context.copy() if context else {}
                        temp_context["is_follow_up"] = is_follow_up
                        temp_context["cached_property"] = cached_property
                        temp_context["cached_analysis"] = cached_analysis

                        extraction_result = await conversation_agent.process(
                            {
                                "message": message,
                                "session_id": context.get("session_id"),
                                "has_cached_context": True
                            },
                            temp_context
                        )
                        
                        extracted_data = extraction_result.get("result", {})
                        analysis = extracted_data.get("analysis", {})
                        intent = analysis.get("intent", {}).get("primary_intent", "general_inquiry")
                        new_entities = analysis.get("entities", {})
                        
                        agent_logger.info("Orchestrator", f"📊 Cached context - Intent: {intent}, Message: {message[:50]}")
                        
                        # معالجة خاصة للميزانية
                        if "budget" in message.lower() or "can't" in message.lower() or "cannot" in message.lower() or "expensive" in message.lower():
                            # استخراج الميزانية من الرسالة
                            import re
                            budget_match = re.search(r'(\d+(?:\.\d+)?)\s*[mM]', message)
                            if budget_match:
                                budget_value = float(budget_match.group(1)) * 1000000
                                new_entities["search_criteria"] = {"budget": budget_value}
                                agent_logger.info("Orchestrator", f"📊 Extracted budget: {budget_value}")
                            
                            return await self._handle_constraint_with_cached_analysis(
                                message, cached_analysis, cached_property, new_entities, context
                            )
                        elif "alternative" in message.lower() or "other" in message.lower() or "different" in message.lower():
                            return await self._handle_alternatives_with_cached_analysis(
                                message, cached_analysis, cached_property, new_entities, context
                            )
                        else:
                            response_data = await self._get_model_response_for_analysis(
                                message, cached_analysis, cached_property, context
                            )
                            return {
                                "result": response_data,
                                "metadata": {
                                    "intent": "analysis_discussion",
                                    "agents_used": ["cached_analysis", "model"],
                                    "completeness": 1.0,
                                    "has_complete_analysis": True
                                }
                            }
                            
                except Exception as e:
                    agent_logger.debug(f"No cached analysis in service: {e}")
            # ========== نهاية الفحص والمعالجة ==========
            
            enhanced_extraction_context["is_follow_up"] = is_follow_up
            
            extraction_result = await conversation_agent.process(
                {
                    "message": message,
                    "session_id": context.get("session_id") if context else None
                },
                enhanced_extraction_context
            )
            
            extracted_data = extraction_result.get("result", {})
            
            # Extract intent from nested analysis structure (UnifiedConversationAgent format)
            if "analysis" in extracted_data:
                analysis = extracted_data["analysis"]
                intent_data = analysis.get("intent", {})
                if isinstance(intent_data, dict):
                    intent = intent_data.get("primary_intent", "general_inquiry")
                else:
                    intent = intent_data or "general_inquiry"
                
                entities = analysis.get("entities", {})
                required_agents = analysis.get("required_agents", [])
                language = analysis.get("language", "en")
            else:
                # Fallback for old format
                intent_data = extracted_data.get("intent", {})
                if isinstance(intent_data, dict):
                    intent = intent_data.get("primary_intent", "general_inquiry")
                else:
                    intent = intent_data or "general_inquiry"
                    
                entities = extracted_data.get("entities", {})
                required_agents = extracted_data.get("required_agents", [])
                language = extracted_data.get("language", "en")
            
            # إضافة جديدة: استخراج معلومات الاكتمال
            completeness = extracted_data.get("completeness", {})
            missing_info = extracted_data.get("missing_info", [])
            ready_for_analysis = extracted_data.get("ready_for_analysis", False)
            
            agent_logger.info("Orchestrator", f"✅ Intent extracted: {intent}", {
                "required_agents": required_agents,
                "language": language,
                "has_property": bool(entities.get("property")),
                "has_location": bool(entities.get("location")),
                "is_follow_up": is_follow_up,
                "completeness": completeness.get("completion_percentage", 0),
                "ready_for_analysis": ready_for_analysis
            })
            
            # إضافة جديدة: إذا كانت المعلومات غير مكتملة، اقترح طلب المزيد
            # استخدام المعايير الجديدة المحسنة من ConversationManager
            completion_pct = completeness.get("completion_percentage", 0)
            missing_categories = completeness.get("missing_categories", [])
            critical_missing_categories = completeness.get("critical_missing", [])
            has_critical_missing = len(critical_missing_categories) > 0
            
            # المعايير الجديدة المحسنة:
            # 1. إذا كانت هناك معلومات حيوية ناقصة
            # 2. إذا كانت نسبة الاكتمال أقل من 75% (للتحليل الكامل)
            # 3. إذا لم تكن جاهزة للتحليل حسب ConversationManager
            
            should_request_info = (
                not ready_for_analysis or  # الأساس: ConversationManager يقول غير جاهز
                has_critical_missing or    # معلومات حيوية ناقصة
                (not is_follow_up and completion_pct < 50) or  # استعلام جديد ومعلومات قليلة جداً
                (is_follow_up and completion_pct < 60 and has_critical_missing)  # متابعة لكن لا تزال ناقصة
            )
            
            # DEBUG: Log the decision process
            should_request_debug = {
                "not_ready_for_analysis": not ready_for_analysis,
                "has_critical_missing": has_critical_missing,
                "not_follow_up_and_low_completion": not is_follow_up and completion_pct < 50,
                "follow_up_with_critical_missing": is_follow_up and completion_pct < 60 and has_critical_missing
            }
            
            agent_logger.info("Orchestrator", f"🔍 Information completeness check", {
                "completion_pct": completion_pct,
                "ready_for_analysis": ready_for_analysis,
                "has_critical_missing": has_critical_missing,
                "critical_missing_categories": critical_missing_categories,
                "missing_categories": missing_categories,
                "is_follow_up": is_follow_up,
                "should_request_info": should_request_info,
                "debug_conditions": should_request_debug
            })
            
            if should_request_info:
                # استخدام النظام الذكي الجديد لطلب المعلومات
                try:
                    # تحديد نوع الرسالة بناء على السياق
                    message_type = self._detect_message_type(message, intent, completeness, is_follow_up)
                    
                    # الحصول على تاريخ المحادثة من extracted_data
                    conversation_history = extracted_data.get("conversation_history", [])
                    
                    # استخدام ResponseFormatterAgent لتوليد رد ذكي
                    response_formatter = self.agents.get("response_formatter")
                    if response_formatter:
                        smart_response = await response_formatter.generate_smart_info_request(
                            message_type=message_type,
                            intent=intent,
                            completeness=completeness,
                            entities=entities,
                            conversation_history=conversation_history,
                            language=language
                        )
                        
                        agent_logger.info("Orchestrator", f"✅ Smart info request generated", {
                            "message_type": message_type,
                            "response_length": len(smart_response)
                        })
                    else:
                        # Fallback للطريقة القديمة
                        smart_response = self._create_info_request_response(completeness, language, entities)
                    
                    if smart_response:
                        return {
                            "agent": "Orchestrator",
                            "agent_type": "orchestrator",
                            "result": {
                                "response": smart_response,
                                "type": "information_request",
                                "completeness": completeness,
                                "entities_collected": entities
                            },
                            "metadata": {
                                "intent": intent,
                                "language": language,
                                "needs_more_info": True,
                                "missing_fields": missing_info,
                                "completion_percentage": completeness.get("completion_percentage", 0),
                                "smart_response": True
                            },
                            "timestamp": datetime.utcnow().isoformat(),
                            "status": "needs_info"
                        }
                        
                except Exception as e:
                    agent_logger.error("Orchestrator", f"❌ Smart response failed, using fallback: {e}")
                    
                    # Fallback للطريقة القديمة
                    info_request_response = self._create_info_request_response(
                        completeness, 
                        language, 
                        entities
                    )
                    
                    if info_request_response:
                        return {
                            "agent": "Orchestrator",
                            "agent_type": "orchestrator",
                            "result": {
                                "response": info_request_response,
                                "type": "information_request",
                                "completeness": completeness,
                                "entities_collected": entities
                            },
                            "metadata": {
                                "intent": intent,
                                "language": language,
                                "needs_more_info": True,
                                "missing_fields": missing_info,
                                "completion_percentage": completeness.get("completion_percentage", 0),
                                "smart_response": False
                            },
                            "timestamp": datetime.utcnow().isoformat(),
                            "status": "needs_info"
                        }
            
            # === Step 2: Collect Data from Required Agents ===
            agent_logger.info("Orchestrator", f"📊 Step 2: Collecting data from {len(required_agents)} agents")
            
            collected_data = await self._collect_agent_data(
                required_agents,
                entities,
                context
            )
            
            agent_logger.info("Orchestrator", f"✅ Data collected from {len(collected_data)} sources", {
                "sources": list(collected_data.keys())
            })
            
            # === Step 3: Generate Response using ResponseFormatter + Qwen ===
            agent_logger.info("Orchestrator", "✍️ Step 3: Generating final response with Qwen")
            
            response_formatter = self.agents['response_formatter']
            
            # إضافة جديدة: تمرير معلومات الاكتمال والمتابعة للـ formatter
            formatted_result = await response_formatter.process(
                {
                    "agent_data": collected_data,
                    "user_query": message,
                    "intent": intent,
                    "language": language,
                    "completeness": completeness,  # إضافة جديدة
                    "is_follow_up": is_follow_up,  # إضافة جديدة
                    "context": context  # إضافة السياق الكامل
                },
                context
            )
            
            final_response = formatted_result.get("result", {})
            
            # === Step 4: Return Final Result ===
            agent_logger.agent_result("Orchestrator", {
                "intent": intent,
                "language": language,
                "data_sources": list(collected_data.keys()),
                "response_generated": bool(final_response.get("response")),
                "is_follow_up": is_follow_up,
                "completeness": completeness.get("completion_percentage", 0)
            }, success=True)
            
            return {
                "agent": "Orchestrator",
                "agent_type": "orchestrator",
                "result": final_response,
                "metadata": {
                    "intent": intent,
                    "language": language,
                    "agents_used": list(collected_data.keys()),
                    "entities_extracted": entities,  # تغيير: إرسال الكيانات كاملة
                    "is_follow_up": is_follow_up,
                    "completeness": completeness,
                    "ready_for_analysis": ready_for_analysis
                },
                "timestamp": datetime.utcnow().isoformat(),
                "status": "success"
            }
            
        except Exception as e:
            logger.error(f"Orchestrator error: {e}", exc_info=True)
            return self._create_error_response(str(e))
    
    def _detect_message_type(self, message: str, intent: str, completeness: Dict[str, Any], is_follow_up: bool = False) -> str:
        """
        تحديد نوع الرسالة لتوليد رد مناسب
        
        Args:
            message: الرسالة الأصلية
            intent: النية المستخرجة
            completeness: معلومات الاكتمال
            
        Returns:
            نوع الرسالة
        """
        
        message_lower = message.lower().strip()
        completion_pct = completeness.get("completion_percentage", 0)
        
        # 1. تحيات بسيطة
        greetings = ["hi", "hello", "hey", "good morning", "good evening", "مرحبا", "اهلا", "سلام"]
        if (any(greeting in message_lower for greeting in greetings) and 
            len(message_lower) < 20 and 
            intent == "general_inquiry" and 
            completion_pct < 10):
            return "greeting"
        
        # 2. استعلام عقاري أولي
        if intent == "property_search":
            # في رسائل المتابعة، حتى لو كانت النسبة منخفضة، نعاملها كتقدمية لتجنب تكرار القالب الأولي
            if is_follow_up and completion_pct >= 20 and completion_pct < 85:
                return "progressive_info_addition"
            if completion_pct < 30:
                return "initial_property_inquiry"
        
        # 3. إضافة معلومة تدريجية
        if (intent == "property_search" and 10 < completion_pct < 85):
            return "progressive_info_addition"
        
        # 4. استعلام عام
        if intent == "general_inquiry":
            return "general_inquiry"
        
        # 5. طلب تحليل
        if intent in ["property_valuation", "market_analysis"]:
            return "analysis_request"
        
        # افتراضي
        return "standard_inquiry"

    def _create_info_request_response(self, completeness: Dict[str, Any], language: str, entities: Dict[str, Any]) -> Optional[str]:
        """
        Create response requesting missing information - Enhanced version
        """
        suggestions = completeness.get("suggestions", [])
        
        if not suggestions:
            return None
        
        # تحديد ما تم جمعه بالفعل مع تفاصيل أكثر
        collected_info = []
        missing_info = []
        
        # فحص المعلومات المجمعة والمفقودة
        location = entities.get("location", {})
        property_info = entities.get("property", {})
        search_criteria = entities.get("search_criteria", {})
        
        # الموقع
        if location.get("city"):
            city_info = f"City: {location['city']}"
            if location.get("district"):
                city_info += f", District: {location['district']}"
            if location.get("neighborhood"):
                city_info += f", Area: {location['neighborhood']}"
            collected_info.append(city_info)
        else:
            missing_info.append("📍 **Location Details**: Specific district/neighborhood (essential for accurate pricing)")
        
        # تفاصيل العقار
        if property_info.get("size"):
            collected_info.append(f"Size: {property_info['size']} m²")
        else:
            missing_info.append("📐 **Property Size**: Square meters")
            
        if property_info.get("rooms"):
            collected_info.append(f"Layout: {property_info['rooms']}")
        else:
            missing_info.append("🏠 **Room Configuration**: (e.g., 2+1, 3+1, 4+1)")
            
        if property_info.get("property_type"):
            collected_info.append(f"Type: {property_info['property_type']}")
        else:
            missing_info.append("🏢 **Property Type**: Apartment, Villa, Commercial, etc.")
        
        # الميزانية والسعر
        if search_criteria.get("budget") or property_info.get("budget"):
            budget = search_criteria.get("budget") or property_info.get("budget")
            collected_info.append(f"Budget: {budget:,} TL")
        else:
            missing_info.append("💰 **Budget Range**: Your investment budget (crucial for property recommendations)")
        
        # الغرض من الشراء
        if search_criteria.get("purpose"):
            collected_info.append(f"Purpose: {search_criteria['purpose']}")
        else:
            missing_info.append("🎯 **Investment Purpose**: Buy, rent, or invest (affects analysis approach)")
        
        # إنشاء الرد المحسن
        if language == "en":
            response = f"""🏠 **Real Estate Search Assistant - {SystemInfo.NAME} v{SystemInfo.VERSION}**

Thank you for your interest in Turkish real estate! I understand you're looking for properties"""
            
            if collected_info:
                response += f" and I've gathered some initial details:\n\n"
                response += "**✅ Information Collected:**\n"
                for info in collected_info:
                    response += f"• {info}\n"
                response += "\n"
            else:
                response += ".\n\n"
            
            if missing_info:
                response += "**📋 For Accurate Analysis, I Need:**\n\n"
                for i, info in enumerate(missing_info, 1):
                    response += f"{i}. {info}\n"
                
                response += f"""
**🎯 Why These Details Matter:**

Turkish real estate prices vary dramatically by location - even within the same city, prices can differ by 300-500% between districts. Property size, layout, and your budget are equally crucial for:

• **Accurate Price Analysis**: Market values change significantly by area and property specifications
• **Targeted Recommendations**: Finding properties that match your exact needs
• **Investment Strategy**: Different areas offer different ROI potential
• **Negotiation Power**: Knowing market ranges helps in price discussions

**💡 You can provide details gradually** - I'll build our analysis step by step, or give me everything at once for a comprehensive evaluation.

**Example:** "I'm looking for a 3+1 apartment, around 120m², budget 6-8 million TL, in Kadıköy or Beşiktaş, for family living."
"""
            else:
                response += "I have all the information needed for a comprehensive analysis!"
                
        elif language == "tr":
            response = f"""🏠 **Emlak Arama Asistanı - {SystemInfo.NAME} v{SystemInfo.VERSION}**

Türk emlak piyasasına ilginiz için teşekkürler! Emlak aradığınızı anlıyorum"""
            
            if collected_info:
                response += f" ve bazı başlangıç bilgileri topladım:\n\n"
                response += "**✅ Toplanan Bilgiler:**\n"
                for info in collected_info:
                    response += f"• {info}\n"
                response += "\n"
            else:
                response += ".\n\n"
                
            if missing_info:
                response += "**📋 Doğru Analiz İçin İhtiyacım Olan Bilgiler:**\n\n"
                for i, info in enumerate(missing_info, 1):
                    response += f"{i}. {info}\n"
                
                response += f"""
**🎯 Bu Detaylar Neden Önemli:**

Türk emlak fiyatları lokasyona göre dramatik şekilde değişir - aynı şehirde bile ilçeler arası %300-500 fark olabilir. Emlak büyüklüğü, oda sayısı ve bütçeniz şunlar için kritik:

• **Doğru Fiyat Analizi**: Piyasa değerleri bölge ve emlak özelliklerine göre önemli ölçüde değişir
• **Hedefli Öneriler**: Tam ihtiyaçlarınıza uygun emlakları bulma
• **Yatırım Stratejisi**: Farklı bölgeler farklı getiri potansiyeli sunar
• **Pazarlık Gücü**: Piyasa aralıklarını bilmek fiyat görüşmelerinde yardımcı olur

**💡 Bilgileri kademeli olarak verebilirsiniz** - analizimizi adım adım oluştururum, ya da kapsamlı değerlendirme için her şeyi bir seferde verin.

**Örnek:** "3+1 daire arıyorum, yaklaşık 120m², bütçe 6-8 milyon TL, Kadıköy veya Beşiktaş'ta, aile yaşamı için."
"""
            else:
                response += "Kapsamlı analiz için gerekli tüm bilgilere sahibim!"
                
        elif language == "ar":
            response = f"""🏠 **مساعد البحث العقاري - {SystemInfo.NAME} v{SystemInfo.VERSION}**

شكراً لاهتمامك بالعقارات التركية! أفهم أنك تبحث عن عقارات"""
            
            if collected_info:
                response += f" وقد جمعت بعض التفاصيل الأولية:\n\n"
                response += "**✅ المعلومات المجمعة:**\n"
                for info in collected_info:
                    response += f"• {info}\n"
                response += "\n"
            else:
                response += ".\n\n"
                
            if missing_info:
                response += "**📋 للحصول على تحليل دقيق، أحتاج:**\n\n"
                for i, info in enumerate(missing_info, 1):
                    response += f"{i}. {info}\n"
                
                response += f"""
**🎯 لماذا هذه التفاصيل مهمة:**

أسعار العقارات التركية تختلف بشكل كبير حسب الموقع - حتى داخل نفس المدينة، يمكن أن تختلف الأسعار بنسبة 300-500% بين الأحياء. حجم العقار والتخطيط والميزانية ضرورية لـ:

• **تحليل دقيق للأسعار**: القيم السوقية تتغير بشكل كبير حسب المنطقة ومواصفات العقار
• **توصيات مستهدفة**: العثور على عقارات تناسب احتياجاتك بالضبط
• **استراتيجية الاستثمار**: مناطق مختلفة تقدم إمكانيات عائد مختلفة
• **قوة التفاوض**: معرفة نطاقات السوق تساعد في مناقشات الأسعار

**💡 يمكنك تقديم التفاصيل تدريجياً** - سأبني تحليلنا خطوة بخطوة، أو أعطني كل شيء مرة واحدة للحصول على تقييم شامل.

**مثال:** "أبحث عن شقة 3+1، حوالي 120 متر مربع، ميزانية 6-8 مليون ليرة، في كاديكوي أو بشيكتاش، للسكن العائلي."
"""
            else:
                response += "لدي جميع المعلومات اللازمة لتحليل شامل!"
        
        else:
            # Default English
            response = f"""🏠 **Real Estate Search Assistant - {SystemInfo.NAME} v{SystemInfo.VERSION}**

I need more information to provide accurate real estate analysis. Please provide property details, location, and budget."""
        
        return response
    

    async def _collect_agent_data(self, required_agents: List[str], entities: Dict[str, Any], context: Optional[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Collect data from all required agents
        ✅ محدث: معالجة أفضل للوكلاء المفقودة
        """
        collected_data = {}
        
        # ✅ إضافة: تسجيل الوكلاء المطلوبة والمتاحة
        available_agents = list(self.agents.keys())
        agent_logger.info("Orchestrator", f"📊 Collecting data", {
            "required": required_agents,
            "available": available_agents,
            "missing": [a for a in required_agents if a not in available_agents and 
                        a + "_data" not in available_agents]
        })
        
        # Process each required agent
        for agent_name in required_agents:
            
            # ✅ تحديث: معالجة أسماء الوكلاء بشكل أفضل
            actual_agent_name = None
            
            # Handle both old format (property) and new format (property_data)
            if agent_name == "property" and "property_data" in self.agents:
                actual_agent_name = "property_data"
            elif agent_name == "property_data" and "property_data" in self.agents:
                actual_agent_name = "property_data"
                agent_name = "property"  # Normalize for processing
            elif agent_name == "market" and "market_data" in self.agents:
                actual_agent_name = "market_data"
            elif agent_name == "market_data" and "market_data" in self.agents:
                actual_agent_name = "market_data"
                agent_name = "market"  # Normalize for processing
            elif agent_name == "location" and "location_data" in self.agents:
                actual_agent_name = "location_data"
            elif agent_name == "location_data" and "location_data" in self.agents:
                actual_agent_name = "location_data"
                agent_name = "location"  # Normalize for processing
            elif agent_name == "conversation":
                # Conversation doesn't need data collection
                collected_data["conversation"] = {
                    "type": "general",
                    "intent": entities.get("intent", "general_inquiry")
                }
                continue
            elif agent_name in self.agents:
                actual_agent_name = agent_name
            
            if not actual_agent_name:
                agent_logger.warning("Orchestrator", f"⚠️ Agent '{agent_name}' not found, skipping")
                continue
            
            # === Property Data ===
            if agent_name == "property":
                agent_logger.info("Orchestrator", "📊 Fetching property data")
                
                try:
                    # Prepare comprehensive property data
                    property_info = entities.get("property", {})
                    location_info = entities.get("location", {})
                    search_criteria = entities.get("search_criteria", {})
                    
                    agent_logger.info("Orchestrator", "📊 Property data preparation", {
                        "property_info": property_info,
                        "location_info": location_info,
                        "search_criteria": search_criteria
                    })
                    
                    # Merge all relevant data
                    merged_data = {
                        **property_info,
                        **location_info,
                        "budget": search_criteria.get("budget_max"),
                        "purpose": search_criteria.get("purpose", "buy")
                    }
                    
                    # Include concise location string for diagnostics
                    try:
                        merged_location = self._extract_location_string(location_info)
                    except Exception:
                        merged_location = None
                    agent_logger.info("Orchestrator", "📊 Merged property data", {
                        "merged_data": merged_data,
                        "merged_location": merged_location
                    })
                    
                    property_result = await self.agents[actual_agent_name].process(
                        {
                            "property_data": merged_data,
                            "data_type": "full"
                        },
                        context
                    )
                    collected_data["property"] = property_result.get("result", {}).get("data", {})
                    
                except Exception as e:
                    logger.error(f"Property data fetch failed: {e}")
                    collected_data["property"] = {"error": str(e)}
            
            # === Market Data ===
            elif agent_name == "market":
                agent_logger.info("Orchestrator", "📈 Fetching market data")
                
                try:
                    # ✅ استخراج الموقع الصحيح
                    location = ""
                    
                    # أولاً: حاول من location entity
                    location_entity = entities.get("location", {})
                    if location_entity:
                        if location_entity.get("district"):
                            location = location_entity.get("district")
                        elif location_entity.get("city"):
                            location = location_entity.get("city")
                    
                    # ثانياً: حاول من property entity
                    if not location:
                        property_entity = entities.get("property", {})
                        if property_entity and property_entity.get("location"):
                            location = property_entity["location"]
                    
                    # Default
                    if not location:
                        location = "Istanbul"
                    
                    agent_logger.info("Orchestrator", f"🔍 Market data location: '{location}'")
                    
                    market_result = await self.agents[actual_agent_name].process(
                        {
                            "location": location,  # ✅ الموقع فقط
                            "data_type": "full"
                        },
                        context
                    )
                    collected_data["market"] = market_result.get("result", {}).get("data", {})
                    
                except Exception as e:
                    logger.error(f"Market data fetch failed: {e}")
                    collected_data["market"] = {"error": str(e)}
            
            # === Location Data ===
            elif agent_name == "location":
                agent_logger.info("Orchestrator", "📍 Fetching location data")
                
                try:
                    location_info = entities.get("location", {})
                    
                    location_result = await self.agents[actual_agent_name].process(
                        location_info,
                        context
                    )
                    collected_data["location"] = location_result.get("result", {}).get("data", {})
                    
                except Exception as e:
                    logger.error(f"Location data fetch failed: {e}")
                    collected_data["location"] = {"error": str(e)}
        
        # ✅ إضافة: تسجيل ملخص البيانات المجموعة
        agent_logger.info("Orchestrator", f"✅ Data collection complete", {
            "collected_agents": list(collected_data.keys()),
            "total_data_points": sum(
                len(v) if isinstance(v, (dict, list)) else 1 
                for v in collected_data.values()
            )
        })
        
        return collected_data

    def _extract_location_string(self, location_entity: Dict[str, Any]) -> str:
        """
        Extract location string from location entity
        
        Args:
            location_entity: Location entity from intent extractor
            
        Returns:
            Location string for queries
        """
        # Priority: full location > city-district > city > district
        if location_entity.get("raw"):
            return location_entity["raw"]
        
        city = location_entity.get("city", "")
        district = location_entity.get("district", "")
        neighborhood = location_entity.get("neighborhood", "")
        
        parts = []
        if city:
            parts.append(city)
        if district:
            parts.append(district)
        if neighborhood:
            parts.append(neighborhood)
        
        if parts:
            return " - ".join(parts)
        
        return "Istanbul"  # Default location
    
    def _create_error_response(self, error: str) -> Dict[str, Any]:
        """
        Create standardized error response
        
        Args:
            error: Error message
            
        Returns:
            Error response dictionary
        """
        agent_logger.error("Orchestrator", f"Error: {error}")
        
        return {
            "agent": "orchestrator",
            "agent_type": "orchestrator",
            "result": {
                "response": "I apologize, but I encountered an error processing your request. Please try again.",
                "error": error,
                "type": "error"
            },
            "metadata": {
                "error": True,
                "error_message": error
            },
            "timestamp": datetime.utcnow().isoformat(),
            "status": "error"
        }
    
    async def _get_model_response_for_analysis(
                self, 
                message: str, 
                cached_analysis: Dict[str, Any], 
                cached_property: Dict[str, Any], 
                context: Dict[str, Any]
            ) -> Dict[str, Any]:
        """
        Get model response for questions about cached analysis
        Uses the model to intelligently respond to questions about the analysis
        """
        try:
            logger.info(f"Getting model response for analysis - message: {message[:50]}...")
            logger.debug(f"Cached analysis keys: {list(cached_analysis.keys()) if cached_analysis else 'None'}")
            logger.debug(f"Cached property keys: {list(cached_property.keys()) if cached_property else 'None'}")
            
            # إنشاء prompt شامل للتحليل
            analysis_context = self._format_analysis_for_model(cached_analysis, cached_property)
            logger.debug(f"Analysis context length: {len(analysis_context)}")
            
            # إنشاء prompt محسّن للنموذج
            system_prompt = f"""You are a real estate expert assistant. You have just completed a comprehensive property analysis and the user is asking questions about it.

    **Previous Analysis Results:**
    {analysis_context}

    **Instructions:**
    - Answer the user's question based on the analysis data provided above
    - Be helpful, accurate, and professional
    - If the user mentions budget constraints, provide practical advice
    - If they ask about investment potential, explain based on the data
    - If they ask about market trends, use the market analysis data
    - Respond in the same language as the user's question
    - Be conversational and helpful, not robotic
    - Reference specific numbers from the analysis when relevant

    **User Question:** {message}

    Please provide a comprehensive and helpful response based on the analysis data."""
            
            response = None
            
            # محاولة استخدام response_formatter أولاً (الأكثر أماناً)
            if 'response_formatter' in self.agents:
                try:
                    response_formatter = self.agents['response_formatter']
                    
                    # استخدام ResponseFormatter مع البيانات الكاملة
                    formatter_input = {
                        "agent_data": {
                            "property": cached_property,
                            "analysis": cached_analysis
                        },
                        "user_query": message,
                        "intent": "analysis_question",
                        "language": "en",
                        "system_prompt": system_prompt,
                        "context_type": "cached_analysis_question"
                    }
                    
                    response_result = await response_formatter.process(formatter_input, context)
                    
                    if response_result and response_result.get("result"):
                        result_data = response_result.get("result", {})
                        if isinstance(result_data, dict):
                            response = result_data.get("response")
                        else:
                            response = str(result_data)
                        
                        if response:
                            logger.info("Response generated via ResponseFormatter")
                            
                except Exception as e:
                    logger.warning(f"ResponseFormatter failed: {e}")
                    response = None
            
            # إذا فشل ResponseFormatter، حاول استخدام ModelLoader
            if not response and hasattr(self, 'model_loader') and self.model_loader:
                try:
                    logger.info("Trying ModelLoader for analysis response")
                    
                    # استخدام الطريقة الصحيحة للـ ModelLoader
                    if hasattr(self.model_loader, 'process_with_qwen'):
                        # استخدام process_with_qwen إذا كانت متاحة
                        response = await self.model_loader.process_with_qwen(
                            prompt=system_prompt,
                            temperature=0.7,
                            max_tokens=1000
                        )
                    elif hasattr(self.model_loader, 'generate_analysis'):
                        # استخدام generate_analysis إذا كانت متاحة
                        response = await self.model_loader.generate_analysis(
                            property_data=cached_property,
                            analysis_data=cached_analysis,
                            user_question=message
                        )
                    else:
                        # محاولة تحميل النموذج مباشرة
                        model = self.model_loader.load_qwen_model()
                        if model:
                            # استخدام النموذج مباشرة إذا أمكن
                            if hasattr(model, 'generate_text'):
                                response = await model.generate_text(system_prompt)
                            elif hasattr(model, 'generate'):
                                response = await model.generate(system_prompt)
                                
                except Exception as e:
                    logger.error(f"ModelLoader failed: {e}")
                    response = None
            
            # إذا لم نحصل على رد، استخدم رد ذكي بناءً على البيانات
            if not response:
                logger.info("Using intelligent fallback response")
                
                # بناء رد ذكي بناءً على السؤال والبيانات المتاحة
                estimated_price = cached_analysis.get('price_estimation', {}).get('estimated_price', 0)
                investment_score = cached_analysis.get('investment_analysis', {}).get('investment_score', 0)
                roi = cached_analysis.get('investment_analysis', {}).get('roi_potential', 'N/A')
                market_position = cached_analysis.get('market_analysis', {}).get('market_position', 'N/A')
                
                # تحليل السؤال وتوليد رد مناسب
                message_lower = message.lower()
                
                if any(word in message_lower for word in ['should', 'buy', 'purchase', 'invest']):
                    if investment_score >= 7:
                        response = f"""Based on the comprehensive analysis:
                        
    The property shows strong investment potential with a score of {investment_score}/10.
    - Estimated value: ₺{estimated_price:,.0f}
    - ROI potential: {roi}
    - Market position: {market_position}

    This appears to be a solid investment opportunity in the current market."""
                    else:
                        response = f"""Based on the analysis:
                        
    The property has an investment score of {investment_score}/10.
    - Estimated value: ₺{estimated_price:,.0f}
    - Market position: {market_position}

    Consider your personal needs and compare with other options before deciding."""
                        
                elif any(word in message_lower for word in ['negotiat', 'discount', 'lower', 'bargain']):
                    response = f"""Regarding negotiation potential:

    The property is estimated at ₺{estimated_price:,.0f} with market position: {market_position}.

    Typical negotiation margins in this market are 5-10%. You could potentially negotiate to around ₺{estimated_price * 0.92:,.0f}.

    Consider the property's time on market and seller's motivation for better negotiation leverage."""
                    
                elif any(word in message_lower for word in ['expensive', 'budget', 'afford']):
                    response = f"""Regarding affordability:

    The property is valued at ₺{estimated_price:,.0f}.

    If this exceeds your budget, consider:
    1. Similar properties in nearby areas (often 20-30% cheaper)
    2. Slightly older buildings (10-15% discount)
    3. Lower floors or smaller units
    4. Emerging neighborhoods with growth potential

    Would you like me to search for alternatives within your budget?"""
                    
                else:
                    # رد عام للأسئلة الأخرى
                    response = f"""Based on the comprehensive analysis of this property in {cached_property.get('location', 'Istanbul')}:

    • Estimated Value: ₺{estimated_price:,.0f}
    • Investment Score: {investment_score}/10
    • Market Position: {market_position}
    • ROI Potential: {roi}

    The analysis shows this is a {market_position.lower()} property in the current market.

    What specific aspect would you like to know more about?"""
            
            return {
                "response": response,
                "type": "analysis_discussion",
                "completeness": 1.0,
                "has_analysis": True,
                "cached_analysis": cached_analysis
            }
            
        except Exception as e:
            logger.error(f"Error getting model response for analysis: {e}", exc_info=True)
            return {
                "response": "I have the analysis results available. What specific aspect would you like to know about this property?",
                "type": "analysis_discussion",
                "completeness": 1.0,
                "has_analysis": True
            }

    
    async def _get_model_response_for_analysis1(
        self, 
        message: str, 
        cached_analysis: Dict[str, Any], 
        cached_property: Dict[str, Any], 
        context: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Get model response for questions about cached analysis
        Uses the model to intelligently respond to questions about the analysis
        """
        try:
            logger.info(f"Getting model response for analysis - message: {message[:50]}...")
            logger.debug(f"Cached analysis keys: {list(cached_analysis.keys()) if cached_analysis else 'None'}")
            logger.debug(f"Cached property keys: {list(cached_property.keys()) if cached_property else 'None'}")
            
            # إنشاء prompt شامل للتحليل
            analysis_context = self._format_analysis_for_model(cached_analysis, cached_property)
            logger.debug(f"Analysis context length: {len(analysis_context)}")
            
            # إنشاء prompt للنموذج
            system_prompt = f"""You are a real estate expert assistant. You have just completed a comprehensive property analysis and the user is asking questions about it.

**Previous Analysis Results:**
{analysis_context}

**Instructions:**
- Answer the user's question based on the analysis data provided above
- Be helpful, accurate, and professional
- If the user mentions budget constraints, provide practical advice
- If they ask about investment potential, explain based on the data
- If they ask about market trends, use the market analysis data
- Respond in the same language as the user's question
- Be conversational and helpful, not robotic

**User Question:** {message}

Please provide a comprehensive and helpful response based on the analysis data."""
            
            # استخدام النموذج للحصول على الاستجابة
            if hasattr(self, 'model_loader') and self.model_loader:
                logger.info("Using model loader for analysis response")
                
                # استخدام الطريقة الصحيحة للـ ModelLoader
                try:
                    model = self.model_loader.load_qwen_model()
                    if model and hasattr(model, 'generate'):
                        response = await model.generate(
                            prompt=system_prompt,
                            max_tokens=1000,
                            temperature=0.7
                        )
                    else:
                        # Fallback لاستخدام response_formatter
                        response = None
                except Exception as e:
                    logger.error(f"Model generation failed: {e}")
                    response = None
                
                if not response:
                    # استخدام fallback response
                    response = f"""Based on the analysis of this property in {cached_property.get('location', 'Istanbul')}:

            **Property Value:** ₺{cached_analysis.get('price_estimation', {}).get('estimated_price', 0):,.0f}
            **Investment Score:** {cached_analysis.get('investment_analysis', {}).get('investment_score', 0)}/10
            **Market Position:** {cached_analysis.get('market_analysis', {}).get('market_position', 'N/A')}

            Regarding your question: "{message}"

            {self._generate_specific_answer(message, cached_analysis, cached_property)}"""

                logger.debug(f"Model response length: {len(response) if response else 0}")
            else:
                # Fallback: استخدام response_formatter إذا كان متوفراً
                if 'response_formatter' in self.agents:
                    response_formatter = self.agents['response_formatter']
                    response_result = await response_formatter.process(
                        {
                            "message": message,
                            "analysis_data": cached_analysis,
                            "property_data": cached_property,
                            "context": analysis_context
                        },
                        context
                    )
                    response = response_result.get("result", {}).get("response", "I can help you with questions about this property analysis.")
                else:
                    response = "I have the analysis results available. What would you like to know about this property?"
            
            return {
                "response": response,
                "type": "analysis_discussion",
                "completeness": 1.0,
                "has_analysis": True,
                "cached_analysis": cached_analysis
            }
            
        except Exception as e:
            logger.error(f"Error getting model response for analysis: {e}")
            return {
                "response": "I have the analysis results available. What would you like to know about this property?",
                "type": "analysis_discussion",
                "completeness": 1.0,
                "has_analysis": True
            }
    
    def _format_analysis_for_model(self, cached_analysis: Dict[str, Any], cached_property: Dict[str, Any]) -> str:
        """
        Format analysis data for model consumption
        """
        try:
            # تنسيق بيانات العقار
            property_info = f"""**Property Details:**
- Location: {cached_property.get('location', 'N/A')}
- Type: {cached_property.get('property_type', 'N/A')}
- Size: {cached_property.get('size_net', cached_property.get('size_gross', 'N/A'))} m²
- Rooms: {cached_property.get('rooms', 'N/A')}
- Building Age: {cached_property.get('building_age', 'N/A')} years
- Floor: {cached_property.get('floor_level', 'N/A')}"""

            # تنسيق تحليل السعر
            price_data = cached_analysis.get("price_estimation", {})
            price_info = f"""**Price Analysis:**
- Estimated Price: ₺{price_data.get('estimated_price', 0):,.0f}
- Confidence: {price_data.get('confidence', 0)*100:.0f}%
- Price Range: ₺{price_data.get('price_range', {}).get('min', 0):,.0f} - ₺{price_data.get('price_range', {}).get('max', 0):,.0f}
- Method: {price_data.get('methodology', 'N/A')}"""

            # تنسيق تحليل السوق
            market_data = cached_analysis.get("market_analysis", {})
            market_info = f"""**Market Analysis:**
- Average Price: ₺{market_data.get('average_price', 0):,.0f}
- Market Position: {market_data.get('market_position', 'N/A')}
- Growth Forecast: {market_data.get('growth_forecast', 0)}%
- Demand Level: {market_data.get('demand_level', 'N/A')}
- Supply Level: {market_data.get('supply_level', 'N/A')}
- Price Trend: {market_data.get('price_trend', 'N/A')}"""

            # تنسيق تحليل الاستثمار
            investment_data = cached_analysis.get("investment_analysis", {})
            investment_info = f"""**Investment Analysis:**
- Investment Score: {investment_data.get('investment_score', 0)}/10
- Rental Yield: {investment_data.get('rental_yield', 0)}%
- ROI Potential: {investment_data.get('roi_potential', 'N/A')}
- Risk Level: {investment_data.get('risk_level', 'N/A')}
- Payback Period: {investment_data.get('payback_period', 0)} years
- Appreciation Forecast: {investment_data.get('appreciation_forecast', 'N/A')}"""

            # تنسيق العقارات المشابهة
            similar_properties = cached_analysis.get("similar_properties", [])
            similar_info = f"""**Similar Properties ({len(similar_properties)}):**
"""
            for i, prop in enumerate(similar_properties[:5], 1):
                similar_info += f"- {i}. {prop.get('rooms', 'N/A')} - {prop.get('size', 'N/A')} m² - {prop.get('district', prop.get('city', 'N/A'))} - ₺{prop.get('price', 0):,.0f} ({prop.get('similarity_score', 0)*100:.0f}% match)\n"

            # تنسيق تحليل Qwen
            qwen_analysis = cached_analysis.get("qwen_analysis", "")
            qwen_info = f"""**AI Expert Analysis:**
{qwen_analysis}"""

            # تنسيق التوصيات
            recommendations = cached_analysis.get("recommendations", [])
            recommendations_info = f"""**Recommendations:**
"""
            for rec in recommendations:
                recommendations_info += f"- {rec}\n"

            return f"{property_info}\n\n{price_info}\n\n{market_info}\n\n{investment_info}\n\n{similar_info}\n\n{qwen_info}\n\n{recommendations_info}"
            
        except Exception as e:
            logger.error(f"Error formatting analysis for model: {e}")
            return "Analysis data available but formatting error occurred."
    
    def get_agent_info(self) -> Dict[str, Any]:
        """
        Get information about loaded agents
        
        Returns:
            Dictionary with agent information
        """
        agent_info = {}
        
        for name, agent in self.agents.items():
            agent_info[name] = {
                "type": agent.agent_type.value if hasattr(agent, 'agent_type') else "unknown",
                "description": agent.description if hasattr(agent, 'description') else "",
                "capabilities": agent.capabilities if hasattr(agent, 'capabilities') else [],
                "status": agent.status if hasattr(agent, 'status') else "unknown"
            }
        
        return {
            "total_agents": len(self.agents),
            "agents": agent_info,
            "architecture": "new",
            "version": "2.0"
        }
    
    async def _handle_constraint_with_cached_analysis(
            self,
            message: str,
            cached_analysis: Dict[str, Any],
            cached_property: Dict[str, Any],
            new_entities: Dict[str, Any],
            context: Dict[str, Any]
        ) -> Dict[str, Any]:
        """
        Handle constraint updates (like budget) with cached analysis
        """
        try:
            # استخراج القيود الجديدة
            new_budget = new_entities.get("search_criteria", {}).get("budget")
            estimated_price = cached_analysis.get("price_estimation", {}).get("estimated_price", 0)
            
            # إنشاء رد ذكي بناء على القيود
            if new_budget and estimated_price:
                if new_budget < estimated_price * 0.8:
                    response = f"""Based on your budget of ₺{new_budget:,.0f}, this property (₺{estimated_price:,.0f}) is above your range.

    **Recommendations:**
    1. Consider similar properties in nearby areas with lower prices
    2. Look for smaller units or older buildings
    3. Explore emerging neighborhoods with growth potential

    Would you like me to search for alternatives within your budget?"""
                elif new_budget >= estimated_price * 0.9 and new_budget <= estimated_price * 1.1:
                    response = f"""Your budget of ₺{new_budget:,.0f} aligns well with this property (₺{estimated_price:,.0f}).

    **Next Steps:**
    1. Schedule a viewing
    2. Prepare negotiation strategy (5-10% discount possible)
    3. Review financing options

    This property fits your criteria. Would you like detailed investment analysis?"""
                else:
                    response = f"""With your budget of ₺{new_budget:,.0f}, you have room for negotiation on this ₺{estimated_price:,.0f} property.

    Consider investing the difference in renovations or keeping it as a buffer for market fluctuations."""
            else:
                # Fallback to model response
                response = await self._get_model_response_for_analysis(
                    message, cached_analysis, cached_property, context
                )
                response = response.get("response", "Let me help you with your requirements.")
            
            return {
                "result": {
                    "response": response,
                    "type": "constraint_analysis",
                    "has_analysis": True
                },
                "metadata": {
                    "intent": "constraint_update",
                    "new_constraints": new_entities,
                    "has_complete_analysis": True
                }
            }
            
        except Exception as e:
            logger.error(f"Error handling constraint: {e}")
            return await self._get_model_response_for_analysis(
                message, cached_analysis, cached_property, context
            )

    async def _handle_alternatives_with_cached_analysis(
        self,
        message: str,
        cached_analysis: Dict[str, Any],
        cached_property: Dict[str, Any],
        new_entities: Dict[str, Any],
        context: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Handle alternative property requests with cached analysis
        """
        try:
            similar_properties = cached_analysis.get("similar_properties", [])
            
            if similar_properties:
                response = f"""Based on your interest, here are alternative properties:

    **Similar Properties:**
    """
                for i, prop in enumerate(similar_properties[:5], 1):
                    response += f"""
    {i}. **{prop.get('district', 'N/A')}** - {prop.get('rooms', 'N/A')} 
    • Size: {prop.get('size', 'N/A')} m²
    • Price: ₺{prop.get('price', 0):,.0f}
    • Match: {prop.get('similarity_score', 0)*100:.0f}%
    """
                
                response += "\nWould you like detailed analysis for any of these alternatives?"
            else:
                response = "I'll search for alternative properties based on your criteria. Please specify what aspects you'd like to change (location, size, budget, etc.)."
            
            return {
                "result": {
                    "response": response,
                    "type": "alternatives",
                    "alternatives": similar_properties[:5]
                },
                "metadata": {
                    "intent": "alternatives_request",
                    "has_alternatives": len(similar_properties) > 0
                }
            }
            
        except Exception as e:
            logger.error(f"Error handling alternatives: {e}")
            return await self._get_model_response_for_analysis(
                message, cached_analysis, cached_property, context
            )

    async def _handle_question_about_cached_analysis(
        self,
        message: str,
        cached_analysis: Dict[str, Any],
        cached_property: Dict[str, Any],
        context: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Handle general questions about cached analysis
        Fallback to existing _get_model_response_for_analysis
        """
        return await self._get_model_response_for_analysis(
            message, cached_analysis, cached_property, context
        )
