# D:\Phd\RE-FusionX\src\backend\app\agents\property_data_agent.py
"""
Property Data Agent - Fetches property data only
Returns structured data without any analysis or recommendations

# الغرض: جلب بيانات العقارات
# المدخلات: معايير البحث
# المخرجات: بيانات خام عن العقارات

الوظائف:
- جلب معلومات عقار محدد
- البحث عن عقارات مشابهة  
- جلب أسعار المنطقة
- توقعات ML (XGBoost)

مثال المخرجات:
{
  "property_info": {...},
  "similar_properties": [...],
  "ml_prediction": {"predicted_price": 5000000}
}

"""

from typing import Dict, Any, List, Optional
from datetime import datetime

from app.agents.base_agent import DataAgent
from app.core.logging import agent_logger, logger
from app.utils.location_utils import get_location_manager, normalize_text
from app.core.storage.integration import StorageIntegration
from app.core.storage.unified_cache import CacheType


class PropertyDataAgent(DataAgent):
    """
    Property Data Agent - Fetches property-related data only
    No analysis, no recommendations, just data
    """
    
    def __init__(self, model_loader=None):
        super().__init__(
            name="PropertyDataAgent",
            description="Fetches property data from storage and external sources",
            capabilities=[
                "Property data retrieval",
                "Price data fetching",
                "Property features extraction",
                "Similar properties search",
                "Market statistics retrieval"
            ],
            data_sources=["storage", "cache", "scrapers", "xgboost"]
        )
        
        self.model_loader = model_loader
        self._storage = None
        self._cache = None
        self.location_manager = get_location_manager()
        
        agent_logger.agent_start(self.name, "Property data agent initialized", {
            "sources": self.data_sources
        })
    
    @property
    def storage(self):
        """Lazy load storage"""
        if self._storage is None:
            try:
                from app.core.storage.integration import StorageIntegration
                self._storage = StorageIntegration.get_storage()
                
                # Fallback if StorageIntegration fails
                if self._storage is None:
                    from app.core.storage.storage_manager import get_storage_manager
                    self._storage = get_storage_manager()
                    
            except Exception as e:
                logger.error(f"Failed to get storage in PropertyDataAgent: {e}")
                # Create a mock storage to prevent crashes
                from unittest.mock import Mock
                self._storage = Mock()
                self._storage.get_properties = lambda **kwargs: []
                self._storage.get_property_by_id = lambda prop_id: None
                
        return self._storage
    
    @property
    def cache(self):
        """Lazy load cache"""
        if self._cache is None:
            try:
                from app.core.storage.integration import StorageIntegration
                self._cache = StorageIntegration.get_cache()
                
                # Fallback if StorageIntegration fails
                if self._cache is None:
                    from app.core.storage.unified_cache import get_cache
                    self._cache = get_cache()
                    
            except Exception as e:
                logger.error(f"Failed to get cache in PropertyDataAgent: {e}")
                # Create a mock cache to prevent crashes
                from unittest.mock import Mock
                self._cache = Mock()
                self._cache.generate_key = lambda cache_type, key: f"{cache_type}:{key}"
                self._cache.get = lambda key, cache_type=None: None
                self._cache.set = lambda key, value, cache_type=None: None
                
        return self._cache
    
    async def validate_input(self, input_data: Dict[str, Any]) -> bool:
        """Validate input has minimum required data"""
        property_data = input_data.get("property_data", {})
        
        # Need at least location or property_id
        has_location = bool(property_data.get("location") or 
                          property_data.get("city") or 
                          property_data.get("district"))
        has_id = bool(property_data.get("property_id"))
        
        is_valid = has_location or has_id
        
        agent_logger.info(self.name, f"📍 Input validation", {
            "has_location": has_location,
            "has_id": has_id,
            "is_valid": is_valid,
            "property_data_keys": list(property_data.keys()) if property_data else []
        })
        
        if not is_valid:
            agent_logger.warning(self.name, "Invalid input - no location or ID")
        
        return is_valid
    
    async def fetch_data(self, criteria: Dict[str, Any], context: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Fetch property data based on criteria
        
        Args:
            criteria: Search criteria with property_data
            context: Optional context
            
        Returns:
            Raw property data only
        """
        property_data = criteria.get("property_data", {})
        data_type = criteria.get("data_type", "full")  # full, prices, features, similar
        
        # Unify has_location computation with scraping decision logic
        has_location_for_log = bool(
            property_data.get("location") or
            property_data.get("city") or
            property_data.get("district")
        )
        # Derive location string for diagnostics
        try:
            location_for_query = self._build_location_string(property_data)
        except Exception:
            location_for_query = None
        agent_logger.agent_action(self.name, "Fetching property data", {
            "data_type": data_type,
            "has_location": has_location_for_log,
            "has_id": bool(property_data.get("property_id")),
            "location_for_query": location_for_query
        })
        
        result = {}
        
        # 1. Get basic property data
        if data_type in ["full", "basic"]:
            result["property_info"] = await self._fetch_property_info(property_data)
        
        # 2. Get price data
        if data_type in ["full", "prices"]:
            result["price_data"] = await self._fetch_price_data(property_data)
        
        # 3. Get similar properties
        if data_type in ["full", "similar"]:
            result["similar_properties"] = await self._fetch_similar_properties(property_data)
        
        # 4. Get market statistics
        if data_type in ["full", "statistics"]:
            result["market_statistics"] = await self._fetch_market_statistics(property_data)
        
        # 5. Get XGBoost prediction if available
        if data_type in ["full", "ml_prediction"]:
            result["ml_prediction"] = await self._fetch_ml_prediction(property_data)
        
        # 6. 🚀 NEW: Trigger scraping if no data found
        if data_type == "full":
            should_scrape = self._should_trigger_scraping(result, property_data)
            agent_logger.info(self.name, f"🔍 Scraping check: {should_scrape}", {
                "data_type": data_type,
                "property_info_count": len(result.get("property_info", {})),
                "similar_properties_count": len(result.get("similar_properties", [])),
                "has_location_data": bool(property_data)
            })
            
            if should_scrape:
                await self._trigger_scraping(property_data, result)
        
        agent_logger.info(self.name, "📊 Data fetched successfully", {
            "sections": list(result.keys()),
            "total_data_points": sum(len(v) if isinstance(v, (list, dict)) else 1 for v in result.values())
        })
        
        return result
    
    async def _fetch_property_info(self, property_data: Dict[str, Any]) -> Dict[str, Any]:
        """Fetch basic property information"""
        
        # If we have a property ID, get from storage
        if property_data.get("property_id"):
            cache_key = self.cache.generate_key(
                CacheType.PROPERTY,
                f"info_{property_data['property_id']}"
            )
            
            cached = await self.cache.get(cache_key, CacheType.PROPERTY)
            if cached:
                return cached
            
            # Get from storage - updated for new system
            location = self._build_location_string(property_data)
            props = await self.storage.get_properties(
                location=location or "unknown",
                filters={"property_id": property_data["property_id"]}
            )
            
            if props:
                await self.cache.set(cache_key, props[0], CacheType.PROPERTY)
                return props[0]
        
        # Return the input data as basic info
        return {
            "location": property_data.get("location"),
            "city": property_data.get("city"),
            "district": property_data.get("district"),
            "property_type": property_data.get("property_type", "Apartment"),
            "size": property_data.get("size"),
            "rooms": property_data.get("rooms"),
            "building_age": property_data.get("building_age"),
            "floor": property_data.get("floor"),
            "features": property_data.get("features", [])
        }
    
    async def _fetch_price_data(self, property_data: Dict[str, Any]) -> Dict[str, Any]:
        """Fetch price data from market"""
        
        location = self._build_location_string(property_data)
        
        # Check cache
        cache_key = self.cache.generate_key(
            CacheType.PROPERTY,
            f"prices_{location}",
            property_data
        )
        
        cached = await self.cache.get(cache_key, CacheType.PROPERTY)
        if cached:
            agent_logger.info(self.name, "💰 Price data from cache")
            return cached
        
        # Get from storage
        properties = await self.storage.get_properties(
            location=location,
            filters={
                "property_type": property_data.get("property_type"),
                "size_min": float(property_data.get("size", 100)) * 0.8 if property_data.get("size") else None,
                "size_max": float(property_data.get("size", 100)) * 1.2 if property_data.get("size") else None,
                "rooms": property_data.get("rooms")
            }
        )
        
        if properties:
            prices = [p.get("price", 0) for p in properties if p.get("price")]
            sizes = [p.get("size", 0) for p in properties if p.get("size")]
            
            price_data = {
                "sample_size": len(prices),
                "average_price": sum(prices) / len(prices) if prices else 0,
                "min_price": min(prices) if prices else 0,
                "max_price": max(prices) if prices else 0,
                "median_price": sorted(prices)[len(prices)//2] if prices else 0,
                "price_per_sqm": self._calculate_avg_price_per_sqm(prices, sizes),
                "price_distribution": self._calculate_distribution(prices),
                "data_freshness": "recent",
                "source": "market_data"
            }
            
            await self.cache.set(cache_key, price_data, CacheType.PROPERTY)
            return price_data
        
        # Return empty data structure
        return {
            "sample_size": 0,
            "average_price": 0,
            "min_price": 0,
            "max_price": 0,
            "median_price": 0,
            "price_per_sqm": 0,
            "data_freshness": "no_data",
            "source": "none"
        }
    
    async def _fetch_similar_properties(self, property_data: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Fetch similar properties"""
        
        location = self._build_location_string(property_data)
        
        # Get from storage
        properties = await self.storage.get_properties(
            location=location,
            filters={
                "property_type": property_data.get("property_type"),
                "size_min": float(property_data.get("size", 100)) * 0.8 if property_data.get("size") else None,
                "size_max": float(property_data.get("size", 100)) * 1.2 if property_data.get("size") else None,
                "rooms": property_data.get("rooms"),
                "limit": 10
            }
        )
        
        # Calculate similarity scores
        similar = []
        for prop in properties[:10]:  # Limit to 10
            similarity = self._calculate_similarity(property_data, prop)
            
            similar.append({
                "property_id": prop.get("property_id", prop.get("listing_id")),
                "location": prop.get("location"),
                "price": prop.get("price"),
                "size": prop.get("size"),
                "rooms": prop.get("rooms"),
                "building_age": prop.get("building_age"),
                "similarity_score": similarity,
                "price_per_sqm": prop.get("price") / prop.get("size") if prop.get("size", 0) > 0 else 0
            })
        
        # Sort by similarity
        similar.sort(key=lambda x: x["similarity_score"], reverse=True)
        
        return similar
    
    async def _fetch_market_statistics(self, property_data: Dict[str, Any]) -> Dict[str, Any]:
        """Fetch market statistics"""
        
        location = self._build_location_string(property_data)
        
        # Get market analysis from storage
        market_data = await self.storage.get_market_analysis(location)
        
        if market_data:
            return {
                "total_listings": market_data.get("total_properties", 0),
                "average_price": market_data.get("avg_price", 0),
                "average_size": market_data.get("avg_size", 0),
                "price_trend": market_data.get("price_trend", "stable"),
                "market_activity": market_data.get("market_activity", "normal"),
                "days_on_market": market_data.get("avg_days_on_market", 30),
                "inventory_level": market_data.get("inventory_level", "balanced")
            }
        
        # Default statistics
        return {
            "total_listings": 0,
            "average_price": 0,
            "average_size": 0,
            "price_trend": "unknown",
            "market_activity": "unknown",
            "days_on_market": 0,
            "inventory_level": "unknown"
        }
    
    async def _fetch_ml_prediction(self, property_data: Dict[str, Any]) -> Dict[str, Any]:
        """Fetch ML model prediction with fallback"""
        
        try:
            from app.tools.pricing.xgboost_predictor import XGBoostPredictor
            
            predictor = XGBoostPredictor()
            result = await predictor.execute(property_data=property_data)
            
            if result.get("success"):
                return {
                    "predicted_price": result.get("predicted_price"),
                    "confidence": result.get("confidence", 0.7),
                    "price_range": {
                        "min": result.get("price_range", {}).get("min", 0),
                        "max": result.get("price_range", {}).get("max", 0)
                    },
                    "model": "xgboost",
                    "features_used": result.get("features_used", [])
                }
        except Exception as e:
            agent_logger.warning(self.name, f"ML prediction failed: {e}")
        
        # ✅ Fallback: حساب تقديري بناءً على البيانات المتاحة
        size = float(property_data.get("size", 100))
        location = property_data.get("location", "Istanbul")
        district = property_data.get("district", "")
        
        # أسعار أكثر واقعية للمتر المربع
        price_per_sqm_estimates = {
            "kadıköy": 65000,  # ✅ رفع السعر لـ Kadıköy
            "beşiktaş": 70000,
            "şişli": 60000,
            "istanbul": 45000,
            "default": 35000
        }
        
        # تحديد السعر الأساسي
        if "kadıköy" in district.lower() or "kadikoy" in location.lower():
            base_price_per_sqm = 65000
        else:
            base_price_per_sqm = 45000
        
        # حساب السعر المقدر
        estimated_price = base_price_per_sqm * size
        
        # تعديلات حسب العمر والمواصفات
        age = int(property_data.get("building_age", 5))
        if age <= 2:
            estimated_price *= 1.15
        elif age > 15:
            estimated_price *= 0.85
        
        return {
            "predicted_price": round(estimated_price),
            "confidence": 0.75,  # ✅ رفع الثقة
            "price_range": {
                "min": round(estimated_price * 0.85),
                "max": round(estimated_price * 1.15)
            },
            "model": "market_based_estimation",
            "features_used": ["size", "location", "district"],
            "calculation_note": f"Based on {base_price_per_sqm:,.0f} TL/m² for {district or location}"
        }
    
    def _build_location_string(self, property_data: Dict[str, Any]) -> str:
        """Build location string from property data"""
        
        if property_data.get("location"):
            return property_data["location"]
        
        parts = []
        if property_data.get("city"):
            parts.append(property_data["city"])
        if property_data.get("district"):
            parts.append(property_data["district"])
        
        return " - ".join(parts) if parts else "Istanbul"
    
    def _calculate_similarity(self, prop1: Dict[str, Any], prop2: Dict[str, Any]) -> float:
        """Calculate similarity score between two properties"""
        
        score = 0.0
        weights = {
            "size": 0.3,
            "rooms": 0.25,
            "age": 0.15,
            "type": 0.15,
            "location": 0.15
        }
        
        # Size similarity
        if prop1.get("size") and prop2.get("size"):
            size_diff = abs(float(prop1["size"]) - float(prop2["size"]))
            size_ratio = 1 - (size_diff / max(float(prop1["size"]), float(prop2["size"])))
            score += max(0, size_ratio) * weights["size"]
        
        # Rooms similarity
        if prop1.get("rooms") == prop2.get("rooms"):
            score += weights["rooms"]
        
        # Age similarity
        if prop1.get("building_age") and prop2.get("building_age"):
            age_diff = abs(int(prop1["building_age"]) - int(prop2["building_age"]))
            if age_diff <= 2:
                score += weights["age"]
            elif age_diff <= 5:
                score += weights["age"] * 0.5
        
        # Type similarity
        if prop1.get("property_type") == prop2.get("property_type"):
            score += weights["type"]
        
        # Location similarity
        if prop1.get("district") == prop2.get("district"):
            score += weights["location"]
        elif prop1.get("city") == prop2.get("city"):
            score += weights["location"] * 0.5
        
        return min(1.0, score)
    
    def _calculate_avg_price_per_sqm(self, prices: List[float], sizes: List[float]) -> float:
        """Calculate average price per square meter"""
        
        if not prices or not sizes or len(prices) != len(sizes):
            return 0
        
        price_per_sqm_list = []
        for price, size in zip(prices, sizes):
            if size > 0:
                price_per_sqm_list.append(price / size)
        
        return sum(price_per_sqm_list) / len(price_per_sqm_list) if price_per_sqm_list else 0
    
    def _calculate_distribution(self, prices: List[float]) -> Dict[str, int]:
        """Calculate price distribution"""
        
        if not prices:
            return {}
        
        distribution = {
            "0-2M": 0,
            "2-4M": 0,
            "4-6M": 0,
            "6-8M": 0,
            "8-10M": 0,
            "10M+": 0
        }
        
        for price in prices:
            if price < 2000000:
                distribution["0-2M"] += 1
            elif price < 4000000:
                distribution["2-4M"] += 1
            elif price < 6000000:
                distribution["4-6M"] += 1
            elif price < 8000000:
                distribution["6-8M"] += 1
            elif price < 10000000:
                distribution["8-10M"] += 1
            else:
                distribution["10M+"] += 1
        
        return distribution


    
    def _should_trigger_scraping(self, result: Dict[str, Any], property_data: Dict[str, Any]) -> bool:
        """
        Determine if scraping should be triggered based on data availability and freshness
        
        Args:
            result: Current fetched data
            property_data: Property search criteria
            
        Returns:
            True if scraping should be triggered
        """
        # Check if we have meaningful property data
        property_info = result.get("property_info", {})
        similar_properties = result.get("similar_properties", [])
        
        has_location = bool(property_data.get("location") or 
                          property_data.get("city") or 
                          property_data.get("district"))
        
        # Check data quantity
        no_property_info = not property_info or len(property_info) <= 3
        few_similar = len(similar_properties) < 5
        insufficient_data = no_property_info or few_similar
        
        agent_logger.info(self.name, "📊 Scraping decision data", {
            "property_info_count": len(property_info) if property_info else 0,
            "similar_properties_count": len(similar_properties),
            "no_property_info": no_property_info,
            "few_similar": few_similar,
            "insufficient_data": insufficient_data,
            "has_location": has_location
        })
        
        # Check data freshness - simplified approach
        data_is_stale = False
        freshness_check_source = "unknown"
        latest_age_hours = None
        try:
            if has_location and len(similar_properties) > 0:
                # Check if we have timestamp columns
                import pandas as pd
                df = pd.DataFrame(similar_properties)
                
                agent_logger.info(self.name, "🔍 Checking data freshness", {
                    "similar_properties_count": len(similar_properties),
                    "dataframe_columns": list(df.columns) if not df.empty else [],
                    "freshness_check_source": "similar_properties"
                })
                
                # Look for timestamp columns
                timestamp_cols = ['scraped_at', 'updated_at', 'created_at', 'timestamp', 'date']
                found_timestamp = False
                
                for col in timestamp_cols:
                    if col in df.columns:
                        try:
                            # Check the latest timestamp
                            latest_timestamp = pd.to_datetime(df[col]).max()
                            age_hours = (pd.Timestamp.now() - latest_timestamp).total_seconds() / 3600
                            
                            latest_age_hours = round(age_hours, 1)
                            freshness_check_source = "similar_properties"
                            agent_logger.info(self.name, f"📅 Data age check", {
                                "timestamp_column": col,
                                "latest_timestamp": str(latest_timestamp),
                                "age_hours": latest_age_hours,
                                "is_stale": age_hours > 24
                            })
                            
                            if age_hours > 24:
                                data_is_stale = True
                                agent_logger.info(self.name, f"📅 Data is stale ({age_hours:.1f} hours old)")
                            else:
                                agent_logger.info(self.name, f"✅ Data is fresh ({age_hours:.1f} hours old)")
                            
                            found_timestamp = True
                            break
                        except Exception as col_error:
                            agent_logger.warning(self.name, f"Error parsing timestamp column {col}: {col_error}")
                            continue
                
                if not found_timestamp:
                    # If no timestamp found, check if we have enough fresh data
                    # If we have few properties, assume data is stale and needs scraping
                    data_is_stale = len(similar_properties) < 15  # Be more aggressive about scraping
                    freshness_check_source = "similar_properties"
                    agent_logger.info(self.name, f"⚠️ No timestamp found, assuming stale based on quantity: {data_is_stale} (count: {len(similar_properties)})")
            else:
                # No location or no similar properties - need scraping if we have location
                if has_location:
                    data_is_stale = True
                    freshness_check_source = "similar_properties"
                    agent_logger.info(self.name, "📅 No similar properties found, data considered stale")
                        
        except Exception as e:
            agent_logger.warning(self.name, f"Could not check data freshness: {e}")
            # If we can't check freshness, be conservative and assume stale if we have few properties
            data_is_stale = len(similar_properties) < 10
        
        # Trigger scraping if:
        # 1. No location → can't scrape
        # 2. Insufficient data (quantity) OR stale data (time)
        should_scrape = has_location and (insufficient_data or data_is_stale)
        
        reasons = []
        if insufficient_data:
            reasons.append("insufficient_data")
        if data_is_stale:
            reasons.append("stale_data")
            
        agent_logger.info(self.name, f"🔍 Scraping decision: {'YES' if should_scrape else 'NO'}", {
            "reasons": reasons,
            "has_location": has_location,
            "property_info_count": len(property_info) if property_info else 0,
            "similar_properties_count": len(similar_properties),
            "insufficient_data": insufficient_data,
            "data_is_stale": data_is_stale,
            "freshness_check_source": freshness_check_source,
            "age_hours": latest_age_hours,
            "final_decision": should_scrape
        })
        
        if should_scrape:
            agent_logger.info(self.name, "🕷️ Triggering scraping", {
                "reasons": reasons
            })
        
        return should_scrape
    
    async def _trigger_scraping(self, property_data: Dict[str, Any], result: Dict[str, Any]) -> None:
        """
        Trigger property scraping for the requested location
        
        Args:
            property_data: Property search criteria
            result: Current result to update with scraped data
        """
        try:
            # Extract location for scraping
            location = self._extract_location_for_scraping(property_data)
            if not location:
                agent_logger.warning(self.name, "No location found for scraping")
                return
            
            agent_logger.info(self.name, f"🕷️ Starting scraping for location: {location}")
            
            # Try to import and use EmlakjetScraper
            try:
                from app.data_collectors.real_estate.sources.emlakjet import EmlakjetScraper
                
                scraped_data = None
                
                # Use async context manager for proper session handling
                async with EmlakjetScraper() as scraper:
                    # Prepare scraping criteria
                    scraping_criteria = {
                        "location": location,
                        "property_type": property_data.get("type", "apartment"),
                        "max_results": 20,  # Limit for initial scraping
                        "sale_type": "sale"  # Default to sale
                    }
                    
                    # Add budget/price filters if available
                    if property_data.get("budget"):
                        scraping_criteria["max_price"] = property_data["budget"]
                    
                    # Add size filter if available
                    if property_data.get("size"):
                        scraping_criteria["min_size"] = max(50, property_data["size"] - 20)
                        scraping_criteria["max_size"] = property_data["size"] + 20
                    
                    # Perform scraping using the correct method
                    scraped_data = await scraper.collect(
                        location=scraping_criteria["location"],
                        property_type=scraping_criteria.get("property_type", "daire"),
                        filters={
                            "max_price": scraping_criteria.get("max_price"),
                            "min_size": scraping_criteria.get("min_size"),
                            "max_size": scraping_criteria.get("max_size"),
                            "sale_type": scraping_criteria.get("sale_type", "sale")
                        },
                        max_pages=2  # Limit pages for performance
                    )
                
                if scraped_data and scraped_data.get("properties"):
                    properties = scraped_data["properties"]
                    agent_logger.info(self.name, f"🎉 Scraped {len(properties)} properties for {location}")
                    
                    # Update result with scraped data
                    if not result.get("similar_properties"):
                        result["similar_properties"] = []
                    
                    # Add scraped properties to similar properties
                    result["similar_properties"].extend(properties[:10])  # Limit to 10
                    
                    # Update property info if we don't have any
                    if not result.get("property_info") and properties:
                        result["property_info"] = {
                            "location": location,
                            "available_properties": len(properties),
                            "price_range": {
                                "min": min(p.get("price", 0) for p in properties if p.get("price")),
                                "max": max(p.get("price", 0) for p in properties if p.get("price"))
                            },
                            "data_source": "scraped",
                            "scraped_at": datetime.utcnow().isoformat()
                        }
                    
                    # Store scraped data for future use
                    await self._store_scraped_data(location, properties)
                    
                else:
                    agent_logger.warning(self.name, f"No properties scraped for {location}")
                    
            except ImportError as e:
                agent_logger.error(self.name, f"Scraper not available: {e}")
            except Exception as e:
                agent_logger.error(self.name, f"Scraping failed: {e}")
                
        except Exception as e:
            agent_logger.error(self.name, f"Error in trigger_scraping: {e}")
    
    def _extract_location_for_scraping(self, property_data: Dict[str, Any]) -> Optional[str]:
        """Extract location string suitable for scraping"""
        
        # Try different location fields
        location = property_data.get("location")
        if location:
            return str(location)
        
        # Try city/district combination
        city = property_data.get("city")
        district = property_data.get("district")
        
        if city and district:
            return f"{city}/{district}"
        elif city:
            return city
        elif district:
            return district
        
        return None
    
    async def _store_scraped_data(self, location: str, properties: List[Dict[str, Any]]) -> None:
        """Store scraped data for future use"""
        try:
            if self.storage and properties:
                # Store in storage
                await self.storage.save_properties(properties, location, "scraper")
                
                # Cache the results
                if self.cache:
                    cache_key = self.cache.generate_key(CacheType.PROPERTY, f"scraped_{location}")
                    await self.cache.set(cache_key, properties, CacheType.PROPERTY)
                
                agent_logger.info(self.name, f"💾 Stored {len(properties)} scraped properties for {location}")
                
        except Exception as e:
            agent_logger.error(self.name, f"Failed to store scraped data: {e}")