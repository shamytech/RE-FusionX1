# D:\Phd\RE-FusionX\src\backend\app\services\chat_service.py
"""
Chat Service - Updated for new agent architecture
Handles conversational interactions with enhanced data flow
"""

from typing import Dict, Any, List, Optional
from datetime import datetime
import uuid

from app.agents.orchestrator import AgentOrchestrator
# DEPRECATED: Use unified conversation system instead
# # DEPRECATED: Use unified conversation system instead
# from app.memory.conversation_memory import ConversationMemory
from app.validators.input_validator import InputValidator
from app.core.logging import logger, agent_logger
from app.utils.location_utils import get_location_manager, extract_location_from_text
from app.core.conversation.conversation_manager import get_conversation_manager


class ChatService:
    """Enhanced chat service with new architecture support"""
    def __init__(self, model_loader, storage_manager=None, **kwargs):
        """Initialize chat service with new architecture
        
        Args:
            model_loader: Model loader instance
            storage_manager: Optional storage manager (for compatibility)
            **kwargs: Any additional keyword arguments (ignored for compatibility)
        """
        self.model_loader = model_loader
        
        # Store external storage if provided (for compatibility with handlers.py)
        self._external_storage = storage_manager
        
        # Initialize enhanced orchestrator
        self.orchestrator = AgentOrchestrator(
            agents=None,
            websocket_manager=None,
            model_loader=model_loader
        )
        
        # Initialize unified conversation system
        self.conversation_manager = get_conversation_manager(model_loader)
        self.input_validator = InputValidator()
        
        # Configuration
        self.use_new_architecture = True  # Toggle for new/legacy architecture
        
        # Lazy initialization for storage
        self._storage = None
        self._cache = None
        
        # Log any unexpected parameters
        if kwargs:
            logger.debug(f"ChatService received additional parameters: {list(kwargs.keys())}")
        
        agent_logger.info("ChatService", "🤖 Chat service initialized", {
            "architecture": "new" if self.use_new_architecture else "legacy",
            "has_external_storage": storage_manager is not None
        })
    
    @property
    def storage(self):
        """Lazy load storage - use external if provided, otherwise get from integration"""
        if self._storage is None:
            if self._external_storage:
                self._storage = self._external_storage
            else:
                # Use unified storage integration with safe fallback
                try:
                    from app.core.storage.integration import StorageIntegration
                    self._storage = StorageIntegration.get_storage()
                    if self._storage is None:
                        from app.core.storage.storage_manager import get_storage_manager
                        self._storage = get_storage_manager()
                except Exception:
                    from app.core.storage.storage_manager import get_storage_manager
                    self._storage = get_storage_manager()
        return self._storage
    
    @property
    def cache(self):
        """Lazy load cache"""
        if self._cache is None:
            # Use unified cache integration with safe fallback
            try:
                from app.core.storage.integration import StorageIntegration
                self._cache = StorageIntegration.get_cache()
                if self._cache is None:
                    from app.core.storage.unified_cache import get_cache
                    self._cache = get_cache()
            except Exception:
                from app.core.storage.unified_cache import UnifiedCache
                self._cache = UnifiedCache()
        return self._cache
    
    async def process_message(
            self, 
            message: str, 
            session_id: str, 
            context: Optional[Dict[str, Any]] = None, 
            include_sources: bool = False,
            use_new_architecture: Optional[bool] = None,
            use_agents: bool = True,
            **kwargs
        ) -> Dict[str, Any]:
        """
        Process chat message with enhanced architecture
        Enhanced with follow-up detection and context linking
        
        Args:
            message: User message
            session_id: Session ID
            context: Optional context
            include_sources: Include data sources in response
            use_new_architecture: Override architecture setting
            use_agents: Whether to use agents for processing
            **kwargs: Any additional keyword arguments
            
        Returns:
            Processed response
        """
        try:
            # Log any unexpected parameters
            if kwargs:
                logger.debug(f"process_message received additional parameters: {list(kwargs.keys())}")
            
            # Determine architecture to use
            use_new = use_new_architecture if use_new_architecture is not None else self.use_new_architecture
            
            agent_logger.agent_action("ChatService", "Processing message", {
                "session_id": session_id,
                "architecture": "new" if use_new else "legacy",
                "message_length": len(message),
                "use_agents": use_agents
            })
            
            # Validate message
            validation = await self.input_validator.validate_message(message)
            
            if not validation["is_valid"]:
                return {
                    "response": validation["error"],
                    "type": "error",
                    "timestamp": datetime.utcnow().isoformat()
                }
            
            # Get conversation history from unified system
            history = await self.conversation_manager.get_conversation_history(session_id)
            
            # إضافة جديدة: كشف إذا كانت الرسالة متابعة
            is_follow_up = self._detect_follow_up(message, history)
            
            # Add user message to unified conversation system
            await self.conversation_manager.add_message_to_history(
                session_id,
                "user", 
                message,
                metadata={
                    "architecture": "new" if use_new else "legacy",
                    "use_agents": use_agents,
                    "is_follow_up": is_follow_up  # إضافة جديدة
                }
            )
            
            # Extract location information
            location_info = extract_location_from_text(message)
            
            # Prepare enhanced context
            enhanced_context = {
                "session_id": session_id,
                "history": history,
                "language": validation.get("language", "en"),
                "location_info": location_info,
                "architecture": "new" if use_new else "legacy",
                "use_agents": use_agents,
                "is_follow_up": is_follow_up  # إضافة جديدة
            }
            
            # إضافة جديدة: البحث عن تحليل محفوظ في الكاش (دائماً)
            try:
                from app.services.analysis_service import AnalysisService
                # استخدم نسخة خفيفة من خدمة التحليل لقراءة الكاش فقط
                cached_analysis_service = AnalysisService(model_loader=None)
                cached_context = await cached_analysis_service.get_chat_context(session_id)

                if cached_context and isinstance(cached_context, dict) and cached_context.get("has_analysis"):
                    cached_property = cached_context.get("property_data", {})
                    if not self._is_new_location_request(location_info, cached_property, message):
                        enhanced_context["cached_analysis"] = cached_context.get("analysis_results")
                        enhanced_context["cached_property"] = cached_property
                        enhanced_context["completeness"] = cached_context.get("completeness", 1.0)
                        # إضافة مؤشر أن التحليل مكتمل
                        enhanced_context["has_complete_analysis"] = True
                        logger.info(f"Found cached analysis for session {session_id}")
                        logger.debug(f"Cached analysis keys: {list(cached_context.keys())}")
                    else:
                        logger.info("User message indicates a new property context; cached analysis will be ignored for this turn")
                        enhanced_context["cached_property"] = cached_property
                        # نحتفظ بالتحليل السابق في الحقل السابق للاستفادة منه عند الحاجة
                        enhanced_context.setdefault("previous_analysis", cached_context.get("analysis_results"))
                else:
                    logger.info(f"No cached analysis found for session {session_id}")
                    if cached_context:
                        logger.debug(
                            "Cached context type: %s, keys: %s",
                            type(cached_context),
                            list(cached_context.keys()) if isinstance(cached_context, dict) else 'N/A'
                        )
            except Exception as e:
                logger.warning(f"Failed to get cached analysis: {e}", exc_info=True)
            
            # إضافة جديدة: إذا كانت متابعة، أضف التحليل السابق والكيانات المتراكمة
            if is_follow_up and history:
                # البحث عن آخر تحليل من المساعد
                for msg in reversed(history):
                    if msg.get("role") == "assistant":
                        msg_metadata = msg.get("metadata", {})
                        if msg_metadata.get("analysis"):
                            enhanced_context["previous_analysis"] = msg_metadata["analysis"]
                        if msg_metadata.get("entities"):
                            enhanced_context["accumulated_entities"] = msg_metadata["entities"]
                        break
                
                # البحث عن الكيانات المتراكمة من الرسائل السابقة
                accumulated_entities = {
                    "property": {},
                    "location": {},
                    "search_criteria": {}
                }
                
                for msg in history:
                    if msg.get("metadata", {}).get("entities"):
                        entities = msg["metadata"]["entities"]
                        for category in ["property", "location", "search_criteria"]:
                            if category in entities:
                                accumulated_entities[category].update(entities[category])
                
                if any(accumulated_entities.values()):
                    enhanced_context["accumulated_entities"] = accumulated_entities
            
            # Merge with provided context
            if context:
                enhanced_context.update(context)
            
            agent_logger.info("ChatService", f"🚀 Processing with {'NEW' if use_new else 'LEGACY'} architecture", {
                "is_follow_up": is_follow_up,
                "has_previous_analysis": "previous_analysis" in enhanced_context
            })
            
            # Process based on use_agents flag
            # Process based on use_agents flag
            if use_agents and self.orchestrator:
                logger.info(f"🔍 DEBUG: Calling orchestrator.process")
                
                result = await self.orchestrator.process(
                    {
                        "message": message,
                        "use_new_architecture": use_new,
                        "is_follow_up": is_follow_up,
                        "session_context": enhanced_context.get("accumulated_entities", {})
                    },
                    enhanced_context
                )
                
                # تشخيص مباشرة بعد orchestrator
                logger.info(f"🔍 DEBUG ChatService: After orchestrator, result type: {type(result)}")
                if isinstance(result, dict):
                    logger.info(f"🔍 DEBUG ChatService: result is dict with keys: {list(result.keys())}")
                else:
                    logger.error(f"🔍 DEBUG ChatService: ERROR! result is not dict: {type(result)} = {result}")
                    
            else:
                result = {
                    "result": {
                        "response": f"Processing message: {message}",
                        "type": "simple"
                    },
                    "metadata": {
                        "intent": "general"
                    }
                }

            # تشخيص قبل السطر 391
            logger.info(f"🔍 DEBUG ChatService Line 390: About to check result.get('result')")
            logger.info(f"🔍 DEBUG ChatService Line 390: result type = {type(result)}")

            # السطر 391 - المشكلة هنا
            # Extract response
            response_text = self._extract_response(result, use_new)

            if not response_text:
                logger.error(f"No response extracted from result")
                response_text = "I apologize, but I couldn't process your request properly. Please try again."

            # تعريف metadata_to_save أولاً - قبل استخدامه
            metadata_to_save = {
                "architecture": "new" if use_new else "legacy",
                "use_agents": use_agents,
                "is_follow_up": is_follow_up
            }

            # إضافة جديدة: حفظ التحليل والكيانات للرجوع إليها لاحقاً
            if result.get("result") and isinstance(result.get("result"), dict):
                result_data = result["result"]
                if result_data.get("analysis"):
                    metadata_to_save["analysis"] = result_data["analysis"]
                if result_data.get("completeness"):
                    metadata_to_save["completeness"] = result_data["completeness"]

            if result.get("metadata") and isinstance(result.get("metadata"), dict):
                result_metadata = result["metadata"]
                if result_metadata.get("entities_extracted"):
                    metadata_to_save["entities"] = result_metadata["entities_extracted"]
                if result_metadata.get("intent"):
                    metadata_to_save["intent"] = result_metadata["intent"]
                if result_metadata.get("agents_used"):
                    metadata_to_save["agents_used"] = result_metadata["agents_used"]

            # Add assistant message to unified conversation system
            await self.conversation_manager.add_message_to_history(
                session_id,
                "assistant", 
                response_text,
                metadata=metadata_to_save
            )

            
            # Prepare final response
            response = {
                "response": response_text,
                "type": self._determine_response_type(result),
                "timestamp": datetime.utcnow().isoformat(),
                "architecture": "new" if use_new else "legacy",
                "used_agents": use_agents,
                "is_follow_up": is_follow_up  # إضافة جديدة
            }
            
            # Add sources if requested
            if include_sources:
                response["sources"] = self._extract_sources(result)
            
            # Add metadata if available
            if result.get("metadata"):
                response["metadata"] = result["metadata"]
                
                # إضافة جديدة: إضافة معلومات الاكتمال إذا كانت متوفرة
                if result["metadata"].get("completeness"):
                    response["completeness"] = result["metadata"]["completeness"]
                
                # إضافة جديدة: إضافة مؤشر إذا كان النظام يحتاج مزيد من المعلومات
                if result["metadata"].get("needs_more_info"):
                    response["needs_more_info"] = True
                    response["missing_fields"] = result["metadata"].get("missing_fields", [])
            
            # Generate suggestions based on context
            suggestions = self._generate_suggestions(result, enhanced_context)
            if suggestions:
                response["suggestions"] = suggestions
            
            # إضافة جديدة: إذا كانت المعلومات غير مكتملة، أضف اقتراحات محددة
            if result.get("metadata", {}).get("completeness", {}).get("suggestions"):
                if not response.get("suggestions"):
                    response["suggestions"] = []
                response["suggestions"].extend(
                    result["metadata"]["completeness"]["suggestions"][:2]
                )
            
            agent_logger.agent_result("ChatService", {
                "response_length": len(response_text),
                "architecture": "new" if use_new else "legacy",
                "used_agents": use_agents,
                "is_follow_up": is_follow_up,
                "has_completeness_info": "completeness" in response,
                "needs_more_info": response.get("needs_more_info", False)
            }, success=True)
            
            return response
            
        except Exception as e:
            logger.error(f"Chat processing failed: {e}", exc_info=True)
            
            # Return error response
            return {
                "response": "An error occurred while processing your request. Please try again.",
                "type": "error",
                "timestamp": datetime.utcnow().isoformat(),
                "error": str(e)
            }


    def _extract_response(self, result: Dict[str, Any], is_new_architecture: bool) -> Optional[str]:
        """
        Extract response based on architecture
        """
        if not result or not isinstance(result, dict):
            return None
        
        result_data = result.get("result", {})
        
        if is_new_architecture:
            # New architecture: response is already formatted
            if isinstance(result_data, dict) and "response" in result_data:
                return result_data["response"]
        else:
            # Legacy architecture: need to format
            if not isinstance(result_data, dict):
                return str(result_data) if result_data else None
            
            if "property_summary" in result_data and "valuation" in result_data:
                return self._format_property_analysis(result_data)
            
            if "response" in result_data:
                return result_data["response"]
            
            if "valuation" in result_data:
                return self._format_valuation_only(result_data["valuation"])
            
            if result_data:
                return self._format_generic_data(result_data)
        
        return None
    
    def _determine_response_type(self, result: Dict[str, Any]) -> str:
        """Determine response type from result"""
        
        # Check metadata first
        metadata = result.get("metadata", {})
        if metadata.get("intent"):
            return metadata["intent"]
        
        # Check result data
        result_data = result.get("result", {})
        if isinstance(result_data, dict):
            if "intent" in result_data:
                return result_data["intent"]
            if "type" in result_data:
                return result_data["type"]
        
        return "general"
    
    def _extract_sources(self, result: Dict[str, Any]) -> List[str]:
        """Extract data sources from result"""
        sources = []
        
        # Check metadata for data sources
        metadata = result.get("metadata", {})
        if metadata.get("data_collected"):
            sources.extend(metadata["data_collected"])
        
        # Check for agents used
        if metadata.get("agents_used"):
            for agent in metadata["agents_used"]:
                if "property" in agent:
                    sources.append("property_data")
                elif "market" in agent:
                    sources.append("market_data")
                elif "location" in agent:
                    sources.append("location_data")
        
        # Legacy source extraction
        if not sources:
            result_data = result.get("result", {})
            if isinstance(result_data, dict):
                if "valuation" in result_data:
                    sources.append("property_analysis")
                if "market_analysis" in result_data:
                    sources.append("market_data")
                if "location" in result_data.get("property_summary", {}):
                    sources.append("location_analysis")
        
        return sources if sources else ["general_analysis"]
    
    def _generate_suggestions(self, result: Dict[str, Any], context: Dict[str, Any]) -> List[str]:
        """Generate follow-up suggestions based on result"""
        suggestions = []
        
        # Get intent from metadata or result
        metadata = result.get("metadata", {})
        intent = metadata.get("intent", "")
        
        if not intent:
            result_data = result.get("result", {})
            if isinstance(result_data, dict):
                intent = result_data.get("intent", "")
        
        # Generate suggestions based on intent
        if intent == "property_valuation":
            suggestions.extend([
                "Compare with similar properties",
                "View market trends for this area",
                "Calculate investment potential"
            ])
        elif intent == "market_comparison":
            suggestions.extend([
                "Get detailed property valuation",
                "Explore different neighborhoods",
                "View historical price trends"
            ])
        elif intent == "market_trends":
            suggestions.extend([
                "Find properties in trending areas",
                "Compare different property types",
                "Get investment recommendations"
            ])
        elif intent == "location_analysis":
            suggestions.extend([
                "Search properties in this location",
                "Compare with nearby areas",
                "View amenities and facilities"
            ])
        else:
            suggestions.extend([
                "Get property valuation",
                "Explore market trends",
                "Find investment opportunities"
            ])
        
        return suggestions[:3]
    
    def _format_property_analysis(self, data: Dict[str, Any]) -> str:
        """Format property analysis (legacy)"""
        summary = data.get("property_summary", {})
        valuation = data.get("valuation", {})
        market = data.get("market_analysis", {})
        recommendations = data.get("recommendations", [])
        
        response_parts = ["## Property Analysis\n"]
        
        if summary:
            response_parts.append("**Property Details:**")
            for key, value in summary.items():
                if value:
                    formatted_key = key.replace('_', ' ').title()
                    response_parts.append(f"• {formatted_key}: {value}")
        
        if valuation:
            response_parts.append("\n**Valuation Results:**")
            
            if "estimated_value" in valuation and valuation["estimated_value"]:
                response_parts.append(f"💰 **Estimated Value:** {valuation['estimated_value']:,.0f} TL")
            
            if "price_per_sqm" in valuation and valuation["price_per_sqm"]:
                response_parts.append(f"📊 **Price per m²:** {valuation['price_per_sqm']:,.0f} TL/m²")
            
            if "confidence_level" in valuation:
                confidence_pct = valuation['confidence_level'] * 100
                response_parts.append(f"🎯 **Confidence Level:** {confidence_pct:.0f}%")
        
        if market:
            response_parts.append("\n**Market Analysis:**")
            for key, value in market.items():
                if value:
                    formatted_key = key.replace('_', ' ').title()
                    response_parts.append(f"• {formatted_key}: {value}")
        
        if recommendations:
            response_parts.append("\n**Recommendations:**")
            for rec in recommendations[:5]:
                response_parts.append(f"• {rec}")
        
        return "\n".join(response_parts)
    
    def _detect_follow_up(self, message: str, history: List[Dict]) -> bool:
        """
        Detect if message is a follow-up to previous conversation
        """
        # إذا لم يكن هناك تاريخ، فليست متابعة
        if not history:
            return False
        
        # إذا كان هناك تاريخ محادثة حديث (آخر رسالة خلال 30 دقيقة)
        if len(history) >= 2:  # يجب أن يكون هناك على الأقل user + assistant
            # إذا كان الـ assistant سأل سؤال في آخر رد
            last_assistant_message = None
            for msg in reversed(history):
                if msg.get("role") == "assistant":
                    last_assistant_message = msg.get("content", "").lower()
                    break
            
            if last_assistant_message:
                # فحص إذا كان الـ assistant سأل عن تفاصيل
                question_indicators = [
                    "budget", "location", "size", "preference", "area", 
                    "district", "details", "tell me", "what", "which",
                    "how much", "where", "when", "what type"
                ]
                
                assistant_asked_question = any(indicator in last_assistant_message for indicator in question_indicators)
                assistant_asked_question = assistant_asked_question or "?" in last_assistant_message
                
                if assistant_asked_question:
                    # فحص إذا كان المستخدم يجيب بتفاصيل عقارية
                    message_lower = message.lower()
                    property_details = [
                        "kadıköy", "beşiktaş", "istanbul", "ankara", "izmir",  # مناطق
                        "tl", "lira", "million", "thousand", "budget",         # ميزانية
                        "1+1", "2+1", "3+1", "4+1", "bedroom", "room",       # حجم
                        "prefer", "want", "looking for", "need",              # تفضيلات
                        "around", "about", "approximately", "near"            # تقديرات
                    ]
                    
                    if any(detail in message_lower for detail in property_details):
                        return True
        
        # كلمات مؤشرة على المتابعة التقليدية
        follow_up_indicators = [
            "i can't", "i cannot", "but", "however", "what about",
            "and", "also", "in addition", "furthermore", "moreover",
            "that", "it", "this", "these", "those",
            "the property", "the apartment", "the house",
            "yes", "no", "okay", "ok", "sure", "fine",
            "what can i do", "alternatives", "options"
        ]
        
        message_lower = message.lower()
        
        # فحص المؤشرات التقليدية
        for indicator in follow_up_indicators:
            if indicator in message_lower:
                return True
        
        # فحص إذا كانت الرسالة قصيرة وتحتوي على نفي
        words = message.split()
        if len(words) < 10 and any(neg in message_lower for neg in ["no", "not", "can't", "cannot", "won't", "don't"]):
            return True
        
        return False

    
    def _format_valuation_only(self, valuation: Dict[str, Any]) -> str:
        """Format valuation data (legacy)"""
        response_parts = ["## Property Valuation\n"]
        
        for key, value in valuation.items():
            if value:
                if key == "estimated_value":
                    response_parts.append(f"**Estimated Value:** {value:,.0f} TL")
                elif key == "price_per_sqm":
                    response_parts.append(f"**Price per m²:** {value:,.0f} TL/m²")
                elif key == "confidence_level":
                    response_parts.append(f"**Confidence:** {value*100:.0f}%")
                else:
                    formatted_key = key.replace('_', ' ').title()
                    response_parts.append(f"**{formatted_key}:** {value}")
        
        return "\n".join(response_parts)
    
    def _format_generic_data(self, data: Dict[str, Any]) -> str:
        """Format generic data (legacy)"""
        response_parts = ["## Analysis Results\n"]
        
        def format_value(value):
            if isinstance(value, (int, float)):
                if value > 1000:
                    return f"{value:,.0f}"
                else:
                    return f"{value:.2f}"
            elif isinstance(value, dict):
                sub_parts = []
                for k, v in value.items():
                    if v:
                        sub_parts.append(f"{k}: {format_value(v)}")
                return " | ".join(sub_parts)
            elif isinstance(value, list):
                return ", ".join(str(v) for v in value[:3])
            else:
                return str(value)
        
        for key, value in data.items():
            if value:
                formatted_key = key.replace('_', ' ').title()
                formatted_value = format_value(value)
                response_parts.append(f"**{formatted_key}:** {formatted_value}")
        
        return "\n".join(response_parts)
    
    async def get_conversation_summary(self, session_id: str) -> Dict[str, Any]:
        """Get conversation summary"""
        return await self.conversation_manager.get_session_summary(session_id)
    
    async def clear_conversation(self, session_id: str) -> bool:
        """Clear conversation history"""
        return await self.conversation_manager.clear_session(session_id)
    
    def set_architecture(self, use_new: bool):
        """
        Toggle between new and legacy architecture
        
        Args:
            use_new: True for new architecture, False for legacy
        """
        self.use_new_architecture = use_new
        agent_logger.info("ChatService", f"Architecture set to: {'NEW' if use_new else 'LEGACY'}")
