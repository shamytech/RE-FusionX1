"""
Analysis service.
Handles property analysis business logic.
"""

import asyncio
from typing import Dict, Any, List, Optional
from datetime import datetime
import uuid

from app.agents.orchestrator import AgentOrchestrator
from app.core.logging import logger
from app.core.exceptions import ValidationException, InsufficientDataException
from app.core.storage.integration import StorageIntegration
from app.core.storage.unified_cache import CacheType

class AnalysisService:
    """Service for property analysis operations."""
    
    def __init__(self, model_loader):
        """
        Initialize analysis service.
        
        Args:
            model_loader: Model loader instance
        """
        self.model_loader = model_loader
        self._storage = None
        self._cache = None
        # إصلاح: تمرير model_loader الصحيح للـ orchestrator
        actual_model_loader = model_loader.model_loader if hasattr(model_loader, 'model_loader') else model_loader
        self.orchestrator = AgentOrchestrator(actual_model_loader)

    @property
    def storage(self):
        """Lazy load storage"""
        if self._storage is None:
            from app.core.storage.integration import StorageIntegration
            self._storage = StorageIntegration.get_storage()
        return self._storage
    
    @property
    def cache(self):
        """Lazy load cache"""
        if self._cache is None:
            from app.core.storage.integration import StorageIntegration
            self._cache = StorageIntegration.get_cache()
        return self._cache
        
    
    async def analyze_property(
        self,
        property_data: Dict[str, Any],
        session_id: str
    ) -> Dict[str, Any]:
        """
        Perform comprehensive property analysis.
        
        Args:
            property_data: Property information
            session_id: Session identifier
            
        Returns:
            Analysis results
        """
        try:
            logger.info(f"Starting property analysis for session {session_id}")
            
            # Generate analysis ID
            analysis_id = str(uuid.uuid4())
            
            # Prepare input for orchestrator
            input_data = {
                "property_data": property_data,
                "analysis_type": "comprehensive",
                "session_id": session_id
            }
            # إضافة كاش للتحليل
            cache_key = self.cache.generate_key(
                CacheType.PROPERTY,
                f"analysis_{property_data.get('property_id', '')}",
                {"session": session_id}
            )
            
            cached = await self.cache.get(cache_key, CacheType.PROPERTY)
            if cached:
                return cached
        
            
            # Execute analysis through orchestrator
            result = await self.orchestrator.process(
                input_data,
                context={"session_id": session_id}
            )
            
            # Format response
            analysis_result = result.get("result", {})
            
            await self.cache.set(cache_key, result, CacheType.PROPERTY)
            
            return {
                "analysis_id": analysis_id,
                "timestamp": datetime.utcnow().isoformat(),
                "property_summary": self.create_property_summary(property_data),
                "price_estimation": analysis_result.get("price_estimation"),
                "market_analysis": analysis_result.get("market_analysis"),
                "investment_analysis": analysis_result.get("investment_analysis"),
                "location_analysis": analysis_result.get("location_analysis"),
                "recommendations": analysis_result.get("recommendations", []),
                "key_insights": self.extract_key_insights(analysis_result),
                "confidence_score": analysis_result.get("confidence_score", 0.7),
                "data_sources": ["property_database", "market_data", "ml_models"],
                "analysis_type": "comprehensive"
            }
            
        except ValidationException as e:
            logger.error(f"Validation error in analysis: {e}")
            raise
        except Exception as e:
            logger.error(f"Analysis failed: {e}", exc_info=True)
            raise
    
    async def analyze_property_with_images(
        self,
        property_data: Dict[str, Any],
        images: List[Any],
        session_id: str
    ) -> Dict[str, Any]:
        """
        Analyze property including visual assessment.
        
        Args:
            property_data: Property information
            images: Property images
            session_id: Session identifier
            
        Returns:
            Analysis results with visual assessment
        """
        try:
            # Perform standard analysis
            analysis = await self.analyze_property(property_data, session_id)
            
            # Add image analysis
            if images:
                from app.tools.analysis.image_analyzer import ImageAnalyzer
                
                image_analyzer = ImageAnalyzer(self.model_loader)
                image_results = await image_analyzer.execute(
                    images=images,
                    context=property_data
                )
                
                analysis["visual_assessment"] = image_results
                
                # Update confidence based on images
                if image_results.get("condition_score"):
                    current_confidence = analysis.get("confidence_score", 0.7)
                    analysis["confidence_score"] = min(0.95, current_confidence + 0.1)
            
            return analysis
            
        except Exception as e:
            logger.error(f"Analysis with images failed: {e}", exc_info=True)
            raise
    
    async def analyze_market(
        self,
        location: str,
        property_type: Optional[str],
        session_id: str
    ) -> Dict[str, Any]:
        """
        Analyze market conditions.
        
        Args:
            location: Location to analyze
            property_type: Optional property type filter
            session_id: Session identifier
            
        Returns:
            Market analysis results
        """
        try:
            from app.agents.market_data_agent import MarketAgent
            
            market_agent = MarketAgent(self.model_loader)
            
            result = await market_agent.process(
                {
                    "location": location,
                    "property_type": property_type
                },
                context={"session_id": session_id}
            )
            
            return result.get("result", {})
            
        except Exception as e:
            logger.error(f"Market analysis failed: {e}", exc_info=True)
            raise
    
    async def analyze_investment(
        self,
        budget: float,
        location: str,
        preferences: Dict[str, Any],
        session_id: str
    ) -> Dict[str, Any]:
        """
        Analyze investment opportunities.
        
        Args:
            budget: Investment budget
            location: Preferred location
            preferences: Investment preferences
            session_id: Session identifier
            
        Returns:
            Investment analysis and recommendations
        """
        try:
            # Use market agent for investment analysis
            from app.agents.market_data_agent import MarketAgent
            
            market_agent = MarketAgent(self.model_loader)
            
            result = await market_agent.process(
                {
                    "location": location,
                    "budget": budget,
                    "preferences": preferences,
                    "analysis_type": "investment"
                },
                context={"session_id": session_id}
            )
            
            market_result = result.get("result", {})
            
            # Generate investment recommendations
            recommendations = self.generate_investment_recommendations(
                budget,
                location,
                preferences,
                market_result
            )
            
            return {
                "budget": budget,
                "location": location,
                "market_analysis": market_result,
                "opportunities": market_result.get("investment_opportunities", []),
                "recommendations": recommendations,
                "risk_assessment": market_result.get("risk_assessment", {}),
                "expected_returns": self.calculate_expected_returns(budget, market_result)
            }
            
        except Exception as e:
            logger.error(f"Investment analysis failed: {e}", exc_info=True)
            raise
    
    def create_property_summary(self, property_data: Dict[str, Any]) -> Dict[str, Any]:
        """Create property summary."""
        return {
            "location": property_data.get("location", "Unknown"),
            "type": property_data.get("property_type", "Unknown"),
            "size": property_data.get("size", "Unknown"),
            "rooms": property_data.get("rooms", "Unknown"),
            "age": property_data.get("building_age", "Unknown"),
            "key_features": self.extract_key_features(property_data)
        }
    
    def extract_key_features(self, property_data: Dict[str, Any]) -> List[str]:
        """Extract key property features."""
        features = []
        
        if property_data.get("in_site") == "Evet":
            features.append("In gated community")
        
        if property_data.get("credit_eligible") == "Krediye Uygun":
            features.append("Mortgage eligible")
        
        if property_data.get("furnished") == "Eşyalı":
            features.append("Furnished")
        
        property_features = property_data.get("features", {})
        if "parking" in str(property_features).lower():
            features.append("Parking available")
        
        if "elevator" in str(property_features).lower():
            features.append("Elevator")
        
        return features
    
    def extract_key_insights(self, analysis_result: Dict[str, Any]) -> List[str]:
        """Extract key insights from analysis."""
        insights = []
        
        if analysis_result.get("price_estimation"):
            price = analysis_result["price_estimation"].get("estimated_price")
            if price:
                insights.append(f"Estimated value: {price}")
        
        if analysis_result.get("investment_score"):
            score = analysis_result["investment_score"]
            if score >= 7:
                insights.append("High investment potential")
            elif score >= 5:
                insights.append("Moderate investment potential")
        
        if analysis_result.get("market_position") == "below_market":
            insights.append("Priced below market average - good opportunity")
        
        return insights
    
    def generate_investment_recommendations(
        self,
        budget: float,
        location: str,
        preferences: Dict[str, Any],
        market_data: Dict[str, Any]
    ) -> List[str]:
        """Generate investment recommendations."""
        recommendations = []
        
        # Budget-based recommendations
        if budget < 2000000:
            recommendations.append("Consider emerging neighborhoods for better value")
            recommendations.append("Look for properties needing minor renovation")
        elif budget < 5000000:
            recommendations.append("Focus on established areas with steady appreciation")
            recommendations.append("Consider 2+1 or 3+1 apartments for better rental yield")
        else:
            recommendations.append("Premium locations offer stable long-term value")
            recommendations.append("Consider multiple smaller units for diversification")
        
        # Market-based recommendations
        if market_data.get("market_trends", {}).get("trend_direction") == "increasing":
            recommendations.append("Market trending upward - good entry point")
        
        # Preference-based recommendations
        if preferences.get("rental_focus"):
            recommendations.append("Prioritize locations near universities or business districts")
        
        return recommendations
    
    def calculate_expected_returns(
        self,
        budget: float,
        market_data: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Calculate expected investment returns."""
        # Get market growth rate
        growth_rate = market_data.get("market_trends", {}).get("forecast_12m", 15) / 100
        
        # Calculate returns
        annual_appreciation = budget * growth_rate
        
        # Estimate rental yield (simplified)
        monthly_rent = budget * 0.004  # 0.4% monthly rental yield
        annual_rental = monthly_rent * 12
        
        total_annual_return = annual_appreciation + annual_rental
        roi_percentage = (total_annual_return / budget) * 100
        
        return {
            "annual_appreciation": round(annual_appreciation),
            "annual_rental_income": round(annual_rental),
            "total_annual_return": round(total_annual_return),
            "roi_percentage": round(roi_percentage, 2),
            "payback_years": round(budget / annual_rental, 1) if annual_rental > 0 else None
        }
    
    async def store_analysis_for_chat(
        self,
        property_data: Dict[str, Any],
        analysis_results: Dict[str, Any],
        session_id: str
    ) -> bool:
        """
        Store analysis results in cache for chat context.
        This allows chat to access analysis data without re-running analysis.
        
        Args:
            property_data: Property information
            analysis_results: Analysis results
            session_id: Session identifier
            
        Returns:
            True if stored successfully
        """
        try:
            logger.info(f"Storing analysis for chat context - session: {session_id}")
            from app.core.storage.unified_cache import CacheType
            
            # Store property data
            property_cache_key = self.cache.generate_key(
                CacheType.PROPERTY,
                f"chat_property_{session_id}",
                {"session": session_id}
            )
            await self.cache.set(property_cache_key, property_data, CacheType.PROPERTY)
            
            # Store analysis results
            analysis_cache_key = self.cache.generate_key(
                CacheType.PROPERTY,
                f"chat_analysis_{session_id}",
                {"session": session_id}
            )
            await self.cache.set(analysis_cache_key, analysis_results, CacheType.PROPERTY)
            
            # Store session context for chat
            session_context = {
                "property_data": property_data,
                "analysis_results": analysis_results,
                "timestamp": datetime.utcnow().isoformat(),
                "completeness": 1.0,  # Full analysis completed
                "has_analysis": True
            }
            
            context_cache_key = self.cache.generate_key(
                CacheType.PROPERTY,
                f"chat_context_{session_id}",
                {"session": session_id}
            )
            await self.cache.set(context_cache_key, session_context, CacheType.PROPERTY)
            
            logger.info(f"Analysis results stored for chat context in session {session_id}")
            logger.debug(f"Stored data - property keys: {list(property_data.keys()) if property_data else 'None'}")
            logger.debug(f"Stored data - analysis keys: {list(analysis_results.keys()) if analysis_results else 'None'}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to store analysis for chat: {e}", exc_info=True)
            return False
    
    async def get_chat_context(self, session_id: str) -> Optional[Dict[str, Any]]:
        """
        Get stored analysis context for chat.
        
        Args:
            session_id: Session identifier
            
        Returns:
            Stored context or None
        """
        try:
            from app.core.storage.unified_cache import CacheType
            
            context_cache_key = self.cache.generate_key(
                CacheType.PROPERTY,
                f"chat_context_{session_id}",
                {"session": session_id}
            )
            
            context = await self.cache.get(context_cache_key, CacheType.PROPERTY)
            return context
            
        except Exception as e:
            logger.error(f"Failed to get chat context: {e}", exc_info=True)
            return None