"""Business logic services."""

from app.core.logging import logger

# Import services with error handling
AnalysisService = None
ChatService = None
PropertyService = None

try:
    from .analysis_service import AnalysisService
except ImportError as e:
    logger.warning(f"AnalysisService not available: {e}")

try:
    from .chat_service import ChatService
except ImportError as e:
    logger.warning(f"ChatService not available: {e}")

try:
    from .property_service import PropertyService
except ImportError as e:
    logger.warning(f"PropertyService not available: {e}")

__all__ = ['AnalysisService', 'ChatService', 'PropertyService']
