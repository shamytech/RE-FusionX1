# app/services/property_service.py

"""
Property service - Updated to use unified storage system
Handles property-related operations with new storage architecture
"""

from typing import Dict, Any, List, Optional
from datetime import datetime

from app.tools.database.property_repository import PropertyRepository
from app.tools.database.similarity_finder import SimilarityFinder
from app.tools.search.property_searcher import PropertySearcher
from app.core.logging import logger
from app.core.storage.integration import StorageIntegration


class PropertyService:
    """Service for property operations using unified storage."""
    
    def __init__(self):
        """
        Initialize property service with unified storage
        """
        self._storage = None
        self._cache = None
        self.repository = PropertyRepository()
        self.similarity_finder = SimilarityFinder()
        self.property_searcher = PropertySearcher()
        

    @property
    def storage(self):
        """Lazy load storage"""
        if self._storage is None:
            from app.core.storage.integration import StorageIntegration
            self._storage = StorageIntegration.get_storage()
        return self._storage
    
    @property
    def cache(self):
        """Lazy load cache"""
        if self._cache is None:
            from app.core.storage.integration import StorageIntegration
            self._cache = StorageIntegration.get_cache()
        return self._cache

    
    async def search_properties(self, criteria: Dict[str, Any], limit: int = 20, offset: int = 0) -> List[Dict[str, Any]]:
        """
        Search for properties using unified storage
        """
        try:
            # Generate cache key
            cache_key = self.cache.generate_key(
                CacheType.SEARCH,
                "property_search",
                {**criteria, "limit": limit, "offset": offset}
            )
            
            # Check cache
            cached = await self.cache.get(cache_key, CacheType.SEARCH)
            if cached:
                logger.info("Returning cached search results")
                return cached
            
            # Get location from criteria
            location = criteria.get("location", "Istanbul")
            
            # Search in storage first
            properties = await self.storage.get_properties(
                location=location,
                filters={
                    "property_type": criteria.get("property_type"),
                    "min_price": criteria.get("min_price"),
                    "max_price": criteria.get("max_price"),
                    "min_size": criteria.get("min_size"),
                    "max_size": criteria.get("max_size"),
                    "rooms": criteria.get("rooms"),
                    "limit": limit
                }
            )
            
            # If no results from storage, try property searcher
            if not properties:
                result = await self.property_searcher.execute(
                    **criteria,
                    limit=limit,
                    offset=offset
                )
                properties = result.get("properties", [])
                
                # Save to storage if found
                if properties:
                    await self.storage.save_properties(
                        properties, 
                        location,
                        "property_searcher"
                    )
            
            # Cache results
            await self.cache.set(cache_key, properties, CacheType.SEARCH)
            
            return properties
            
        except Exception as e:
            logger.error(f"Property search failed: {e}", exc_info=True)
            return []
    
    async def get_property(self, property_id: str) -> Optional[Dict[str, Any]]:
        """
        Get property details using unified cache
        """
        try:
            # Generate cache key
            cache_key = self.cache.generate_key(
                CacheType.PROPERTY,
                f"details_{property_id}"
            )
            
            # Check cache
            cached = await self.cache.get(cache_key, CacheType.PROPERTY)
            if cached:
                return cached
            
            # Get from repository
            property_data = await self.repository.get_property(property_id)
            
            if property_data:
                # Cache result
                await self.cache.set(cache_key, property_data, CacheType.PROPERTY)
            
            return property_data
            
        except Exception as e:
            logger.error(f"Failed to get property {property_id}: {e}")
            return None
    
    async def find_similar_properties(self, property_id: str, limit: int = 10) -> List[Dict[str, Any]]:
        """
        Find similar properties using unified storage
        """
        try:
            # Get reference property
            reference = await self.get_property(property_id)
            if not reference:
                return []
            
            # Use storage manager for similar properties
            similar = await self.storage.search_similar_properties(
                reference,
                limit
            )
            
            return similar
            
        except Exception as e:
            logger.error(f"Failed to find similar properties: {e}")
            return []
    
    async def compare_properties(self, property_ids: List[str]) -> Dict[str, Any]:
        """
        Compare multiple properties
        """
        try:
            # Get all properties
            properties = []
            for prop_id in property_ids:
                prop = await self.get_property(prop_id)
                if prop:
                    properties.append(prop)
            
            if len(properties) < 2:
                return {"error": "Need at least 2 properties for comparison"}
            
            # Create comparison
            comparison = {
                "properties": properties,
                "comparison_table": self.create_comparison_table(properties),
                "best_value": self.find_best_value(properties),
                "insights": self.generate_comparison_insights(properties)
            }
            
            return comparison
            
        except Exception as e:
            logger.error(f"Property comparison failed: {e}")
            return {"error": str(e)}
    
    def create_comparison_table(self, properties: List[Dict[str, Any]]) -> Dict[str, List[Any]]:
        """Create property comparison table."""
        table = {
            "location": [],
            "price": [],
            "size": [],
            "rooms": [],
            "building_age": [],
            "price_per_sqm": [],
            "in_site": [],
            "features_count": []
        }
        
        for prop in properties:
            table["location"].append(prop.get("location", "N/A"))
            table["price"].append(prop.get("price", "N/A"))
            table["size"].append(prop.get("size_net", prop.get("size_gross", "N/A")))
            table["rooms"].append(prop.get("room_count", "N/A"))
            table["building_age"].append(prop.get("building_age", "N/A"))
            
            # Calculate price per sqm
            try:
                price = float(prop.get("price", "0").replace(" TL", "").replace(".", "").replace(",", "."))
                size = float(prop.get("size_net", "1").replace(" m²", "").replace(",", "."))
                table["price_per_sqm"].append(f"{round(price/size):,} TL/m²" if size > 0 else "N/A")
            except:
                table["price_per_sqm"].append("N/A")
            
            table["in_site"].append(prop.get("in_site", "N/A"))
            
            # Count features
            features = prop.get("property_features", {})
            feature_count = sum(len(v) if isinstance(v, list) else 1 for v in features.values())
            table["features_count"].append(feature_count)
        
        return table
    
    def find_best_value(self, properties: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Find best value property."""
        if not properties:
            return {}
        
        best_value = None
        best_score = float('inf')
        
        for prop in properties:
            try:
                price = float(prop.get("price", "0").replace(" TL", "").replace(".", "").replace(",", "."))
                size = float(prop.get("size_net", "1").replace(" m²", "").replace(",", "."))
                
                # Simple value score (price per sqm)
                if size > 0:
                    score = price / size
                    if score < best_score:
                        best_score = score
                        best_value = prop
            except:
                continue
        
        return best_value or properties[0]
    
    def generate_comparison_insights(self, properties: List[Dict[str, Any]]) -> List[str]:
        """Generate comparison insights."""
        insights = []
        
        # Price comparison
        prices = []
        for prop in properties:
            try:
                price = float(prop.get("price", "0").replace(" TL", "").replace(".", "").replace(",", "."))
                prices.append(price)
            except:
                pass
        
        if prices:
            min_price = min(prices)
            max_price = max(prices)
            price_diff = ((max_price - min_price) / min_price) * 100 if min_price > 0 else 0
            
            insights.append(f"Price range: {min_price:,.0f} - {max_price:,.0f} TL ({price_diff:.1f}% difference)")
        
        # Size comparison
        sizes = []
        for prop in properties:
            try:
                size = float(prop.get("size_net", "0").replace(" m²", "").replace(",", "."))
                if size > 0:
                    sizes.append(size)
            except:
                pass
        
        if sizes:
            insights.append(f"Size range: {min(sizes):.0f} - {max(sizes):.0f} m²")
        
        # Age comparison
        new_count = sum(1 for p in properties if "Yeni" in str(p.get("building_age", "")) or "0" in str(p.get("building_age", "")))
        if new_count > 0:
            insights.append(f"{new_count} new construction propert{'ies' if new_count > 1 else 'y'}")
        
        # Site comparison
        in_site_count = sum(1 for p in properties if p.get("in_site") == "Evet")
        if in_site_count > 0:
            insights.append(f"{in_site_count} propert{'ies' if in_site_count > 1 else 'y'} in gated communities")
        
        return insights
    
    async def get_market_statistics(self, location: Optional[str] = None) -> Dict[str, Any]:
        """
        Get market statistics.
        
        Args:
            location: Optional location filter
            
        Returns:
            Market statistics
        """
        try:
            # Get statistics from repository
            stats = await self.repository.get_statistics(location=location)
            
            return stats
            
        except Exception as e:
            logger.error(f"Failed to get market statistics: {e}")
            return {}
