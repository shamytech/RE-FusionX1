"""
Context Enrichment Service
يثري السياق بالمعلومات الجغرافية والسوقية
"""
from app.tools.geographic.distance_calculator import DistanceCalculator
from app.tools.geographic.location_analyzer import LocationAnalyzer
from app.tools.geographic.turkey_geography import TurkeyGeography
from app.tools.pricing.xgboost_predictor import XGBoostPredictor
from app.tools.database.similarity_finder import SimilarityFinder
from app.core.storage.integration import StorageIntegration

class ContextEnrichmentService:
    def __init__(self):
        self.distance_calc = DistanceCalculator()
        self.location_analyzer = LocationAnalyzer()
        self.turkey_geo = TurkeyGeography()
        self.xgboost = XGBoostPredictor()
        self.similarity_finder = SimilarityFinder()
        self._storage = None
        self._cache = None    

    @property
    def storage(self):
        """Lazy load storage"""
        if self._storage is None:
            from app.core.storage.integration import StorageIntegration
            self._storage = StorageIntegration.get_storage()
        return self._storage
    
    @property
    def cache(self):
        """Lazy load cache"""
        if self._cache is None:
            from app.core.storage.integration import StorageIntegration
            self._cache = StorageIntegration.get_cache()
        return self._cache

    
    async def enrich_property_context(self, property_data: Dict) -> Dict:
        """إثراء سياق العقار بمعلومات إضافية"""
        
        # تحقق من الكاش أولاً
        cache_key = self.cache.generate_key(
            CacheType.PROPERTY,
            f"context_{property_data.get('property_id', '')}",
            property_data
        )
        
        cached = await self.cache.get(cache_key, CacheType.PROPERTY)
        if cached:
            return cached
        
        
        enriched = property_data.copy()
        
        # 1. معلومات جغرافية
        location = property_data.get('location', '')
        geo_info = await self.turkey_geo.execute(location=location)
        enriched['geographic_context'] = {
            'city_tier': geo_info.get('tier'),
            'economic_importance': geo_info.get('economic_importance'),
            'tourism_score': geo_info.get('tourism_score'),
            'region': geo_info.get('region')
        }
        
        # 2. تحليل الموقع
        location_analysis = await self.location_analyzer.execute(location=location)
        enriched['location_quality'] = {
            'grade': location_analysis.get('grade'),
            'accessibility': location_analysis.get('scores', {}).get('accessibility'),
            'growth_potential': location_analysis.get('growth_potential')
        }
        
        # 3. المسافات المهمة
        distances = await self.distance_calc.execute(location=location)
        enriched['distances'] = {
            'to_center': distances.get('poi_distances', {}).get('center'),
            'to_airport': distances.get('poi_distances', {}).get('airport'),
            'amenities': distances.get('nearest_amenities')
        }
        
        # 4. تنبؤ السعر بـ XGBoost
        price_prediction = await self.xgboost.execute(property_data=property_data)
        enriched['ml_price_prediction'] = price_prediction
        
        # 5. عقارات مشابهة
        similar = await self.similarity_finder.execute(
            property_data=property_data,
            limit=5
        )
        enriched['similar_properties'] = similar.get('properties', [])
        
        await self.cache.set(cache_key, enriched, CacheType.PROPERTY)
        
        return enriched
