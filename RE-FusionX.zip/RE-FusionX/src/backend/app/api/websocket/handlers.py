# app/api/websocket/handlers.py



"""

WebSocket request handlers - Updated for unified storage.

Processes WebSocket messages and coordinates responses.

"""



from fastapi import WebSocket, WebSocketDisconnect

from typing import Dict, Any, Optional, List

from datetime import datetime

import uuid

import json

import re



from app.core.logging import logger

from app.core.config import settings

from app.api.websocket.connection_manager import ConnectionManager

from app.services.chat_service import ChatService

from app.models.llm.model_loader import ModelLoader

from app.core.storage.integration import StorageIntegration

from app.core.storage.unified_cache import CacheType

from app.core.storage.session_manager import get_session_manager

from app.agents.orchestrator import AgentOrchestrator

from app.agents.market_comparison_agent import MarketComparisonDataAgent as MarketComparisonAgent

from app.agents.property_data_agent import PropertyDataAgent as PropertyAgent

from app.utils.location_utils import get_location_manager





async def websocket_endpoint(

        websocket: WebSocket,

        session_id: str,

        connection_manager: ConnectionManager,

        model_loader: ModelLoader

    ):

    """

    Main WebSocket endpoint handler with unified storage.

    

    Args:

        websocket: WebSocket connection (already accepted)

        session_id: Session identifier

        connection_manager: Connection manager instance

        model_loader: Model loader instance

    """

    client_id = str(uuid.uuid4())

    

    try:

        # Register connection (don't accept again, already accepted in main.py)

        # Store connection

        connection_manager.active_connections[client_id] = websocket

        

        # Track session connections

        if session_id not in connection_manager.session_connections:

            connection_manager.session_connections[session_id] = set()

        connection_manager.session_connections[session_id].add(client_id)

        

        # Store metadata

        connection_manager.connection_metadata[client_id] = {

            "session_id": session_id,

            "connected_at": datetime.utcnow().isoformat(),

            "last_activity": datetime.utcnow().isoformat()

        }

        

        logger.info(f"WebSocket connected: client={client_id}, session={session_id}")

        

        # Send welcome message

        await websocket.send_json({

            "type": "connection",

            "status": "connected",

            "message": "Connected to RE-FusionX real-time service",

            "client_id": client_id,

            "timestamp": datetime.utcnow().isoformat()

        })

        

        # Initialize services with unified storage (with error handling)

        try:

            from app.core.storage.integration import get_storage_integration

            integration = await get_storage_integration()

            storage = integration.storage

            cache = integration.cache

            session_manager = integration.sessions

        except Exception as e:

            logger.error(f"Failed to get storage integration: {e}")

            # Fallback to direct imports

            from app.core.storage.storage_manager import get_storage_manager

            from app.core.storage.unified_cache import get_cache

            from app.core.storage.session_manager import get_session_manager

            storage = get_storage_manager()

            # Fallback cache initialization
            from app.core.storage.unified_cache import get_cache
            cache = get_cache()

            # Fallback session manager initialization
            from app.core.storage.session_manager import get_session_manager
            session_manager = get_session_manager()

        

        # Initialize chat service with storage

        chat_service = ChatService(model_loader, storage_manager=storage)

        

        # Store session info in cache

        cache_key = cache.generate_key(

            CacheType.SESSION,

            f"ws_session_{session_id}"

        )

        await cache.set(

            cache_key,

            {

                "client_id": client_id,

                "session_id": session_id,

                "connected": True

            },

            CacheType.SESSION

        )

        

        while True:

            # Receive message

            data = await websocket.receive_text()

            message = json.loads(data)

            

            logger.info(f"WebSocket message from {client_id}: {message.get('type')}")

            

            # Update last activity

            if client_id in connection_manager.connection_metadata:

                connection_manager.connection_metadata[client_id]["last_activity"] = datetime.utcnow().isoformat()

            

            # Handle different message types

            if message.get("type") == "chat":

                await handle_chat_message(

                    message,

                    client_id,

                    session_id,

                    connection_manager,

                    chat_service

                )

            elif message.get("type") == "analysis":

                await handle_analysis_request(

                    message,

                    client_id,

                    session_id,

                    connection_manager,

                    model_loader

                )

            elif message.get("type") == "agent":

                await handle_agent_chat(

                    message,

                    client_id,

                    session_id,

                    connection_manager,

                    model_loader

                )

            elif message.get("type") == "ping":

                await websocket.send_json({

                    "type": "pong",

                    "timestamp": datetime.utcnow().isoformat()

                })

            else:

                # Handle system messages

                response = await connection_manager.handle_client_message(

                    client_id,

                    message

                )

                await websocket.send_json(response)

                

    except WebSocketDisconnect:

        connection_manager.disconnect(client_id)

        logger.info(f"Client {client_id} disconnected normally")

        

    except Exception as e:

        logger.error(f"WebSocket error for client {client_id}: {e}", exc_info=True)

        connection_manager.disconnect(client_id)

        raise  # Re-raise to be handled by main.py





async def handle_chat_message(

        message: Dict,

        client_id: str,

        session_id: str,

        connection_manager: ConnectionManager,

        chat_service: ChatService

    ):

    """

    Handle chat messages via WebSocket with intelligent data retrieval.

    Uses unified storage system for data access.

    """

    try:

        # Send typing indicator

        await connection_manager.send_typing_indicator(session_id, True)

        

        # Extract message data

        message_data = message.get("data", {})

        user_message = message_data.get("content", "")

        context = message_data.get("context", {})

        

        logger.info(f"Processing chat message: '{user_message[:100]}...' from session {session_id}")

        

        # Get storage and cache instances (with error handling)

        try:

            from app.core.storage.integration import get_storage_integration

            integration = await get_storage_integration()

            storage = integration.storage

            cache = integration.cache

            session_manager = integration.sessions

        except Exception as e:

            logger.error(f"Failed to get storage integration: {e}")

            # Fallback to direct imports

            from app.core.storage.storage_manager import get_storage_manager

            from app.core.storage.unified_cache import get_cache

            from app.core.storage.session_manager import get_session_manager

            storage = get_storage_manager()

            # Fallback cache initialization
            from app.core.storage.unified_cache import get_cache
            cache = get_cache()

            # Fallback session manager initialization
            from app.core.storage.session_manager import get_session_manager
            session_manager = get_session_manager()

        

        # Store message in session history

        await session_manager.add_message(

            session_id=session_id,

            role="user",

            content=user_message,

            metadata={"client_id": client_id}

        )

        

        # Initialize enhanced context

        enhanced_context = {**context}

        use_local_data = False

        local_data_context = {}

        

        # Check if message is about market/properties AND has sufficient information for analysis
        # Only trigger local data search if we have complete information
        has_property_keywords = any(keyword in user_message.lower() for keyword in 

               ["market", "trend", "price", "property", "emlak", "konut", "fiyat", 

                "compare", "similar", "average", "investment", "area", "size", "room", "apartment"])
        
        # Check for completeness indicators - only search if we have detailed criteria
        # Must have: location AND size/rooms AND budget (all three categories)
        has_location = any(loc in user_message.lower() for loc in ["istanbul", "ankara", "izmir", "kadıköy", "beşiktaş", "district"])
        has_size_or_rooms = (
            any(size in user_message.lower() for size in ["m²", "m2", "meter"]) or
            any(room in user_message.lower() for room in ["+1", "+2", "+3", "room", "bedroom"])
        )
        has_budget = any(budget in user_message.lower() for budget in ["million", "tl", "budget", "lira"])
        
        # Only search if we have ALL three: location, size/rooms, AND budget
        has_complete_info = has_location and has_size_or_rooms and has_budget

        # DISABLED: Let the new architecture handle complete property queries
        # The new system provides better analysis and response generation
        if False and has_property_keywords and has_complete_info:

            

            try:

                # Extract location from message

                location = extract_location_from_message(user_message)

                

                # Determine query type

                query_type = determine_query_type(user_message)

                

                logger.info(f"Query type: {query_type}, Location: {location}")

                

                # Handle different query types

                if query_type == "market_analysis":

                    # Get market analysis from storage

                    market_data = await storage.get_market_analysis(location, days_back=30)

                    

                    if market_data and market_data.get('property_statistics'):

                        local_data_context = {

                            "market_data": market_data,

                            "location": location,

                            "data_type": "market_analysis"

                        }

                        use_local_data = True

                        logger.info(f"Found market data for {location}")

                

                elif query_type == "property_search":

                    # Extract search criteria

                    criteria = extract_search_criteria(user_message)

                    

                    # Search properties using storage

                    properties = await storage.get_properties(

                        location=location,

                        filters=criteria,

                        force_refresh=False

                    )

                    

                    if properties:

                        local_data_context = {

                            "properties": properties[:10],  # Limit to 10 for response

                            "total_count": len(properties),

                            "criteria": criteria,

                            "location": location,

                            "data_type": "property_search"

                        }

                        use_local_data = True

                        logger.info(f"Found {len(properties)} properties from storage")

                

                elif query_type == "investment_opportunities":

                    # Extract budget

                    budget = extract_budget(user_message)

                    

                    # Search for investment opportunities

                    if budget:

                        properties = await storage.get_properties(

                            location=location,

                            filters={

                                "max_price": budget * 1.1,

                                "min_price": budget * 0.5,

                                "limit": 20

                            }

                        )

                        

                        if properties:

                            # Calculate investment scores

                            opportunities = []

                            for prop in properties[:10]:

                                try:

                                    price = float(prop.get("price", 0))

                                    size = float(prop.get("size", 100))

                                    

                                    if price > 0 and size > 0:

                                        monthly_rent = price * 0.004

                                        annual_roi = (monthly_rent * 12 / price) * 100

                                        

                                        opportunities.append({

                                            **prop,

                                            "estimated_monthly_rent": monthly_rent,

                                            "estimated_annual_roi": round(annual_roi, 2),

                                            "investment_score": min(10, annual_roi)

                                        })

                                except:

                                    continue

                            

                            if opportunities:

                                opportunities.sort(key=lambda x: x["estimated_annual_roi"], reverse=True)

                                local_data_context = {

                                    "opportunities": opportunities[:5],

                                    "budget": budget,

                                    "location": location,

                                    "data_type": "investment_opportunities"

                                }

                                use_local_data = True

                                logger.info(f"Found {len(opportunities)} investment opportunities")

                

                elif query_type == "price_comparison":

                    # Use market comparison agent

                    property_data = extract_property_data_from_message(user_message)

                    if property_data:

                        market_agent = MarketComparisonAgent()

                        comparison_result = await market_agent.process({

                            "property_data": property_data,

                            "force_refresh": False

                        })

                        

                        if comparison_result and comparison_result.get("result"):

                            local_data_context = {

                                "comparison": comparison_result["result"],

                                "property_data": property_data,

                                "data_type": "price_comparison"

                            }

                            use_local_data = True

                            logger.info("Market comparison completed")

                

                # Check if we need fresh data

                if not use_local_data or should_collect_fresh_data(user_message):

                    # Send status update

                    await connection_manager.send_to_session(

                        {

                            "type": "status",

                            "message": "جاري البحث عن بيانات محدثة... / Searching for updated data...",

                            "timestamp": datetime.utcnow().isoformat()

                        },

                        session_id

                    )

                    

                    # Force refresh from storage

                    properties = await storage.get_properties(

                        location=location,

                        filters=extract_search_criteria(user_message),

                        force_refresh=True

                    )

                    

                    if properties:

                        local_data_context = {

                            "properties": properties[:10],

                            "total_count": len(properties),

                            "location": location,

                            "data_type": "fresh_collection"

                        }

                        use_local_data = True

                        logger.info(f"Fresh data collected: {len(properties)} properties")

                

            except Exception as e:

                logger.warning(f"Failed to get local data: {e}")

        

        # Prepare enhanced context with local data

        if local_data_context:

            enhanced_context["local_data"] = local_data_context

            enhanced_context["has_data"] = True

            

            # Create a data-enriched prompt

            data_summary = create_data_summary(local_data_context)

            enhanced_context["data_summary"] = data_summary

        

        # Process message with chat service

        response = await chat_service.process_message(

            message=user_message,

            session_id=session_id,

            context=enhanced_context,

            include_sources=True,

            use_agents=True

        )

        

        # If we have local data, enrich the response

        if local_data_context and response.get("response"):

            model_response = response["response"]

            

            # Format local data based on type

            formatted_data = ""

            if local_data_context.get("data_type") == "market_analysis":

                formatted_data = format_market_response(

                    local_data_context.get("market_data", {}), 

                    local_data_context.get("location", "")

                )

            elif local_data_context.get("data_type") == "property_search":

                formatted_data = format_property_response(

                    local_data_context.get("properties", []), 

                    local_data_context.get("criteria", {})

                )

            elif local_data_context.get("data_type") == "investment_opportunities":

                formatted_data = format_investment_response(

                    local_data_context.get("opportunities", []), 

                    local_data_context.get("budget")

                )

            elif local_data_context.get("data_type") == "price_comparison":

                formatted_data = format_comparison_response(

                    local_data_context.get("comparison", {}),

                    local_data_context.get("property_data", {})

                )

            elif local_data_context.get("data_type") == "fresh_collection":

                formatted_data = format_comprehensive_response(

                    {"properties": local_data_context.get("properties", [])}, 

                    local_data_context.get("location", "")

                )

            

            # Combine responses intelligently

            if formatted_data:

                combined_response = f"{formatted_data}\n\n---\n\n**تحليل الذكاء الاصطناعي / AI Analysis:**\n{model_response}"

                response["response"] = combined_response

                response["has_local_data"] = True

        

        # Update response metadata

        response["sources"] = response.get("sources", [])

        if use_local_data:

            response["sources"].append("local_storage")

        if local_data_context.get("data_type") == "fresh_collection":

            response["sources"].append("fresh_data")

        

        # Store assistant response in session

        await session_manager.add_message(

            session_id=session_id,

            role="assistant",

            content=response.get("response", ""),

            metadata={

                "sources": response.get("sources", []),

                "has_data": use_local_data

            }

        )

        

        # Cache the response

        cache_key = cache.generate_key(

            CacheType.API,

            f"chat_response_{session_id}",

            {"message": user_message[:50]}

        )

        await cache.set(cache_key, response, CacheType.API)

        

        # Stop typing indicator

        await connection_manager.send_typing_indicator(session_id, False)

        

        # Send response

        await connection_manager.send_to_session(

            {

                "type": "chat_response",

                "content": response.get("response", ""),

                "sources": response.get("sources", []),

                "timestamp": response.get("timestamp", datetime.utcnow().isoformat()),

                "data_source": "combined" if local_data_context else "ai",

                "has_local_data": response.get("has_local_data", False),

                "metadata": {

                    "location": local_data_context.get("location") if local_data_context else None,

                    "data_type": local_data_context.get("data_type") if local_data_context else None,

                    "query_type": query_type if 'query_type' in locals() else None

                }

            },

            session_id

        )

        

        logger.info("Response sent successfully via WebSocket")

        

    except Exception as e:

        logger.error(f"Failed to handle chat message: {e}", exc_info=True)

        

        # Stop typing indicator

        await connection_manager.send_typing_indicator(session_id, False)

        

        # Send error message

        await connection_manager.send_personal_message(

            {

                "type": "error",

                "message": "عذراً، حدث خطأ. يرجى المحاولة مرة أخرى. / Sorry, an error occurred. Please try again.",

                "timestamp": datetime.utcnow().isoformat()

            },

            client_id

        )





def create_data_summary(local_data_context: Dict) -> str:

    """

    Create a summary of local data to pass to the model as context.

    """

    summary = []

    

    if local_data_context.get("data_type") == "market_analysis":

        market_data = local_data_context.get("market_data", {})

        stats = market_data.get('property_statistics', {})

        summary.append(f"Market Data for {local_data_context.get('location', 'Turkey')}:")

        summary.append(f"- Total Properties: {stats.get('total_properties', 0)}")

        summary.append(f"- Average Price: {stats.get('avg_price', 0):,.0f} TL")

        summary.append(f"- Price per m²: {stats.get('avg_price_per_sqm', 0):,.0f} TL/m²")

        

    elif local_data_context.get("data_type") == "property_search":

        properties = local_data_context.get("properties", [])

        total_count = local_data_context.get("total_count", len(properties))

        summary.append(f"Found {total_count} properties matching criteria:")

        if properties:

            prices = [p.get('price', 0) for p in properties if p.get('price')]

            if prices:

                avg_price = sum(prices) / len(prices)

                summary.append(f"- Average Price: {avg_price:,.0f} TL")

            summary.append(f"- Location: {local_data_context.get('location', 'Turkey')}")

            

    elif local_data_context.get("data_type") == "investment_opportunities":

        opportunities = local_data_context.get("opportunities", [])

        budget = local_data_context.get("budget", 0)

        summary.append(f"Investment Opportunities (Budget: {budget:,.0f} TL):")

        summary.append(f"- Found {len(opportunities)} opportunities")

        if opportunities:

            best_roi = max(opp.get("estimated_annual_roi", 0) for opp in opportunities)

            summary.append(f"- Best ROI: {best_roi:.1f}%")

    

    elif local_data_context.get("data_type") == "price_comparison":

        comparison = local_data_context.get("comparison", {})

        market_stats = comparison.get("market_statistics", {})

        summary.append(f"Market Comparison for {local_data_context.get('property_data', {}).get('location', '')}:")

        summary.append(f"- Similar Properties: {market_stats.get('similar_properties_found', 0)}")

        summary.append(f"- Average Price: {market_stats.get('average_price', 0):,.0f} TL")

        

    elif local_data_context.get("data_type") == "fresh_collection":

        properties = local_data_context.get("properties", [])

        summary.append(f"Fresh Data for {local_data_context.get('location', 'Turkey')}:")

        summary.append(f"- Properties: {len(properties)} listings")

    

    return "\n".join(summary)





def extract_location_from_message(message: str) -> str:

    """Extract location from user message using location manager"""

    location_manager = get_location_manager()

    location_info = location_manager.extract_location_from_text(message)

    

    # Build location string

    if location_info['city']:

        if location_info['district']:

            return f"{location_info['city']} - {location_info['district']}"

        return location_info['city']

    

    # Fallback to simple extraction

    message_lower = message.lower()

    

    # Common Turkish cities

    cities = {

        "istanbul": "Istanbul", "ankara": "Ankara", "izmir": "Izmir",

        "antalya": "Antalya", "bursa": "Bursa", "adana": "Adana",

        "konya": "Konya", "gaziantep": "Gaziantep", "kayseri": "Kayseri"

    }

    

    for city_key, city_name in cities.items():

        if city_key in message_lower:

            return city_name

    

    return "Istanbul"  # Default





def determine_query_type(message: str) -> str:

    """Determine the type of query from message"""

    message_lower = message.lower()

    

    # Market analysis keywords

    if any(word in message_lower for word in 

           ["market", "trend", "analysis", "تحليل", "سوق", "piyasa", "analiz"]):

        return "market_analysis"

    

    # Investment keywords

    if any(word in message_lower for word in 

           ["investment", "invest", "opportunity", "استثمار", "فرصة", "yatırım", "getiri", "roi"]):

        return "investment_opportunities"

    

    # Price comparison keywords

    if any(word in message_lower for word in 

           ["compare", "comparison", "similar", "average", "مقارنة", "karşılaştır", "benzer"]):

        return "price_comparison"

    

    # Property search keywords

    if any(word in message_lower for word in 

           ["property", "house", "apartment", "عقار", "شقة", "ev", "daire", "konut"]):

        return "property_search"

    

    # Price keywords

    if any(word in message_lower for word in 

           ["price", "cost", "value", "سعر", "قيمة", "fiyat", "değer"]):

        return "price_inquiry"

    

    return "general"





def extract_search_criteria(message: str) -> Dict[str, Any]:

    """Extract property search criteria from message"""

    criteria = {}

    message_lower = message.lower()

    

    # Extract price range

    price_match = re.search(r'(\d+)[kKmM]?\s*-\s*(\d+)[kKmM]?', message)

    if price_match:

        min_price = float(price_match.group(1))

        max_price = float(price_match.group(2))

        

        # Convert K/M notation

        if 'k' in message_lower[price_match.start():price_match.end()]:

            min_price *= 1000

            max_price *= 1000

        elif 'm' in message_lower[price_match.start():price_match.end()]:

            min_price *= 1000000

            max_price *= 1000000

        

        criteria["min_price"] = min_price

        criteria["max_price"] = max_price

    

    # Extract rooms

    rooms_match = re.search(r'(\d)\+(\d)', message)

    if rooms_match:

        criteria["rooms"] = f"{rooms_match.group(1)}+{rooms_match.group(2)}"

    

    # Extract size

    size_match = re.search(r'(\d+)\s*(?:m2|m²|sqm|متر)', message)

    if size_match:

        size = int(size_match.group(1))

        criteria["min_size"] = size - 20

        criteria["max_size"] = size + 20

    

    # Property type

    if any(word in message_lower for word in ["villa", "فيلا"]):

        criteria["property_type"] = "Villa"

    elif any(word in message_lower for word in ["apartment", "daire", "شقة"]):

        criteria["property_type"] = "Daire"

    

    criteria["limit"] = 20  # Default limit

    

    return criteria





def extract_budget(message: str) -> Optional[float]:

    """Extract budget from message"""

    # Look for numbers with currency or budget keywords

    budget_match = re.search(r'(\d+(?:\.\d+)?)\s*(?:mil|million|مليون|milyon|[kKmM])?', message)

    

    if budget_match:

        budget = float(budget_match.group(1))

        

        # Convert based on suffix

        if any(word in message.lower() for word in ["mil", "million", "مليون", "milyon"]):

            budget *= 1000000

        elif 'k' in message.lower()[budget_match.start():budget_match.end()]:

            budget *= 1000

        elif 'm' in message.lower()[budget_match.start():budget_match.end()]:

            budget *= 1000000

        

        return budget

    

    return None





def extract_property_type(message: str) -> Optional[str]:

    """Extract property type from message"""

    message_lower = message.lower()

    

    property_types = {

        "daire": ["apartment", "daire", "شقة", "flat"],

        "villa": ["villa", "فيلا"],

        "residence": ["residence", "rezidans"],

        "arsa": ["land", "arsa", "أرض"]

    }

    

    for prop_type, keywords in property_types.items():

        if any(keyword in message_lower for keyword in keywords):

            return prop_type

    

    return None





def extract_property_data_from_message(message: str) -> Dict[str, Any]:

    """Extract property data for comparison from message"""

    location_manager = get_location_manager()

    

    data = {}

    

    # Extract location

    location_info = location_manager.extract_location_from_text(message)

    if location_info['city']:

        data['city'] = location_info['city']

        if location_info['district']:

            data['district'] = location_info['district']

            data['location'] = f"{location_info['city']} - {location_info['district']}"

        else:

            data['location'] = location_info['city']

    

    # Extract size

    size_match = re.search(r'(\d+)\s*(?:m2|m²|sqm|متر)', message)

    if size_match:

        data['size'] = int(size_match.group(1))

    

    # Extract rooms

    rooms_match = re.search(r'(\d)\+(\d)', message)

    if rooms_match:

        data['rooms'] = f"{rooms_match.group(1)}+{rooms_match.group(2)}"

    

    # Extract age

    age_match = re.search(r'(\d+)\s*(?:year|yıl|sene|سنة)', message.lower())

    if age_match:

        data['building_age'] = int(age_match.group(1))

    

    # Extract property type

    data['property_type'] = extract_property_type(message) or "Daire"

    

    return data if data.get('location') else None





def should_collect_fresh_data(message: str) -> bool:

    """Determine if fresh data collection is needed"""

    fresh_keywords = ["güncel", "latest", "new", "fresh", "محدث", "جديد", "son", "yeni"]

    return any(keyword in message.lower() for keyword in fresh_keywords)





def format_market_response(market_data: Dict, location: str) -> str:

    """Format market analysis data for response"""

    stats = market_data.get('property_statistics', {})

    trends = market_data.get('price_trends', [])

    

    response = f"""📊 **تحليل سوق العقارات في {location} / {location} Real Estate Market Analysis**



**📈 إحصائيات السوق / Market Statistics:**

• إجمالي العقارات / Total Properties: {stats.get('total_properties', 0):,}

• متوسط السعر / Average Price: {stats.get('avg_price', 0):,.0f} TL

• السعر لكل متر مربع / Price per m²: {stats.get('avg_price_per_sqm', 0):,.0f} TL/m²

• متوسط المساحة / Average Size: {stats.get('avg_size', 0):.0f} m²



**📊 اتجاهات الأسعار / Price Trends:**

"""

    

    if trends:

        for trend in trends[:3]:

            response += f"• {trend.get('week', 'N/A')}: {trend.get('avg_price', 0):,.0f} TL ({trend.get('listings', 0)} عقار/properties)\n"

    

    response += f"\n*آخر تحديث / Last Update: {market_data.get('analysis_date', datetime.utcnow().isoformat())}*"

    

    return response





def format_property_response(properties: List[Dict], criteria: Dict) -> str:

    """Format property search results for response"""

    response = f"""🏠 **نتائج البحث عن العقارات / Property Search Results**



**🔍 معايير البحث / Search Criteria:**

"""

    

    if criteria.get("min_price") and criteria.get("max_price"):

        response += f"• السعر / Price: {criteria['min_price']:,.0f} - {criteria['max_price']:,.0f} TL\n"

    if criteria.get("rooms"):

        response += f"• الغرف / Rooms: {criteria['rooms']}\n"

    if criteria.get("min_size") and criteria.get("max_size"):

        avg_size = (criteria['min_size'] + criteria['max_size']) / 2

        response += f"• المساحة / Size: ~{avg_size:.0f} m²\n"

    

    response += f"\n**🏘️ العقارات المتاحة / Available Properties ({len(properties)} found):**\n\n"

    

    for idx, prop in enumerate(properties[:5], 1):

        response += f"""📍 **{idx}. {prop.get('title', 'Property')}**

• السعر / Price: {prop.get('price', 0):,.0f} TL

• المساحة / Size: {prop.get('size', 0):.0f} m²

• الموقع / Location: {prop.get('location', 'N/A')}

• الغرف / Rooms: {prop.get('rooms', 'N/A')}

---

"""

    

    return response





def format_investment_response(opportunities: List[Dict], budget: Optional[float]) -> str:

    """Format investment opportunities for response"""

    response = f"""💰 **فرص الاستثمار العقاري / Real Estate Investment Opportunities**



"""

    

    if budget:

        response += f"**💵 الميزانية / Budget:** {budget:,.0f} TL\n\n"

    

    response += f"**🎯 أفضل الفرص / Top Opportunities ({len(opportunities)} found):**\n\n"

    

    for idx, opp in enumerate(opportunities[:3], 1):

        response += f"""🏆 **{idx}. {opp.get('title', 'Investment Property')}**

• السعر / Price: {opp.get('price', 0):,.0f} TL

• العائد السنوي المتوقع / Expected Annual ROI: {opp.get('estimated_annual_roi', 0):.1f}%

• الإيجار الشهري المتوقع / Est. Monthly Rent: {opp.get('estimated_monthly_rent', 0):,.0f} TL

• نقاط الاستثمار / Investment Score: {opp.get('investment_score', 0):.1f}/10

• الموقع / Location: {opp.get('location', 'N/A')}

---

"""

    

    return response





def format_comparison_response(comparison: Dict, property_data: Dict) -> str:

    """Format market comparison response"""

    market_stats = comparison.get("market_statistics", {})

    market_position = comparison.get("market_position", {})

    

    response = f"""📊 **مقارنة السوق / Market Comparison**



**🏠 العقار المرجعي / Reference Property:**

• الموقع / Location: {property_data.get('location', 'N/A')}

• المساحة / Size: {property_data.get('size', 'N/A')} m²

• الغرف / Rooms: {property_data.get('rooms', 'N/A')}



**📈 إحصائيات السوق / Market Statistics:**

• عقارات مشابهة / Similar Properties: {market_stats.get('similar_properties_found', 0)}

• متوسط السعر / Average Price: {market_stats.get('average_price', 0):,.0f} TL

• نطاق الأسعار / Price Range: {market_stats.get('price_range', {}).get('min', 0):,.0f} - {market_stats.get('price_range', {}).get('max', 0):,.0f} TL



**📍 موقع السوق / Market Position:**

• التقييم / Assessment: {market_position.get('assessment', 'N/A')}

• الانحراف عن المتوسط / Deviation: {market_position.get('deviation_percentage', 0):.1f}%

"""

    

    return response





def format_comprehensive_response(data: Dict, location: str) -> str:

    """Format comprehensive data collection response"""

    properties = data.get('properties', [])

    

    response = f"""🔄 **بيانات محدثة لـ {location} / Fresh Data for {location}**



📊 **ملخص البيانات / Data Summary:**

• العقارات / Properties: {len(properties)} عقار/listings

"""

    

    if properties:

        prices = [p.get('price', 0) for p in properties if p.get('price')]

        if prices:

            avg_price = sum(prices) / len(prices)

            response += f"• متوسط السعر / Avg Price: {avg_price:,.0f} TL\n"

            response += f"• أقل سعر / Min Price: {min(prices):,.0f} TL\n"

            response += f"• أعلى سعر / Max Price: {max(prices):,.0f} TL\n"

    

    response += "\n*✅ تم تحديث البيانات وحفظها / Data updated and saved*"

    

    return response





async def handle_analysis_request(

        message: Dict,

        client_id: str,

        session_id: str,

        connection_manager: ConnectionManager,

        model_loader: ModelLoader

    ):

    """

    Handle property analysis requests via WebSocket using unified storage.

    """

    try:

        # Send progress update

        await connection_manager.send_progress_update(

            session_id,

            10,

            "بدء التحليل... / Starting analysis..."

        )

        

        # Get storage (with error handling)

        try:

            from app.core.storage.integration import get_storage_integration

            integration = await get_storage_integration()

            storage = integration.storage

        except Exception as e:

            logger.error(f"Failed to get storage integration: {e}")

            # Fallback to direct import

            from app.core.storage.storage_manager import get_storage_manager

            storage = get_storage_manager()

        

        # Initialize orchestrator with agents

        orchestrator = AgentOrchestrator(model_loader=model_loader)

        

        # Extract property data

        property_data = message.get("property_data", {})

        images = message.get("images", [])

        

        # Update progress

        await connection_manager.send_progress_update(

            session_id,

            30,

            "معالجة معلومات العقار... / Processing property information..."

        )

        

        # Process with orchestrator

        analysis_input = {

            "message": f"Analyze property in {property_data.get('location', 'Istanbul')}",

            "property_data": property_data

        }

        

        result = await orchestrator.process(

            analysis_input,

            {"session_id": session_id}

        )

        

        # Update progress

        await connection_manager.send_progress_update(

            session_id,

            60,

            "تحليل السوق... / Analyzing market..."

        )

        

        # Add market comparison

        if property_data:

            market_agent = MarketComparisonAgent(model_loader)

            market_result = await market_agent.process({

                "property_data": property_data,

                "force_refresh": False

            })

            

            if market_result and market_result.get("result"):

                result["market_comparison"] = market_result["result"]

        

        # Update progress

        await connection_manager.send_progress_update(

            session_id,

            80,

            "حفظ النتائج... / Saving results..."

        )

        

        # Save to storage

        if property_data:

            await storage.save_properties(

                [property_data],

                property_data.get("location", "Istanbul"),

                source="websocket_analysis"

            )

        

        # Update progress

        await connection_manager.send_progress_update(

            session_id,

            90,

            "إنهاء التحليل... / Finalizing analysis..."

        )

        

        # Send results

        await connection_manager.send_to_session(

            {

                "type": "analysis_complete",

                "results": result,

                "timestamp": datetime.utcnow().isoformat()

            },

            session_id

        )

        

        # Complete progress

        await connection_manager.send_progress_update(

            session_id,

            100,

            "التحليل مكتمل! / Analysis complete!"

        )

        

    except Exception as e:

        logger.error(f"Failed to handle analysis request: {e}", exc_info=True)

        

        # Send error message

        await connection_manager.send_personal_message(

            {

                "type": "error",

                "message": "فشل إكمال التحليل. يرجى المحاولة مرة أخرى. / Failed to complete analysis. Please try again.",

                "timestamp": datetime.utcnow().isoformat()

            },

            client_id

        )





async def handle_agent_chat(

        message: Dict,

        client_id: str,

        session_id: str,

        connection_manager: ConnectionManager,

        orchestrator: Any  # AgentOrchestrator

    ):

    """Handle chat with specific agent using unified storage"""

    try:

        agent_name = message.get('agent', 'property')

        user_message = message.get('content', '')

        context = message.get('context', {})

        

        # Initialize orchestrator if not provided

        if not orchestrator:

            from app.models.llm.model_loader import ModelLoader

            model_loader = ModelLoader()

            orchestrator = AgentOrchestrator(model_loader=model_loader)

        

        # Process with orchestrator

        agent_input = {

            "message": user_message,

            "agent_type": agent_name,

            **context

        }

        

        # Send typing indicator

        await connection_manager.send_typing_indicator(session_id, True)

        

        # Process with agent

        response = await orchestrator.process(

            agent_input,

            {"session_id": session_id}

        )

        

        # Stop typing indicator

        await connection_manager.send_typing_indicator(session_id, False)

        

        # Send response

        await connection_manager.send_to_session(

            {

                'type': 'agent_response',

                'agent': response.get('agent', agent_name),

                'content': response.get('result', {}).get('response', ''),

                'timestamp': response.get('timestamp', datetime.utcnow().isoformat())

            },

            session_id

        )

        

    except Exception as e:

        logger.error(f"Failed to handle agent chat: {e}", exc_info=True)

        

        await connection_manager.send_personal_message(

            {

                'type': 'error',

                'message': 'فشل معالجة الدردشة مع الوكيل / Failed to process agent chat',

                'timestamp': datetime.utcnow().isoformat()

            },

            client_id

        )



