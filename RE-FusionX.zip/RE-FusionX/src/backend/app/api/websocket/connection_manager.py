"""
WebSocket connection management.
Handles real-time communication with clients.
"""

from typing import Dict, List, Set
from fastapi import WebSocket, WebSocketDisconnect
import json
import asyncio
from datetime import datetime

from app.core.logging import logger
from app.core.storage.integration import StorageIntegration
from app.core.storage.unified_cache import CacheType

class ConnectionManager:
    """Manages WebSocket connections for real-time communication."""
    
    def __init__(self):
        """Initialize connection manager."""
        self.active_connections: Dict[str, WebSocket] = {}
        self.session_connections: Dict[str, Set[str]] = {}
        self.connection_metadata: Dict[str, Dict] = {}
        self._last_messages: Dict[str, str] = {} 
        
    async def connect(
        self,
        websocket: WebSocket,
        client_id: str,
        session_id: str
    ) -> None:
        """
        Accept and register a new WebSocket connection.
        
        Args:
            websocket: WebSocket connection
            client_id: Unique client identifier
            session_id: Session identifier
        """
        await websocket.accept()
        
        # Store connection
        self.active_connections[client_id] = websocket
        
        # Track session connections
        if session_id not in self.session_connections:
            self.session_connections[session_id] = set()
        self.session_connections[session_id].add(client_id)
        
        # Store metadata
        self.connection_metadata[client_id] = {
            "session_id": session_id,
            "connected_at": datetime.utcnow().isoformat(),
            "last_activity": datetime.utcnow().isoformat()
        }
        
        logger.info(f"WebSocket connected: client={client_id}, session={session_id}")
        
        # Send welcome message
        await self.send_personal_message(
            {
                "type": "connection",
                "status": "connected",
                "message": "Connected to RE-FusionX real-time service",
                "client_id": client_id,
                "timestamp": datetime.utcnow().isoformat()
            },
            client_id
        )
    
    def disconnect(self, client_id: str) -> None:
        """
        Remove a WebSocket connection.
        
        Args:
            client_id: Client identifier to disconnect
        """
        if client_id in self.active_connections:
            # Remove from active connections
            del self.active_connections[client_id]
            
            # Remove from session tracking
            if client_id in self.connection_metadata:
                session_id = self.connection_metadata[client_id]["session_id"]
                if session_id in self.session_connections:
                    self.session_connections[session_id].discard(client_id)
                    if not self.session_connections[session_id]:
                        del self.session_connections[session_id]
                
                # Remove metadata
                del self.connection_metadata[client_id]
            
            logger.info(f"WebSocket disconnected: client={client_id}")
    
    async def send_personal_message(
        self,
        message: Dict,
        client_id: str
    ) -> None:
        """
        Send message to specific client.
        
        Args:
            message: Message to send
            client_id: Target client ID
        """
        if client_id in self.active_connections:
            try:
                websocket = self.active_connections[client_id]
                await websocket.send_json(message)
                
                # Update last activity
                if client_id in self.connection_metadata:
                    self.connection_metadata[client_id]["last_activity"] = \
                        datetime.utcnow().isoformat()
                        
            except Exception as e:
                logger.error(f"Failed to send message to {client_id}: {e}")
                self.disconnect(client_id)
    
    async def send_to_session(
            self,
            message: Dict,
            session_id: str
        ) -> None:
        """Send message to all clients in a session with duplicate prevention"""
        
        # 🔴 منع الرسائل المكررة
        message_content = message.get("content", "")
        last_content = self._last_messages.get(session_id, "")
        
        if message_content == last_content and message.get("type") == "chat_response":
            logger.warning(f"Skipping duplicate message to session {session_id}")
            return
        
        self._last_messages[session_id] = message_content
        
        if session_id in self.session_connections:
            disconnected_clients = []
            
            for client_id in self.session_connections[session_id]:
                try:
                    await self.send_personal_message(message, client_id)
                except:
                    disconnected_clients.append(client_id)
            
            # Clean up disconnected clients
            for client_id in disconnected_clients:
                self.disconnect(client_id)

    async def broadcast(self, message: Dict) -> None:
        """
        Broadcast message to all connected clients.
        
        Args:
            message: Message to broadcast
        """
        disconnected_clients = []
        
        for client_id in self.active_connections:
            try:
                await self.send_personal_message(message, client_id)
            except:
                disconnected_clients.append(client_id)
        
        # Clean up disconnected clients
        for client_id in disconnected_clients:
            self.disconnect(client_id)
    
    async def send_typing_indicator(
        self,
        session_id: str,
        is_typing: bool = True
    ) -> None:
        """
        Send typing indicator to session.
        
        Args:
            session_id: Session ID
            is_typing: Whether assistant is typing
        """
        message = {
            "type": "typing",
            "is_typing": is_typing,
            "timestamp": datetime.utcnow().isoformat()
        }
        
        await self.send_to_session(message, session_id)
    
    async def send_progress_update(
        self,
        session_id: str,
        progress: int,
        message: str
    ) -> None:
        """
        Send progress update to session.
        
        Args:
            session_id: Session ID
            progress: Progress percentage (0-100)
            message: Progress message
        """
        update = {
            "type": "progress",
            "progress": progress,
            "message": message,
            "timestamp": datetime.utcnow().isoformat()
        }
        
        await self.send_to_session(update, session_id)
    
    async def handle_client_message(
        self,
        client_id: str,
        message: Dict
    ) -> Dict:
        """
        Handle incoming message from client.
        
        Args:
            client_id: Client ID
            message: Received message
            
        Returns:
            Response to send back
        """
        message_type = message.get("type", "unknown")
        
        if message_type == "ping":
            return {
                "type": "pong",
                "timestamp": datetime.utcnow().isoformat()
            }
        elif message_type == "status":
            return {
                "type": "status",
                "connected_clients": len(self.active_connections),
                "timestamp": datetime.utcnow().isoformat()
            }
        else:
            return {
                "type": "error",
                "message": f"Unknown message type: {message_type}",
                "timestamp": datetime.utcnow().isoformat()
            }
    
    async def disconnect_all(self) -> None:
        """Disconnect all active connections."""
        logger.info(f"Disconnecting all {len(self.active_connections)} connections")
        
        for client_id in list(self.active_connections.keys()):
            try:
                await self.active_connections[client_id].close()
            except:
                pass
            self.disconnect(client_id)
    
    def get_connection_stats(self) -> Dict:
        """
        Get connection statistics.
        
        Returns:
            Connection statistics
        """
        return {
            "total_connections": len(self.active_connections),
            "active_sessions": len(self.session_connections),
            "connections_by_session": {
                session_id: len(clients)
                for session_id, clients in self.session_connections.items()
            }
        }
    
    async def store_connection_info(self, client_id: str, session_id: str):
        """Store connection info in cache for persistence"""
        cache = StorageIntegration.get_cache()
        cache_key = cache.generate_key(
            CacheType.SESSION,
            f"ws_connection_{client_id}"
        )
        await cache.set(
            cache_key,
            {
                "client_id": client_id,
                "session_id": session_id,
                "connected_at": datetime.utcnow().isoformat()
            },
            CacheType.SESSION,
            ttl_override=3600  # 1 hour
        )
