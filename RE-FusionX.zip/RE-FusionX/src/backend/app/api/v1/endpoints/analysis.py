# app/api/v1/endpoints/analysis.py

"""
Property analysis endpoints - Updated for unified storage.
Handles comprehensive property analysis requests with agents.
"""

from typing import Dict, Any, List, Optional
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Form, status
from pydantic import BaseModel, Field
from datetime import datetime
import json

from app.core.logging import logger
from app.core.exceptions import ValidationException, InsufficientDataException
from app.api.v1.dependencies import (
    get_current_session,
    check_rate_limit,
    get_model_loader,
    SessionDep,
    StorageDep
)
from app.core.storage.storage_manager import StorageManager
from app.services.analysis_service import AnalysisService
from app.models.schemas.property import PropertyInput
from app.models.schemas.analysis import AnalysisRequest, AnalysisResponse
from app.agents.orchestrator import AgentOrchestrator
from app.agents.property_data_agent import PropertyDataAgent as PropertyAgent
from app.agents.market_comparison_agent import MarketComparisonDataAgent as MarketComparisonAgent


router = APIRouter()


@router.post(
    "/property",
    response_model=AnalysisResponse,
    status_code=status.HTTP_200_OK,
    summary="Analyze property",
    description="Perform comprehensive property analysis using agents"
)
async def analyze_property(
    property_data: PropertyInput,
    include_market_comparison: bool = True,
    session: Dict = SessionDep,
    _: None = Depends(check_rate_limit),
    model_loader = Depends(get_model_loader),
    storage: StorageManager = StorageDep
) -> AnalysisResponse:
    """
    Analyze a property with comprehensive details using unified storage.
    
    Args:
        property_data: Property information
        include_market_comparison: Include market comparison
        session: Current user session
        model_loader: Model loader instance
        storage: Storage manager instance
        
    Returns:
        Comprehensive analysis results
    """
    try:
        logger.info(f"Starting property analysis for session {session['id']}")
        
        # Use orchestrator with proper message format
        logger.info(f"Starting orchestrator analysis for property: {property_data.location}")
        
        # Create detailed message for orchestrator
        message_parts = [
            f"Please analyze this property:"
        ]
        
        # Add location
        if property_data.location:
            message_parts.append(f"Location: {property_data.location}")
            
        # Add property details
        if property_data.property_type:
            message_parts.append(f"Type: {property_data.property_type}")
            
        if property_data.rooms:
            message_parts.append(f"Rooms: {property_data.rooms}")
            
        if property_data.size_net:
            message_parts.append(f"Net area: {property_data.size_net} m²")
        elif property_data.size_gross:
            message_parts.append(f"Gross area: {property_data.size_gross} m²")
            
        if property_data.building_age:
            message_parts.append(f"Building age: {property_data.building_age} years")
            
        if property_data.floor:
            message_parts.append(f"Floor: {property_data.floor}")
            
        if property_data.price:
            message_parts.append(f"Listed price: {property_data.price:,} TL")
        
        message_parts.append("I need a comprehensive property analysis with price estimation and market comparison.")
        
        analysis_message = ". ".join(message_parts)
        
        # Initialize orchestrator with agents
        # If model_loader is None, create a minimal orchestrator without Qwen-dependent agents
        if model_loader is None:
            logger.info("Model loader is None, using direct agents approach")
            # Skip orchestrator and use agents directly (our current working approach)
            orchestrator = None
        else:
            orchestrator = AgentOrchestrator(model_loader=model_loader)
            # Debug: Check if agents are loaded
            logger.info(f"Orchestrator initialized with {len(orchestrator.agents)} agents: {list(orchestrator.agents.keys())}")
        
        # Use hybrid approach: Direct agents for data + ResponseFormatter for Qwen analysis
        logger.info("Using hybrid approach: Direct agents + ResponseFormatter for Qwen analysis")
        
        result = {
            "analysis_id": f"analysis_{session['id'][:8]}",
            "timestamp": datetime.utcnow(),
            "confidence_score": 0.8,
            "analysis_type": "comprehensive",
            "data_sources": ["property_agent", "market_agent", "qwen_formatter"],
        }
        
        # Step 1: Collect data from agents
        collected_data = {}
        
        # 1. Property Data Agent
        try:
            from app.agents.property_data_agent import PropertyDataAgent
            property_agent = PropertyDataAgent(model_loader)
            property_result = await property_agent.process({
                "property_data": property_data.dict(),
                "data_type": "full"
            })
            
            if property_result and property_result.get("result") and property_result["result"].get("data"):
                result["property_data"] = property_result["result"]["data"]
                collected_data["property"] = property_result["result"]["data"]
                logger.info(f"Property agent completed successfully")
            else:
                logger.warning(f"Property agent returned empty result")
                result["property_data"] = {}
                collected_data["property"] = {}
            
        except Exception as e:
            logger.error(f"Property agent failed: {e}")
            result["property_data"] = {}
            collected_data["property"] = {}
        
        # 2. Market Comparison Agent
        if include_market_comparison:
            try:
                market_agent = MarketComparisonAgent(model_loader)
                market_result = await market_agent.process({
                    "property_data": property_data.dict()
                })
                
                if market_result and market_result.get("result") and market_result["result"].get("data"):
                    result["market_comparison"] = market_result["result"]["data"]
                    collected_data["market"] = market_result["result"]["data"]
                    logger.info(f"Market agent completed successfully")
                else:
                    logger.warning(f"Market agent returned empty result")
                    result["market_comparison"] = {}
                    collected_data["market"] = {}
                    
            except Exception as e:
                logger.error(f"Market agent failed: {e}")
                result["market_comparison"] = {}
                collected_data["market"] = {}
        
        # Step 2: Use ResponseFormatterAgent with Qwen to generate investment analysis
        qwen_analysis = None
        if model_loader and collected_data:
            try:
                from app.agents.response_formatter_agent import ResponseFormatterAgent
                response_formatter = ResponseFormatterAgent(model_loader)
                
                # Create comprehensive data for Qwen
                qwen_input = {
                    "agent_data": collected_data,
                    "user_query": analysis_message,
                    "intent": "property_analysis",
                    "language": "en",
                    "context": {"session_id": session['id'], "analysis_type": "investment"}
                }
                
                logger.info("Sending data to ResponseFormatter with Qwen for investment analysis")
                qwen_result = await response_formatter.process(qwen_input, {"session_id": session['id']})
                
                if qwen_result and qwen_result.get("result"):
                    qwen_response = qwen_result["result"].get("response", "")
                    logger.info(f"Qwen generated analysis: {len(qwen_response)} characters")
                    
                    # 🔍 DEBUG: Print full Qwen response for analysis
                    print("=" * 80)
                    print("🧠 QWEN ANALYSIS - BACKEND DEBUG")
                    print("=" * 80)
                    print(f"📊 Length: {len(qwen_response)} characters")
                    print(f"📝 Full Response:")
                    print(qwen_response)
                    print("=" * 80)
                    
                    qwen_analysis = qwen_response
                    
                    # Try to extract structured investment data from Qwen response
                    # This is where Qwen's analysis should be parsed for investment metrics
                    result["qwen_analysis"] = qwen_response
                    
            except Exception as e:
                logger.error(f"ResponseFormatter with Qwen failed: {e}")
                qwen_analysis = None
        
        # Save analysis results to storage
        await storage.save_properties(
            [property_data.dict()],
            property_data.location,
            source="analysis"
        )
        
        logger.info(f"Property analysis completed for session {session['id']}")
        
        # Transform agent data to AnalysisResponse format
        property_data_result = result.get("property_data", {})
        market_data_result = result.get("market_comparison", {})
        
        
        # Extract price estimation from property data
        price_estimation = None
        if property_data_result.get("ml_prediction"):
            ml_pred = property_data_result["ml_prediction"]
            predicted_price = ml_pred.get("predicted_price", 0)
            if predicted_price > 0:
                price_estimation = {
                    "estimated_price": predicted_price,
                    "price_range": {
                        "min": predicted_price * 0.9,
                        "max": predicted_price * 1.1
                    },
                    "confidence": ml_pred.get("confidence", 0.8),
                    "factors": [
                        {"factor": "Location", "impact": 15, "description": f"Property in {property_data.location}"},
                        {"factor": "Size", "impact": 10, "description": f"Size: {property_data.size_net or property_data.size_gross} m²"}
                    ],
                    "methodology": "XGBoost Machine Learning Model"
                }
        
        # Extract market analysis from MarketComparisonDataAgent
        market_analysis = None
        if market_data_result and market_data_result.get("area_statistics"):
            area_stats = market_data_result["area_statistics"]
            price_stats = area_stats.get("price_statistics", {})
            
            market_analysis = {
                "market_position": "Above Average",
                "average_price": price_stats.get("mean"),
                "price_trend": "Stable",
                "demand_level": "Medium", 
                "supply_level": "Medium",
                "growth_forecast": 8.5
            }
        
        # Extract similar properties (prefer MarketComparisonDataAgent data)
        similar_properties = []
        
        # First try MarketComparisonDataAgent (more detailed)
        if market_data_result and market_data_result.get("similar_properties"):
            similar_props = market_data_result["similar_properties"]
            if isinstance(similar_props, list):
                similar_properties = similar_props[:5]  # Top 5
        # Fallback to PropertyDataAgent
        elif property_data_result.get("similar_properties"):
            similar_props = property_data_result["similar_properties"]
            if isinstance(similar_props, list):
                similar_properties = similar_props[:5]  # Top 5
        
        # Build final response
        # Generate investment analysis - preferring Qwen analysis over calculated values
        investment_analysis = None
        if price_estimation and market_analysis:
            # Try to extract investment metrics from Qwen analysis first
            if qwen_analysis:
                # Parse Qwen response for investment metrics
                # This is a simplified parser - in production, you'd want more sophisticated parsing
                try:
                    import re
                    
                    # Look for investment score patterns in Qwen response
                    score_match = re.search(r'investment.{0,20}score.{0,10}(\d+(?:\.\d+)?)', qwen_analysis, re.IGNORECASE)
                    yield_match = re.search(r'rental.{0,20}yield.{0,10}(\d+(?:\.\d+)?)', qwen_analysis, re.IGNORECASE)
                    roi_match = re.search(r'roi.{0,20}(\d+(?:\.\d+)?)', qwen_analysis, re.IGNORECASE)
                    risk_match = re.search(r'risk.{0,20}(low|medium|high)', qwen_analysis, re.IGNORECASE)
                    
                    qwen_investment_score = float(score_match.group(1)) if score_match else None
                    qwen_rental_yield = float(yield_match.group(1)) if yield_match else None
                    qwen_roi = float(roi_match.group(1)) if roi_match else None
                    qwen_risk = risk_match.group(1).title() if risk_match else None
                    
                    logger.info(f"Extracted from Qwen: score={qwen_investment_score}, yield={qwen_rental_yield}, roi={qwen_roi}, risk={qwen_risk}")
                    
                except Exception as e:
                    logger.warning(f"Failed to parse Qwen investment analysis: {e}")
                    qwen_investment_score = qwen_rental_yield = qwen_roi = qwen_risk = None
            else:
                qwen_investment_score = qwen_rental_yield = qwen_roi = qwen_risk = None
            
            # Use Qwen values if available, otherwise calculate fallback values
            estimated_price = price_estimation.get("estimated_price", 0)
            confidence = price_estimation.get("confidence", 0.6)
            
            # Investment score: prefer Qwen, fallback to calculation
            if qwen_investment_score:
                investment_score = min(10, max(1, qwen_investment_score))
            else:
                investment_score = min(10, max(1, confidence * 10 + (1 if market_analysis.get("market_position") == "Above Average" else 0)))
            
            # Rental yield: prefer Qwen, fallback to calculation
            if qwen_rental_yield:
                rental_yield = qwen_rental_yield
            else:
                base_yield = 4.5  # Base rental yield for Turkey
                location_bonus = 1.0 if "İstanbul" in str(property_data.location) else 0.5
                type_bonus = 0.5 if property_data.property_type == "Daire" else 0.0
                rental_yield = base_yield + location_bonus + type_bonus
            
            # ROI calculation: prefer Qwen, fallback to calculation
            if qwen_roi:
                roi_potential = f"{qwen_roi:.1f}% annually"
            else:
                growth_forecast = market_analysis.get("growth_forecast", 5.0)
                roi_potential = f"{growth_forecast + rental_yield:.1f}% annually"
            
            # Risk assessment: prefer Qwen, fallback to calculation
            if qwen_risk:
                risk_level = qwen_risk
            else:
                risk_level = "Low" if confidence >= 0.8 else "Medium" if confidence >= 0.6 else "High"
            
            investment_analysis = {
                "investment_score": round(investment_score, 1),
                "roi_potential": roi_potential,
                "rental_yield": round(rental_yield, 1),
                "risk_level": risk_level,
                "payback_period": round(100/rental_yield, 1) if rental_yield > 0 else None,  # Float, not string
                "appreciation_forecast": "Positive" if market_analysis.get("growth_forecast", 5.0) > 5 else "Stable",  # Required field
                "market_outlook": "Positive" if market_analysis.get("growth_forecast", 5.0) > 5 else "Stable",
                "qwen_enhanced": bool(qwen_analysis)  # Flag to indicate if Qwen was used
            }
        
        analysis_response = {
            "analysis_id": result.get("analysis_id", f"analysis_{session['id'][:8]}"),
            "timestamp": result.get("timestamp", datetime.utcnow()),
            "confidence_score": result.get("confidence_score", 0.8),
            "analysis_type": result.get("analysis_type", "comprehensive"),
            "data_sources": result.get("data_sources", ["property_agent", "market_agent"]),
            "price_estimation": price_estimation,
            "market_analysis": market_analysis,
            "investment_analysis": investment_analysis,
            "similar_properties": similar_properties,
            "qwen_analysis": qwen_analysis,  # 🔧 FIX: Add qwen_analysis to response
            "recommendations": [
                "Property analysis completed successfully",
                f"Found {len(similar_properties)} similar properties in the area",
                "Market data is fresh and up-to-date",
                f"Investment score: {investment_analysis['investment_score']}/10" if investment_analysis else "Investment analysis pending"
            ],
            "key_insights": [
                f"Property located in {property_data.location}",
                f"Size: {property_data.size_net or property_data.size_gross} m²",
                f"Type: {property_data.property_type}",
                f"Estimated rental yield: {investment_analysis['rental_yield']}%" if investment_analysis else "Rental analysis pending"
            ]
        }
        
        return AnalysisResponse(**analysis_response)
        
    except ValidationException as e:
        logger.error(f"Validation error: {e}")
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=e.to_dict()
        )
    except Exception as e:
        logger.error(f"Analysis failed: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Analysis failed. Please try again."
        )


@router.post(
    "/property/images",
    response_model=AnalysisResponse,
    status_code=status.HTTP_200_OK,
    summary="Analyze property with images",
    description="Perform property analysis including visual assessment"
)
async def analyze_property_with_images(
    images: List[UploadFile] = File(...),
    property_data: str = Form(...),
    session: Dict = SessionDep,
    _: None = Depends(check_rate_limit),
    model_loader = Depends(get_model_loader),
    storage: StorageManager = StorageDep
) -> AnalysisResponse:
    """
    Analyze property with images using unified storage.
    
    Args:
        images: Property images
        property_data: Property data as JSON string
        session: Current user session
        model_loader: Model loader instance
        storage: Storage manager instance
        
    Returns:
        Analysis results including visual assessment
    """
    try:
        # Parse property data
        property_dict = json.loads(property_data)
        
        logger.info(f"Starting property analysis with {len(images)} images")
        
        # Validate images
        max_image_size = 10 * 1024 * 1024  # 10MB
        allowed_types = ["image/jpeg", "image/png", "image/jpg"]
        
        validated_images = []
        for image in images:
            if image.content_type not in allowed_types:
                raise ValidationException(
                    f"Invalid image type: {image.content_type}",
                    field="images"
                )
            
            # Check file size
            contents = await image.read()
            if len(contents) > max_image_size:
                raise ValidationException(
                    f"Image {image.filename} exceeds maximum size",
                    field="images"
                )
            
            # Reset file pointer
            await image.seek(0)
            validated_images.append(image)
        
        # Initialize analysis service
        analysis_service = AnalysisService(model_loader, storage_manager=storage)
        
        # Perform analysis with images
        result = await analysis_service.analyze_property_with_images(
            property_data=property_dict,
            images=validated_images,
            session_id=session['id']
        )
        
        logger.info(f"Property analysis with images completed")
        
        # Ensure required fields are present for AnalysisResponse
        if 'confidence_score' not in result:
            result['confidence_score'] = 0.85  # Higher confidence with images
        
        if 'analysis_type' not in result:
            result['analysis_type'] = 'comprehensive_with_images'
            
        if 'timestamp' not in result:
            result['timestamp'] = datetime.utcnow()
        
        return AnalysisResponse(**result)
        
    except json.JSONDecodeError:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid property data format"
        )
    except ValidationException as e:
        logger.error(f"Validation error: {e}")
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=e.to_dict()
        )
    except Exception as e:
        logger.error(f"Analysis with images failed: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Analysis failed. Please try again."
        )


@router.post(
    "/market",
    response_model=Dict[str, Any],
    status_code=status.HTTP_200_OK,
    summary="Market analysis",
    description="Analyze market conditions for a location"
)
async def analyze_market(
    location: str = Form(..., description="Location to analyze"),
    property_type: Optional[str] = Form(None, description="Property type"),
    include_forecast: bool = Form(True, description="Include market forecast"),
    session: Dict = SessionDep,
    _: None = Depends(check_rate_limit),
    model_loader = Depends(get_model_loader),
    storage: StorageManager = StorageDep
) -> Dict[str, Any]:
    """
    Analyze market conditions using unified storage.
    
    Args:
        location: Location to analyze
        property_type: Type of property
        include_forecast: Include market forecast
        session: Current user session
        model_loader: Model loader instance
        storage: Storage manager instance
        
    Returns:
        Market analysis results
    """
    try:
        logger.info(f"Starting market analysis for {location}")
        
        # Use market comparison agent
        market_agent = MarketComparisonAgent(model_loader)
        
        # Prepare input
        market_input = {
            "property_data": {
                "location": location,
                "property_type": property_type or "Apartment"
            },
            "force_refresh": False
        }
        
        # Get market analysis
        result = await market_agent.process(market_input)
        
        # Get additional market data from storage
        market_stats = await storage.get_market_analysis(
            location=location,
            days_back=30
        )
        
        # Combine results
        analysis = {
            "location": location,
            "property_type": property_type,
            "market_comparison": result.get("result", {}),
            "market_statistics": market_stats,
            "analysis_timestamp": datetime.utcnow().isoformat()
        }
        
        # Add forecast if requested
        if include_forecast:
            analysis["forecast"] = {
                "3_months": "Stable with slight increase",
                "6_months": "5-8% appreciation expected",
                "12_months": "10-15% appreciation expected",
                "confidence": "Medium"
            }
        
        return analysis
        
    except Exception as e:
        logger.error(f"Market analysis failed: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Market analysis failed. Please try again."
        )


@router.post(
    "/investment",
    response_model=Dict[str, Any],
    status_code=status.HTTP_200_OK,
    summary="Investment analysis",
    description="Analyze investment potential"
)
async def analyze_investment(
    budget: float = Form(..., gt=0, description="Investment budget"),
    location: str = Form(..., description="Preferred location"),
    property_type: Optional[str] = Form("Apartment", description="Property type"),
    investment_horizon: str = Form("medium", description="Investment horizon: short/medium/long"),
    preferences: Optional[str] = Form("{}", description="Investment preferences as JSON"),
    session: Dict = SessionDep,
    _: None = Depends(check_rate_limit),
    model_loader = Depends(get_model_loader),
    storage: StorageManager = StorageDep
) -> Dict[str, Any]:
    """
    Analyze investment opportunities using unified storage.
    
    Args:
        budget: Investment budget
        location: Preferred location
        property_type: Type of property
        investment_horizon: Investment time horizon
        preferences: Investment preferences as JSON
        session: Current user session
        model_loader: Model loader instance
        storage: Storage manager instance
        
    Returns:
        Investment analysis and recommendations
    """
    try:
        # Parse preferences
        prefs = json.loads(preferences)
        
        logger.info(f"Starting investment analysis with budget {budget:,.0f} TL")
        
        # Search for properties within budget
        properties = await storage.get_properties(
            location=location,
            filters={
                "max_price": budget * 1.1,  # Allow 10% flexibility
                "min_price": budget * 0.5,   # Minimum 50% of budget
                "property_type": property_type,
                "limit": 20
            }
        )
        
        # Get market analysis
        market_stats = await storage.get_market_analysis(location)
        
        # Calculate investment metrics
        opportunities = []
        for prop in properties[:10]:  # Top 10 properties
            try:
                price = float(prop.get("price", 0))
                size = float(prop.get("size", 100))
                
                if price <= 0 or size <= 0:
                    continue
                
                # Calculate basic ROI
                monthly_rent = price * 0.004  # Assume 0.4% monthly rental yield
                annual_rent = monthly_rent * 12
                roi = (annual_rent / price) * 100
                
                opportunities.append({
                    "property_id": prop.get("property_id", ""),
                    "location": prop.get("location", ""),
                    "price": price,
                    "size": size,
                    "price_per_sqm": price / size,
                    "estimated_monthly_rent": monthly_rent,
                    "estimated_annual_roi": round(roi, 2),
                    "investment_score": min(10, roi),
                    "url": prop.get("url", "")
                })
            except Exception as e:
                logger.warning(f"Skipping property in investment analysis: {e}")
                continue
        
        # Sort by ROI
        opportunities.sort(key=lambda x: x["estimated_annual_roi"], reverse=True)
        
        # Generate recommendations
        recommendations = []
        if opportunities:
            if opportunities[0]["estimated_annual_roi"] > 8:
                recommendations.append("Excellent investment opportunities found")
            elif opportunities[0]["estimated_annual_roi"] > 6:
                recommendations.append("Good investment opportunities available")
            else:
                recommendations.append("Moderate returns expected")
        
        # Horizon-based recommendations
        if investment_horizon == "short":
            recommendations.append("Focus on properties with high rental yield")
        elif investment_horizon == "long":
            recommendations.append("Consider properties in developing areas")
        else:
            recommendations.append("Balance between rental yield and appreciation")
        
        return {
            "budget": budget,
            "location": location,
            "property_type": property_type,
            "investment_horizon": investment_horizon,
            "opportunities_found": len(opportunities),
            "top_opportunities": opportunities[:5],
            "market_overview": market_stats,
            "recommendations": recommendations,
            "analysis_timestamp": datetime.utcnow().isoformat()
        }
        
    except json.JSONDecodeError:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid preferences format"
        )
    except Exception as e:
        logger.error(f"Investment analysis failed: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Investment analysis failed. Please try again."
        )


@router.get(
    "/report/{analysis_id}",
    response_model=Dict[str, Any],
    status_code=status.HTTP_200_OK,
    summary="Get analysis report",
    description="Retrieve a previously generated analysis report"
)
async def get_analysis_report(
    analysis_id: str,
    session: Dict = SessionDep,
    storage: StorageManager = StorageDep
) -> Dict[str, Any]:
    """
    Get a previously generated analysis report.
    
    Args:
        analysis_id: Analysis ID
        session: Current user session
        storage: Storage manager instance
        
    Returns:
        Analysis report
    """
    try:
        logger.info(f"Retrieving analysis report {analysis_id}")
        
        # For now, return a placeholder
        # In production, this would retrieve from database
        return {
            "analysis_id": analysis_id,
            "status": "completed",
            "message": "Report retrieval will be implemented with database integration",
            "timestamp": datetime.utcnow().isoformat()
        }
        
    except Exception as e:
        logger.error(f"Failed to retrieve analysis report: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to retrieve analysis report."
        )
