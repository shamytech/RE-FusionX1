"""
Location API endpoints for frontend location filters
"""

import json
from pathlib import Path
from typing import Dict, Any, List
from fastapi import APIRouter, HTTPException
from fastapi.responses import JSONResponse

from app.core.logging import logger

router = APIRouter()

# Cache for location data
_location_data_cache = None

def get_location_data() -> Dict[str, Any]:
    """Get location data from cache or file"""
    global _location_data_cache
    
    if _location_data_cache is not None:
        return _location_data_cache
    
    try:
        # Try to load from backend configs
        config_path = Path(__file__).parent.parent.parent.parent / "data_collectors" / "real_estate" / "configs" / "cities_and_districts_data.json"
        
        if config_path.exists():
            with open(config_path, 'r', encoding='utf-8') as f:
                old_format_data = json.load(f)
            
            # Convert old format to new hierarchical format
            cities_data = {}
            neighborhoods_data = {}
            
            for city, districts in old_format_data.items():
                cities_data[city] = {"districts": districts}
                neighborhoods_data[city] = {}
                
                # Add some sample neighborhoods for major districts
                for district in districts[:5]:  # Limit to first 5 districts for performance
                    neighborhoods_data[city][district] = [
                        f"{district} Merkez",
                        f"{district} Mahallesi",
                        f"Yeni {district}",
                        f"{district} Çarşı"
                    ]
            
            _location_data_cache = {
                "cities": cities_data,
                "neighborhoods": neighborhoods_data
            }
            
            logger.info(f"Loaded location data: {len(cities_data)} cities")
            return _location_data_cache
            
    except Exception as e:
        logger.error(f"Failed to load location data: {e}")
    
    # Fallback minimal data
    _location_data_cache = {
        "cities": {
            "İstanbul": {
                "districts": ["Kadıköy", "Beşiktaş", "Şişli", "Beyoğlu", "Bakırköy", "Üsküdar", "Fatih", "Ataşehir", "Maltepe", "Kartal"]
            },
            "Ankara": {
                "districts": ["Çankaya", "Keçiören", "Yenimahalle", "Mamak", "Altındağ", "Etimesgut", "Sincan", "Pursaklar"]
            },
            "İzmir": {
                "districts": ["Konak", "Karşıyaka", "Bornova", "Buca", "Çiğli", "Gaziemir", "Balçova", "Narlıdere"]
            }
        },
        "neighborhoods": {
            "İstanbul": {
                "Kadıköy": ["Moda", "Fenerbahçe", "Göztepe", "Bostancı", "Suadiye"],
                "Beşiktaş": ["Etiler", "Levent", "Bebek", "Ortaköy", "Arnavutköy"]
            },
            "Ankara": {
                "Çankaya": ["Kızılay", "Bahçelievler", "Emek", "Ayrancı", "Gaziosmanpaşa"]
            },
            "İzmir": {
                "Konak": ["Alsancak", "Güzelyalı", "Basmane", "Çankaya"]
            }
        }
    }
    
    return _location_data_cache


@router.get("/data")
async def get_locations_data():
    """
    Get hierarchical location data (cities, districts, neighborhoods)
    """
    try:
        data = get_location_data()
        return JSONResponse(content=data)
    except Exception as e:
        logger.error(f"Failed to serve location data: {e}")
        raise HTTPException(status_code=500, detail="Failed to load location data")


@router.get("/cities")
async def get_cities() -> List[str]:
    """Get list of all cities"""
    try:
        data = get_location_data()
        cities = list(data.get("cities", {}).keys())
        return cities
    except Exception as e:
        logger.error(f"Failed to get cities: {e}")
        raise HTTPException(status_code=500, detail="Failed to load cities")


@router.get("/districts/{city}")
async def get_districts(city: str) -> List[str]:
    """Get districts for a specific city"""
    try:
        data = get_location_data()
        city_data = data.get("cities", {}).get(city, {})
        districts = city_data.get("districts", [])
        return districts
    except Exception as e:
        logger.error(f"Failed to get districts for {city}: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to load districts for {city}")


@router.get("/neighborhoods/{city}/{district}")
async def get_neighborhoods(city: str, district: str) -> List[str]:
    """Get neighborhoods for a specific city and district"""
    try:
        data = get_location_data()
        neighborhoods = data.get("neighborhoods", {}).get(city, {}).get(district, [])
        return neighborhoods
    except Exception as e:
        logger.error(f"Failed to get neighborhoods for {city}/{district}: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to load neighborhoods for {city}/{district}")


@router.post("/search")
async def search_locations(query: str, location_type: str = "all"):
    """
    Search locations by query
    
    Args:
        query: Search query
        location_type: Type of location to search ('cities', 'districts', 'neighborhoods', 'all')
    """
    try:
        data = get_location_data()
        results = {
            "cities": [],
            "districts": [],
            "neighborhoods": []
        }
        
        query_lower = query.lower()
        
        if location_type in ("all", "cities"):
            # Search cities
            for city in data.get("cities", {}).keys():
                if query_lower in city.lower():
                    results["cities"].append(city)
        
        if location_type in ("all", "districts"):
            # Search districts
            for city, city_data in data.get("cities", {}).items():
                for district in city_data.get("districts", []):
                    if query_lower in district.lower():
                        results["districts"].append({
                            "district": district,
                            "city": city
                        })
        
        if location_type in ("all", "neighborhoods"):
            # Search neighborhoods
            for city, city_neighborhoods in data.get("neighborhoods", {}).items():
                for district, neighborhoods in city_neighborhoods.items():
                    for neighborhood in neighborhoods:
                        if query_lower in neighborhood.lower():
                            results["neighborhoods"].append({
                                "neighborhood": neighborhood,
                                "district": district,
                                "city": city
                            })
        
        return results
        
    except Exception as e:
        logger.error(f"Failed to search locations: {e}")
        raise HTTPException(status_code=500, detail="Failed to search locations")

