# app/api/v1/endpoints/health.py

"""
Health check endpoints for system monitoring - Updated for unified storage.
Provides health status and system metrics.
"""

from typing import Dict, Any
from datetime import datetime
import psutil
from fastapi import APIRouter, Depends, status
from fastapi import HTTPException
from app.core.config import settings
from app.core.logging import logger
from app.api.v1.dependencies import (
    get_model_loader,
    StorageDep,
    CacheDep
)
from app.core.storage.storage_manager import StorageManager
from app.core.storage.unified_cache import UnifiedCache


router = APIRouter()


@router.get(
    "/",
    response_model=Dict[str, Any],
    status_code=status.HTTP_200_OK,
    summary="Basic health check",
    description="Check if the service is running"
)
async def health_check() -> Dict[str, Any]:
    """
    Basic health check endpoint.
    
    Returns:
        Health status
    """
    return {
        "status": "healthy",
        "service": settings.APP_NAME,
        "version": settings.APP_VERSION,
        "timestamp": datetime.utcnow().isoformat()
    }

@router.get(
    "/integration",
    response_model=Dict[str, Any],
    status_code=status.HTTP_200_OK,
    summary="Storage Integration health",
    description="Check storage integration health"
)
async def integration_health() -> Dict[str, Any]:
    """
    Check storage integration health.
    
    Returns:
        Integration health status
    """
    try:
        from app.core.storage.integration import StorageIntegration
        
        health = StorageIntegration.verify_health()
        
        return {
            "status": "healthy" if health["overall"] else "unhealthy",
            "components": health,
            "timestamp": datetime.utcnow().isoformat()
        }
        
    except Exception as e:
        logger.error(f"Integration health check failed: {e}")
        return {
            "status": "unhealthy",
            "error": str(e),
            "timestamp": datetime.utcnow().isoformat()
        }

@router.get(
    "/ready",
    response_model=Dict[str, Any],
    status_code=status.HTTP_200_OK,
    summary="Readiness check",
    description="Check if the service is ready to handle requests"
)
async def readiness_check(
    model_loader = Depends(get_model_loader),
    storage: StorageManager = StorageDep,
    cache: UnifiedCache = CacheDep
) -> Dict[str, Any]:
    """
    Readiness check endpoint with unified storage.
    
    Args:
        model_loader: Model loader instance
        storage: Storage manager instance
        cache: Cache instance
        
    Returns:
        Readiness status
    """
    checks = {
        "model_loaded": False,
        "cache_connected": False,
        "storage_ready": False,
        "search_engine_ready": False
    }
    
    try:
        # Check model
        checks["model_loaded"] = model_loader.is_loaded()
        
        # Check cache
        test_key = "health_check_test"
        await cache.set(test_key, "test", ttl_override=10)
        test_value = await cache.get(test_key)
        checks["cache_connected"] = test_value == "test"
        await cache.delete(test_key)
        
        # Check storage
        stats = storage.get_statistics()
        checks["storage_ready"] = stats is not None
        
        # Check search engine
        checks["search_engine_ready"] = storage.search_client is not None
        
    except Exception as e:
        logger.error(f"Readiness check failed: {e}")
    
    all_ready = all(checks.values())
    
    return {
        "ready": all_ready,
        "checks": checks,
        "timestamp": datetime.utcnow().isoformat()
    }


@router.get(
    "/metrics",
    response_model=Dict[str, Any],
    status_code=status.HTTP_200_OK,
    summary="System metrics",
    description="Get system performance metrics"
)
async def system_metrics(
    storage: StorageManager = StorageDep,
    cache: UnifiedCache = CacheDep
) -> Dict[str, Any]:
    """
    System metrics endpoint with storage statistics.
    
    Args:
        storage: Storage manager instance
        cache: Cache instance
        
    Returns:
        System performance metrics
    """
    try:
        # CPU metrics
        cpu_percent = psutil.cpu_percent(interval=1)
        cpu_count = psutil.cpu_count()
        
        # Memory metrics
        memory = psutil.virtual_memory()
        memory_percent = memory.percent
        memory_used = memory.used / (1024 ** 3)  # Convert to GB
        memory_total = memory.total / (1024 ** 3)  # Convert to GB
        
        # Disk metrics
        disk = psutil.disk_usage('/')
        disk_percent = disk.percent
        disk_used = disk.used / (1024 ** 3)  # Convert to GB
        disk_total = disk.total / (1024 ** 3)  # Convert to GB
        
        # Storage metrics
        storage_stats = storage.get_statistics()
        
        # Cache metrics
        cache_stats = cache.get_stats()
        
        return {
            "system": {
                "cpu": {
                    "usage_percent": cpu_percent,
                    "cores": cpu_count
                },
                "memory": {
                    "usage_percent": memory_percent,
                    "used_gb": round(memory_used, 2),
                    "total_gb": round(memory_total, 2)
                },
                "disk": {
                    "usage_percent": disk_percent,
                    "used_gb": round(disk_used, 2),
                    "total_gb": round(disk_total, 2)
                }
            },
            "storage": storage_stats,
            "cache": cache_stats,
            "timestamp": datetime.utcnow().isoformat()
        }
        
    except Exception as e:
        logger.error(f"Failed to get system metrics: {e}")
        return {
            "error": "Failed to retrieve metrics",
            "timestamp": datetime.utcnow().isoformat()
        }


@router.get(
    "/storage",
    response_model=Dict[str, Any],
    status_code=status.HTTP_200_OK,
    summary="Storage health",
    description="Check storage system health"
)
async def storage_health(
    storage: StorageManager = StorageDep
) -> Dict[str, Any]:
    """
    Storage system health check.
    
    Args:
        storage: Storage manager instance
        
    Returns:
        Storage health status
    """
    try:
        stats = storage.get_statistics()
        
        # Check if storage has recent data
        performance = stats.get("performance_metrics", {})
        storage_info = stats.get("storage_stats", {})
        
        return {
            "status": "healthy",
            "statistics": stats,
            "cache_hits": performance.get("cache_hits", 0),
            "storage_hits": performance.get("storage_hits", 0),
            "total_files": storage_info.get("storage", {}).get("total_files", 0),
            "timestamp": datetime.utcnow().isoformat()
        }
        
    except Exception as e:
        logger.error(f"Storage health check failed: {e}")
        return {
            "status": "unhealthy",
            "error": str(e),
            "timestamp": datetime.utcnow().isoformat()
        }


@router.post(
    "/cleanup",
    response_model=Dict[str, Any],
    status_code=status.HTTP_200_OK,
    summary="Cleanup old data",
    description="Clean up old cached and stored data"
)
async def cleanup_old_data(
    days_to_keep: int = 30,
    storage: StorageManager = StorageDep,
    cache: UnifiedCache = CacheDep
) -> Dict[str, Any]:
    """
    Clean up old data from storage and cache.
    
    Args:
        days_to_keep: Number of days to keep data
        storage: Storage manager instance
        cache: Cache instance
        
    Returns:
        Cleanup statistics
    """
    try:
        logger.info(f"Starting cleanup, keeping last {days_to_keep} days")
        
        # Cleanup storage
        cleanup_stats = await storage.cleanup_old_data(days_to_keep)
        
        # Clear old cache entries
        cache_cleared = await cache.clear_pattern("*")
        
        return {
            "status": "success",
            "storage_cleaned": cleanup_stats,
            "cache_cleared": cache_cleared,
            "timestamp": datetime.utcnow().isoformat()
        }
        
    except Exception as e:
        logger.error(f"Cleanup failed: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Cleanup operation failed."
        )
