# app/api/v1/endpoints/chat.py

"""
Chat endpoints for conversational interaction - Updated for unified storage.
Handles chat messages and maintains conversation context.
"""

from typing import Dict, Any, List, Optional
from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, Field
from datetime import datetime
from app.core.logging import logger
from app.api.v1.dependencies import (
    get_current_session,
    check_rate_limit,
    get_model_loader,
    SessionDep,
    StorageDep
)
from app.core.storage.session_manager import get_session_manager
from app.core.storage.storage_manager import StorageManager
from app.services.chat_service import ChatService
from app.services.analysis_service import AnalysisService
from app.models.schemas.response import ChatMessage, ChatResponse


router = APIRouter()


class ChatRequest(BaseModel):
    """Chat request model."""
    message: str = Field(..., min_length=1, max_length=5000)
    context: Optional[Dict[str, Any]] = Field(default=None)
    include_sources: bool = Field(default=False)
    use_agents: bool = Field(default=True, description="Use specialized agents")


class StoreAnalysisRequest(BaseModel):
    """Store analysis for chat context."""
    property_data: Dict[str, Any] = Field(..., description="Property information")
    analysis_results: Dict[str, Any] = Field(..., description="Analysis results")
    session_id: str = Field(..., description="Session identifier")


@router.post(
    "/message",
    response_model=ChatResponse,
    status_code=status.HTTP_200_OK,
    summary="Send chat message",
    description="Send a message to the AI assistant with unified storage"
)
async def send_message(
    request: ChatRequest,
    session: Dict = SessionDep,
    _: None = Depends(check_rate_limit),
    model_loader = Depends(get_model_loader),
    storage: StorageManager = StorageDep
) -> ChatResponse:
    """
    Send a chat message to the AI assistant.
    
    Args:
        request: Chat request with message
        session: Current user session
        model_loader: Model loader instance
        storage: Storage manager instance
        
    Returns:
        AI assistant response
    """
    try:
        logger.info(f"Processing chat message for session {session['id']}")
        
        # Get session manager (unified system)
        session_manager = get_session_manager()
        
        # Add user message to session history
        await session_manager.add_message(
            session_id=session['id'],
            role="user",
            content=request.message,
            metadata=request.context
        )
        
        # Initialize chat service with storage
        chat_service = ChatService(model_loader, storage_manager=storage)
        
        # Process message
        response = await chat_service.process_message(
            message=request.message,
            session_id=session['id'],
            context=request.context,
            include_sources=request.include_sources,
            use_agents=request.use_agents
        )
        
        # Add assistant response to session history
        await session_manager.add_message(
            session_id=session['id'],
            role="assistant",
            content=response.get('response', ''),
            metadata={
                "sources": response.get('sources', []),
                "agent_used": response.get('agent', 'chat')
            }
        )
        
        return ChatResponse(**response)
        
    except Exception as e:
        logger.error(f"Chat processing failed: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to process message. Please try again."
        )


@router.get(
    "/history",
    response_model=List[ChatMessage],
    status_code=status.HTTP_200_OK,
    summary="Get chat history",
    description="Retrieve conversation history from unified session storage"
)
async def get_chat_history(
    limit: int = 50,
    offset: int = 0,
    session: Dict = SessionDep
) -> List[ChatMessage]:
    """
    Get chat history for current session.
    
    Args:
        limit: Maximum number of messages to retrieve
        offset: Offset for pagination
        session: Current user session
        
    Returns:
        List of chat messages
    """
    try:
        logger.info(f"Retrieving chat history for session {session['id']}")
        
        # Get session manager (unified system)
        session_manager = get_session_manager()
        
        # Get full session data
        session_data = await session_manager.get_session(session['id'])
        
        if not session_data:
            return []
        
        # Get conversation history
        messages = session_data.get('conversation_history', [])
        
        # Apply pagination
        start = offset
        end = offset + limit
        paginated_messages = messages[start:end]
        
        # Convert to response model
        return [ChatMessage(**msg) for msg in paginated_messages]
        
    except Exception as e:
        logger.error(f"Failed to retrieve chat history: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to retrieve chat history."
        )


@router.delete(
    "/history",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Clear chat history",
    description="Clear conversation history for current session"
)
async def clear_chat_history(
    session: Dict = SessionDep
) -> None:
    """
    Clear chat history for current session.
    
    Args:
        session: Current user session
    """
    try:
        logger.info(f"Clearing chat history for session {session['id']}")
        
        # Get session manager (unified system)
        session_manager = get_session_manager()
        
        # Update session to clear history
        await session_manager.update_session(
            session_id=session['id'],
            updates={'conversation_history': []}
        )
        
        logger.info(f"Chat history cleared for session {session['id']}")
        
    except Exception as e:
        logger.error(f"Failed to clear chat history: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to clear chat history."
        )


class FeedbackRequest(BaseModel):
    """Feedback request model."""
    message_id: str = Field(..., description="Message ID")
    rating: int = Field(..., ge=1, le=5, description="Rating from 1 to 5")
    comment: Optional[str] = Field(None, max_length=1000)
    helpful: Optional[bool] = Field(None, description="Was the response helpful?")


@router.post(
    "/feedback",
    status_code=status.HTTP_200_OK,
    summary="Submit feedback",
    description="Submit feedback for a message"
)
async def submit_feedback(
    request: FeedbackRequest,
    session: Dict = SessionDep,
    storage: StorageManager = StorageDep
) -> Dict[str, str]:
    """
    Submit feedback for a message.
    
    Args:
        request: Feedback request
        session: Current user session
        storage: Storage manager instance
        
    Returns:
        Confirmation message
    """
    try:
        logger.info(
            f"Feedback submitted for message {request.message_id}: "
            f"rating={request.rating}, helpful={request.helpful}"
        )
        
        # Store feedback in session context using unified session manager
        session_manager = get_session_manager()
        
        feedback_data = {
            "message_id": request.message_id,
            "rating": request.rating,
            "comment": request.comment,
            "helpful": request.helpful,
            "timestamp": datetime.utcnow().isoformat()
        }
        
        # Update session with feedback
        await session_manager.update_session(
            session_id=session['id'],
            updates={
                "context": {
                    f"feedback_{request.message_id}": feedback_data
                }
            }
        )
        
        return {
            "status": "success",
            "message": "Thank you for your feedback!"
        }
        
    except Exception as e:
        logger.error(f"Failed to submit feedback: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to submit feedback."
        )


@router.get(
    "/context",
    response_model=Dict[str, Any],
    status_code=status.HTTP_200_OK,
    summary="Get conversation context",
    description="Get current conversation context and metadata"
)
async def get_conversation_context(
    session: Dict = SessionDep
) -> Dict[str, Any]:
    """
    Get conversation context for current session.
    
    Args:
        session: Current user session
        
    Returns:
        Conversation context and metadata
    """
    try:
        logger.info(f"Getting context for session {session['id']}")
        
        # Get session manager (unified system)
        session_manager = get_session_manager()
        
        # Get full session data
        session_data = await session_manager.get_session(session['id'])
        
        if not session_data:
            return {
                "context": {},
                "preferences": {},
                "message_count": 0
            }
        
        return {
            "context": session_data.get('context', {}),
            "preferences": session_data.get('preferences', {}),
            "message_count": len(session_data.get('conversation_history', [])),
            "session_created": session_data.get('created_at'),
            "last_activity": session_data.get('last_activity')
        }
    except Exception as e:
        logger.error(f"Failed to get conversation context: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to get conversation context."
        )


@router.post(
    "/store-analysis",
    status_code=status.HTTP_200_OK,
    summary="Store analysis for chat context",
    description="Store analysis results in cache for chat context"
)
async def store_analysis(
    request: StoreAnalysisRequest,
    model_loader = Depends(get_model_loader)
) -> Dict[str, Any]:
    """
    Store analysis results in cache for chat context.
    This allows chat to access analysis data without re-running analysis.
    """
    try:
        # نستخدم نسخة خفيفة من خدمة التحليل حتى لا يتم تحميل الوكلاء أو النموذج أثناء التخزين فقط
        analysis_service = AnalysisService(model_loader=None)
        success = await analysis_service.store_analysis_for_chat(
            property_data=request.property_data,
            analysis_results=request.analysis_results,
            session_id=request.session_id
        )
        
        if success:
            return {
                "success": True,
                "message": "Analysis results stored successfully",
                "session_id": request.session_id
            }
        else:
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Failed to store analysis results"
            )
            
    except Exception as e:
        logger.error(f"Failed to store analysis: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to store analysis: {str(e)}"
        )
