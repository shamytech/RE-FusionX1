# app/api/v1/endpoints/properties.py

"""
Property management endpoints - Updated for unified storage system.
Handles property search, comparison, and data retrieval.
"""

from typing import Dict, Any, List, Optional
from fastapi import APIRouter, Depends, HTTPException, Query, status
from pydantic import BaseModel, Field

from app.core.logging import logger
from app.core.constants import PropertyType, RoomConfiguration
from app.api.v1.dependencies import (
    get_current_session,
    check_rate_limit,
    StorageDep,
    CacheDep,
    SessionDep
)
from app.core.storage.storage_manager import StorageManager
from app.core.storage.unified_cache import UnifiedCache
from app.services.property_service import PropertyService
from app.models.schemas.property import PropertySearch, PropertyDetails


router = APIRouter()


@router.get(
    "/search",
    response_model=List[PropertyDetails],
    status_code=status.HTTP_200_OK,
    summary="Search properties",
    description="Search for properties based on criteria using unified storage"
)
async def search_properties(
    location: Optional[str] = Query(None, description="Location to search"),
    property_type: Optional[PropertyType] = Query(None, description="Type of property"),
    rooms: Optional[RoomConfiguration] = Query(None, description="Room configuration"),
    min_price: Optional[float] = Query(None, ge=0, description="Minimum price"),
    max_price: Optional[float] = Query(None, ge=0, description="Maximum price"),
    min_size: Optional[int] = Query(None, ge=0, description="Minimum size in sqm"),
    max_size: Optional[int] = Query(None, ge=0, description="Maximum size in sqm"),
    limit: int = Query(20, ge=1, le=100, description="Number of results"),
    offset: int = Query(0, ge=0, description="Offset for pagination"),
    force_refresh: bool = Query(False, description="Force refresh from source"),
    session: Dict = SessionDep,
    _: None = Depends(check_rate_limit),
    storage: StorageManager = StorageDep
) -> List[PropertyDetails]:
    """
    Search for properties using unified storage system.
    
    Args:
        Various search criteria
        session: Current user session
        storage: Storage manager instance
        
    Returns:
        List of matching properties
    """
    try:
        logger.info(f"Searching properties: location={location}, type={property_type}, force_refresh={force_refresh}")
        
        # Build filters
        filters = {
            "property_type": property_type.value if property_type else None,
            "rooms": rooms.value if rooms else None,
            "min_price": min_price,
            "max_price": max_price,
            "min_size": min_size,
            "max_size": max_size,
            "limit": limit,
            "offset": offset
        }
        
        # Remove None values
        filters = {k: v for k, v in filters.items() if v is not None}
        
        # Search using storage manager
        properties = await storage.get_properties(
            location=location or "Istanbul",
            filters=filters,
            force_refresh=force_refresh
        )
        
        # Convert to response model
        results = []
        for prop in properties[:limit]:
            try:
                results.append(PropertyDetails(**prop))
            except Exception as e:
                logger.warning(f"Skipping invalid property data: {e}")
                continue
        
        logger.info(f"Found {len(results)} properties")
        return results
        
    except Exception as e:
        logger.error(f"Property search failed: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Property search failed. Please try again."
        )


@router.get(
    "/similar/{property_id}",
    response_model=List[PropertyDetails],
    status_code=status.HTTP_200_OK,
    summary="Find similar properties",
    description="Find properties similar to a given property"
)
async def find_similar_properties(
    property_id: str,
    limit: int = Query(10, ge=1, le=50, description="Maximum number of results"),
    session: Dict = SessionDep,
    _: None = Depends(check_rate_limit),
    storage: StorageManager = StorageDep
) -> List[PropertyDetails]:
    """
    Find similar properties using unified storage.
    
    Args:
        property_id: ID of reference property
        limit: Maximum number of results
        session: Current user session
        storage: Storage manager instance
        
    Returns:
        List of similar properties
    """
    try:
        logger.info(f"Finding properties similar to {property_id}")
        
        # Initialize property service with new storage
        property_service = PropertyService()
        
        # Get reference property
        reference = await property_service.get_property(property_id)
        if not reference:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Property {property_id} not found"
            )
        
        # Find similar using storage manager
        similar = await storage.search_similar_properties(
            reference,
            limit
        )
        
        # Convert to response model
        results = []
        for prop in similar:
            try:
                results.append(PropertyDetails(**prop))
            except Exception as e:
                logger.warning(f"Skipping invalid property data: {e}")
                continue
        
        return results
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to find similar properties: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to find similar properties."
        )


class PropertyComparisonRequest(BaseModel):
    """Request model for property comparison."""
    property_ids: List[str] = Field(
        ..., 
        min_items=2, 
        max_items=5,
        description="List of property IDs to compare"
    )


@router.post(
    "/compare",
    response_model=Dict[str, Any],
    status_code=status.HTTP_200_OK,
    summary="Compare properties",
    description="Compare multiple properties side by side"
)
async def compare_properties(
    request: PropertyComparisonRequest,
    session: Dict = SessionDep,
    _: None = Depends(check_rate_limit)
) -> Dict[str, Any]:
    """
    Compare multiple properties.
    
    Args:
        request: Property comparison request
        session: Current user session
        
    Returns:
        Comparison results
    """
    try:
        logger.info(f"Comparing {len(request.property_ids)} properties")
        
        # Initialize property service
        property_service = PropertyService()
        
        # Compare properties
        comparison = await property_service.compare_properties(
            request.property_ids
        )
        
        return comparison
        
    except Exception as e:
        logger.error(f"Property comparison failed: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Property comparison failed."
        )


@router.get(
    "/{property_id}",
    response_model=PropertyDetails,
    status_code=status.HTTP_200_OK,
    summary="Get property details",
    description="Get detailed information about a property"
)
async def get_property_details(
    property_id: str,
    session: Dict = SessionDep,
    _: None = Depends(check_rate_limit),
    cache: UnifiedCache = CacheDep
) -> PropertyDetails:
    """
    Get property details using unified cache.
    
    Args:
        property_id: Property ID
        session: Current user session
        cache: Cache instance
        
    Returns:
        Property details
    """
    try:
        logger.info(f"Retrieving details for property {property_id}")
        
        # Initialize property service
        property_service = PropertyService()
        
        # Get property details
        property_data = await property_service.get_property(property_id)
        
        if not property_data:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Property not found"
            )
        
        return PropertyDetails(**property_data)
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to get property details: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to retrieve property details."
        )


@router.get(
    "/market/statistics",
    response_model=Dict[str, Any],
    status_code=status.HTTP_200_OK,
    summary="Get market statistics",
    description="Get market statistics for a location"
)
async def get_market_statistics(
    location: str = Query(..., description="Location for statistics"),
    property_type: Optional[PropertyType] = Query(None, description="Property type filter"),
    session: Dict = SessionDep,
    _: None = Depends(check_rate_limit),
    storage: StorageManager = StorageDep
) -> Dict[str, Any]:
    """
    Get market statistics for a location.
    
    Args:
        location: Location name
        property_type: Optional property type filter
        session: Current user session
        storage: Storage manager instance
        
    Returns:
        Market statistics
    """
    try:
        logger.info(f"Getting market statistics for {location}")
        
        # Get market analysis from storage
        stats = await storage.get_market_analysis(
            location=location,
            days_back=30
        )
        
        # Add property type filter if provided
        if property_type and stats.get("properties"):
            filtered_props = [
                p for p in stats["properties"]
                if p.get("property_type") == property_type.value
            ]
            stats["filtered_count"] = len(filtered_props)
            stats["filter_applied"] = property_type.value
        
        return stats
        
    except Exception as e:
        logger.error(f"Failed to get market statistics: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to retrieve market statistics."
        )


@router.post(
    "/refresh/{location}",
    response_model=Dict[str, str],
    status_code=status.HTTP_200_OK,
    summary="Refresh property data",
    description="Force refresh property data for a location"
)
async def refresh_property_data(
    location: str,
    session: Dict = SessionDep,
    _: None = Depends(check_rate_limit),
    storage: StorageManager = StorageDep,
    cache: UnifiedCache = CacheDep
) -> Dict[str, str]:
    """
    Force refresh property data for a location.
    
    Args:
        location: Location to refresh
        session: Current user session
        storage: Storage manager instance
        cache: Cache instance
        
    Returns:
        Refresh status
    """
    try:
        logger.info(f"Refreshing property data for {location}")
        
        # Clear cache for location
        cleared = await cache.clear_pattern(f"*{location}*")
        
        # Force refresh from storage
        properties = await storage.get_properties(
            location=location,
            force_refresh=True
        )
        
        return {
            "status": "success",
            "message": f"Refreshed {len(properties)} properties for {location}",
            "cache_cleared": f"{cleared} entries"
        }
        
    except Exception as e:
        logger.error(f"Failed to refresh property data: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to refresh property data."
        )
