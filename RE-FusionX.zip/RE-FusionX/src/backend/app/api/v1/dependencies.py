# app/api/v1/dependencies.py



"""

Shared dependencies for API endpoints.

Provides common dependencies for dependency injection.

"""



from typing import Optional, Dict, Any

from fastapi import Depends, HTTPException, Request, status

from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials



from app.core.security import security_manager, rate_limiter

from app.core.logging import logger

from app.core.storage.session_manager import get_session_manager
from app.core.storage.storage_manager import get_storage_manager

from app.core.storage.unified_cache import get_cache

from app.models.llm.model_loader import ModelLoader

from app.core.storage.integration import StorageIntegration



# Security scheme

bearer_scheme = HTTPBearer(auto_error=False)





async def get_current_session(

    request: Request,

    credentials: Optional[HTTPAuthorizationCredentials] = Depends(bearer_scheme)

) -> Dict[str, Any]:

    """

    Get current user session.

    

    Args:

        request: FastAPI request object

        credentials: Bearer token credentials

        

    Returns:

        Session data

        

    Raises:

        HTTPException: If session is invalid

    """

    # Use unified session integration
    session_manager = get_session_manager()

    

    # Try to get session from token

    if credentials:

        try:

            session_data = security_manager.verify_token(credentials.credentials)

            session_id = session_data.get("session_id")

            

            if session_id:

                session = await session_manager.get_session(session_id)

                if session:

                    return session

        except Exception as e:

            logger.warning(f"Invalid session token: {e}")

    

    # Create new session if none exists

    session = await session_manager.create_session()

    return session





async def check_rate_limit(request: Request) -> None:

    """

    Check rate limiting for request.

    

    Args:

        request: FastAPI request object

        

    Raises:

        HTTPException: If rate limit exceeded

    """

    # Get client identifier (IP address)

    client_ip = request.client.host if request.client else "unknown"

    

    if not rate_limiter.check_rate_limit(client_ip):

        raise HTTPException(

            status_code=status.HTTP_429_TOO_MANY_REQUESTS,

            detail="Rate limit exceeded. Please try again later."

        )





async def get_model_loader(request: Request) -> ModelLoader:

    """

    Get model loader instance.

    

    Args:

        request: FastAPI request object

        

    Returns:

        ModelLoader instance

    """

    return request.app.state.model_loader





async def get_storage(request: Request = None):

    """

    Get storage manager instance.

    Uses singleton pattern for consistency.

    

    Args:

        request: Optional FastAPI request object

        

    Returns:

        StorageManager instance

    """

    return get_storage_manager()





async def get_cache(request: Request = None):

    """

    Get unified cache instance.

    Uses singleton pattern for consistency.

    

    Args:

        request: Optional FastAPI request object

        

    Returns:

        UnifiedCache instance

    """

    from app.core.storage.unified_cache import get_cache as get_cache_instance

    return get_cache_instance()





async def get_session_manager_dep(request: Request = None):

    """

    Get session manager instance.

    Uses singleton pattern for consistency.

    

    Args:

        request: Optional FastAPI request object

        

    Returns:

        SessionManager instance

    """

    return get_session_manager()



async def get_storage_integrated(request: Request = None):

    """

    Get storage manager using integration.

    """

    return StorageIntegration.get_storage()



async def get_cache_integrated(request: Request = None):

    """

    Get cache using integration.

    """

    return StorageIntegration.get_cache()



def validate_content_type(content_type: str = "application/json"):

    """

    Validate request content type.

    

    Args:

        content_type: Expected content type

        

    Returns:

        Dependency function

    """

    def dependency(request: Request):

        if request.headers.get("content-type") != content_type:

            raise HTTPException(

                status_code=status.HTTP_415_UNSUPPORTED_MEDIA_TYPE,

                detail=f"Content-Type must be {content_type}"

            )

    

    return Depends(dependency)







# Convenience dependencies for common patterns

StorageDep = Depends(get_storage)

CacheDep = Depends(get_cache)

SessionDep = Depends(get_current_session)

ModelLoaderDep = Depends(get_model_loader)

RateLimitDep = Depends(check_rate_limit)

StorageIntegratedDep = Depends(get_storage_integrated)

CacheIntegratedDep = Depends(get_cache_integrated)

