"""
Data Validator for collected data
==================================
Validates and ensures data quality
"""

from typing import Dict, Any, List, Optional, Union
from datetime import datetime
import re
from dataclasses import dataclass

from app.core.logging import logger


@dataclass
class ValidationResult:
    """Result of data validation"""
    is_valid: bool
    errors: List[str]
    warnings: List[str]
    quality_score: float
    metadata: Dict[str, Any]


class DataValidator:
    """
    Validates collected data for quality and completeness
    """
    
    def __init__(self):
        """Initialize data validator"""
        self.validation_rules = {
            "property": self._get_property_rules(),
            "economic": self._get_economic_rules(),
            "news": self._get_news_rules()
        }
    
    def _get_property_rules(self) -> Dict[str, Any]:
        """Get validation rules for property data"""
        return {
            "required_fields": ["price", "size", "location"],
            "optional_fields": ["rooms", "building_age", "floor", "features"],
            "price_range": {"min": 10000, "max": 100000000},
            "size_range": {"min": 20, "max": 5000},
            "patterns": {
                "rooms": r"^\d+\+\d+$|^\d+$",
                "phone": r"^[\d\s\-\+\(\)]+$"
            }
        }
    
    def _get_economic_rules(self) -> Dict[str, Any]:
        """Get validation rules for economic data"""
        return {
            "required_indicators": ["usd_try", "inflation_rate"],
            "value_ranges": {
                "usd_try": {"min": 1, "max": 100},
                "inflation_rate": {"min": -10, "max": 200},
                "interest_rate": {"min": 0, "max": 100}
            },
            "freshness_hours": 24
        }
    
    def _get_news_rules(self) -> Dict[str, Any]:
        """Get validation rules for news data"""
        return {
            "required_fields": ["title", "url", "published"],
            "min_content_length": 50,
            "max_age_days": 90,
            "valid_languages": ["tr", "en"]
        }
    
    def validate_property_data(self, data: Dict[str, Any]) -> ValidationResult:
        """
        Validate property data
        
        Args:
            data: Property data to validate
            
        Returns:
            ValidationResult
        """
        errors = []
        warnings = []
        rules = self.validation_rules["property"]
        
        # Check required fields
        for field in rules["required_fields"]:
            if field not in data or data[field] is None:
                errors.append(f"Missing required field: {field}")
        
        # Validate price
        if "price" in data and data["price"] is not None:
            price = data["price"]
            if not isinstance(price, (int, float)):
                errors.append("Price must be numeric")
            elif price < rules["price_range"]["min"]:
                warnings.append(f"Price unusually low: {price}")
            elif price > rules["price_range"]["max"]:
                warnings.append(f"Price unusually high: {price}")
        
        # Validate size
        if "size" in data and data["size"] is not None:
            size = data["size"]
            if not isinstance(size, (int, float)):
                errors.append("Size must be numeric")
            elif size < rules["size_range"]["min"]:
                errors.append(f"Size too small: {size}")
            elif size > rules["size_range"]["max"]:
                warnings.append(f"Size unusually large: {size}")
        
        # Validate rooms format
        if "rooms" in data and data["rooms"]:
            rooms = str(data["rooms"])
            if not re.match(rules["patterns"]["rooms"], rooms):
                warnings.append(f"Unusual room format: {rooms}")
        
        # Calculate quality score
        quality_score = self._calculate_property_quality_score(data, errors, warnings)
        
        return ValidationResult(
            is_valid=len(errors) == 0,
            errors=errors,
            warnings=warnings,
            quality_score=quality_score,
            metadata={"data_type": "property"}
        )
    
    def validate_economic_data(self, data: Dict[str, Any]) -> ValidationResult:
        """
        Validate economic data
        
        Args:
            data: Economic data to validate
            
        Returns:
            ValidationResult
        """
        errors = []
        warnings = []
        rules = self.validation_rules["economic"]
        
        # Check required indicators
        for indicator in rules["required_indicators"]:
            if indicator not in data:
                errors.append(f"Missing required indicator: {indicator}")
        
        # Validate value ranges
        for indicator, value in data.items():
            if indicator in rules["value_ranges"]:
                range_rule = rules["value_ranges"][indicator]
                if isinstance(value, dict) and "value" in value:
                    val = value["value"]
                else:
                    val = value
                
                if isinstance(val, (int, float)):
                    if val < range_rule["min"] or val > range_rule["max"]:
                        warnings.append(f"{indicator} out of expected range: {val}")
        
        # Check data freshness
        if "timestamp" in data:
            try:
                timestamp = datetime.fromisoformat(data["timestamp"])
                age_hours = (datetime.now() - timestamp).total_seconds() / 3600
                if age_hours > rules["freshness_hours"]:
                    warnings.append(f"Data is {age_hours:.1f} hours old")
            except:
                warnings.append("Invalid timestamp format")
        
        quality_score = self._calculate_economic_quality_score(data, errors, warnings)
        
        return ValidationResult(
            is_valid=len(errors) == 0,
            errors=errors,
            warnings=warnings,
            quality_score=quality_score,
            metadata={"data_type": "economic"}
        )
    
    def validate_news_data(self, data: List[Dict[str, Any]]) -> ValidationResult:
        """
        Validate news data
        
        Args:
            data: News data to validate
            
        Returns:
            ValidationResult
        """
        errors = []
        warnings = []
        rules = self.validation_rules["news"]
        valid_items = 0
        
        for i, item in enumerate(data):
            # Check required fields
            for field in rules["required_fields"]:
                if field not in item:
                    errors.append(f"Item {i}: Missing {field}")
            
            # Check content length
            content = item.get("summary", "") + item.get("full_text", "")
            if len(content) < rules["min_content_length"]:
                warnings.append(f"Item {i}: Content too short")
            
            # Check age
            if "published" in item:
                try:
                    pub_date = datetime.fromisoformat(item["published"])
                    age_days = (datetime.now() - pub_date).days
                    if age_days > rules["max_age_days"]:
                        warnings.append(f"Item {i}: Too old ({age_days} days)")
                except:
                    warnings.append(f"Item {i}: Invalid date format")
            
            if len([e for e in errors if f"Item {i}" in e]) == 0:
                valid_items += 1
        
        quality_score = valid_items / len(data) if data else 0.0
        
        return ValidationResult(
            is_valid=len(errors) == 0,
            errors=errors,
            warnings=warnings,
            quality_score=quality_score,
            metadata={"data_type": "news", "total_items": len(data), "valid_items": valid_items}
        )
    
    def validate_combined_data(self, data: Dict[str, Any]) -> ValidationResult:
        """
        Validate combined data from multiple sources
        
        Args:
            data: Combined data to validate
            
        Returns:
            ValidationResult
        """
        all_errors = []
        all_warnings = []
        quality_scores = []
        
        # Validate property data if present
        if "properties" in data:
            result = self.validate_property_data(data["properties"])
            all_errors.extend(result.errors)
            all_warnings.extend(result.warnings)
            quality_scores.append(result.quality_score)
        
        # Validate economic data if present
        if "economic" in data:
            result = self.validate_economic_data(data["economic"])
            all_errors.extend(result.errors)
            all_warnings.extend(result.warnings)
            quality_scores.append(result.quality_score)
        
        # Validate news data if present
        if "news" in data:
            result = self.validate_news_data(data["news"])
            all_errors.extend(result.errors)
            all_warnings.extend(result.warnings)
            quality_scores.append(result.quality_score)
        
        overall_quality = sum(quality_scores) / len(quality_scores) if quality_scores else 0.0
        
        return ValidationResult(
            is_valid=len(all_errors) == 0,
            errors=all_errors,
            warnings=all_warnings,
            quality_score=overall_quality,
            metadata={"data_type": "combined", "components": list(data.keys())}
        )
    
    def _calculate_property_quality_score(
        self,
        data: Dict[str, Any],
        errors: List[str],
        warnings: List[str]
    ) -> float:
        """Calculate quality score for property data"""
        score = 1.0
        
        # Deduct for errors
        score -= len(errors) * 0.2
        
        # Deduct for warnings
        score -= len(warnings) * 0.05
        
        # Bonus for complete data
        optional_fields = ["rooms", "building_age", "floor", "features"]
        filled_optional = sum(1 for f in optional_fields if f in data and data[f])
        score += filled_optional * 0.05
        
        # Bonus for images
        if "images" in data and data["images"]:
            score += 0.1
        
        return max(0.0, min(1.0, score))
    
    def _calculate_economic_quality_score(
        self,
        data: Dict[str, Any],
        errors: List[str],
        warnings: List[str]
    ) -> float:
        """Calculate quality score for economic data"""
        score = 1.0
        
        # Deduct for errors
        score -= len(errors) * 0.3
        
        # Deduct for warnings
        score -= len(warnings) * 0.1
        
        # Bonus for comprehensive data
        if len(data) > 10:
            score += 0.1
        
        # Check data freshness
        if "timestamp" in data:
            try:
                timestamp = datetime.fromisoformat(data["timestamp"])
                age_hours = (datetime.now() - timestamp).total_seconds() / 3600
                if age_hours < 1:
                    score += 0.1
                elif age_hours > 24:
                    score -= 0.1
            except:
                pass
        
        return max(0.0, min(1.0, score))
