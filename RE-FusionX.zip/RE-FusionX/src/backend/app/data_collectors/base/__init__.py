"""Base collector components"""

# Import only base classes to avoid circular imports
from .base_collector import BaseCollector, CollectorConfig, CollectionResult, DataSource

# Import manager separately to be added to __all__ only when needed
__all__ = [
    "BaseCollector",
    "CollectorConfig",
    "CollectionResult",
    "DataSource",
    "CollectorManager",
    "DataValidator"
]
