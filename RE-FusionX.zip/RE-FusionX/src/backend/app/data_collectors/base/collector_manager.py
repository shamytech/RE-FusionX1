"""
Collector Manager - Central Data Collection System
==================================================
Manages all data collectors and provides unified interface
"""

import asyncio
from typing import Dict, Any, List, Optional, Union
from datetime import datetime
from pathlib import Path
import json

from app.data_collectors.base.base_collector import CollectorConfig, CollectionResult, DataSource
from app.data_collectors.real_estate.property_scraper import PropertyScraper
from app.data_collectors.smart_collectors.ai_scraper import AIScraper
from app.data_collectors.economic.api_clients import EconomicDataAPI
from app.data_collectors.economic.snapshot import EconomicSnapshot
from app.data_collectors.market_intelligence.news_collector import NewsCollector
from app.data_collectors.market_intelligence.trend_analyzer import TrendAnalyzer
from app.data_collectors.market_intelligence.market_reports import MarketReportsCollector
from app.core.storage.parquet_manager import ParquetManager
from app.core.storage.search_engine import SearchEngine
from app.core.storage.quality_monitor import QualityMonitor
from app.core.storage.integration import StorageIntegration
from app.core.storage.unified_cache import CacheType, get_cache
from app.core.logging import logger
from app.core.config import settings

class CollectorManager:
    """
    Central manager for all data collection operations
    """
    def __init__(self):
        """Initialize collector manager"""
        self.collectors = {}
        self.results_cache = {}
        
        # Check if AI scraping is enabled
        self.use_ai_scraping = getattr(settings, 'USE_AI_SCRAPING', True) if hasattr(settings, 'USE_AI_SCRAPING') else True
        
        self._storage = None
        self._cache = None
        
        # Initialize AI Scraper if enabled
        self.ai_scraper = None
        if self.use_ai_scraping:
            try:
                self.ai_scraper = AIScraper()
                logger.info("✅ AI Scraper initialized successfully")
            except Exception as e:
                logger.warning(f"⚠️ AI Scraper initialization failed: {e}. Falling back to traditional scrapers")
                self.use_ai_scraping = False
                        
        # Initialize paths
        self.data_dir = Path(settings.DATA_DIR) if hasattr(settings, 'DATA_DIR') else Path("backend/data")
        self.outputs_dir = self.data_dir / "outputs"
        self.cache_dir = self.data_dir / "collector_cache"
        
        # Ensure directories exist
        self.outputs_dir.mkdir(parents=True, exist_ok=True)
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        
        # Initialize components
        self.output_manager = ParquetManager(self.outputs_dir)
        self.cache_manager = CacheManager(self.cache_dir)
        self.data_store = DataStore(self.data_dir)
        self.search_client = None  # Lazy initialization
        self.quality_monitor = QualityMonitor(self.data_dir)
        
        # Initialize collectors
        self.initialize_collectors()
        
        # ✅ أضف هذا السطر الجديد
        self._auto_discover_sources()
        
        logger.info(f"CollectorManager initialized with {len(self.collectors)} collectors | AI Scraping: {'Enabled' if self.use_ai_scraping else 'Disabled'}")

    @property
    def storage(self):
        """Lazy load storage"""
        if self._storage is None:
            from app.core.storage.integration import StorageIntegration
            self._storage = StorageIntegration.get_storage()
        return self._storage
    
    @property
    def cache(self):
        """Lazy load cache"""
        if self._cache is None:
            from app.core.storage.integration import StorageIntegration
            self._cache = StorageIntegration.get_cache()
        return self._cache
       
    def initialize_collectors(self):
        """Initialize all data collectors"""
        
        # If AI Scraper is available and enabled, use it as primary collector
        if self.use_ai_scraping and self.ai_scraper:
            # Register AI Scraper for all property sources
            self.collectors["ai_properties"] = self.ai_scraper
            self.collectors["ai_news"] = self.ai_scraper
            self.collectors["ai_market_reports"] = self.ai_scraper
            logger.info("🤖 AI Scraper registered as primary collector")
        
        # Economic data collectors (not affected by AI scraping)
        try:
            self.collectors["economic"] = EconomicDataAPI()
            self.collectors["economic_snapshot"] = EconomicSnapshot()
            logger.info("Initialized economic data collectors")
        except Exception as e:
            logger.error(f"Failed to initialize economic collectors: {e}")
        
        # Market intelligence collectors (can use AI if enabled)
        try:
            if not self.use_ai_scraping or not self.ai_scraper:
                # Use traditional collectors if AI is not available
                self.collectors["news"] = NewsCollector()
                self.collectors["market_reports"] = MarketReportsCollector()
            
            # Trend analyzer always needed
            self.collectors["trend_analyzer"] = TrendAnalyzer()
            logger.info("Initialized market intelligence collectors")
        except Exception as e:
            logger.error(f"Failed to initialize market intelligence collectors: {e}")

    def _auto_discover_sources(self):
        """Auto-discover and load available sources"""
        try:
            from app.data_collectors.base.source_registry import SourceRegistry
            
            # Auto-discover sources
            SourceRegistry.auto_discover()
            
            # Load discovered sources
            for source_name in SourceRegistry.get_available_sources():
                if source_name not in self.collectors:  # Don't override existing
                    try:
                        instance = SourceRegistry.create_instance(source_name)
                        if instance:
                            self.collectors[source_name] = instance
                            logger.info(f"✅ Auto-loaded source: {source_name}")
                    except Exception as e:
                        logger.warning(f"⚠️ Could not instantiate {source_name}: {e}")
                        
            logger.info(f"📊 Total sources discovered: {len(SourceRegistry.get_available_sources())}")
            
        except ImportError as e:
            logger.warning(f"SourceRegistry not available: {e}")
        except Exception as e:
            logger.error(f"Error in auto-discovery: {e}")

    async def collect_comprehensive_data( self, location: str, property_type: Optional[str] = None, property_specs: Optional[Dict[str, Any]] = None, use_cache: bool = True, save_outputs: bool = True, prefer_ai: bool = None ) -> Dict[str, Any]:
        """
        Collect comprehensive data for property analysis
        
        Args:
            location: Target location
            property_type: Type of property
            property_specs: Specific property characteristics
            use_cache: Whether to use cached data
            save_outputs: Whether to save outputs to Parquet
            prefer_ai: Override AI preference (None uses default)
            
        Returns:
            Comprehensive data package
        """
        # Determine if we should use AI for this collection
        use_ai = prefer_ai if prefer_ai is not None else self.use_ai_scraping
        
        logger.info(f"Starting comprehensive data collection for {location} | Using AI: {use_ai and self.ai_scraper is not None}")
        
        # Check cache first if enabled
        if use_cache:
            cache_key = self.cache_manager.generate_cache_key(
                "comprehensive",
                {"location": location, "property_type": property_type, "specs": property_specs}
            )
            
            cached_data = await self.cache_manager.get(cache_key, "comprehensive")
            if cached_data:
                logger.info(f"Using cached data for {location}")
                return cached_data
        
        # Check local Parquet files for existing data
        if use_cache:
            local_data = await self._check_local_data(location, property_type)
            if local_data:
                return local_data
        
        # Prepare results structure
        results = {
            "timestamp": datetime.now().isoformat(),
            "location": location,
            "property_type": property_type,
            "property_specs": property_specs,
            "data": {},
            "source": "ai_collection" if use_ai else "web_collection"
        }
        
        # Prepare filters
        filters = self._prepare_filters(property_specs)
        
        # Collect data using AI or traditional methods
        if use_ai and self.ai_scraper:
            # Use AI Scraper for all data collection
            results["data"] = await self._collect_with_ai(location, property_type, filters)
        else:
            # Use traditional collectors
            results["data"] = await self._collect_traditional(location, property_type, filters)
        
        # Always collect economic data (not affected by AI preference)
        economic_data = await self._collect_economic_data()
        if economic_data.get("success"):
            results["data"]["economic"] = economic_data.get("data")
        
        # Generate insights
        results["insights"] = self._generate_insights(results["data"])
        
        # Calculate data quality score
        results["quality_score"] = self._calculate_overall_quality(results["data"])
        
        # Save outputs if enabled
        if save_outputs:
            await self._save_all_outputs(results["data"], location)
        
        # Save to cache if enabled
        if use_cache:
            await self.cache_manager.set(
                cache_key,
                results,
                "comprehensive",
                metadata={"location": location, "timestamp": datetime.now().isoformat()}
            )
        
        logger.info(f"Comprehensive data collection completed with quality score: {results['quality_score']:.2f}")
        
        return results
    
    async def _collect_with_ai(self,location: str, property_type: Optional[str],filters: Dict[str, Any] ) -> Dict[str, Any]:
        """
        Collect all data using AI Scraper
        
        Args:
            location: Target location
            property_type: Type of property
            filters: Search filters
            
        Returns:
            Collected data dictionary
        """
        logger.info(f"🤖 Using AI Scraper for {location}")
        
        data = {}
        
        try:
            # 1. Collect property data with AI
            logger.info("Collecting properties with AI...")
            
            # Build search query for AI
            search_query = f"real estate properties for sale in {location}"
            if property_type:
                search_query += f" type:{property_type}"
            if filters.get("min_price") and filters.get("max_price"):
                search_query += f" price:{filters['min_price']}-{filters['max_price']}"
            if filters.get("rooms"):
                search_query += f" rooms:{filters['rooms']}"
            
            # Search and extract properties
            properties = await self.ai_scraper.search_and_extract(
                query=search_query,
                max_results=50
            )
            
            # Extract detailed information for each property
            detailed_properties = []
            for prop in properties[:20]:  # Limit to 20 for detailed extraction
                if prop.get("url"):
                    detailed = await self.ai_scraper.extract_property_data(prop["url"])
                    if detailed:
                        detailed.update(prop)  # Merge with search result
                        detailed_properties.append(detailed)
            
            if detailed_properties:
                data["properties"] = {
                    "all_properties": detailed_properties,
                    "total_count": len(detailed_properties),
                    "source": "ai_extraction"
                }
                
                # Analyze market from properties
                data["market_analysis"] = self._analyze_market_from_properties(data["properties"])
            
            # 2. Collect market news with AI
            logger.info("Collecting market news with AI...")
            
            news_query = f"real estate market news {location} Turkey latest"
            news_results = await self.ai_scraper.search_and_extract(
                query=news_query,
                max_results=30
            )
            
            # Extract full content for top news
            detailed_news = []
            for article in news_results[:10]:
                if article.get("url"):
                    content = await self.ai_scraper.extract_news_content(article["url"])
                    if content:
                        content.update(article)
                        detailed_news.append(content)
            
            if detailed_news:
                data["market_intelligence"] = {
                    "articles": detailed_news,
                    "total_collected": len(detailed_news),
                    "source": "ai_extraction"
                }
                
                # Analyze sentiment
                if self.collectors.get("trend_analyzer"):
                    sentiment_analysis = self.collectors["trend_analyzer"].analyze_market_sentiment(
                        detailed_news,
                        period_days=30
                    )
                    data["market_intelligence"]["sentiment_analysis"] = sentiment_analysis
            
            # 3. Collect market reports with AI
            logger.info("Collecting market reports with AI...")
            
            report_query = f"real estate market report {location} Turkey statistics analysis"
            reports = await self.ai_scraper.search_and_extract(
                query=report_query,
                max_results=10
            )
            
            # Extract market data from reports
            for report in reports[:5]:
                if report.get("url"):
                    market_data = await self.ai_scraper.extract_market_data(report["url"])
                    if market_data:
                        if "market_reports" not in data:
                            data["market_reports"] = []
                        data["market_reports"].append(market_data)
            
            logger.info(f"✅ AI collection completed: {len(data.get('properties', {}).get('all_properties', []))} properties, {len(data.get('market_intelligence', {}).get('articles', []))} news articles")
            
        except Exception as e:
            logger.error(f"AI collection failed: {e}. Falling back to traditional methods")
            # Fallback to traditional collection
            return await self._collect_traditional(location, property_type, filters)
        
        return data
    
    async def _collect_traditional( self, location: str,  property_type: Optional[str], filters: Dict[str, Any]) -> Dict[str, Any]:
        """
        Collect data using traditional scrapers
        
        Args:
            location: Target location
            property_type: Type of property
            filters: Search filters
            
        Returns:
            Collected data dictionary
        """
        logger.info(f"📊 Using traditional scrapers for {location}")
        
        data = {}
        
        # ✅ التعديل هنا - استخدم المصادر المكتشفة تلقائياً
        property_tasks = []
        
        # جمع من كل المصادر المتاحة
        available_sources = ["emlakjet", "sahibinden", "hurriyetemlak", "zingat"]
        
        for source_name in available_sources:
            if source_name in self.collectors:
                # تحقق من نوع المجمع
                collector = self.collectors[source_name]
                
                # إذا كان لديه method collect، استخدمه
                if hasattr(collector, 'collect'):
                    task = self._collect_from_source(
                        source_name,
                        location,
                        property_type,
                        filters
                    )
                    property_tasks.append(task)
                    logger.info(f"Added {source_name} to collection tasks")
        
        # Collect market intelligence
        market_task = self._collect_market_intelligence(location)
        
        # Execute all tasks concurrently
        all_tasks = property_tasks + [market_task]
        
        if not property_tasks:
            logger.warning("No property collectors available!")
            return data
        
        task_results = await asyncio.gather(*all_tasks, return_exceptions=True)
        
        # Process property results
        property_results = []
        for i, result in enumerate(task_results[:len(property_tasks)]):
            if not isinstance(result, Exception):
                if isinstance(result, dict) and result.get("success"):
                    property_results.append(result)
                elif hasattr(result, 'success') and result.success:
                    property_results.append(result.data)
        
        # Combine property data
        if property_results:
            combined_properties = self._combine_property_data(property_results)
            data["properties"] = combined_properties
            data["market_analysis"] = self._analyze_market_from_properties(combined_properties)
        
        # Add market intelligence
        if len(task_results) > len(property_tasks):
            market_result = task_results[len(property_tasks)]
            if not isinstance(market_result, Exception):
                if hasattr(market_result, 'success') and market_result.success:
                    data["market_intelligence"] = market_result.data
        
        return data
    
    async def _collect_from_source(self, source_name: str, location: str, property_type: Optional[str],filters: Dict[str, Any]) -> Dict[str, Any]:
        """
        Collect from a specific source using its collect method
        
        Args:
            source_name: Name of the source
            location: Location to search
            property_type: Type of property
            filters: Search filters
            
        Returns:
            Collection result
        """
        try:
            collector = self.collectors.get(source_name)
            if not collector:
                logger.warning(f"Collector not found: {source_name}")
                return {"success": False, "error": f"Collector not found: {source_name}"}
            
            # Call collect method with appropriate parameters
            result = await collector.collect(
                location=location,
                property_type=property_type or "daire",
                filters=filters,
                max_pages=3  # Limit pages for performance
            )
            
            return result
            
        except Exception as e:
            logger.error(f"Collection failed for {source_name}: {e}")
            return {"success": False, "error": str(e), "source": source_name}

    async def _check_local_data( self,  location: str, property_type: Optional[str]) -> Optional[Dict[str, Any]]:
        """
        Check and return local data if fresh enough
        
        Args:
            location: Location to check
            property_type: Property type
            
        Returns:
            Local data if fresh, None otherwise
        """
        try:
            search_client = self.get_search_client()
            local_properties = search_client.search_properties(
                filters={"location": location, "property_type": property_type},
                limit=100
            )
            
            if not local_properties.empty:
                logger.info(f"Found {len(local_properties)} properties in local storage")
                
                # Check freshness
                if 'scraped_at' in local_properties.columns:
                    import pandas as pd
                    latest_date = pd.to_datetime(local_properties['scraped_at']).max()
                    days_old = (datetime.now() - latest_date).days
                    
                    if days_old < 7:  # Data is fresh enough
                        logger.info(f"Using local data (age: {days_old} days)")
                        
                        # Get market analysis from local data
                        market_analysis = search_client.get_market_analysis(location, days_back=30)
                        
                        return {
                            "timestamp": datetime.now().isoformat(),
                            "location": location,
                            "property_type": property_type,
                            "data": {
                                "properties": {
                                    "all_properties": local_properties.to_dict('records'),
                                    "total_count": len(local_properties)
                                },
                                "market_analysis": market_analysis
                            },
                            "source": "local_storage",
                            "quality_score": 0.9
                        }
        except Exception as e:
            logger.warning(f"Failed to search local data: {e}")
        
        return None
    
    async def _save_all_outputs(self,data: Dict[str, Any],location: str ):
        """
        Save all collected data to outputs
        
        Args:
            data: Collected data
            location: Location identifier
        """
        try:
            # Save properties
            if data.get("properties", {}).get("all_properties"):
                properties = data["properties"]["all_properties"]
                output_path = self.output_manager.save_properties(properties, location)
                saved_count = self.data_store.save_properties(properties)
                logger.info(f"Saved {saved_count} properties to outputs")
            
            # Save market data
            if data.get("economic", {}).get("indicators"):
                market_data_list = self._convert_economic_to_list(
                    data["economic"]["indicators"],
                    location
                )
                if market_data_list:
                    self.output_manager.save_market_data(market_data_list, "indicators")
                    self.data_store.save_market_data(market_data_list)
                    logger.info(f"Saved {len(market_data_list)} market indicators")
            
            # Save news
            if data.get("market_intelligence", {}).get("articles"):
                articles = data["market_intelligence"]["articles"]
                self.output_manager.save_news(articles)
                self.data_store.save_news(articles)
                logger.info(f"Saved {len(articles)} news articles")
                
        except Exception as e:
            logger.error(f"Failed to save outputs: {e}")
    
    def _convert_economic_to_list(self,indicators: Dict[str, Any],location: str) -> List[Dict[str, Any]]:
        """Convert economic indicators to list format"""
        market_data_list = []
        
        for indicator_name, indicator_data in indicators.items():
            if hasattr(indicator_data, 'iterrows'):  # If it's a DataFrame
                for _, row in indicator_data.iterrows():
                    market_data_list.append({
                        "indicator_name": indicator_name,
                        "value": row.get("value", 0),
                        "date": row.name if isinstance(row.name, datetime) else datetime.now(),
                        "location": location
                    })
            elif isinstance(indicator_data, dict):
                market_data_list.append({
                    "indicator_name": indicator_name,
                    "value": indicator_data.get("value", 0),
                    "date": datetime.now(),
                    "location": location
                })
        
        return market_data_list
    
    def get_search_client(self) -> SearchEngine:
        """Get or initialize search client"""
        if not self.search_client:
            self.search_client = SearchEngine(self.data_dir)
        return self.search_client

    async def _collect_property_data( self, source: str,  location: str,   property_type: str, filters: Dict[str, Any]) -> CollectionResult:
        """Collect property data from a specific source"""
        try:
            collector = self.collectors.get(source)
            if not collector:
                logger.warning(f"Collector not found for source: {source}")
                return CollectionResult(success=False, error=f"Collector not found: {source}")
            
            result = await collector.collect(
                location=location,
                property_type=property_type or "daire",
                filters=filters,
                find_similar=True
            )
            return result
            
        except Exception as e:
            logger.error(f"Property collection failed for {source}: {e}")
            return CollectionResult(success=False, error=str(e))
    
    async def _collect_economic_data(self) -> Dict[str, Any]:
        """Collect economic indicators"""
        try:
            collector = self.collectors.get("economic")
            if not collector:
                return {"success": False, "error": "Economic collector not available"}
            
            # Get comprehensive Turkish data
            economic_data = await asyncio.to_thread(
                collector.get_comprehensive_turkish_data
            )
            
            # Get current snapshot
            snapshot_collector = self.collectors.get("economic_snapshot")
            if snapshot_collector:
                snapshot_data = snapshot_collector.get_current_economic_snapshot()
            else:
                snapshot_data = None
            
            return {
                "success": True,
                "data": {
                    "indicators": economic_data,
                    "snapshot": snapshot_data
                }
            }
            
        except Exception as e:
            logger.error(f"Economic data collection failed: {e}")
            return {"success": False, "error": str(e)}
    
    async def _collect_market_intelligence(self, location: str) -> CollectionResult:
        """Collect market intelligence and news"""
        try:
            news_collector = self.collectors.get("news")
            if not news_collector:
                return CollectionResult(success=False, error="News collector not available")
            
            result = await news_collector.collect(
                news_type="all",
                days_back=30
            )
            
            # Analyze trends if available
            if result.success and result.data.get("articles"):
                trend_analyzer = self.collectors.get("trend_analyzer")
                if trend_analyzer:
                    # Analyze news sentiment
                    sentiment_analysis = trend_analyzer.analyze_market_sentiment(
                        result.data["articles"],
                        period_days=30
                    )
                    result.data["sentiment_analysis"] = sentiment_analysis
            
            return result
            
        except Exception as e:
            logger.error(f"Market intelligence collection failed: {e}")
            return CollectionResult(success=False, error=str(e))
    
    def _prepare_filters(self, property_specs: Optional[Dict[str, Any]]) -> Dict[str, Any]:
        """Prepare search filters from property specifications"""
        if not property_specs:
            return {}
        
        filters = {}
        
        # Map specifications to filter parameters
        if "size" in property_specs:
            size = property_specs["size"]
            filters["min_size"] = size * 0.8  # 20% tolerance
            filters["max_size"] = size * 1.2
        
        if "rooms" in property_specs:
            filters["rooms"] = property_specs["rooms"]
        
        if "price_range" in property_specs:
            filters["min_price"] = property_specs["price_range"].get("min")
            filters["max_price"] = property_specs["price_range"].get("max")
        
        if "building_age" in property_specs:
            filters["max_age"] = property_specs["building_age"]
        
        if "floor" in property_specs:
            filters["floor"] = property_specs["floor"]
        
        return filters
    
    def _combine_property_data(self, property_results: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Combine property data from multiple sources"""
        combined = {
            "all_properties": [],
            "similar_properties": [],
            "by_source": {},
            "total_count": 0
        }
        
        for result in property_results:
            if isinstance(result, dict):
                # ✅ تحسين معالجة النتائج من المصادر المختلفة
                source = result.get("source", "unknown")
                
                # Handle new format from our scrapers
                if "properties" in result:
                    if isinstance(result["properties"], list):
                        combined["all_properties"].extend(result["properties"])
                        combined["by_source"][source] = {
                            "count": len(result["properties"]),
                            "source": source
                        }
                    elif isinstance(result["properties"], dict) and "all_properties" in result["properties"]:
                        combined["all_properties"].extend(result["properties"]["all_properties"])
                        combined["by_source"][source] = {
                            "count": len(result["properties"]["all_properties"]),
                            "source": source
                        }
                
                # Handle properties at root level (new scrapers format)
                elif "total_properties" in result and isinstance(result.get("properties"), list):
                    combined["all_properties"].extend(result["properties"])
                    combined["by_source"][source] = {
                        "count": result["total_properties"],
                        "source": source
                    }
                
                if "similar_properties" in result:
                    combined["similar_properties"].extend(result["similar_properties"])
        
        # Remove duplicates based on listing_id, URL or title
        seen = set()
        unique_properties = []
        
        for prop in combined["all_properties"]:
            # Create unique identifier - prioritize listing_id
            identifier = (
                prop.get("listing_id") or 
                prop.get("url") or 
                f"{prop.get('title', '')}_{prop.get('price', '')}"
            )
            
            if identifier and identifier not in seen:
                seen.add(identifier)
                unique_properties.append(prop)
        
        combined["all_properties"] = unique_properties
        combined["total_count"] = len(unique_properties)
        
        # Log sources summary
        sources_summary = ", ".join([
            f"{src}: {info['count']}" 
            for src, info in combined["by_source"].items()
        ])
        logger.info(f"Combined {combined['total_count']} unique properties from sources: {sources_summary}")
        
        return combined

    def _analyze_market_from_properties(self, property_data: Dict[str, Any]) -> Dict[str, Any]:
        """Analyze market conditions from collected properties"""
        analysis = {
            "sample_size": property_data.get("total_count", 0),
            "price_analysis": {},
            "size_analysis": {},
            "price_per_sqm": {},
            "room_distribution": {},
            "market_depth": "unknown"
        }
        
        properties = property_data.get("all_properties", [])
        
        if not properties:
            return analysis
        
        # Extract metrics
        prices = [p.get("price") for p in properties if p.get("price")]
        sizes = [p.get("size") or p.get("size_sqm") for p in properties if p.get("size") or p.get("size_sqm")]
        rooms = [p.get("rooms") for p in properties if p.get("rooms")]
        
        # Price analysis
        if prices:
            analysis["price_analysis"] = {
                "min": min(prices),
                "max": max(prices),
                "average": sum(prices) / len(prices),
                "median": sorted(prices)[len(prices) // 2],
                "std_dev": self._calculate_std_dev(prices)
            }
        
        # Size analysis
        if sizes:
            analysis["size_analysis"] = {
                "min": min(sizes),
                "max": max(sizes),
                "average": sum(sizes) / len(sizes),
                "median": sorted(sizes)[len(sizes) // 2]
            }
        
        # Price per square meter
        price_per_sqm = []
        for prop in properties:
            price = prop.get("price")
            size = prop.get("size") or prop.get("size_sqm")
            
            if price and size and size > 0:
                price_per_sqm.append(price / size)
        
        if price_per_sqm:
            analysis["price_per_sqm"] = {
                "min": min(price_per_sqm),
                "max": max(price_per_sqm),
                "average": sum(price_per_sqm) / len(price_per_sqm),
                "median": sorted(price_per_sqm)[len(price_per_sqm) // 2]
            }
        
        # Room distribution
        if rooms:
            from collections import Counter
            room_counts = Counter(rooms)
            analysis["room_distribution"] = dict(room_counts)
        
        # Market depth assessment
        if len(properties) > 100:
            analysis["market_depth"] = "high"
        elif len(properties) > 50:
            analysis["market_depth"] = "moderate"
        elif len(properties) > 20:
            analysis["market_depth"] = "low"
        else:
            analysis["market_depth"] = "very_low"
        
        return analysis
    
    def _calculate_std_dev(self, values: List[float]) -> float:
        """Calculate standard deviation"""
        if not values:
            return 0.0
        
        mean = sum(values) / len(values)
        variance = sum((x - mean) ** 2 for x in values) / len(values)
        return variance ** 0.5
    
    def _generate_insights(self, data: Dict[str, Any]) -> List[str]:
        """Generate insights from collected data"""
        insights = []
        
        # Property market insights
        if "market_analysis" in data:
            market = data["market_analysis"]
            
            if market.get("price_per_sqm", {}).get("average"):
                avg_sqm = market["price_per_sqm"]["average"]
                insights.append(f"Average price per square meter: {avg_sqm:,.0f} TL")
            
            if market.get("market_depth") == "high":
                insights.append("High market liquidity with many available properties")
            elif market.get("market_depth") == "low":
                insights.append("Limited inventory may indicate seller's market")
            
            if market.get("room_distribution"):
                most_common = max(market["room_distribution"].items(), key=lambda x: x[1])
                insights.append(f"Most common property type: {most_common[0]} ({most_common[1]} listings)")
        
        # Economic insights
        if "economic" in data and "snapshot" in data["economic"]:
            snapshot = data["economic"]["snapshot"]
            
            if snapshot and "analysis" in snapshot:
                analysis = snapshot["analysis"]
                
                if analysis.get("overall_assessment") == "positive":
                    insights.append("Favorable economic conditions for real estate investment")
                elif analysis.get("overall_assessment") == "cautious":
                    insights.append("Economic indicators suggest careful market evaluation")
                
                if analysis.get("currency_stability") == "weak":
                    insights.append("Weak currency may deter foreign investment but create local opportunities")
                
                if analysis.get("inflation_environment") == "high":
                    insights.append("High inflation environment - real estate as inflation hedge")
        
        # Market intelligence insights
        if "market_intelligence" in data:
            intel = data["market_intelligence"]
            
            if intel and "sentiment_analysis" in intel:
                sentiment = intel["sentiment_analysis"]
                
                if sentiment.get("overall_sentiment") == "bullish":
                    insights.append("Market sentiment is positive based on recent news")
                elif sentiment.get("overall_sentiment") == "bearish":
                    insights.append("Negative market sentiment detected in recent news")
            
            if intel and "statistics" in intel:
                stats = intel["statistics"]
                
                if stats.get("by_sentiment", {}).get("positive", 0) > stats.get("by_sentiment", {}).get("negative", 0) * 2:
                    insights.append("Strong positive news coverage for real estate sector")
        
        return insights
    
    def _calculate_overall_quality(self, data: Dict[str, Any]) -> float:
        """Calculate overall data quality score"""
        scores = []
        
        # Property data quality
        if "properties" in data:
            prop_count = data["properties"].get("total_count", 0)
            if prop_count > 50:
                scores.append(1.0)
            elif prop_count > 20:
                scores.append(0.7)
            elif prop_count > 10:
                scores.append(0.5)
            else:
                scores.append(0.3)
        
        # Economic data quality
        if "economic" in data:
            if data["economic"] and "indicators" in data["economic"]:
                # Check how many indicators we have
                indicator_count = len(data["economic"]["indicators"]) if isinstance(data["economic"]["indicators"], dict) else 0
                if indicator_count > 5:
                    scores.append(0.9)
                elif indicator_count > 2:
                    scores.append(0.6)
                else:
                    scores.append(0.3)
        
        # Market intelligence quality
        if "market_intelligence" in data:
            if data["market_intelligence"] and data["market_intelligence"].get("articles"):
                article_count = len(data["market_intelligence"]["articles"])
                if article_count > 20:
                    scores.append(0.8)
                elif article_count > 10:
                    scores.append(0.6)
                else:
                    scores.append(0.4)
        
        # Calculate weighted average
        if scores:
            return sum(scores) / len(scores)
        
        return 0.0
    
    async def update_data_if_needed(self) -> Dict[str, Any]:
        """Check data quality and update if needed"""
        logger.info("Checking if data update is needed...")
        
        # Check data quality
        quality_report = self.quality_monitor.check_data_quality()
        
        updates_performed = []
        
        # Check properties
        if quality_report.get("properties", {}).get("freshness_score", 0) < 0.5:
            logger.info("Property data is stale, updating...")
            
            for city in ["Istanbul", "Ankara", "Izmir"]:
                try:
                    result = await self.collect_comprehensive_data(
                        location=city,
                        property_type="daire",
                        use_cache=False,
                        save_outputs=True
                    )
                    
                    if result.get("quality_score", 0) > 0.5:
                        updates_performed.append(f"Updated {city} properties")
                        
                except Exception as e:
                    logger.error(f"Failed to update {city}: {e}")
        
        # Check market data
        if quality_report.get("market_data", {}).get("completeness_score", 0) < 0.5:
            logger.info("Market data incomplete, updating...")
            
            try:
                economic_data = await self._collect_economic_data()
                if economic_data.get("success"):
                    updates_performed.append("Updated economic indicators")
            except Exception as e:
                logger.error(f"Failed to update economic data: {e}")
        
        # Check news
        if quality_report.get("news", {}).get("freshness_score", 0) < 0.5:
            logger.info("News data is stale, updating...")
            
            try:
                news_result = await self._collect_market_intelligence("Turkey")
                if news_result.success:
                    updates_performed.append("Updated news articles")
            except Exception as e:
                logger.error(f"Failed to update news: {e}")
        
        return {
            "timestamp": datetime.now().isoformat(),
            "updates_performed": updates_performed,
            "quality_before": quality_report,
            "quality_after": self.quality_monitor.check_data_quality() if updates_performed else quality_report
        }
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get comprehensive statistics"""
        stats = {
            "collectors": {
                "total": len(self.collectors),
                "active": sum(1 for c in self.collectors.values() if c),
                "types": list(self.collectors.keys())
            },
            "cache": self.cache_manager.get_cache_stats(),
            "storage": self.data_store.get_statistics(),
            "outputs": self.output_manager.get_statistics() if self.output_manager else {},
            "last_update": datetime.now().isoformat()
        }
        
        return stats
