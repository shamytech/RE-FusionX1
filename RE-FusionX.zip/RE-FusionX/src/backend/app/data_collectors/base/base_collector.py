"""
Base Collector Framework for RE-FusionX
========================================
Advanced data collection infrastructure with multi-source support
"""

from abc import ABC, abstractmethod
from typing import Dict, Any, List, Optional, Union
from datetime import datetime, timedelta
from pathlib import Path
import hashlib
import json
import asyncio
from enum import Enum
from dataclasses import dataclass, field
import aiohttp
from bs4 import BeautifulSoup
import pandas as pd

from app.core.logging import logger
from app.core.config import settings


class DataSource(Enum):
    """Data source types"""
    SAHIBINDEN = "sahibinden"
    EMLAKJET = "emlakjet"
    HURRIYETEMLAK = "hurriyetemlak"
    ZINGAT = "zingat"
    TCMB = "tcmb"
    FRED = "fred"
    WORLDBANK = "worldbank"
    NEWS = "news"
    CUSTOM = "custom"


@dataclass
class CollectorConfig:
    """Configuration for data collectors"""
    source: DataSource
    enabled: bool = True
    cache_duration: timedelta = field(default_factory=lambda: timedelta(hours=6))
    rate_limit: int = 10  # requests per minute
    retry_attempts: int = 3
    timeout: int = 30
    use_proxy: bool = False
    use_ai_extraction: bool = False
    headers: Dict[str, str] = field(default_factory=lambda: {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
        "Accept": "text/html,application/json",
        "Accept-Language": "tr-TR,tr;q=0.9,en;q=0.8"
    })


@dataclass
class CollectionResult:
    """Result from data collection"""
    success: bool
    data: Optional[Any] = None
    error: Optional[str] = None
    source: Optional[DataSource] = None
    timestamp: datetime = field(default_factory=datetime.now)
    metadata: Dict[str, Any] = field(default_factory=dict)
    quality_score: float = 0.0


class BaseCollector(ABC):
    """
    Abstract base class for all data collectors
    """
    
    def __init__(self, config: CollectorConfig):
        """
        Initialize base collector
        
        Args:
            config: Collector configuration
        """
        self.config = config
        self.session: Optional[aiohttp.ClientSession] = None
        self.cache_dir = Path(settings.DATA_DIR) / "collector_cache" / config.source.value
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        
        # Rate limiting
        self._rate_limiter = asyncio.Semaphore(config.rate_limit)
        self._last_request_time = datetime.now()
        
        # Statistics
        self.stats = {
            "total_requests": 0,
            "successful_requests": 0,
            "failed_requests": 0,
            "cache_hits": 0,
            "total_data_points": 0,
            "average_response_time": 0.0
        }
    
    async def __aenter__(self):
        """Async context manager entry"""
        self.session = aiohttp.ClientSession(
            headers=self.config.headers,
            timeout=aiohttp.ClientTimeout(total=self.config.timeout)
        )
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit"""
        if self.session:
            await self.session.close()
    
    @abstractmethod
    async def collect(self, **kwargs) -> CollectionResult:
        """
        Collect data from source
        
        Returns:
            CollectionResult with data or error
        """
        pass
    
    @abstractmethod
    async def validate_data(self, data: Any) -> bool:
        """
        Validate collected data
        
        Args:
            data: Data to validate
            
        Returns:
            True if valid
        """
        pass
    
    async def fetch_with_retry(self, url: str, **kwargs) -> Optional[str]:
        """
        Fetch URL with retry logic
        
        Args:
            url: URL to fetch
            **kwargs: Additional request parameters
            
        Returns:
            Response text or None
        """
        for attempt in range(self.config.retry_attempts):
            try:
                async with self._rate_limiter:
                    # Rate limiting
                    await self._apply_rate_limit()
                    
                    if not self.session:
                        self.session = aiohttp.ClientSession(headers=self.config.headers)
                    
                    async with self.session.get(url, **kwargs) as response:
                        if response.status == 200:
                            self.stats["successful_requests"] += 1
                            return await response.text()
                        elif response.status == 429:  # Too many requests
                            wait_time = (attempt + 1) * 5
                            logger.warning(f"Rate limited, waiting {wait_time}s")
                            await asyncio.sleep(wait_time)
                        else:
                            logger.warning(f"HTTP {response.status} for {url}")
                            
            except asyncio.TimeoutError:
                logger.error(f"Timeout on attempt {attempt + 1} for {url}")
            except Exception as e:
                logger.error(f"Error on attempt {attempt + 1}: {e}")
            
            if attempt < self.config.retry_attempts - 1:
                await asyncio.sleep(2 ** attempt)  # Exponential backoff
        
        self.stats["failed_requests"] += 1
        return None
    
    async def _apply_rate_limit(self):
        """Apply rate limiting between requests"""
        elapsed = (datetime.now() - self._last_request_time).total_seconds()
        min_interval = 60.0 / self.config.rate_limit  # Convert to seconds between requests
        
        if elapsed < min_interval:
            await asyncio.sleep(min_interval - elapsed)
        
        self._last_request_time = datetime.now()
    
    def get_cache_key(self, **kwargs) -> str:
        """
        Generate cache key from parameters
        
        Args:
            **kwargs: Parameters to hash
            
        Returns:
            Cache key
        """
        key_str = json.dumps(kwargs, sort_keys=True)
        return hashlib.md5(key_str.encode()).hexdigest()
    
    async def get_cached_data(self, cache_key: str) -> Optional[Any]:
        """
        Get data from cache
        
        Args:
            cache_key: Cache key
            
        Returns:
            Cached data or None
        """
        cache_file = self.cache_dir / f"{cache_key}.json"
        
        if cache_file.exists():
            # Check if cache is still valid
            file_age = datetime.now() - datetime.fromtimestamp(cache_file.stat().st_mtime)
            
            if file_age < self.config.cache_duration:
                try:
                    with open(cache_file, 'r', encoding='utf-8') as f:
                        self.stats["cache_hits"] += 1
                        return json.load(f)
                except Exception as e:
                    logger.error(f"Error reading cache: {e}")
        
        return None
    
    async def save_to_cache(self, cache_key: str, data: Any):
        """
        Save data to cache
        
        Args:
            cache_key: Cache key
            data: Data to cache
        """
        cache_file = self.cache_dir / f"{cache_key}.json"
        
        try:
            with open(cache_file, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=2, default=str)
        except Exception as e:
            logger.error(f"Error saving to cache: {e}")
    
    def calculate_quality_score(self, data: Any) -> float:
        """
        Calculate data quality score
        
        Args:
            data: Data to score
            
        Returns:
            Quality score (0-1)
        """
        if not data:
            return 0.0
        
        score = 0.5  # Base score
        
        # Check completeness
        if isinstance(data, dict):
            filled_fields = sum(1 for v in data.values() if v is not None)
            total_fields = len(data)
            if total_fields > 0:
                score += 0.3 * (filled_fields / total_fields)
        elif isinstance(data, list):
            if len(data) > 0:
                score += 0.3
        
        # Check freshness (if timestamp available)
        if isinstance(data, dict) and 'timestamp' in data:
            try:
                timestamp = pd.to_datetime(data['timestamp'])
                age_days = (datetime.now() - timestamp).days
                if age_days < 1:
                    score += 0.2
                elif age_days < 7:
                    score += 0.1
            except:
                pass
        
        return min(1.0, score)
