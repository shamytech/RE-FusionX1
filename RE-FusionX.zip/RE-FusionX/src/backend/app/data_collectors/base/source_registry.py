"""
Source Registry System
======================
Dynamic registration and discovery of data sources
"""

import importlib
import inspect
from typing import Dict, Any, Optional, Type
from pathlib import Path
from app.core.logging import logger


class SourceRegistry:
    """
    Registry for data sources - auto-discovers and manages sources
    """
    
    _sources: Dict[str, Type] = {}
    _initialized: bool = False
    
    @classmethod
    def register(cls, source_name: str):
        """
        Decorator to register sources automatically
        
        Usage:
            @SourceRegistry.register("emlakjet")
            class EmlakjetScraper:
                ...
        """
        def decorator(source_class):
            cls._sources[source_name] = source_class
            logger.info(f"✅ Registered source: {source_name}")
            return source_class
        return decorator
    
    @classmethod
    def get_available_sources(cls) -> list:
        """Get all available source names"""
        if not cls._initialized:
            cls.auto_discover()
        return list(cls._sources.keys())
    
    @classmethod
    def get_source(cls, name: str) -> Optional[Type]:
        """
        Get a specific source class by name
        
        Args:
            name: Source name
            
        Returns:
            Source class or None
        """
        if not cls._initialized:
            cls.auto_discover()
        return cls._sources.get(name)
    
    @classmethod
    def create_instance(cls, name: str, **kwargs) -> Optional[Any]:
        """
        Create an instance of a source
        
        Args:
            name: Source name
            **kwargs: Arguments for source constructor
            
        Returns:
            Source instance or None
        """
        source_class = cls.get_source(name)
        if source_class:
            try:
                return source_class(**kwargs)
            except Exception as e:
                logger.error(f"Failed to create instance of {name}: {e}")
        return None
    
    @classmethod
    def auto_discover(cls):
        """
        Auto-discover sources from the sources directory
        """
        if cls._initialized:
            return
            
        cls._initialized = True
        
        # Define paths to search
        search_paths = [
            Path(__file__).parent.parent / "real_estate" / "sources",
            Path(__file__).parent.parent / "smart_collectors" / "sources",
        ]
        
        for base_path in search_paths:
            if not base_path.exists():
                logger.debug(f"Path does not exist: {base_path}")
                continue
                
            # Find all Python files
            for file_path in base_path.glob("*.py"):
                if file_path.name.startswith("_"):
                    continue
                    
                module_name = f"app.data_collectors.{base_path.parent.name}.sources.{file_path.stem}"
                
                try:
                    # Import the module
                    module = importlib.import_module(module_name)
                    
                    # Check if module has any registered classes
                    for name, obj in inspect.getmembers(module):
                        if inspect.isclass(obj) and hasattr(obj, '__module__'):
                            # Check if this class was registered
                            if obj.__module__ == module.__name__:
                                logger.debug(f"Discovered module: {file_path.stem}")
                                
                except ImportError as e:
                    logger.debug(f"Could not import {module_name}: {e}")
                except Exception as e:
                    logger.error(f"Error discovering {file_path.stem}: {e}")
    
    @classmethod
    def get_statistics(cls) -> Dict[str, Any]:
        """Get registry statistics"""
        if not cls._initialized:
            cls.auto_discover()
            
        return {
            "total_sources": len(cls._sources),
            "sources": list(cls._sources.keys()),
            "initialized": cls._initialized
        }
    
    @classmethod
    def clear(cls):
        """Clear the registry (mainly for testing)"""
        cls._sources.clear()
        cls._initialized = False
