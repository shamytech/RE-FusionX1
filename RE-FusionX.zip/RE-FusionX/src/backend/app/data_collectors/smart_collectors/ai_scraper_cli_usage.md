
# AI Scraper CLI Usage Guide

This document provides **all available command-line options** for `ai_scraper.py` with practical examples.

---

## 📌 General Syntax
```bash
$env:PYTHONPATH="D:\Phd\RE-FusionX\src\backend"

python src/backend/app/data_collectors/smart_collectors/ai_scraper.py [url] [options]
```

---

## ⚙️ Options

### 1. `-m, --method`
Specifies the scraping method:
- `property` → Extract property data (default).
- `market` → Extract market data/statistics.
- `news` → Extract a news article.
- `search` → Search using a query.
- `scrape` → Custom scraping using a prompt.

### 2. `-t, --tool`
Forces a specific scraping tool instead of hybrid mode:
- `scrapegraphai`
- `crawl4ai`
- `langchain`
- `traditional`

### 3. `-p, --prompt`
Custom **prompt** when using `-m scrape`.

### 4. `-q, --query`
Custom **search query** when using `-m search`.

### 5. `--json`
Outputs raw JSON results.

---

## 🏠 Practical Examples

### 1. Extract property data (default)
```bash
python src/backend/app/data_collectors/smart_collectors/ai_scraper.py -m property https://www.emlakjet.com/satilik-konut/ankara-akyurt
```

### 2. Extract market data
```bash
python src/backend/app/data_collectors/smart_collectors/ai_scraper.py -m market https://www.emlakjet.com/satilik-konut/istanbul/
```

### 3. Extract news article
```bash
python src/backend/app/data_collectors/smart_collectors/ai_scraper.py -m news https://www.hurriyet.com.tr/ekonomi/istanbulda-konut-fiyatlari-42345678
```

### 4. Search properties using a query
```bash
python src/backend/app/data_collectors/smart_collectors/ai_scraper.py -m search -q "Istanbul Kadıköy apartment 3+1 for sale"
```

### 5. Custom scraping with prompt
```bash
python src/backend/app/data_collectors/smart_collectors/ai_scraper.py -m scrape -p "Extract property title, price, and contact phone" https://www.emlakjet.com/satilik-konut/istanbul-kadikoy/
```

### 6. Force tool: ScrapegraphAI
```bash
python src/backend/app/data_collectors/smart_collectors/ai_scraper.py -m property -t scrapegraphai https://www.emlakjet.com/satilik-konut/istanbul-kadikoy/
```

### 7. Force tool: Crawl4AI
```bash
python src/backend/app/data_collectors/smart_collectors/ai_scraper.py -m property -t crawl4ai https://www.emlakjet.com/satilik-konut/istanbul-kadikoy/
```

### 8. Force tool: LangChain
```bash
python src/backend/app/data_collectors/smart_collectors/ai_scraper.py -m property -t langchain https://www.emlakjet.com/satilik-konut/istanbul-kadikoy/
```

### 9. Force tool: Traditional
```bash
python src/backend/app/data_collectors/smart_collectors/ai_scraper.py -m property -t traditional https://www.emlakjet.com/satilik-konut/istanbul-kadikoy/
```

### 10. Show results as JSON
```bash
python src/backend/app/data_collectors/smart_collectors/ai_scraper.py -m property --json https://www.emlakjet.com/satilik-konut/istanbul-kadikoy/
```

---

## 📊 Quick Summary (Table)

| Purpose             | Method/Option Example |
|---------------------|------------------------|
| Extract property    | `-m property [url]` |
| Market statistics   | `-m market [url]` |
| News article        | `-m news [url]` |
| Search properties   | `-m search -q "query"` |
| Custom scrape       | `-m scrape -p "prompt" [url]` |
| Use ScrapegraphAI   | `-t scrapegraphai` |
| Use Crawl4AI        | `-t crawl4ai` |
| Use LangChain       | `-t langchain` |
| Use Traditional     | `-t traditional` |
| Output raw JSON     | `--json` |

---

✅ With this guide, you can test **all available tools** (`scrapegraphai`, `crawl4ai`, `langchain`, `traditional`) and **all methods** (`property`, `market`, `news`, `search`, `scrape`).
