"""
LLM-based Data Extractor
========================
Uses language models for intelligent data extraction
"""

from typing import Dict, Any, List, Optional, Union
import json
import re
from datetime import datetime

from app.core.logging import logger


class LLMExtractor:
    """
    Extracts structured data using LLMs
    """
    
    def __init__(self, model_loader=None):
        """
        Initialize LLM extractor
        
        Args:
            model_loader: Model loader for LLM access
        """
        self.model_loader = model_loader
        self.extraction_prompts = self._load_extraction_prompts()
    
    def _load_extraction_prompts(self) -> Dict[str, str]:
        """Load extraction prompts for different data types"""
        return {
            "property": """
                Extract property information from the following text.
                Return a JSON object with these fields:
                - price (numeric value)
                - currency (TL, USD, EUR)
                - size_sqm (numeric, square meters)
                - rooms (format: X+Y)
                - location (city, district, neighborhood)
                - building_age (numeric, years)
                - floor (numeric)
                - total_floors (numeric)
                - features (list of amenities)
                - property_type (apartment, villa, etc.)
                
                Text: {text}
                
                JSON Output:
            """,
            
            "market_metrics": """
                Extract market metrics from the following text.
                Return a JSON object with these fields:
                - metric_name
                - value (numeric)
                - unit (%, TL, index, etc.)
                - period (monthly, yearly, etc.)
                - date
                - change_value (numeric)
                - change_percent (numeric)
                
                Text: {text}
                
                JSON Output:
            """,
            
            "contact": """
                Extract contact information from the following text.
                Return a JSON object with:
                - name
                - phone
                - email
                - company
                - address
                - website
                
                Text: {text}
                
                JSON Output:
            """,
            
            "location": """
                Extract location details from the following text.
                Return a JSON object with:
                - country
                - city
                - district
                - neighborhood
                - street
                - postal_code
                - landmarks (list)
                - coordinates (lat, lon if available)
                
                Text: {text}
                
                JSON Output:
            """
        }
    
    async def extract_structured_data(
        self,
        text: str,
        data_type: str
    ) -> Optional[Dict[str, Any]]:
        """
        Extract structured data from text
        
        Args:
            text: Input text
            data_type: Type of data to extract
            
        Returns:
            Extracted structured data
        """
        if not self.model_loader:
            return self._fallback_extraction(text, data_type)
        
        prompt_template = self.extraction_prompts.get(data_type)
        if not prompt_template:
            logger.warning(f"No prompt template for data type: {data_type}")
            return None
        
        try:
            # Format prompt
            prompt = prompt_template.format(text=text)
            
            # Get model response
            model = await self.model_loader.get_model()
            response = await model.generate(
                prompt=prompt,
                max_tokens=500,
                temperature=0.1  # Low temperature for structured extraction
            )
            
            # Parse JSON from response
            extracted_data = self._parse_json_response(response)
            
            if extracted_data:
                # Validate and clean data
                cleaned_data = self._validate_and_clean(extracted_data, data_type)
                return cleaned_data
            
        except Exception as e:
            logger.error(f"LLM extraction failed: {e}")
        
        # Fallback to regex extraction
        return self._fallback_extraction(text, data_type)
    
    def _parse_json_response(self, response: str) -> Optional[Dict[str, Any]]:
        """Parse JSON from LLM response"""
        try:
            # Try direct JSON parsing
            return json.loads(response)
        except:
            # Try to extract JSON from response
            json_match = re.search(r'\{.*\}', response, re.DOTALL)
            if json_match:
                try:
                    return json.loads(json_match.group())
                except:
                    pass
        
        return None
    
    def _fallback_extraction(
        self,
        text: str,
        data_type: str
    ) -> Dict[str, Any]:
        """Fallback extraction using regex patterns"""
        extracted = {}
        
        if data_type == "property":
            extracted = self._extract_property_regex(text)
        elif data_type == "contact":
            extracted = self._extract_contact_regex(text)
        elif data_type == "location":
            extracted = self._extract_location_regex(text)
        elif data_type == "market_metrics":
            extracted = self._extract_metrics_regex(text)
        
        return extracted
    
    def _extract_property_regex(self, text: str) -> Dict[str, Any]:
        """Extract property data using regex"""
        extracted = {}
        
        # Price patterns
        price_patterns = [
            r'(\d{1,3}(?:\.\d{3})*(?:,\d{2})?\s*(?:TL|₺))',
            r'([\d.,]+)\s*(?:TL|₺|TRY)',
        ]
        
        for pattern in price_patterns:
            match = re.search(pattern, text, re.IGNORECASE)
            if match:
                price_str = match.group(1)
                # Clean and convert
                price_str = re.sub(r'[^\d,.]', '', price_str)
                price_str = price_str.replace('.', '').replace(',', '.')
                try:
                    extracted['price'] = float(price_str)
                    break
                except:
                    pass
        
        # Size patterns
        size_match = re.search(r'(\d+)\s*(?:m²|m2|metrekare)', text, re.IGNORECASE)
        if size_match:
            extracted['size_sqm'] = int(size_match.group(1))
        
        # Rooms pattern
        rooms_match = re.search(r'(\d+)\+(\d+)', text)
        if rooms_match:
            extracted['rooms'] = f"{rooms_match.group(1)}+{rooms_match.group(2)}"
        
        # Building age
        age_match = re.search(r'(\d+)\s*(?:yaşında|yıllık|years?)', text, re.IGNORECASE)
        if age_match:
            extracted['building_age'] = int(age_match.group(1))
        
        # Floor
        floor_match = re.search(r'(\d+)\.\s*(?:kat|floor)', text, re.IGNORECASE)
        if floor_match:
            extracted['floor'] = int(floor_match.group(1))
        
        return extracted
    
    def _extract_contact_regex(self, text: str) -> Dict[str, Any]:
        """Extract contact information using regex"""
        extracted = {}
        
        # Phone patterns
        phone_patterns = [
            r'(?:tel|telefon|phone)[:\s]*([+\d\s\-\(\)]+)',
            r'(\+90[\d\s\-]+)',
            r'(0\d{3}[\s\-]?\d{3}[\s\-]?\d{2}[\s\-]?\d{2})'
        ]
        
        for pattern in phone_patterns:
            match = re.search(pattern, text, re.IGNORECASE)
            if match:
                extracted['phone'] = match.group(1).strip()
                break
        
        # Email pattern
        email_match = re.search(r'[\w\.-]+@[\w\.-]+\.\w+', text)
        if email_match:
            extracted['email'] = email_match.group()
        
        # Website pattern
        website_match = re.search(r'(?:www\.|http)[^\s]+', text)
        if website_match:
            extracted['website'] = website_match.group()
        
        return extracted
    
    def _extract_location_regex(self, text: str) -> Dict[str, Any]:
        """Extract location information using regex"""
        extracted = {}
        
        # Turkish cities
        cities = [
            "istanbul", "ankara", "izmir", "antalya", "bursa",
            "adana", "konya", "gaziantep", "mersin", "kayseri"
        ]
        
        text_lower = text.lower()
        for city in cities:
            if city in text_lower:
                extracted['city'] = city.title()
                break
        
        # Districts (common Istanbul districts)
        districts = [
            "kadıköy", "beşiktaş", "şişli", "bakırköy", "ataşehir",
            "üsküdar", "sarıyer", "beyoğlu", "fatih", "başakşehir"
        ]
        
        for district in districts:
            if district in text_lower:
                extracted['district'] = district.title()
                break
        
        return extracted
    
    def _extract_metrics_regex(self, text: str) -> Dict[str, Any]:
        """Extract market metrics using regex"""
        extracted = {}
        
        # Percentage patterns
        percent_match = re.search(r'(%|yüzde|percent)\s*(\d+(?:[.,]\d+)?)', text, re.IGNORECASE)
        if percent_match:
            value = percent_match.group(2).replace(',', '.')
            extracted['change_percent'] = float(value)
        
        # Index patterns
        index_match = re.search(r'(?:index|endeks)[:\s]*(\d+(?:[.,]\d+)?)', text, re.IGNORECASE)
        if index_match:
            value = index_match.group(1).replace(',', '.')
            extracted['index_value'] = float(value)
        
        return extracted
    
    def _validate_and_clean(
        self,
        data: Dict[str, Any],
        data_type: str
    ) -> Dict[str, Any]:
        """Validate and clean extracted data"""
        cleaned = {}
        
        for key, value in data.items():
            # Skip None values
            if value is None:
                continue
            
            # Clean strings
            if isinstance(value, str):
                value = value.strip()
                if not value:
                    continue
            
            # Validate numeric values
            if key in ['price', 'size_sqm', 'floor', 'building_age']:
                try:
                    value = float(value)
                    if value < 0:
                        continue
                except:
                    continue
            
            cleaned[key] = value
        
        # Add metadata
        cleaned['extraction_method'] = 'llm'
        cleaned['extraction_date'] = datetime.now().isoformat()
        cleaned['data_type'] = data_type
        
        return cleaned
