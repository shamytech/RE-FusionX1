"""Smart AI-powered collectors"""

from .ai_scraper import AIScraper
from .llm_extractor import LLMExtractor
from .adaptive_parser import AdaptiveParser
__all__ = [
    "AIScraper",
    "LLMExtractor",
    "AdaptiveParser",
]
