"""
Adaptive Parser
===============
Self-learning parser that adapts to website structure changes
"""

from typing import Dict, Any, List, Optional, Tuple
import json
from pathlib import Path
from datetime import datetime
import hashlib
from bs4 import BeautifulSoup
import difflib

from app.core.logging import logger


class AdaptiveParser:
    """
    Parser that learns and adapts to website structure changes
    """
    
    def __init__(self, patterns_dir: Optional[Path] = None):
        """
        Initialize adaptive parser
        
        Args:
            patterns_dir: Directory to store learned patterns
        """
        self.patterns_dir = patterns_dir or Path("data/parser_patterns")
        self.patterns_dir.mkdir(parents=True, exist_ok=True)
        
        self.patterns = self._load_patterns()
        self.success_history = []
        self.failure_history = []
    
    def _load_patterns(self) -> Dict[str, Any]:
        """Load saved parsing patterns"""
        patterns = {}
        
        for pattern_file in self.patterns_dir.glob("*.json"):
            try:
                with open(pattern_file, 'r', encoding='utf-8') as f:
                    site_patterns = json.load(f)
                    site_name = pattern_file.stem
                    patterns[site_name] = site_patterns
            except Exception as e:
                logger.error(f"Failed to load pattern {pattern_file}: {e}")
        
        return patterns
    
    def parse(
        self,
        html: str,
        site_name: str,
        expected_fields: List[str]
    ) -> Dict[str, Any]:
        """
        Parse HTML adaptively
        
        Args:
            html: HTML content
            site_name: Name of the website
            expected_fields: Fields to extract
            
        Returns:
            Extracted data
        """
        soup = BeautifulSoup(html, 'html.parser')
        
        # Try existing patterns first
        if site_name in self.patterns:
            result = self._apply_patterns(soup, self.patterns[site_name])
            if self._validate_result(result, expected_fields):
                self._record_success(site_name, self.patterns[site_name])
                return result
        
        # Try to learn new patterns
        new_patterns = self._learn_patterns(soup, expected_fields)
        if new_patterns:
            result = self._apply_patterns(soup, new_patterns)
            if self._validate_result(result, expected_fields):
                # Save successful patterns
                self._save_patterns(site_name, new_patterns)
                self._record_success(site_name, new_patterns)
                return result
        
        # Fallback to heuristic extraction
        result = self._heuristic_extraction(soup, expected_fields)
        
        if self._validate_result(result, expected_fields, threshold=0.5):
            # Learn from partial success
            patterns = self._learn_from_result(soup, result)
            if patterns:
                self._update_patterns(site_name, patterns)
        else:
            self._record_failure(site_name, expected_fields)
        
        return result
    
    def _apply_patterns(
        self,
        soup: BeautifulSoup,
        patterns: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Apply learned patterns to extract data"""
        extracted = {}
        
        for field, pattern in patterns.items():
            try:
                if pattern['type'] == 'css':
                    element = soup.select_one(pattern['selector'])
                    if element:
                        if pattern.get('attribute'):
                            extracted[field] = element.get(pattern['attribute'])
                        else:
                            extracted[field] = element.get_text(strip=True)
                
                elif pattern['type'] == 'xpath':
                    # Would need lxml for XPath support
                    pass
                
                elif pattern['type'] == 'regex':
                    import re
                    text = soup.get_text()
                    match = re.search(pattern['pattern'], text, re.IGNORECASE)
                    if match:
                        extracted[field] = match.group(1) if pattern.get('group') else match.group()
                
                elif pattern['type'] == 'custom':
                    # Custom extraction logic
                    extracted[field] = self._custom_extraction(
                        soup,
                        field,
                        pattern.get('config', {})
                    )
                    
            except Exception as e:
                logger.warning(f"Pattern extraction failed for {field}: {e}")
        
        return extracted
    
    def _learn_patterns(
        self,
        soup: BeautifulSoup,
        expected_fields: List[str]
    ) -> Dict[str, Any]:
        """Learn patterns from HTML structure"""
        patterns = {}
        
        for field in expected_fields:
            # Try different strategies to find patterns
            
            # Strategy 1: Look for labeled data
            pattern = self._find_labeled_pattern(soup, field)
            if pattern:
                patterns[field] = pattern
                continue
            
            # Strategy 2: Look for data by format
            pattern = self._find_format_pattern(soup, field)
            if pattern:
                patterns[field] = pattern
                continue
            
            # Strategy 3: Look for semantic patterns
            pattern = self._find_semantic_pattern(soup, field)
            if pattern:
                patterns[field] = pattern
        
        return patterns
    
    def _find_labeled_pattern(
        self,
        soup: BeautifulSoup,
        field: str
    ) -> Optional[Dict[str, Any]]:
        """Find pattern based on labels"""
        # Common label variations
        label_variations = self._get_label_variations(field)
        
        for label in label_variations:
            # Look for label:value patterns
            elements = soup.find_all(text=re.compile(label, re.IGNORECASE))
            
            for elem in elements:
                parent = elem.parent
                if parent:
                    # Check next sibling
                    next_sibling = parent.find_next_sibling()
                    if next_sibling and next_sibling.get_text(strip=True):
                        return {
                            'type': 'css',
                            'selector': self._generate_selector(next_sibling),
                            'confidence': 0.8
                        }
                    
                    # Check within parent
                    value_elem = parent.find_next()
                    if value_elem and value_elem.get_text(strip=True):
                        return {
                            'type': 'css',
                            'selector': self._generate_selector(value_elem),
                            'confidence': 0.7
                        }
        
        return None
    
    def _find_format_pattern(
        self,
        soup: BeautifulSoup,
        field: str
    ) -> Optional[Dict[str, Any]]:
        """Find pattern based on data format"""
        import re
        
        format_patterns = {
            'price': r'[\d.,]+\s*(?:TL|₺|USD|EUR)',
            'size': r'\d+\s*(?:m²|m2|metrekare)',
            'rooms': r'\d+\+\d+',
            'phone': r'[\d\s\-\(\)]+',
            'email': r'[\w\.-]+@[\w\.-]+\.\w+'
        }
        
        if field in format_patterns:
            pattern = format_patterns[field]
            text = soup.get_text()
            
            if re.search(pattern, text):
                return {
                    'type': 'regex',
                    'pattern': f'({pattern})',
                    'group': 1,
                    'confidence': 0.6
                }
        
        return None
    
    def _find_semantic_pattern(
        self,
        soup: BeautifulSoup,
        field: str
    ) -> Optional[Dict[str, Any]]:
        """Find pattern based on semantic HTML"""
        semantic_mappings = {
            'price': ['price', 'cost', 'fiyat'],
            'location': ['location', 'address', 'konum', 'adres'],
            'title': ['title', 'heading', 'başlık'],
            'description': ['description', 'details', 'açıklama']
        }
        
        if field in semantic_mappings:
            for keyword in semantic_mappings[field]:
                # Check class names
                elements = soup.find_all(class_=re.compile(keyword, re.IGNORECASE))
                if elements:
                    return {
                        'type': 'css',
                        'selector': f'.{elements[0].get("class")[0]}',
                        'confidence': 0.5
                    }
                
                # Check IDs
                element = soup.find(id=re.compile(keyword, re.IGNORECASE))
                if element:
                    return {
                        'type': 'css',
                        'selector': f'#{element.get("id")}',
                        'confidence': 0.5
                    }
        
        return None
    
    def _heuristic_extraction(
        self,
        soup: BeautifulSoup,
        expected_fields: List[str]
    ) -> Dict[str, Any]:
        """Fallback heuristic extraction"""
        extracted = {}
        
        for field in expected_fields:
            # Try multiple heuristics
            value = None
            
            # Heuristic 1: Meta tags
            if field in ['title', 'description']:
                meta = soup.find('meta', {'property': f'og:{field}'})
                if meta:
                    value = meta.get('content')
            
            # Heuristic 2: Common patterns
            if not value and field == 'price':
                import re
                price_match = re.search(r'([\d.,]+)\s*(?:TL|₺)', soup.get_text())
                if price_match:
                    value = price_match.group(1)
            
            # Heuristic 3: Largest text block for description
            if not value and field == 'description':
                paragraphs = soup.find_all('p')
                if paragraphs:
                    longest = max(paragraphs, key=lambda p: len(p.get_text()))
                    value = longest.get_text(strip=True)
            
            if value:
                extracted[field] = value
        
        return extracted
    
    def _generate_selector(self, element) -> str:
        """Generate CSS selector for element"""
        selector_parts = []
        
        # Use ID if available
        if element.get('id'):
            return f'#{element.get("id")}'
        
        # Use unique class combination
        if element.get('class'):
            classes = '.'.join(element.get('class'))
            selector_parts.append(f'.{classes}')
        
        # Add tag name
        selector_parts.insert(0, element.name)
        
        # Add parent context if needed
        parent = element.parent
        if parent and parent.name != 'body':
            if parent.get('id'):
                selector_parts.insert(0, f'#{parent.get("id")} >')
            elif parent.get('class'):
                parent_class = parent.get('class')[0]
                selector_parts.insert(0, f'.{parent_class} >')
        
        return ' '.join(selector_parts)
    
    def _get_label_variations(self, field: str) -> List[str]:
        """Get label variations for a field"""
        variations = {
            'price': ['price', 'fiyat', 'tutar', 'ücret'],
            'size': ['size', 'alan', 'm²', 'metrekare', 'büyüklük'],
            'rooms': ['rooms', 'oda', 'oda sayısı'],
            'location': ['location', 'konum', 'yer', 'adres', 'lokasyon'],
            'age': ['age', 'yaş', 'bina yaşı', 'yapım yılı']
        }
        
        return variations.get(field, [field])
    
    def _validate_result(
        self,
        result: Dict[str, Any],
        expected_fields: List[str],
        threshold: float = 0.7
    ) -> bool:
        """Validate extraction result"""
        if not result:
            return False
        
        found_fields = sum(1 for field in expected_fields if field in result and result[field])
        completeness = found_fields / len(expected_fields) if expected_fields else 0
        
        return completeness >= threshold
    
    def _save_patterns(self, site_name: str, patterns: Dict[str, Any]):
        """Save successful patterns"""
        pattern_file = self.patterns_dir / f"{site_name}.json"
        
        # Merge with existing patterns
        existing_patterns = {}
        if pattern_file.exists():
            try:
                with open(pattern_file, 'r', encoding='utf-8') as f:
                    existing_patterns = json.load(f)
            except:
                pass
        
        # Update patterns
        existing_patterns.update(patterns)
        
        # Add metadata
        existing_patterns['_metadata'] = {
            'last_updated': datetime.now().isoformat(),
            'success_count': existing_patterns.get('_metadata', {}).get('success_count', 0) + 1
        }
        
        # Save
        with open(pattern_file, 'w', encoding='utf-8') as f:
            json.dump(existing_patterns, f, ensure_ascii=False, indent=2)
    
    def _update_patterns(self, site_name: str, patterns: Dict[str, Any]):
        """Update patterns with new learnings"""
        self.patterns[site_name] = self.patterns.get(site_name, {})
        self.patterns[site_name].update(patterns)
        self._save_patterns(site_name, self.patterns[site_name])
    
    def _learn_from_result(
        self,
        soup: BeautifulSoup,
        result: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Learn patterns from successful extraction"""
        patterns = {}
        
        for field, value in result.items():
            if value:
                # Try to find the element containing this value
                elements = soup.find_all(text=str(value))
                if elements:
                    element = elements[0].parent
                    if element:
                        patterns[field] = {
                            'type': 'css',
                            'selector': self._generate_selector(element),
                            'confidence': 0.4
                        }
        
        return patterns
    
    def _record_success(self, site_name: str, patterns: Dict[str, Any]):
        """Record successful extraction"""
        self.success_history.append({
            'site': site_name,
            'timestamp': datetime.now().isoformat(),
            'patterns': patterns
        })
    
    def _record_failure(self, site_name: str, expected_fields: List[str]):
        """Record extraction failure"""
        self.failure_history.append({
            'site': site_name,
            'timestamp': datetime.now().isoformat(),
            'expected_fields': expected_fields
        })
    
    def _custom_extraction(
        self,
        soup: BeautifulSoup,
        field: str,
        config: Dict[str, Any]
    ) -> Any:
        """Custom extraction logic for complex cases"""
        # Implement custom extraction strategies here
        return None
    
    def get_extraction_stats(self) -> Dict[str, Any]:
        """Get extraction statistics"""
        return {
            'total_sites': len(self.patterns),
            'success_count': len(self.success_history),
            'failure_count': len(self.failure_history),
            'success_rate': len(self.success_history) / (len(self.success_history) + len(self.failure_history)) if self.success_history or self.failure_history else 0,
            'patterns_learned': sum(len(p) for p in self.patterns.values())
        }
