"""
AI-Powered Smart Scraper (Hybrid Version)
==========================================
Uses multiple AI scraping strategies with intelligent fallback
"""

import asyncio
from typing import Dict, Any, List, Optional, Union
from datetime import datetime
import json
from abc import ABC, abstractmethod
from dotenv import load_dotenv
import sys
import os
load_dotenv()

# Tool imports with availability checks
try:
    from scrapegraphai.graphs import SmartScraperGraph
    SCRAPEGRAPHAI_AVAILABLE = True
    print(" 🕷️  ScrapegraphAI loaded successfully")
except ImportError as e:
    print(f"❌ ScrapegraphAI import error: {e}")
    SCRAPEGRAPHAI_AVAILABLE = False
    
try:
    from crawl4ai import AsyncWebCrawler as WebCrawler
    CRAWL4AI_AVAILABLE = True
    print(" 🕸️  Crawl4AI loaded successfully")
except ImportError as e:
    print(f"❌ Crawl4AI import error: {e}")
    CRAWL4AI_AVAILABLE = False
    
try:
    from langchain_community.document_loaders import AsyncHtmlLoader
    from langchain_community.document_transformers import BeautifulSoupTransformer
    LANGCHAIN_AVAILABLE = True
    print(" 🧠 LangChain loaded successfully")
except ImportError as e:
    print(f"❌ LangChain import error: {e}")
    LANGCHAIN_AVAILABLE = False

try:
    import agentql
    from agentql.ext.playwright.sync_api import Page as AgentQLPage
    AGENTQL_AVAILABLE = True
    print(" 🤖 AgentQL loaded successfully")
except ImportError as e:
    print(f"❌ AgentQL import error: {e}")
    AGENTQL_AVAILABLE = False

from bs4 import BeautifulSoup
import aiohttp

from app.core.logging import logger

# Try to import scraping config, use defaults if not available
try:
    from app.core.scraping_config import (
        ScrapingConfig, ScrapingTool, SCRAPING_CONFIG, get_active_tools
    )
    CONFIG_AVAILABLE = True
except ImportError:
    CONFIG_AVAILABLE = False
    # Define minimal config
    from enum import Enum
    
    
    class ScrapingTool(Enum):
        SCRAPEGRAPHAI = "scrapegraphai"
        CRAWL4AI = "crawl4ai"
        LANGCHAIN_BS4 = "langchain_bs4"
        TRADITIONAL = "traditional"
        AGENTQL = "agentql"
    
    class ScrapingConfig:
        def __init__(self):
            self.enabled_tools = [
                ScrapingTool.SCRAPEGRAPHAI,
                ScrapingTool.CRAWL4AI,
                ScrapingTool.LANGCHAIN_BS4,
                ScrapingTool.TRADITIONAL,
                ScrapingTool.AGENTQL  # Add to enabled tools
            ]
            self.auto_fallback = True
            self.max_retries_per_tool = 2
            self.turkish_prompts = {
                "property_extraction": "Extract property details including price, location, size, rooms",
                "market_search": "Search for similar properties in the market"
            }
            self.scrapegraphai_config = {"llm": {"model": "gpt-3.5-turbo"}}
            self.crawl4ai_config = {"headless": True}
            self.langchain_config = {}
            self.agentql_config = {"headless": True}
    
    SCRAPING_CONFIG = ScrapingConfig()

# Rich console for pretty output
try:
    from rich.console import Console
    console = Console()
except ImportError:
    # Fallback console
    class Console:
        def log(self, msg): print(msg)
        def print(self, msg): print(msg)
    console = Console()


class ScrapingStrategy(ABC):
    """Abstract base class for scraping strategies"""
    
    @abstractmethod
    async def scrape(self, url: str, prompt: str, config: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Execute scraping strategy"""
        pass
    
    @abstractmethod
    def is_available(self) -> bool:
        """Check if this strategy is available"""
        pass


class ScrapegraphAIStrategy(ScrapingStrategy):
    """ScrapegraphAI scraping strategy"""
    
    def __init__(self, model_loader=None):
        self.model_loader = model_loader
        
    def is_available(self) -> bool:
        return SCRAPEGRAPHAI_AVAILABLE
    
    async def scrape(self, url: str, prompt: str, config: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Scrape using ScrapegraphAI"""
        if not self.is_available():
            return None
            
        try:
            console.log("[cyan]🧠 Using ScrapegraphAI (Most Intelligent)...[/cyan]")
            
            # تحسين الإعدادات للعمل مع مختلف المزودين
            scraper_config = config.copy()
            
            # إضافة دعم المفاتيح من متغيرات البيئة
            import os           
            print(url)
            print(prompt)
            # جرب Groq أولاً (مجاني وسريع)
            if groq_key := os.getenv("GROQ_API_KEY"):
                from groq import Groq
                client = Groq(api_key=groq_key)

                response = client.chat.completions.create(
                    model="llama-3.3-70b-versatile",
                    messages=[{"role": "user", "content": prompt}],
                    temperature=0.1,
                    max_completion_tokens=1024,
                    top_p=1,
                    stream=False,
                    response_format={"type": "json_object"}
                )
                
                message = response.choices[0].message
                print(message)
                content = getattr(message, "content", None) or str(message)

                parsed = None
                try:
                    parsed = json.loads(content)
                except Exception:
                    pass

                if isinstance(parsed, dict):
                    normalized = parsed
                else:
                    normalized = {"description": content}

                normalized["_raw"] = content
                return self._standardize_result(normalized, "groq")

            # أو OpenAI إذا كان متاحاً
            elif openai_key := os.getenv("OPENAI_API_KEY"):
                scraper_config["llm"] = {
                    "api_key": openai_key,
                    "model": "gpt-3.5-turbo",
                    "model_provider": "openai",
                    "temperature": 0.1
                }
                console.log("[green]Using OpenAI API[/green]")     
                
            elif self._check_ollama():
                scraper_config["llm"] = {
                    "model": "ollama/mistral",
                    "base_url": "http://localhost:11434",
                    "model_provider": "ollama",
                    "temperature": 0.1
                }
                console.log("[green]Using Ollama (Local)[/green]")           
            
            # إذا لم يجد أي مزود
            else:
                console.log("[red]No AI provider configured![/red]")
                console.log("[yellow]Please set GROQ_API_KEY or OPENAI_API_KEY in .env[/yellow]")
                return None
            
            scraper = SmartScraperGraph(
                prompt=prompt,
                source=url,
                config=scraper_config
            )
            
            result = await asyncio.to_thread(scraper.run)
            
            if result:
                console.log("[green]✓ ScrapegraphAI extraction successful[/green]")
                return self._standardize_result(result, "scrapegraphai")
                
        except Exception as e:
            logger.error(f"ScrapegraphAI failed: {e}")
            console.log(f"[yellow]⚠ ScrapegraphAI failed: {e}[/yellow]")
            
        return None
    
    def _check_ollama(self) -> bool:
        """Check if Ollama is running locally"""
        try:
            import requests
            response = requests.get("http://localhost:11434/api/tags", timeout=1)
            return response.status_code == 200
        except:
            return False
  
    def _standardize_result(self, result: Any, source: str) -> Dict[str, Any]:
        """Standardize result format"""
        if isinstance(result, dict):
            # إذا كان dict بالفعل أضف معلومات المصدر فقط
            result.setdefault("_source", source)
            result.setdefault("_timestamp", datetime.now().isoformat())
            return result
        return {
            "data": result,
            "_source": source,
            "_timestamp": datetime.now().isoformat()
        }


class Crawl4AIStrategy(ScrapingStrategy):
    """Crawl4AI scraping strategy"""
    
    def is_available(self) -> bool:
        return CRAWL4AI_AVAILABLE
    
    async def scrape(self, url: str, prompt: str, config: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Scrape using Crawl4AI"""
        if not self.is_available():
            return None
            
        try:
            console.log("[blue]⚡ Using Crawl4AI (Fast & Efficient)...[/blue]")
            
            crawler = WebCrawler(**config)
            result = await crawler.arun(url=url)
            
            if result and result.html:
                extracted = self._extract_with_prompt(result.html, prompt)
                
                if extracted:
                    console.log("[green]✓ Crawl4AI extraction successful[/green]")
                    return self._standardize_result(extracted, "crawl4ai")
                    
        except Exception as e:
            logger.error(f"Crawl4AI failed: {e}")
            console.log(f"[yellow]⚠ Crawl4AI failed: {e}[/yellow]")
            
        return None
    
    def _extract_with_prompt(self, html: str, prompt: str) -> Dict[str, Any]:
        """Extract data from HTML based on prompt"""
        soup = BeautifulSoup(html, 'html.parser')
        extracted = {}
        
        # Extract based on prompt keywords
        if 'price' in prompt.lower() or 'fiyat' in prompt.lower():
            price = self._extract_price(soup)
            if price:
                extracted['price'] = price
        
        if 'location' in prompt.lower() or 'konum' in prompt.lower():
            location = self._extract_location(soup)
            if location:
                extracted['location'] = location
        
        if 'size' in prompt.lower() or 'metrekare' in prompt.lower():
            size = self._extract_size(soup)
            if size:
                extracted['size'] = size
        
        if 'room' in prompt.lower() or 'oda' in prompt.lower():
            rooms = self._extract_rooms(soup)
            if rooms:
                extracted['rooms'] = rooms
                
        return extracted if extracted else None
    
    def _extract_price(self, soup: BeautifulSoup) -> Optional[str]:
        """Extract price from HTML"""
        import re
        
        price_patterns = [
            r'(\d{1,3}(?:\.\d{3})*(?:,\d{2})?\s*(?:TL|₺))',
            r'([\d.,]+)\s*(?:TL|₺|TRY)',
        ]
        
        text = soup.get_text()
        for pattern in price_patterns:
            match = re.search(pattern, text, re.IGNORECASE)
            if match:
                return match.group(1)
        
        return None
    
    def _extract_location(self, soup: BeautifulSoup) -> Optional[str]:
        """Extract location from HTML"""
        location_keywords = ['konum', 'yer', 'adres', 'location', 'il', 'ilçe', 'mahalle']
        
        for keyword in location_keywords:
            elements = soup.find_all(text=lambda text: keyword in text.lower() if text else False)
            for elem in elements:
                parent = elem.parent
                if parent:
                    location_text = parent.get_text(strip=True)
                    if len(location_text) > 5 and len(location_text) < 200:
                        return location_text
        
        return None
    
    def _extract_size(self, soup: BeautifulSoup) -> Optional[str]:
        """Extract size from HTML"""
        import re
        
        size_patterns = [
            r'(\d+)\s*(?:m²|m2|metrekare)',
            r'(\d+)\s*(?:metre\s*kare)',
        ]
        
        text = soup.get_text()
        for pattern in size_patterns:
            match = re.search(pattern, text, re.IGNORECASE)
            if match:
                return f"{match.group(1)} m²"
        
        return None
    
    def _extract_rooms(self, soup: BeautifulSoup) -> Optional[str]:
        """Extract room configuration more accurately"""
        import re
        
        # Look for room patterns near keywords
        room_keywords = ['oda', 'room', 'salon']
        
        for keyword in room_keywords:
            elements = soup.find_all(text=re.compile(f'{keyword}', re.IGNORECASE))
            for elem in elements:
                # Check nearby text for room pattern
                parent_text = elem.parent.get_text() if elem.parent else ""
                match = re.search(r'(\d+)\+(\d+)', parent_text)
                if match and int(match.group(1)) < 10:  # Sanity check
                    return f"{match.group(1)}+{match.group(2)}"
        
        # Fallback to general search
        text = soup.get_text()
        matches = re.findall(r'(\d+)\+(\d+)', text)
        for match in matches:
            if int(match[0]) < 10 and int(match[1]) < 5:  # Reasonable room numbers
                return f"{match[0]}+{match[1]}"
        
        return None

    def _standardize_result(self, result: Dict[str, Any], source: str) -> Dict[str, Any]:
        """Standardize result format"""
        result["_source"] = source
        result["_timestamp"] = datetime.now().isoformat()
        return result


class LangChainStrategy(ScrapingStrategy):
    """LangChain + BeautifulSoup scraping strategy"""
    
    def __init__(self, model_loader=None):
        self.model_loader = model_loader
        
    def is_available(self) -> bool:
        return LANGCHAIN_AVAILABLE
    
    async def scrape(self, url: str, prompt: str, config: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Scrape using LangChain + BeautifulSoup"""
        if not self.is_available():
            return None
            
        try:
            console.log("[green]🔧 Using LangChain + BS4 (Stable & Reliable)...[/green]")
            
            loader = AsyncHtmlLoader([url])
            docs = await loader.aload()
            
            if docs:
                transformer = BeautifulSoupTransformer()
                transformed = transformer.transform_documents(docs)
                
                if transformed:
                    # Extract from HTML
                    soup = BeautifulSoup(transformed[0].page_content, 'html.parser')
                    extracted = self._extract_from_soup(soup)
                    
                    if extracted:
                        console.log("[green]✓ LangChain extraction successful[/green]")
                        return self._standardize_result(extracted, "langchain")
                        
        except Exception as e:
            logger.error(f"LangChain strategy failed: {e}")
            console.log(f"[yellow]⚠ LangChain failed: {e}[/yellow]")
            
        return None
    
    def _extract_from_soup(self, soup) -> Dict[str, Any]:
        """Extract data from BeautifulSoup object"""
        import re
        
        extracted = {}
        text = soup.get_text()
        
        # Extract title
        title = soup.find('title')
        if title:
            extracted['title'] = title.get_text(strip=True)
        
        # Extract price
        price_match = re.search(r'([\d.,]+)\s*(?:TL|₺)', text, re.IGNORECASE)
        if price_match:
            extracted['price'] = price_match.group(1)
        
        # Extract size
        size_match = re.search(r'(\d+)\s*(?:m²|m2|metrekare)', text, re.IGNORECASE)
        if size_match:
            extracted['size'] = f"{size_match.group(1)} m²"
        
        # Extract rooms
        room_match = re.search(r'(\d+)\+(\d+)', text)
        if room_match:
            extracted['rooms'] = f"{room_match.group(1)}+{room_match.group(2)}"
        
        return extracted if extracted else None
    
    def _standardize_result(self, result: Dict[str, Any], source: str) -> Dict[str, Any]:
        """Standardize result format"""
        result["_source"] = source
        result["_timestamp"] = datetime.now().isoformat()
        return result


class TraditionalStrategy(ScrapingStrategy):
    """Traditional BeautifulSoup scraping strategy"""
    
    def is_available(self) -> bool:
        return True  # Always available as fallback
    
    async def scrape(self, url: str, prompt: str, config: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Scrape using traditional BeautifulSoup"""
        try:
            console.log("[yellow]📜 Using Traditional Scraping (Basic Fallback)...[/yellow]")
            
            async with aiohttp.ClientSession() as session:
                async with session.get(url, timeout=30) as response:
                    if response.status == 200:
                        html = await response.text()
                        soup = BeautifulSoup(html, 'html.parser')
                        
                        extracted = self._basic_extraction(soup)
                        
                        if extracted:
                            console.log("[green]✓ Traditional extraction successful[/green]")
                            return self._standardize_result(extracted, "traditional")
                            
        except Exception as e:
            logger.error(f"Traditional scraping failed: {e}")
            console.log(f"[red]✗ Traditional scraping failed: {e}[/red]")
            
        return None
    
    def _basic_extraction(self, soup: BeautifulSoup) -> Dict[str, Any]:
        """Basic data extraction from HTML"""
        extracted = {}
        
        title = soup.find('title')
        if title:
            extracted['title'] = title.get_text(strip=True)
        
        meta_desc = soup.find('meta', {'name': 'description'})
        if meta_desc:
            extracted['description'] = meta_desc.get('content', '')
        
        text = soup.get_text()[:5000]
        extracted['content_preview'] = text
        
        import re
        
        price_match = re.search(r'([\d.,]+)\s*(?:TL|₺)', text)
        if price_match:
            extracted['possible_price'] = price_match.group(1)
        
        size_match = re.search(r'(\d+)\s*(?:m²|m2)', text)
        if size_match:
            extracted['possible_size'] = f"{size_match.group(1)} m²"
        
        room_match = re.search(r'(\d+)\+(\d+)', text)
        if room_match:
            extracted['possible_rooms'] = f"{room_match.group(1)}+{room_match.group(2)}"
        
        return extracted if extracted else None
    
    def _standardize_result(self, result: Dict[str, Any], source: str) -> Dict[str, Any]:
        """Standardize result format"""
        result["_source"] = source
        result["_timestamp"] = datetime.now().isoformat()
        result["_quality"] = "low"
        return result

class AgentQLStrategy(ScrapingStrategy):
    """AgentQL scraping strategy using natural language queries"""
    
    def __init__(self):
        self.api_key = None
        if AGENTQL_AVAILABLE:
            import os
            self.api_key = os.getenv("AGENTQL_API_KEY")
            if self.api_key:
                # Set API key for AgentQL
                import agentql
                agentql.configure(api_key=self.api_key)
    
    def is_available(self) -> bool:
        """Check if AgentQL is available"""
        return AGENTQL_AVAILABLE
    
    async def scrape(self, url: str, prompt: str, config: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Scrape using AgentQL with natural language queries"""
        if not self.is_available():
            return None
        
        try:
            console.log("[magenta]🎯 Using AgentQL (Natural Language Query)...[/magenta]")
            
            # Run synchronous AgentQL in thread pool
            result = await asyncio.to_thread(
                self._scrape_sync,
                url,
                prompt,
                config
            )
            
            if result:
                console.log("[green]✓ AgentQL extraction successful[/green]")
                return self._standardize_result(result, "agentql")
                    
        except Exception as e:
            logger.error(f"AgentQL failed: {e}")
            console.log(f"[yellow]⚠ AgentQL failed: {e}[/yellow]")
        
        return None
    
    def _scrape_sync(self, url: str, prompt: str, config: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Synchronous scraping using AgentQL (runs in thread)"""
        from playwright.sync_api import sync_playwright
        
        try:
            with sync_playwright() as p:
                # Launch browser
                browser = p.chromium.launch(
                    headless=config.get('headless', True)
                )
                
                # Create page and wrap it with AgentQL
                page = agentql.wrap(browser.new_page())
                
                # Navigate to URL
                page.goto(url, wait_until='networkidle', timeout=30000)
                
                # Generate and execute query
                query = self._generate_agentql_query(prompt, config)
                
                console.log(f"[dim]Executing AgentQL query...[/dim]")
                
                # Execute the query using query_data
                response = page.query_data(query)
                
                browser.close()
                
                # Process response
                if response:
                    return self._process_agentql_response(response)
                
        except Exception as e:
            logger.error(f"AgentQL sync scraping failed: {e}")
            
        return None
    
    def _generate_agentql_query(self, prompt: str, config: Dict[str, Any]) -> str:
        """Generate AgentQL query from prompt"""
        
        # Check if custom query is provided
        if config.get('agentql_query'):
            return config['agentql_query']
        
        prompt_lower = prompt.lower()
        
        # Property listing query
        if any(word in prompt_lower for word in ['property', 'emlak', 'konut', 'ev', 'daire', 'satilik', 'kiralik']):
            return self._generate_property_query(prompt_lower)
        
        # Market data query
        elif any(word in prompt_lower for word in ['market', 'piyasa', 'statistics', 'istatistik', 'endeks']):
            return self._generate_market_query(prompt_lower)
        
        # News query
        elif any(word in prompt_lower for word in ['news', 'haber', 'article', 'makale']):
            return self._generate_news_query(prompt_lower)
        
        # Default general extraction
        else:
            return """
            {
                page_content {
                    title
                    main_text
                    data_points[] {
                        label
                        value
                    }
                    links[] {
                        text
                        url
                    }
                }
            }
            """
    
    def _generate_property_query(self, prompt: str) -> str:
        """Generate property-specific AgentQL query"""
        
        # Extract filters from prompt
        filters = []
        
        # City filter
        cities = {
            'ankara': 'Ankara',
            'istanbul': 'İstanbul', 
            'izmir': 'İzmir',
            'antalya': 'Antalya',
            'bursa': 'Bursa',
            'adana': 'Adana',
            'konya': 'Konya'
        }
        
        for city_key, city_name in cities.items():
            if city_key in prompt or city_name.lower() in prompt:
                filters.append(f'in city "{city_name}"')
                break
        
        # Room configuration
        import re
        room_patterns = [
            (r'(\d+)\+(\d+)', 'exactly {0} rooms'),
            (r'(\d+)\s*oda', 'with {0} bedrooms'),
            (r'stüdyo|studio', 'studio apartments')
        ]
        
        for pattern, template in room_patterns:
            match = re.search(pattern, prompt)
            if match:
                if pattern == r'(\d+)\+(\d+)':
                    filters.append(template.format(match.group(0)))
                elif pattern == r'(\d+)\s*oda':
                    filters.append(template.format(match.group(1)))
                else:
                    filters.append(template)
                break
        
        # Area/Size filter
        size_match = re.search(r'(\d+)\s*(?:m²|m2|metrekare)', prompt)
        if size_match:
            size = size_match.group(1)
            if 'minimum' in prompt or 'en az' in prompt:
                filters.append(f'minimum area {size} sqm')
            elif 'maximum' in prompt or 'en fazla' in prompt:
                filters.append(f'maximum area {size} sqm')
            else:
                filters.append(f'area around {size} sqm')
        
        # Price filter
        price_match = re.search(r'([\d.,]+)\s*(?:TL|₺|bin|milyon)', prompt)
        if price_match:
            price = price_match.group(1).replace('.', '').replace(',', '')
            if 'bin' in prompt:
                price = str(int(price) * 1000)
            elif 'milyon' in prompt:
                price = str(int(price) * 1000000)
            
            if 'maximum' in prompt or 'en fazla' in prompt:
                filters.append(f'maximum price {price} TL')
            elif 'minimum' in prompt or 'en az' in prompt:
                filters.append(f'minimum price {price} TL')
        
        # Property type
        if 'daire' in prompt or 'apartment' in prompt:
            filters.append('only apartments')
        elif 'villa' in prompt:
            filters.append('only villas')
        elif 'müstakil' in prompt or 'detached' in prompt:
            filters.append('only detached houses')
        
        # Sale or rent
        if 'satilik' in prompt or 'satılık' in prompt:
            filters.append('for sale')
        elif 'kiralik' in prompt or 'kiralık' in prompt:
            filters.append('for rent')
        
        # Build the filter string
        filter_str = ', '.join(filters) if filters else ''
        
        # Limit results
        limit = 20
        limit_match = re.search(r'(\d+)\s*(?:tane|adet|sonuç|result)', prompt)
        if limit_match:
            limit = min(int(limit_match.group(1)), 50)
        
        return f"""
        {{
            listings({filter_str}, show at most {limit} results)[] {{
                property_details {{
                    title
                    price
                    currency
                    price_per_sqm
                    listing_id
                    listing_date
                    url
                }}
                location_info {{
                    city
                    district
                    neighborhood
                    full_address
                    map_link
                }}
                property_features {{
                    property_type
                    room_configuration
                    number_of_rooms
                    number_of_bathrooms
                    area_sqm
                    floor_number
                    total_floors
                    building_age
                    heating_type
                    furnished_status
                    balcony
                    elevator
                    parking
                }}
                description
                seller_info {{
                    name
                    type
                    phone
                    verified_status
                }}
                images[] {{
                    url
                    caption
                }}
            }}
        }}
        """
    
    def _generate_market_query(self, prompt: str) -> str:
        """Generate market data AgentQL query"""
        
        # Check for specific metrics mentioned
        metrics = []
        if 'fiyat' in prompt or 'price' in prompt:
            metrics.append('price_trends')
        if 'satış' in prompt or 'sales' in prompt:
            metrics.append('sales_volume')
        if 'kira' in prompt or 'rent' in prompt:
            metrics.append('rental_yields')
        if 'endeks' in prompt or 'index' in prompt:
            metrics.append('market_indices')
        
        metrics_str = ', '.join(metrics) if metrics else 'all_metrics'
        
        return f"""
        {{
            market_report {{
                overview {{
                    title
                    report_date
                    summary
                    source
                }}
                statistics({metrics_str})[] {{
                    metric_name
                    current_value
                    previous_value
                    change_amount
                    change_percentage
                    period
                    unit
                }}
                price_indices[] {{
                    index_name
                    current_value
                    previous_month_value
                    previous_year_value
                    monthly_change
                    yearly_change
                    base_year
                }}
                regional_breakdown[] {{
                    region_name
                    average_price_per_sqm
                    total_sales
                    average_property_size
                    most_popular_type
                    price_trend
                }}
                market_trends[] {{
                    trend_description
                    impact_level
                    affected_segments[]
                }}
                forecast {{
                    next_quarter_prediction
                    yearly_outlook
                    key_factors[]
                }}
            }}
        }}
        """
    
    def _generate_news_query(self, prompt: str) -> str:
        """Generate news article AgentQL query"""
        return """
        {
            article {
                headline
                subheadline
                author {
                    name
                    title
                    profile_link
                }
                publication_info {
                    date
                    time
                    last_updated
                    reading_time
                }
                categories[]
                tags[]
                content {
                    summary
                    full_text
                    key_points[]
                    quotes[] {
                        text
                        speaker
                        context
                    }
                }
                media {
                    featured_image {
                        url
                        caption
                        credit
                    }
                    gallery[] {
                        url
                        caption
                    }
                    videos[] {
                        url
                        title
                        duration
                    }
                }
                related_articles[] {
                    title
                    url
                    thumbnail
                    date
                }
                engagement {
                    views
                    shares
                    comments_count
                }
            }
        }
        """
    
    def _process_agentql_response(self, response: Any) -> Dict[str, Any]:
        """Process AgentQL response into dictionary format"""
        
        # If response is a list (which is the actual case), wrap it
        if isinstance(response, list):
            return {
                'listings': response,
                'total_count': len(response)
            }
        
        # If response is already a dict, return it
        if isinstance(response, dict):
            return response
        
        # Convert object to dict recursively
        return self._object_to_dict(response)
        
    def _object_to_dict(self, obj: Any) -> Any:
        """Recursively convert object to dictionary"""
        
        # Handle None
        if obj is None:
            return None
        
        # Handle primitives
        if isinstance(obj, (str, int, float, bool)):
            return obj
        
        # Handle lists
        if isinstance(obj, list):
            return [self._object_to_dict(item) for item in obj]
        
        # Handle dicts
        if isinstance(obj, dict):
            return {k: self._object_to_dict(v) for k, v in obj.items()}
        
        # Handle objects with __dict__
        if hasattr(obj, '__dict__'):
            return {
                k: self._object_to_dict(v) 
                for k, v in obj.__dict__.items() 
                if not k.startswith('_')
            }
        
        # Default: convert to string
        return str(obj)
    
    def _standardize_result(self, result: Dict[str, Any], source: str) -> Dict[str, Any]:
        """Standardize AgentQL result format"""
        standardized = {
            "_source": source,
            "_timestamp": datetime.now().isoformat(),
            "_extraction_method": "agentql_natural_language"
        }
        
        # Handle listings specially
        if 'listings' in result:
            listings = result['listings']
            print(listings)
            if isinstance(listings, list) and len(listings) > 0:
                # Extract first listing as main result
                first = listings[0]
                
                # Flatten nested structure
                if 'property_details' in first:
                    details = first['property_details']
                    standardized['title'] = details.get('title')
                    standardized['price'] = details.get('price')
                    standardized['url'] = details.get('url')
                    standardized['listing_id'] = details.get('listing_id')
                
                if 'location_info' in first:
                    loc = first['location_info']
                    standardized['location'] = {
                        'city': loc.get('city'),
                        'district': loc.get('district'),
                        'neighborhood': loc.get('neighborhood'),
                        'address': loc.get('full_address')
                    }
                
                if 'property_features' in first:
                    features = first['property_features']
                    standardized['rooms'] = features.get('room_configuration') or features.get('number_of_rooms')
                    standardized['size'] = features.get('area_sqm')
                    standardized['floor'] = features.get('floor_number')
                    standardized['building_age'] = features.get('building_age')
                    standardized['property_type'] = features.get('property_type')
                
                # Store all listings
                standardized['_all_listings'] = listings
                standardized['_total_count'] = len(listings)
        
        # Handle market data
        elif 'market_report' in result:
            report = result['market_report']
            standardized['market_data'] = report
            
            # Extract key metrics
            if 'statistics' in report:
                standardized['key_statistics'] = report['statistics']
            
            if 'price_indices' in report:
                standardized['indices'] = report['price_indices']
        
        # Handle news articles
        elif 'article' in result:
            article = result['article']
            standardized['headline'] = article.get('headline')
            standardized['content'] = article.get('content', {}).get('full_text')
            standardized['author'] = article.get('author')
            standardized['date'] = article.get('publication_info', {}).get('date')
            standardized['_full_article'] = article
        
        # Handle generic content
        else:
            standardized.update(result)
        
        return standardized

class AIScraper:
    """
    AI-powered scraper with multiple strategies and intelligent fallback
    (This is actually the HybridAIScraper but keeping the name for compatibility)
    """
    
    def __init__(self, model_config: Optional[Dict[str, Any]] = None):
        """Initialize AI scraper with hybrid capabilities"""
        self.model_config = model_config or self._get_default_config()
        self.model_loader = None
        self.config = SCRAPING_CONFIG if CONFIG_AVAILABLE else ScrapingConfig()
        
        # Initialize strategies
        self.strategies = {}
        
        # Add strategies based on what's defined in ScrapingTool
        if hasattr(ScrapingTool, 'SCRAPEGRAPHAI'):
            self.strategies[ScrapingTool.SCRAPEGRAPHAI] = ScrapegraphAIStrategy(self.model_loader)
        
        if hasattr(ScrapingTool, 'CRAWL4AI'):
            self.strategies[ScrapingTool.CRAWL4AI] = Crawl4AIStrategy()
        
        if hasattr(ScrapingTool, 'LANGCHAIN_BS4'):
            self.strategies[ScrapingTool.LANGCHAIN_BS4] = LangChainStrategy(self.model_loader)
        
        if hasattr(ScrapingTool, 'TRADITIONAL'):
            self.strategies[ScrapingTool.TRADITIONAL] = TraditionalStrategy()
        
        # Add AgentQL if available
        if AGENTQL_AVAILABLE:
            try:
                # Create the enum value if it doesn't exist
                if not hasattr(ScrapingTool, 'AGENTQL'):
                    # For dynamic enum extension (might not work with all Python versions)
                    ScrapingTool.AGENTQL = "agentql"
                
                self.strategies[ScrapingTool.AGENTQL] = AgentQLStrategy()
            except Exception as e:
                console.log(f"[yellow]Could not add AgentQL strategy: {e}[/yellow]")
        
        # Check availability
        self.check_availability()
    
    def _get_default_config(self) -> Dict[str, Any]:
        """Get default model configuration"""
        return {
            "llm": {
                "model": "gpt-3.5-turbo",
                "temperature": 0.1,
                "max_tokens": 2000
            },
            "embeddings": {
                "model": "text-embedding-ada-002"
            },
            "verbose": False,
            "headless": True
        }
    
    def check_availability(self):
        """Check which scraping tools are available"""
        console.print("\n[bold cyan]🔍 Checking Scraping Tools Availability:[/bold cyan]")
        
        for tool, strategy in self.strategies.items():
            is_available = strategy.is_available()
            tool_name = tool.value if hasattr(tool, 'value') else str(tool)
            status = "[green]✓ Available[/green]" if is_available else "[red]✗ Not Installed[/red]"
            console.print(f"  {tool_name}: {status}")
        console.print("")
    
    # Add method to check if AgentQL is available
    def has_agentql(self) -> bool:
        """Check if AgentQL strategy is available"""
        for tool in self.strategies:
            if hasattr(tool, 'value') and tool.value == 'agentql':
                return True
            elif str(tool) == 'agentql':
                return True
        return False
    # ========== Compatibility Methods (Original AIScraper interface) ==========
    
    async def extract_property_data(self, url: str) -> Optional[Dict[str, Any]]:
        """
        Extract property data from URL using AI
        (Compatibility method for original AIScraper interface)
        
        Args:
            url: Property listing URL
            
        Returns:
            Extracted property data
        """
        prompt = "Extract property details including price, location, size, rooms, building age, floor"
        return await self.scrape_property(url, custom_prompt=prompt)
    
    async def extract_market_data(self, url: str) -> Optional[Dict[str, Any]]:
        """
        Extract market data and statistics from URL
        (Compatibility method for original AIScraper interface)
        
        Args:
            url: Market report or statistics page URL
            
        Returns:
            Extracted market data
        """
        prompt = """Extract market statistics and data:
        - Market indicators and indices
        - Price trends and changes
        - Sales volumes and transactions
        - Supply and demand metrics"""
        
        result = await self.scrape_property(url, custom_prompt=prompt)
        if result:
            return self._standardize_market_data(result)
        return None
    
    async def extract_news_content(self, url: str) -> Optional[Dict[str, Any]]:
        """
        Extract news article content
        (Compatibility method for original AIScraper interface)
        
        Args:
            url: News article URL
            
        Returns:
            Extracted article content
        """
        prompt = """Extract news article information:
        - Title
        - Publication date
        - Author
        - Summary
        - Full article text"""
        
        result = await self.scrape_property(url, custom_prompt=prompt)
        if result:
            return self._standardize_news_data(result)
        return None
    
    async def search_and_extract(
        self,
        query: str,
        max_results: int = 10
    ) -> List[Dict[str, Any]]:
        """
        Search for information and extract data
        (Compatibility method for original AIScraper interface)
        
        Args:
            query: Search query
            max_results: Maximum number of results
            
        Returns:
            List of extracted data
        """
        # Simplified implementation
        logger.info(f"Search functionality: {query}")
        return []
    
    # ========== New Hybrid Methods ==========
    
    async def scrape_property(
        self,
        url: str,
        custom_prompt: Optional[str] = None,
        force_tool: Optional[ScrapingTool] = None
    ) -> Optional[Dict[str, Any]]:
        """
        Scrape property data with intelligent fallback
        
        Args:
            url: URL to scrape
            custom_prompt: Custom extraction prompt
            force_tool: Force specific tool (bypasses priority)
            
        Returns:
            Extracted property data or None
        """
        prompt = custom_prompt or self.config.turkish_prompts.get(
            "property_extraction",
            "Extract property details including price, location, size, rooms"
        )
        
        # If specific tool is forced
        if force_tool:
            if force_tool in self.strategies:
                strategy = self.strategies[force_tool]
                if strategy.is_available():
                    console.print(f"[cyan]🎯 Forced to use: {force_tool}[/cyan]")
                    return await self._try_strategy(strategy, url, prompt, force_tool)
                else:
                    console.print(f"[red]✗ {force_tool.value} is not available[/red]")
            return None
        
        # Try tools in priority order
        for tool in self.config.enabled_tools:
            if tool not in self.strategies:
                continue
                
            strategy = self.strategies[tool]
            
            if not strategy.is_available():
                console.log(f"[dim]Skipping {tool.value} (not available)[/dim]")
                continue
            
            result = await self._try_strategy(strategy, url, prompt, tool)
            
            if result:
                return result
            
            if not self.config.auto_fallback:
                console.log("[yellow]Auto-fallback disabled, stopping[/yellow]")
                break
        
        console.log("[red]✗ All scraping strategies failed[/red]")
        return None
    
    async def _try_strategy(
        self,
        strategy: ScrapingStrategy,
        url: str,
        prompt: str,
        tool: ScrapingTool
    ) -> Optional[Dict[str, Any]]:
        """Try a specific scraping strategy with retries"""
        
        for attempt in range(self.config.max_retries_per_tool):
            try:
                # Get tool-specific config
                if tool == ScrapingTool.SCRAPEGRAPHAI:
                    config = self.config.scrapegraphai_config
                elif tool == ScrapingTool.CRAWL4AI:
                    config = self.config.crawl4ai_config
                elif tool == ScrapingTool.LANGCHAIN_BS4:
                    config = self.config.langchain_config
                else:
                    config = {}
                
                result = await strategy.scrape(url, prompt, config)
                
                if result:
                    if self._validate_result(result):
                        console.log(f"[green]✓ {tool} succeeded[/green]")
                        return result
                    else:
                        console.log(f"[yellow]⚠ {tool} returned invalid data[/yellow]")
                        
            except Exception as e:
                logger.error(f"{tool} attempt {attempt+1} failed: {e}")
                
            if attempt < self.config.max_retries_per_tool - 1:
                await asyncio.sleep(2 ** attempt)
        
        return None
    
    def _validate_result(self, result: Dict[str, Any]) -> bool:
        """Validate scraped result has minimum required data"""
        if not result:
            return False
        
        # تخفيف الشروط - قبول أي حقل مفيد
        useful_fields = [
            'price', 'location', 'size', 'rooms',
            'title', 'description', 'possible_price',
            'fiyat', 'konum', 'alan', 'oda',  # حقول تركية
            'content_preview'  # محتوى عام
        ]
        
        found = sum(1 for field in useful_fields if field in result and result[field])
        return found >= 1 

    
    # ========== Helper Methods ==========
    
    def _standardize_property_data(self, raw_data: Dict[str, Any]) -> Dict[str, Any]:
        """Standardize extracted property data"""
        standardized = {
            "source": "ai_extraction",
            "extracted_at": datetime.now().isoformat(),
            "confidence": 0.8,
            "library": raw_data.get("_source", "unknown")
        }
        
        field_mapping = {
            "title": ["title", "başlık", "ad"],
            "price": ["price", "fiyat", "tutar", "possible_price"],
            "location": ["location", "konum", "yer", "adres"],
            "size": ["size", "alan", "m2", "metrekare", "possible_size"],
            "rooms": ["rooms", "oda", "oda_sayısı", "possible_rooms"],
            "age": ["age", "yaş", "bina_yaşı"],
            "floor": ["floor", "kat"],
            "description": ["description", "açıklama", "detay"]
        }

        
        for standard_field, possible_fields in field_mapping.items():
            for field in possible_fields:
                if field in raw_data:
                    standardized[standard_field] = raw_data[field]
                    break
        
        for key, value in raw_data.items():
            if key not in standardized and not key.startswith("_"):
                standardized[f"extra_{key}"] = value
        
        return standardized
    
    def _standardize_market_data(self, raw_data: Dict[str, Any]) -> Dict[str, Any]:
        """Standardize extracted market data"""
        return {
            "source": "ai_extraction",
            "extracted_at": datetime.now().isoformat(),
            "data": raw_data,
            "type": "market_statistics",
            "library": raw_data.get("_source", "unknown")
        }
    
    def _standardize_news_data(self, raw_data: Dict[str, Any]) -> Dict[str, Any]:
        """Standardize extracted news data"""
        return {
            "source": "ai_extraction",
            "extracted_at": datetime.now().isoformat(),
            "title": raw_data.get("title", ""),
            "content": raw_data.get("full_text", raw_data.get("text", "")),
            "summary": raw_data.get("summary", ""),
            "published": raw_data.get("date", raw_data.get("publication_date")),
            "sentiment": raw_data.get("sentiment", "neutral"),
            "tags": raw_data.get("tags", raw_data.get("topics", [])),
            "type": "news_article",
            "library": raw_data.get("_source", "unknown")
        }

    async def scrape_with_agentql(
        self,
        url: str,
        query: str,
        headless: bool = True
    ) -> Optional[Dict[str, Any]]:
        """
        Scrape using AgentQL with custom query
        
        Args:
            url: URL to scrape
            query: AgentQL query string
            headless: Run browser in headless mode
            
        Returns:
            Extracted data or None
        """
        if ScrapingTool.AGENTQL not in self.strategies:
            console.print("[red]AgentQL is not available[/red]")
            return None
        
        strategy = self.strategies[ScrapingTool.AGENTQL]
        if not strategy.is_available():
            console.print("[red]AgentQL is not properly configured[/red]")
            console.print("[yellow]Please set AGENTQL_API_KEY in .env file[/yellow]")
            return None
        
        config = {
            'agentql_query': query,
            'headless': headless
        }
        
        return await strategy.scrape(url, "", config)

# ========== Direct Testing Interface ==========
async def main():
    """Main function for direct testing"""
    import argparse
    
    parser = argparse.ArgumentParser(description='AI-Powered Smart Scraper with AgentQL')
    parser.add_argument('url', nargs='?', 
                       default='https://www.emlakjet.com/satilik-konut',
                       help='URL to scrape')
    parser.add_argument('--method', '-m', 
                       choices=['property', 'market', 'news', 'search', 'scrape', 'agentql'],
                       default='property',
                       help='Scraping method to use')
    parser.add_argument('--tool', '-t',
                       choices=['scrapegraphai', 'crawl4ai', 'langchain', 'traditional', 'agentql'],
                       help='Force specific scraping tool')
    parser.add_argument('--prompt', '-p',
                       help='Custom extraction prompt')
    parser.add_argument('--agentql-query', '-aq',
                       help='Custom AgentQL query (for agentql method)')
    parser.add_argument('--query', '-q',
                       help='Search query (for search method)')
    parser.add_argument('--json', action='store_true',
                       help='Output as JSON only')
    parser.add_argument('--no-headless', action='store_true',
                       help='Run browser in visible mode (for debugging)')
    
    args = parser.parse_args()
    
    # Initialize scraper
    console.print("\n[bold cyan]🚀 AI-Powered Smart Scraper[/bold cyan]")
    console.print(f"[dim]URL: {args.url}[/dim]")
    console.print(f"[dim]Method: {args.method}[/dim]\n")
    
    scraper = AIScraper()
    
    # Map tool name to enum
    force_tool = None
    if args.tool:
        tool_map = {
            'scrapegraphai': ScrapingTool.SCRAPEGRAPHAI,
            'crawl4ai': ScrapingTool.CRAWL4AI,
            'langchain': ScrapingTool.LANGCHAIN_BS4,
            'traditional': ScrapingTool.TRADITIONAL,
            'agentql': ScrapingTool.AGENTQL
        }
        force_tool = tool_map.get(args.tool)
    
    # Execute based on method
    result = None
    
    if args.method == 'agentql':
        console.print("[magenta]🎯 Using AgentQL natural language query...[/magenta]\n")
        
        # Use custom query if provided
        query = args.agentql_query
        prompt = args.prompt or "Extract property listings with all details"
        
        if query:
            console.print(f"[dim]Custom Query: {query}[/dim]\n")
        else:
            console.print(f"[dim]Prompt: {prompt}[/dim]\n")
        
        result = await scraper.scrape_with_agentql(
            args.url,
            query=query,
            prompt=prompt,
            headless=not args.no_headless
        )
    
    elif args.method == 'property':
        console.print("[yellow]📊 Extracting property data...[/yellow]\n")
        if force_tool:
            result = await scraper.scrape_property(args.url, force_tool=force_tool)
        else:
            result = await scraper.extract_property_data(args.url)
        
    elif args.method == 'market':
        console.print("[yellow]📈 Extracting market data...[/yellow]\n")
        result = await scraper.extract_market_data(args.url)
        
    elif args.method == 'news':
        console.print("[yellow]📰 Extracting news content...[/yellow]\n")
        result = await scraper.extract_news_content(args.url)
        
    elif args.method == 'search':
        query = args.query or "Istanbul real estate prices"
        console.print(f"[yellow]🔍 Searching: {query}[/yellow]\n")
        results = await scraper.search_and_extract(query)
        result = {"results": results, "count": len(results)}
        
    elif args.method == 'scrape':
        console.print("[yellow]🎯 Custom scraping...[/yellow]\n")
        prompt = args.prompt or "Extract all relevant information from this page"
        result = await scraper.scrape_property(
            args.url, 
            custom_prompt=prompt,
            force_tool=force_tool
        )
    
    # Display results
    if result:
        if args.json:
            # JSON only output
            print(json.dumps(result, indent=2, ensure_ascii=False))
        else:
            # Pretty output
            console.print("\n[bold green]✅ Extraction Successful![/bold green]\n")
            
             # Special handling for AgentQL results with listings
            if '_all_listings' in result:
                console.print(f"[bold]Found {result.get('_total_listings', 0)} listings[/bold]\n")
                
                # Show first listing details
                console.print("[bold]📍 First Listing:[/bold]")
                for key, value in result.items():
                    if not key.startswith('_') and key != 'location':
                        console.print(f"  {key}: {value}")
                
                if 'location' in result and isinstance(result['location'], dict):
                    console.print("  Location:")
                    for loc_key, loc_val in result['location'].items():
                        if loc_val:
                            console.print(f"    {loc_key}: {loc_val}")
                
                console.print("\n[dim]💡 Full listings available in JSON output (--json flag)[/dim]")
            
            # Show key fields
            if isinstance(result, dict):
                # Standardized property data
                if 'price' in result or 'location' in result:
                    console.print("[bold]📍 Property Information:[/bold]")
                    if 'title' in result:
                        console.print(f"  Title: {result['title']}")
                    if 'price' in result:
                        console.print(f"  💰 Price: {result['price']}")
                    if 'location' in result:
                        console.print(f"  📍 Location: {result['location']}")
                    if 'size' in result:
                        console.print(f"  📏 Size: {result['size']}")
                    if 'rooms' in result:
                        console.print(f"  🏠 Rooms: {result['rooms']}")
                    if 'floor' in result:
                        console.print(f"  🏢 Floor: {result['floor']}")
                    if 'age' in result:
                        console.print(f"  📅 Age: {result['age']}")
                
                # Metadata
                console.print("\n[bold]📊 Metadata:[/bold]")
                if 'source' in result:
                    console.print(f"  Source: {result['source']}")
                if 'library' in result:
                    console.print(f"  Library: {result['library']}")
                if '_source' in result:
                    console.print(f"  Scraper: {result['_source']}")
                if 'confidence' in result:
                    console.print(f"  Confidence: {result['confidence']:.2%}")
                if 'extracted_at' in result:
                    console.print(f"  Extracted: {result['extracted_at']}")
                
                # Extra fields
                extras = {k: v for k, v in result.items() 
                         if k.startswith('extra_') or k.startswith('possible_')}
                if extras:
                    console.print("\n[bold]🔍 Additional Fields:[/bold]")
                    for key, value in extras.items():
                        clean_key = key.replace('extra_', '').replace('possible_', '').replace('_', ' ').title()
                        console.print(f"  {clean_key}: {value}")
                
                # Full JSON option
                console.print("\n[dim]💡 Tip: Use --json flag for full JSON output[/dim]")
    else:
        console.print("[bold red]❌ Extraction failed![/bold red]")
        console.print("[yellow]Please check the URL and try again[/yellow]")
        console.print("[dim]Try using --tool flag to force a specific scraper[/dim]")
    
    return result


if __name__ == "__main__":
    # Run with command line arguments
    #$env:PYTHONPATH="D:\Phd\RE-FusionX\src\backend"
    #python src/backend/app/data_collectors/smart_collectors/ai_scraper.py -tool scrapegraphai
    result = asyncio.run(main())
    
    # Exit with appropriate code
    sys.exit(0 if result else 1)

