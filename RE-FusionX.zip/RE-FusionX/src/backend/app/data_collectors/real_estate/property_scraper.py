"""
Basic Property Scraper
======================
Traditional web scraping for property data
"""

import asyncio
from typing import Dict, Any, List, Optional
from datetime import datetime
import aiohttp
from bs4 import BeautifulSoup

from app.data_collectors.base.base_collector import BaseCollector, CollectorConfig, CollectionResult
from app.core.logging import logger
from app.core.storage.integration import StorageIntegration
from app.core.storage.unified_cache import CacheType


class PropertyScraper(BaseCollector):
    """
    Basic property scraper using traditional methods
    """
    
    def __init__(self, config: CollectorConfig):
        """Initialize property scraper"""
        super().__init__(config)
        
        self._storage = None
        self._cache = None
        
        self.source_configs = {
            "sahibinden": {
                "base_url": "https://www.sahibinden.com",
                "search_path": "/satilik-daire",
                "selectors": {
                    "listings": "tr.searchResultsItem",
                    "title": "a.classifiedTitle",
                    "price": "td.searchResultsPriceValue",
                    "location": "td.searchResultsLocationValue",
                    "attributes": "td.searchResultsAttributeValue",
                    "date": "td.searchResultsDateValue"
                }
            },
            "emlakjet": {
                "base_url": "https://www.emlakjet.com",
                "search_path": "/satilik-konut",
                "selectors": {
                    "listings": "div._3qUI9q",
                    "title": "h3._2Nely4",
                    "price": "span._2TxNQv",
                    "location": "div._2wVG12",
                    "attributes": "div._3_RDTP"
                }
            }
        }

    @property
    def storage(self):
        """Lazy load storage"""
        if self._storage is None:
            from app.core.storage.integration import StorageIntegration
            self._storage = StorageIntegration.get_storage()
        return self._storage
    
    @property
    def cache(self):
        """Lazy load cache"""
        if self._cache is None:
            from app.core.storage.integration import StorageIntegration
            self._cache = StorageIntegration.get_cache()
        return self._cache
        
    async def collect(self, **kwargs) -> CollectionResult:
        """
        Collect property data with unified storage
        """
        location = kwargs.get("location", "istanbul")
        property_type = kwargs.get("property_type", "daire")
        page_limit = kwargs.get("page_limit", 5)
        
        # Generate cache key using new system
        cache_key = self.cache.generate_key(
            CacheType.PROPERTY,
            f"scraper_{self.config.source.value}_{location}",
            {"type": property_type, "pages": page_limit}
        )
        
        # Check unified cache first
        cached_data = await self.cache.get(cache_key, CacheType.PROPERTY)
        
        if cached_data:
            logger.info(f"Cache hit for {location} from unified cache")
            return CollectionResult(
                success=True,
                data=cached_data,
                source=self.config.source,
                metadata={"from_cache": True}
            )
        
        try:
            # Check storage for existing data
            stored_properties = await self.storage.get_properties(
                location=location,
                filters={"property_type": property_type, "limit": page_limit * 20}
            )
            
            if stored_properties:
                logger.info(f"Found {len(stored_properties)} properties in storage")
                # Cache for next time
                await self.cache.set(cache_key, stored_properties, CacheType.PROPERTY)
                
                return CollectionResult(
                    success=True,
                    data=stored_properties,
                    source=self.config.source,
                    metadata={"from_storage": True}
                )
            
            # If no cached/stored data, scrape
            properties = []
            source_name = self.config.source.value
            
            if source_name in self.source_configs:
                config = self.source_configs[source_name]
                
                for page in range(1, page_limit + 1):
                    page_properties = await self._scrape_page(
                        config,
                        location,
                        property_type,
                        page
                    )
                    properties.extend(page_properties)
                    
                    # Rate limiting
                    await asyncio.sleep(1)
            
            # Save to unified storage
            if properties:
                await self.storage.save_properties(
                    properties,
                    location,
                    source_name
                )
                
                # Cache the results
                await self.cache.set(cache_key, properties, CacheType.PROPERTY)
            
            return CollectionResult(
                success=True,
                data=properties,
                source=self.config.source,
                quality_score=self.calculate_quality_score(properties)
            )
            
        except Exception as e:
            logger.error(f"Property scraping failed: {e}")
            return CollectionResult(
                success=False,
                error=str(e),
                source=self.config.source
            )
            
    async def _scrape_page(
        self,
        config: Dict[str, Any],
        location: str,
        property_type: str,
        page: int
    ) -> List[Dict[str, Any]]:
        """Scrape a single page of listings"""
        properties = []
        
        # Build URL
        url = f"{config['base_url']}{config['search_path']}/{location}"
        if page > 1:
            url += f"?pagingOffset={(page-1)*20}"
        
        # Fetch page
        html = await self.fetch_with_retry(url)
        if not html:
            return properties
        
        # Parse HTML
        soup = BeautifulSoup(html, 'html.parser')
        listings = soup.select(config['selectors']['listings'])
        
        for listing in listings:
            property_data = self._extract_property_data(listing, config['selectors'])
            if property_data:
                property_data['source'] = config['base_url']
                property_data['scraped_at'] = datetime.now().isoformat()
                properties.append(property_data)
        
        return properties
    
    def _extract_property_data(
        self,
        listing,
        selectors: Dict[str, str]
    ) -> Optional[Dict[str, Any]]:
        """Extract property data from listing element"""
        try:
            data = {}
            
            # Title
            title_elem = listing.select_one(selectors.get('title'))
            if title_elem:
                data['title'] = title_elem.get_text(strip=True)
                href = title_elem.get('href')
                if href:
                    data['url'] = href if href.startswith('http') else f"{self.source_configs[self.config.source.value]['base_url']}{href}"
            
            # Price
            price_elem = listing.select_one(selectors.get('price'))
            if price_elem:
                price_text = price_elem.get_text(strip=True)
                data['price'] = self._parse_price(price_text)
            
            # Location
            location_elem = listing.select_one(selectors.get('location'))
            if location_elem:
                data['location'] = location_elem.get_text(strip=True)
            
            # Attributes
            attr_elems = listing.select(selectors.get('attributes', ''))
            if attr_elems:
                attrs = [elem.get_text(strip=True) for elem in attr_elems]
                data['attributes'] = self._parse_attributes(attrs)
            
            # Date
            date_elem = listing.select_one(selectors.get('date', ''))
            if date_elem:
                data['listing_date'] = date_elem.get_text(strip=True)
            
            return data if data else None
            
        except Exception as e:
            logger.warning(f"Failed to extract property: {e}")
            return None
    
    def _parse_price(self, price_text: str) -> Optional[float]:
        """Parse price from text"""
        try:
            import re
            # Remove non-numeric characters except dots and commas
            price_text = re.sub(r'[^\d.,]', '', price_text)
            # Handle Turkish number format
            price_text = price_text.replace('.', '').replace(',', '.')
            return float(price_text) if price_text else None
        except:
            return None
    
    def _parse_attributes(self, attrs: List[str]) -> Dict[str, Any]:
        """Parse property attributes"""
        parsed = {}
        
        for attr in attrs:
            attr_lower = attr.lower()
            
            # Size
            if 'm²' in attr or 'm2' in attr:
                import re
                match = re.search(r'(\d+)', attr)
                if match:
                    parsed['size'] = int(match.group(1))
            
            # Rooms
            elif '+' in attr:
                parsed['rooms'] = attr
            
            # Age
            elif 'yaş' in attr_lower or 'yıl' in attr_lower:
                import re
                match = re.search(r'(\d+)', attr)
                if match:
                    parsed['building_age'] = int(match.group(1))
            
            # Floor
            elif 'kat' in attr_lower:
                import re
                match = re.search(r'(\d+)', attr)
                if match:
                    parsed['floor'] = int(match.group(1))
        
        return parsed
    
    async def validate_data(self, data: Any) -> bool:
        """Validate collected data"""
        if not data:
            return False
        
        if isinstance(data, list):
            # Check if we have valid properties
            valid_count = sum(1 for p in data if 'price' in p and 'location' in p)
            return valid_count > 0
        
        return False
