"""Real estate data collectors"""

from .property_scraper import PropertyScraper

__all__ = [
    "PropertyScraper"
]
