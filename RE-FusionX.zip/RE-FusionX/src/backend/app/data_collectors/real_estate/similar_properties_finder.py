"""
Similar Properties Finder
=========================
Finds and analyzes similar properties for comparison
"""

from typing import Dict, Any, List, Optional, Tuple
from datetime import datetime
import numpy as np
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.preprocessing import StandardScaler
from app.core.storage.integration import StorageIntegration
from app.core.storage.unified_cache import CacheType

from core.logging import logger


class SimilarPropertiesFinder:
    """
    Finds similar properties based on various criteria
    """
    
    def __init__(self):
        """Initialize similar properties finder"""
        self.feature_weights = {
            "size": 0.25,
            "rooms": 0.20,
            "price": 0.20,
            "location": 0.15,
            "building_age": 0.10,
            "floor": 0.05,
            "features": 0.05
        }
        
        self._storage = None
        self._cache = None
        
        self.scaler = StandardScaler()

    @property
    def storage(self):
        """Lazy load storage"""
        if self._storage is None:
            from app.core.storage.integration import StorageIntegration
            self._storage = StorageIntegration.get_storage()
        return self._storage
    
    @property
    def cache(self):
        """Lazy load cache"""
        if self._cache is None:
            from app.core.storage.integration import StorageIntegration
            self._cache = StorageIntegration.get_cache()
        return self._cache
        
    
    def find_similar_properties(
            self,
            target_property: Dict[str, Any],
            property_pool: List[Dict[str, Any]],
            max_results: int = 20,
            similarity_threshold: float = 0.5
             ) -> List[Dict[str, Any]]:
            """
            Find similar properties with caching
            """
            # Generate cache key
            cache_key = self.cache.generate_key(
                CacheType.SEARCH,
                "similar",
                {
                    "target_id": target_property.get("property_id", ""),
                    "location": target_property.get("location", ""),
                    "max_results": max_results
                }
            )
            
            # Check cache (synchronous)
            try:
                import asyncio
                loop = asyncio.get_event_loop()
                cached = loop.run_until_complete(self.cache.get(cache_key, CacheType.SEARCH))
                if cached:
                    logger.info("Similar properties found in cache")
                    return cached
            except:
                pass  # Continue without cache if async not available
            
            # If no property pool provided, get from storage
            if not property_pool:
                try:
                    location = target_property.get("location", "Istanbul")
                    loop = asyncio.get_event_loop()
                    property_pool = loop.run_until_complete(
                        self.storage.get_properties(
                            location=location,
                            filters={"limit": 100}
                        )
                    )
                except:
                    logger.warning("Could not get properties from storage")
                    property_pool = []
            
            if not property_pool:
                return []
            
            # Extract features and calculate similarities (existing code)
            target_features = self._extract_features(target_property)
            pool_features = [self._extract_features(p) for p in property_pool]
            
            similarities = []
            
            for i, prop in enumerate(property_pool):
                if prop == target_property:
                    continue
                
                similarity = self._calculate_similarity(
                    target_features,
                    pool_features[i],
                    target_property,
                    prop
                )
                
                if similarity >= similarity_threshold:
                    prop_copy = prop.copy()
                    prop_copy['similarity_score'] = similarity
                    prop_copy['similarity_details'] = self._get_similarity_details(
                        target_property,
                        prop
                    )
                    similarities.append(prop_copy)
            
            # Sort by similarity
            similarities.sort(key=lambda x: x['similarity_score'], reverse=True)
            
            # Add ranking
            for i, prop in enumerate(similarities[:max_results]):
                prop['similarity_rank'] = i + 1
            
            result = similarities[:max_results]
            
            # Cache the result
            try:
                loop = asyncio.get_event_loop()
                loop.run_until_complete(
                    self.cache.set(cache_key, result, CacheType.SEARCH)
                )
            except:
                pass  # Continue without caching if async not available
            
            return result
    
    def _extract_features(self, property_data: Dict[str, Any]) -> Dict[str, Any]:
        """Extract features from property data"""
        features = {
            "size": property_data.get("size", 0),
            "rooms": self._encode_rooms(property_data.get("rooms", "")),
            "price": property_data.get("price", 0),
            "building_age": property_data.get("building_age", 10),
            "floor": property_data.get("floor", 1),
            "has_parking": 1 if "parking" in str(property_data.get("features", "")).lower() else 0,
            "has_elevator": 1 if "elevator" in str(property_data.get("features", "")).lower() else 0,
            "has_balcony": 1 if "balcony" in str(property_data.get("features", "")).lower() else 0,
            "in_site": 1 if property_data.get("in_site") else 0
        }
        
        return features
    
    def _encode_rooms(self, rooms: str) -> float:
        """Encode room configuration to numeric value"""
        if not rooms:
            return 0
        
        # Handle formats like "3+1", "2+1", etc.
        if '+' in str(rooms):
            parts = str(rooms).split('+')
            try:
                return float(parts[0]) + float(parts[1]) * 0.5
            except:
                return 0
        
        # Try to extract number
        try:
            import re
            match = re.search(r'(\d+)', str(rooms))
            if match:
                return float(match.group(1))
        except:
            pass
        
        return 0
    
    def _calculate_similarity(
        self,
        features1: Dict[str, Any],
        features2: Dict[str, Any],
        prop1: Dict[str, Any],
        prop2: Dict[str, Any]
    ) -> float:
        """Calculate similarity between two properties"""
        similarity = 0.0
        
        # Numeric features similarity
        numeric_features = ["size", "rooms", "price", "building_age", "floor"]
        
        for feature in numeric_features:
            if feature in self.feature_weights:
                val1 = features1.get(feature, 0)
                val2 = features2.get(feature, 0)
                
                if val1 > 0 and val2 > 0:
                    # Calculate relative difference
                    diff = abs(val1 - val2) / max(val1, val2)
                    feature_similarity = max(0, 1 - diff)
                    similarity += feature_similarity * self.feature_weights[feature]
        
        # Location similarity
        loc1 = prop1.get("location", "").lower()
        loc2 = prop2.get("location", "").lower()
        location_similarity = self._calculate_location_similarity(loc1, loc2)
        similarity += location_similarity * self.feature_weights.get("location", 0.15)
        
        # Binary features similarity
        binary_features = ["has_parking", "has_elevator", "has_balcony", "in_site"]
        binary_matches = sum(1 for f in binary_features if features1.get(f) == features2.get(f))
        binary_similarity = binary_matches / len(binary_features)
        similarity += binary_similarity * self.feature_weights.get("features", 0.05)
        
        return min(1.0, similarity)
    
    def _calculate_location_similarity(self, loc1: str, loc2: str) -> float:
        """Calculate location similarity"""
        if not loc1 or not loc2:
            return 0.0
        
        # Split locations into parts
        parts1 = [p.strip() for p in loc1.split(',')]
        parts2 = [p.strip() for p in loc2.split(',')]
        
        # Check exact match
        if loc1 == loc2:
            return 1.0
        
        # Check partial matches
        matches = 0
        for part1 in parts1:
            for part2 in parts2:
                if part1 in part2 or part2 in part1:
                    matches += 1
                    break
        
        return matches / max(len(parts1), len(parts2))
    
    def _get_similarity_details(
        self,
        prop1: Dict[str, Any],
        prop2: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Get detailed similarity comparison"""
        details = {}
        
        # Size comparison
        if prop1.get("size") and prop2.get("size"):
            size_diff = prop2["size"] - prop1["size"]
            details["size_difference"] = f"{size_diff:+.0f} m²"
            details["size_diff_percent"] = f"{(size_diff / prop1['size'] * 100):+.1f}%"
        
        # Price comparison
        if prop1.get("price") and prop2.get("price"):
            price_diff = prop2["price"] - prop1["price"]
            details["price_difference"] = f"{price_diff:+,.0f} TL"
            details["price_diff_percent"] = f"{(price_diff / prop1['price'] * 100):+.1f}%"
        
        # Price per sqm comparison
        if prop1.get("price") and prop1.get("size") and prop2.get("price") and prop2.get("size"):
            ppsqm1 = prop1["price"] / prop1["size"]
            ppsqm2 = prop2["price"] / prop2["size"]
            details["price_per_sqm_diff"] = f"{(ppsqm2 - ppsqm1):+,.0f} TL/m²"
        
        # Room comparison
        details["rooms_match"] = prop1.get("rooms") == prop2.get("rooms")
        
        # Age comparison
        if prop1.get("building_age") and prop2.get("building_age"):
            age_diff = prop2["building_age"] - prop1["building_age"]
            details["age_difference"] = f"{age_diff:+d} years"
        
        return details
    
    def analyze_similar_properties(
        self,
        similar_properties: List[Dict[str, Any]]
    ) -> Dict[str, Any]:
        """
        Analyze similar properties to extract market insights
        
        Args:
            similar_properties: List of similar properties
            
        Returns:
            Market analysis based on similar properties
        """
        if not similar_properties:
            return {}
        
        analysis = {
            "sample_size": len(similar_properties),
            "average_similarity": 0.0,
            "price_statistics": {},
            "size_statistics": {},
            "price_per_sqm_statistics": {},
            "common_features": [],
            "market_position": {}
        }
        
        # Calculate average similarity
        similarities = [p.get("similarity_score", 0) for p in similar_properties]
        analysis["average_similarity"] = sum(similarities) / len(similarities)
        
        # Price statistics
        prices = [p["price"] for p in similar_properties if p.get("price")]
        if prices:
            analysis["price_statistics"] = {
                "min": min(prices),
                "max": max(prices),
                "mean": sum(prices) / len(prices),
                "median": sorted(prices)[len(prices) // 2],
                "std_dev": np.std(prices)
            }
        
        # Size statistics
        sizes = [p["size"] for p in similar_properties if p.get("size")]
        if sizes:
            analysis["size_statistics"] = {
                "min": min(sizes),
                "max": max(sizes),
                "mean": sum(sizes) / len(sizes),
                "median": sorted(sizes)[len(sizes) // 2]
            }
        
        # Price per sqm statistics
        price_per_sqm = []
        for prop in similar_properties:
            if prop.get("price") and prop.get("size") and prop["size"] > 0:
                price_per_sqm.append(prop["price"] / prop["size"])
        
        if price_per_sqm:
            analysis["price_per_sqm_statistics"] = {
                "min": min(price_per_sqm),
                "max": max(price_per_sqm),
                "mean": sum(price_per_sqm) / len(price_per_sqm),
                "median": sorted(price_per_sqm)[len(price_per_sqm) // 2]
            }
        
        # Common features
        feature_counts = {}
        for prop in similar_properties:
            features = prop.get("features", "")
            if isinstance(features, str):
                for feature in features.split(','):
                    feature = feature.strip().lower()
                    if feature:
                        feature_counts[feature] = feature_counts.get(feature, 0) + 1
        
        # Get most common features
        if feature_counts:
            sorted_features = sorted(feature_counts.items(), key=lambda x: x[1], reverse=True)
            analysis["common_features"] = [
                {"feature": f[0], "frequency": f[1] / len(similar_properties)}
                for f in sorted_features[:10]
            ]
        
        return analysis
