"""
Emlakjet.com Property Scraper
==============================
Traditional scraper with configuration-based approach
"""

import json
import asyncio
import re
from typing import Dict, Any, List, Optional, Tuple
from datetime import datetime
from pathlib import Path
import hashlib

import aiohttp
from bs4 import BeautifulSoup

from app.data_collectors.base.source_registry import SourceRegistry
from app.core.logging import logger
from app.utils.location_utils import get_location_manager, normalize_text
from app.core.storage.integration import StorageIntegration
from app.core.storage.unified_cache import CacheType

@SourceRegistry.register("emlakjet")
class EmlakjetScraper:
    """
    Emlakjet.com property scraper with external configuration
    """
    
    def __init__(self):
        """Initialize Emlakjet scraper with configuration"""
        self.config = self._load_config()
        self._load_cities_data()
        self.session = None
        self._storage = None
        self._cache = None
        self.stats = {
            "total_scraped": 0,
            "successful": 0,
            "failed": 0,
            "start_time": None
        }        

    @property
    def storage(self):
        """Lazy load storage with fallback"""
        if self._storage is None:
            try:
                from app.core.storage.integration import StorageIntegration
                self._storage = StorageIntegration.get_storage()
                if self._storage is None:
                    from app.core.storage.storage_manager import get_storage_manager
                    self._storage = get_storage_manager()
            except Exception as e:
                logger.error(f"Failed to get storage in EmlakjetScraper: {e}")
                # Create mock storage
                from unittest.mock import Mock
                self._storage = Mock()
                self._storage.save_properties = lambda properties, location, source: None
        return self._storage
    
    @property
    def cache(self):
        """Lazy load cache with fallback"""
        if self._cache is None:
            try:
                from app.core.storage.integration import StorageIntegration
                self._cache = StorageIntegration.get_cache()
                if self._cache is None:
                    from app.core.storage.unified_cache import get_cache
                    self._cache = get_cache()
            except Exception as e:
                logger.error(f"Failed to get cache in EmlakjetScraper: {e}")
                # Create mock cache
                from unittest.mock import Mock
                self._cache = Mock()
                self._cache.generate_key = lambda cache_type, key, filters=None: f"{cache_type}:{key}"
                self._cache.get = lambda key, cache_type=None: None
                self._cache.set = lambda key, value, cache_type=None: None
        return self._cache
       
    def _load_config(self) -> Dict[str, Any]:
        """Load configuration from JSON file"""
        config_path = Path(__file__).parent.parent / "configs" / "emlakjet_config.json"
        
        try:
            with open(config_path, 'r', encoding='utf-8') as f:
                config = json.load(f)
                logger.info(f"✅ Loaded Emlakjet configuration from {config_path}")
                return config
        except FileNotFoundError:
            logger.error(f"Configuration file not found: {config_path}")
            # Return minimal default config
            return {
                "site_info": {
                    "base_url": "https://www.emlakjet.com",
                    "rate_limit": 10
                },
                "urls": {
                    "search_base": "/satilik-konut"
                },
                "selectors": {},
                "mappings": {}
            }
        except Exception as e:
            logger.error(f"Failed to load configuration: {e}")
            return {}
    
    async def __aenter__(self):
        """Async context manager entry"""
        self.session = aiohttp.ClientSession(
            headers={
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
                "Accept": "text/html,application/xhtml+xml",
                "Accept-Language": "tr-TR,tr;q=0.9,en;q=0.8"
            }
        )
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit"""
        if self.session:
            await self.session.close()
    
    async def collect( self, location: str, property_type: str = "daire",  filters: Optional[Dict[str, Any]] = None, max_pages: int = 3,  **kwargs) -> Dict[str, Any]:
        """
        Collect properties from Emlakjet
        """
        # Generate cache key
        cache_key = self.cache.generate_key(
            CacheType.PROPERTY,
            f"emlakjet_{location}_{property_type}",
            filters
        )
        
        # Check cache first if not forcing refresh
        if kwargs.get('use_cache', True):
            cached = await self.cache.get(cache_key, CacheType.PROPERTY)
            if cached:
                logger.info(f"✅ Using cached Emlakjet data for {location}")
                return cached
            
        # Store search context for location parsing
        self._search_context = {
            'location': location,
            'property_type': property_type
        }
        
        # Try to extract city from search location
        location_lower = location.lower()
        for city_name in self._load_cities_data().keys():
            if city_name.lower() in location_lower:
                self._search_context['city'] = city_name
                break
        
        # If location contains hyphen, might be city-district format
        if '-' in location and not self._search_context.get('city'):
            parts = location.split('-')
            city_candidate = parts[0].strip()
            # Check if it's a valid city
            for city_name in self._cities_data.keys():
                if city_name.lower() == city_candidate.lower():
                    self._search_context['city'] = city_name
                    break            
        
        self.stats["start_time"] = datetime.now()
        logger.info(f"🏠 Starting Emlakjet collection for {location}")
        
        properties = []
        filters = filters or {}
        
        # Create session if not exists
        if not self.session:
            self.session = aiohttp.ClientSession()
        
        try:
            for page in range(1, max_pages + 1):
                try:
                    # Build search URL with page number
                    url = self._build_search_url(location, property_type, filters, page)
                    
                    logger.info(f"📄 Fetching page {page}: {url}")
                    
                    # Fetch page
                    html = await self._fetch_page(url)
                    
                    if not html:
                        logger.warning(f"No content received for page {page}")
                        break
                    
                    # Parse properties
                    page_properties = self._parse_properties(html, page)
                    
                    if not page_properties:
                        logger.info(f"No properties found on page {page}")
                        break
                    
                    properties.extend(page_properties)
                    self.stats["successful"] += len(page_properties)
                    
                    logger.info(f"✅ Page {page}: Extracted {len(page_properties)} properties")
                    
                    # Rate limiting
                    if page < max_pages:
                        await asyncio.sleep(1)
                        
                except Exception as e:
                    logger.error(f"Error processing page {page}: {e}")
                    self.stats["failed"] += 1
                    continue
            
            # Process and clean data
            cleaned_properties = self._clean_and_enrich_properties(properties)
            
            # Calculate statistics
            duration = (datetime.now() - self.stats["start_time"]).total_seconds()
            
            result = {
                "success": True,
                "source": "emlakjet",
                "location": location,
                "property_type": property_type,
                "filters_applied": filters,
                "total_properties": len(cleaned_properties),
                "properties": cleaned_properties,
                "statistics": {
                    "pages_scraped": min(page, max_pages),
                    "duration_seconds": duration,
                    "properties_per_second": len(cleaned_properties) / duration if duration > 0 else 0,
                    "duplicates_removed": len(properties) - len(cleaned_properties)
                },
                "timestamp": datetime.now().isoformat()
            }
            
            # Cache the successful result
            if result["success"] and result["properties"]:
                await self.cache.set(cache_key, result, CacheType.PROPERTY)
                
                # Save once to Storage (avoid duplicate console lines elsewhere)
                await self.storage.save_properties(result["properties"], location, "emlakjet")
            
            return result
            
        except Exception as e:
            logger.error(f"Collection failed: {e}", exc_info=True)
            return {
                "success": False,
                "source": "emlakjet",
                "error": str(e),
                "properties": properties,
                "timestamp": datetime.now().isoformat()
            }
        finally:
            # Close session if it was created
            if self.session and not hasattr(self, '_external_session'):
                await self.session.close()
                self.session = None

    def _build_search_url(self, location: str, property_type: str, filters: Dict[str, Any], page: int = 1) -> str:
        """
        Build search URL with correct format for Emlakjet
        """
        base_url = self.config["site_info"]["base_url"]
    
        # 1. تحديد نوع العقار
        property_types = {
            "daire": "satilik-daire",
            "konut": "satilik-konut",
            "villa": "satilik-villa",
            "arsa": "satilik-arsa",
            "işyeri": "satilik-isyeri"
        }
        property_path = property_types.get(property_type.lower(), "satilik-konut")
        
        # 2. دالة تطبيع خاصة لـ URL
        def url_normalize(text):
            """تطبيع النص لاستخدامه في URL"""
            if not text:
                return ""
            
            # إزالة كل الأحرف التركية والخاصة
            replacements = {
                'ı': 'i', 'ğ': 'g', 'ü': 'u', 'ş': 's', 'ö': 'o', 'ç': 'c',
                'İ': 'i', 'Ğ': 'g', 'Ü': 'u', 'Ş': 's', 'Ö': 'o', 'Ç': 'c',
                'I': 'i', ' ': '-', ',': '', '.': '', '̇': '',
                '(': '', ')': '', '/': '-', '\\': '-'
            }
            
            text = text.lower().strip()
            
            # تطبيق الاستبدالات
            for old, new in replacements.items():
                text = text.replace(old, new)
            
            # إزالة الأحرف غير المسموحة
            import re
            text = re.sub(r'[^a-z0-9\-]', '', text)
            
            # إزالة الشرطات المتعددة
            text = re.sub(r'-+', '-', text)
            
            return text.strip('-')
        
        # 3. معالجة الموقع باستخدام مدير المواقع
        location_manager = get_location_manager()
        location_info = location_manager.parse_location(location)
        
        # 4. بناء أجزاء URL
        url_parts = []
        
        # إضافة المدينة
        if location_info.get('city'):
            city_slug = url_normalize(location_info['city'])
            if city_slug:
                url_parts.append(city_slug)
        
        # إضافة المنطقة
        if location_info.get('district'):
            district_slug = url_normalize(location_info['district'])
            if district_slug:
                url_parts.append(district_slug)
        
        # إضافة الحي مع كلمة mahallesi
        if location_info.get('neighborhood'):
            neighborhood = location_info['neighborhood']
            # إضافة mahallesi إذا لم تكن موجودة
            if 'mahallesi' not in neighborhood.lower() and 'mah.' not in neighborhood.lower():
                neighborhood = f"{neighborhood} mahallesi"
            neighborhood_slug = url_normalize(neighborhood)
            if neighborhood_slug:
                url_parts.append(neighborhood_slug)
        
        # 5. إذا لم نجد أي مكونات، استخدم الموقع الأصلي
        if not url_parts:
            location_slug = url_normalize(location)
        else:
            location_slug = '-'.join(url_parts)
        
        # 6. بناء URL الأساسي
        if location_slug:
            url = f"{base_url}/{property_path}/{location_slug}"
        else:
            url = f"{base_url}/{property_path}"            
        
        
        # 4. بناء معاملات الفلتر
        params = []
        
        # رقم الصفحة
        if page > 1:
            params.append(f"sayfa={page}")
        
        # السعر
        if filters.get("min_fiyat"):
            params.append(f"min_fiyat={filters['min_fiyat']}")
        if filters.get("max_fiyat"):
            params.append(f"max_fiyat={filters['max_fiyat']}")
        
        # المساحة
        if filters.get("min_m2"):
            params.append(f"min_m2={filters['min_m2']}")
        if filters.get("max_m2"):
            params.append(f"max_m2={filters['max_m2']}")
        
        # عدد الغرف - استخدم الأرقام مباشرة من القاموس
        if filters.get("oda_sayisi"):
            rooms = filters["oda_sayisi"]
            if isinstance(rooms, list):
                for room in rooms:
                    params.append(f"oda_sayisi[]={room}")
            else:
                params.append(f"oda_sayisi[]={rooms}")
        
        # عمر البناء
        if filters.get("binanin_yasi"):
            ages = filters["binanin_yasi"]
            if isinstance(ages, list):
                for age in ages:
                    params.append(f"binanin_yasi[]={age}")
            else:
                params.append(f"binanin_yasi[]={ages}")
        
        # طابق الشقة
        if filters.get("dairenin_kati"):
            floors = filters["dairenin_kati"]
            if isinstance(floors, list):
                for floor in floors:
                    params.append(f"dairenin_kati[]={floor}")
            else:
                params.append(f"dairenin_kati[]={floors}")
        
        # عدد طوابق البناء
        if filters.get("binanin_kat_sayisi"):
            total_floors = filters["binanin_kat_sayisi"]
            if isinstance(total_floors, list):
                for tf in total_floors:
                    params.append(f"binanin_kat_sayisi[]={tf}")
            else:
                params.append(f"binanin_kat_sayisi[]={total_floors}")
        
        # التدفئة
        if filters.get("isitma"):
            heating = filters["isitma"]
            if isinstance(heating, list):
                for h in heating:
                    params.append(f"isitma[]={h}")
            else:
                params.append(f"isitma[]={heating}")
        
        # عدد الحمامات
        if filters.get("banyo_sayisi"):
            bathrooms = filters["banyo_sayisi"]
            if isinstance(bathrooms, list):
                for b in bathrooms:
                    params.append(f"banyo_sayisi[]={b}")
            else:
                params.append(f"banyo_sayisi[]={bathrooms}")
        
        # حالة البناء
        if filters.get("yapi_durumu"):
            status = filters["yapi_durumu"]
            if isinstance(status, list):
                for s in status:
                    params.append(f"yapi_durumu[]={s}")
            else:
                params.append(f"yapi_durumu[]={status}")
        
        # حالة الاستخدام
        if filters.get("kullanim_durumu"):
            usage = filters["kullanim_durumu"]
            if isinstance(usage, list):
                for u in usage:
                    params.append(f"kullanim_durumu[]={u}")
            else:
                params.append(f"kullanim_durumu[]={usage}")
        
        # وضع الطابو
        if filters.get("tapu_konumu"):
            deed = filters["tapu_konumu"]
            if isinstance(deed, list):
                for d in deed:
                    params.append(f"tapu_konumu[]={d}")
            else:
                params.append(f"tapu_konumu[]={deed}")
        
        # مناسب للائتمان
        if filters.get("krediye_uygunluk"):
            params.append(f"krediye_uygunluk[]={filters['krediye_uygunluk']}")
        
        # مناسب للاستثمار
        if filters.get("yatirima_uygunluk"):
            params.append(f"yatirima_uygunluk[]={filters['yatirima_uygunluk']}")
        
        # حالة الأثاث
        if filters.get("esya_durumu"):
            params.append(f"esya_durumu[]={filters['esya_durumu']}")
        
        # داخل مجمع سكني
        if filters.get("site_icerisinde"):
            params.append(f"site_icerisinde[]={filters['site_icerisinde']}")
        
        # الفترة الزمنية
        if filters.get("tarih_araligi"):
            params.append(f"tarih_araligi[]={filters['tarih_araligi']}")
        
        # حالة الشرفة
        if filters.get("balcony_condition"):
            params.append(f"balcony_condition[]={filters['balcony_condition']}")
        
        # نوع الشرفة
        if filters.get("balkon_tipi"):
            balcony_types = filters["balkon_tipi"]
            if isinstance(balcony_types, list):
                for bt in balcony_types:
                    params.append(f"balkon_tipi[]={bt}")
            else:
                params.append(f"balkon_tipi[]={balcony_types}")
        
        # مميزات البناء
        if filters.get("yapi_ozellik"):
            features = filters["yapi_ozellik"]
            if isinstance(features, list):
                for feature in features:
                    params.append(f"yapi_ozellik[]={feature}")
            else:
                params.append(f"yapi_ozellik[]={features}")
        
        # من طرف
        if filters.get("kimden"):
            params.append(f"kimden[]={filters['kimden']}")
        
        # 5. إضافة المعاملات إلى URL
        if params:
            url += "?" + "&".join(params)
        
        logger.info(f"🔗 Built URL: {url}")
        return url

    async def _fetch_page(self, url: str) -> Optional[str]:
        """
        Fetch page content with retry logic
        
        Args:
            url: URL to fetch
            
        Returns:
            HTML content or None
        """
        max_retries = 3
        
        for attempt in range(max_retries):
            try:
                async with self.session.get(
                    url,
                    timeout=aiohttp.ClientTimeout(total=30)
                ) as response:
                    if response.status == 200:
                        return await response.text()
                    elif response.status == 404:
                        logger.warning(f"Page not found: {url}")
                        return None
                    else:
                        logger.warning(f"HTTP {response.status} for {url}")
                        
            except asyncio.TimeoutError:
                logger.warning(f"Timeout on attempt {attempt + 1} for {url}")
            except Exception as e:
                logger.error(f"Fetch error on attempt {attempt + 1}: {e}")
            
            if attempt < max_retries - 1:
                await asyncio.sleep(2 ** attempt)
        
        return None
    
    def _parse_properties(self, html: str, page_num: int) -> List[Dict[str, Any]]:
        """
        Parse properties from HTML using correct selectors
        """
        soup = BeautifulSoup(html, 'html.parser')
        properties = []
        selectors = self.config.get("selectors", {})
        
        # Find all property listings
        listings = soup.select(selectors.get("listing_item", "div.styles_container__LUeRn"))
        
        logger.debug(f"Found {len(listings)} listings on page {page_num}")
        
        for listing in listings:
            try:
                prop = self._extract_property_data(listing)
                if prop and self._validate_property_data(prop):
                    properties.append(prop)
                    
            except Exception as e:
                logger.debug(f"Failed to extract property: {e}")
                continue
        
        return properties
    
    def _load_cities_data(self) -> Dict[str, List[str]]:
        """
        Load cities and districts data from JSON file
        
        Returns:
            Dictionary with city names as keys and list of districts as values
        """
        if hasattr(self, '_cities_data'):
            return self._cities_data
        
        cities_path = Path(__file__).parent.parent / "configs" / "cities_and_districts_data.json"
        
        try:
            with open(cities_path, 'r', encoding='utf-8') as f:
                self._cities_data = json.load(f)
                logger.debug(f"✅ Loaded cities data with {len(self._cities_data)} cities")
                
                # Create reverse mapping (district -> city) for faster lookup
                self._district_to_city = {}
                for city, districts in self._cities_data.items():
                    for district in districts:
                        self._district_to_city[district.lower()] = city
                
                return self._cities_data
        except FileNotFoundError:
            logger.error(f"Cities data file not found: {cities_path}")
            self._cities_data = {}
            self._district_to_city = {}
            return {}
        except Exception as e:
            logger.error(f"Failed to load cities data: {e}")
            self._cities_data = {}
            self._district_to_city = {}
            return {}
    
    def _extract_property_data(self, listing) -> Dict[str, Any]:
        """
        Extract property data from a listing element
        
        Args:
            listing: BeautifulSoup element
            
        Returns:
            Property data dictionary
        """
        selectors = self.config.get("selectors", {})
        prop = {}
        
        # Extract ID
        if listing.get("data-id"):
            prop["listing_id"] = listing["data-id"]
        
        # Extract title
        title_elem = listing.select_one(selectors.get("title", "h3.styles_title__aKEGQ"))
        if title_elem:
            prop["title"] = title_elem.get_text(strip=True)
        
        # Extract location
        location_elem = listing.select_one(selectors.get("location", "span.styles_location__OwJiQ"))
        if location_elem:
            location_text = location_elem.get_text(strip=True)  # "Beşiktaş - Türkali Mahallesi"
            prop["location"] = location_text
            
            # Parse location into components using cities data
            self._parse_location_with_data(location_text, prop)
        
        
        # Extract price
        price_elem = listing.select_one(selectors.get("price", "span.styles_price__F3pMQ"))
        if price_elem:
            prop["price"] = self._parse_price(price_elem.get_text())
            prop["price_raw"] = price_elem.get_text(strip=True)
        
        # Extract quick info (type, rooms, floor, area)
        quick_info_elem = listing.select_one(selectors.get("quick_info", "div.styles_quickinfoWrapper__Vsnk5"))
        if quick_info_elem:
            quick_info = quick_info_elem.get_text(strip=True)
            self._parse_quick_info(quick_info, prop)
        
        # Extract URL
        url_elem = listing.select_one(selectors.get("url", "a.styles_wrapper__587DT"))
        if url_elem and url_elem.get("href"):
            href = url_elem["href"]
            if not href.startswith("http"):
                href = self.config["site_info"]["base_url"] + href
            prop["url"] = href
        
        # Extract image
        image_elem = listing.select_one(selectors.get("image", "img.styles_imageClass___SLvt"))
        if image_elem and image_elem.get("src"):
            prop["image_url"] = image_elem["src"]
        
        # Add metadata
        prop["source"] = "emlakjet"
        prop["scraped_at"] = datetime.now().isoformat()
        
        # Generate unique ID if not present
        if "listing_id" not in prop:
            prop["listing_id"] = self._generate_listing_id(prop)
        
        return prop
    
    def _parse_location_with_context(self, location_text: str, prop: Dict[str, Any]):
        """
        Parse location with search context awareness using centralized location manager
        """
        location_manager = get_location_manager()
        
        # تحليل الموقع باستخدام مدير المواقع
        location_info = location_manager.parse_location(location_text)
        
        # استخدم سياق البحث إذا لم نجد المدينة
        if not location_info['city'] and hasattr(self, '_search_context'):
            search_location = self._search_context.get('location', '')
            search_info = location_manager.extract_location_from_text(search_location)
            if search_info['city']:
                location_info['city'] = search_info['city']
        
        # تحديث العقار بالموقع المحلل
        prop["city"] = location_info['city'] or "İstanbul"  # افتراضي لإسطنبول
        prop["district"] = location_info['district'] or ""
        prop["neighborhood"] = location_info['neighborhood'] or ""
        
        logger.debug(f"Location parsed: '{location_text}' -> City: '{prop['city']}', District: '{prop['district']}', Neighborhood: '{prop['neighborhood']}'")

    def _parse_location_with_data(self, location_text: str, prop: Dict[str, Any]):
        """
        Parse location text into city, district, and neighborhood using cities data
        
        Args:
            location_text: Location string like "Beşiktaş - Türkali Mahallesi"
            prop: Property dictionary to update
        
        Examples:
            "Beşiktaş - Türkali Mahallesi" -> city: Istanbul, district: Beşiktaş, neighborhood: Türkali
            "Kadıköy - Fenerbahçe Mahallesi" -> city: Istanbul, district: Kadıköy, neighborhood: Fenerbahçe
            "Çankaya - Kızılay" -> city: Ankara, district: Çankaya, neighborhood: Kızılay
        """
        # Load cities data if not already loaded
        if not hasattr(self, '_district_to_city'):
            self._load_cities_data()
        
        # Clean and split location text
        location_text = location_text.strip()
        parts = [part.strip() for part in location_text.split(" - ")]
        
        # Initialize location fields
        city = ""
        district = ""
        neighborhood = ""
        
        if len(parts) == 0:
            logger.warning(f"Empty location text")
            return
        
        # Case 1: "District - Neighborhood" (most common in Emlakjet)
        if len(parts) >= 1:
            district_candidate = parts[0].strip()
            
            # Look up city from district using our mapping
            city_found = self._district_to_city.get(district_candidate.lower())
            
            if city_found:
                city = city_found
                district = district_candidate
                
                # Extract neighborhood if available
                if len(parts) >= 2:
                    neighborhood_text = parts[1].strip()
                    # Clean common suffixes
                    neighborhood = (neighborhood_text
                                .replace("Mahallesi", "")
                                .replace("Mah.", "")
                                .replace("Mah", "")
                                .strip())
            else:
                # District not found in mapping
                logger.debug(f"District '{district_candidate}' not found in cities data")
                
                # Try to use context from search if available
                if hasattr(self, '_search_context'):
                    # If we know the city from search context
                    if self._search_context.get('city'):
                        city = self._search_context['city']
                        district = district_candidate
                    elif self._search_context.get('location'):
                        # Try to extract city from search location
                        search_loc = self._search_context['location'].lower()
                        for city_name in self._cities_data.keys():
                            if city_name.lower() in search_loc:
                                city = city_name
                                district = district_candidate
                                break
                
                # If still no city, make educated guess based on common districts
                if not city:
                    # Default to Istanbul for unknown districts (largest city)
                    city = "İstanbul"
                    district = district_candidate
                    logger.debug(f"Defaulting to {city} for unknown district: {district_candidate}")
                
                # Extract neighborhood
                if len(parts) >= 2:
                    neighborhood_text = parts[1].strip()
                    neighborhood = (neighborhood_text
                                .replace("Mahallesi", "")
                                .replace("Mah.", "")
                                .replace("Mah", "")
                                .strip())
        
        # Case 2: "City - District - Neighborhood" (rare but possible)
        if len(parts) >= 3:
            city_candidate = parts[0].strip()
            
            # Check if first part is actually a city
            if city_candidate in self._cities_data:
                city = city_candidate
                district = parts[1].strip()
                neighborhood_text = parts[2].strip()
                neighborhood = (neighborhood_text
                            .replace("Mahallesi", "")
                            .replace("Mah.", "")
                            .replace("Mah", "")
                            .strip())
        
        # Update property with parsed location
        prop["city"] = city
        prop["district"] = district
        prop["neighborhood"] = neighborhood
        
        # Log parsing result for debugging
        logger.debug(f"Parsed location: '{location_text}' -> City: '{city}', District: '{district}', Neighborhood: '{neighborhood}'")
        
    def _parse_quick_info(self, info_text: str, prop: Dict[str, Any]):
        """
        Parse quick info text containing type, rooms, floor, area
        
        Args:
            info_text: Quick info text (e.g., "Daire | 3+1 | 5. Kat | 120 m²")
            prop: Property dictionary to update
        """
        parts = [p.strip() for p in info_text.split("|")]
        
        if len(parts) >= 1:
            prop["property_type"] = parts[0]
        
        if len(parts) >= 2:
            prop["rooms"] = parts[1]
        
        if len(parts) >= 3:
            floor_text = parts[2]
            prop["floor_text"] = floor_text
            # Extract floor number
            floor_match = re.search(r'(\d+)', floor_text)
            if floor_match:
                prop["floor"] = int(floor_match.group(1))
        
        if len(parts) >= 4:
            area_text = parts[3]
            prop["area_text"] = area_text
            # Extract area number
            area_match = re.search(r'(\d+)', area_text)
            if area_match:
                prop["size"] = int(area_match.group(1))

    def _parse_price(self, price_text: str) -> Optional[float]:
        """
        Parse price from text
        
        Args:
            price_text: Price text (e.g., "2.500.000 TL")
            
        Returns:
            Price as float or None
        """
        try:
            # Remove currency and spaces
            price_text = price_text.replace("TL", "").replace("₺", "").strip()
            
            # Handle Turkish number format (dots for thousands, comma for decimal)
            price_text = price_text.replace(".", "")
            price_text = price_text.replace(",", ".")
            
            return float(price_text)
            
        except (ValueError, AttributeError):
            logger.debug(f"Could not parse price: {price_text}")
            return None
    
    def _generate_listing_id(self, prop: Dict[str, Any]) -> str:
        """
        Generate unique listing ID
        
        Args:
            prop: Property data
            
        Returns:
            Unique ID string
        """
        # Use URL if available
        if prop.get("url"):
            return hashlib.md5(prop["url"].encode()).hexdigest()[:12]
        
        # Otherwise use title + price + location
        unique_str = f"{prop.get('title', '')}{prop.get('price', '')}{prop.get('location', '')}"
        return hashlib.md5(unique_str.encode()).hexdigest()[:12]
    
    def _validate_property_data(self, prop: Dict[str, Any]) -> bool:
        """
        Validate property has minimum required data
        
        Args:
            prop: Property data
            
        Returns:
            True if valid
        """
        # Minimum requirements
        required = ["title", "price"]
        return all(prop.get(field) for field in required)
    
    def _clean_and_enrich_properties(self, properties: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Clean and enrich property data
        
        Args:
            properties: Raw property list
            
        Returns:
            Cleaned and enriched properties
        """
        cleaned = []
        seen_ids = set()
        
        for prop in properties:
            # Skip duplicates
            if prop["listing_id"] in seen_ids:
                continue
            seen_ids.add(prop["listing_id"])
            
            # Clean location
            if prop.get("location"):
                prop["location"] = prop["location"].replace("\n", " ").strip()
                prop["location"] = re.sub(r'\s+', ' ', prop["location"])
            
            # Calculate price per square meter
            if prop.get("price") and prop.get("size") and prop["size"] > 0:
                prop["price_per_sqm"] = round(prop["price"] / prop["size"], 2)
            
            # Parse room configuration for sorting
            if prop.get("rooms"):
                room_match = re.match(r'(\d+)\+(\d+)', prop["rooms"])
                if room_match:
                    prop["room_count"] = int(room_match.group(1)) + int(room_match.group(2))
            
            # Add to cleaned list
            cleaned.append(prop)
        
        # Sort by price
        cleaned.sort(key=lambda x: x.get("price", 0))
        
        return cleaned


# Auto-register when module is imported
logger.info("✅ Emlakjet scraper module loaded and registered")
