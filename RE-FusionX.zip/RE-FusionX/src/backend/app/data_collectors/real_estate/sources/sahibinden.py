"""
Sahibinden.com Scraper
======================
Specialized scraper for Sahibinden real estate listings
"""

import asyncio
from typing import Dict, Any, List, Optional
from datetime import datetime
import re
from urllib.parse import urljoin, urlencode

from playwright.async_api import async_playwright, Page
from bs4 import BeautifulSoup

from app.data_collectors.base.base_collector import BaseCollector, CollectorConfig, DataSource, CollectionResult
from app.core.logging import logger


class SahibindenScraper(BaseCollector):
    """
    Specialized scraper for Sahibinden.com
    """
    
    def __init__(self):
        """Initialize Sahibinden scraper"""
        config = CollectorConfig(
            source=DataSource.SAHIBINDEN,
            rate_limit=5,  # Respectful rate limiting
            timeout=30
        )
        super().__init__(config)
        
        self.base_url = "https://www.sahibinden.com"
        self.playwright = None
        self.browser = None
    
    async def initialize_browser(self):
        """Initialize Playwright browser"""
        if not self.playwright:
            self.playwright = await async_playwright().start()
            self.browser = await self.playwright.chromium.launch(
                headless=True,
                args=['--disable-blink-features=AutomationControlled']
            )
    
    async def collect(self, **kwargs) -> CollectionResult:
        """
        Collect property data from Sahibinden
        
        Args:
            location: Location to search
            property_type: Property type (konut, arsa, etc.)
            listing_type: Listing type (satilik, kiralik)
            filters: Additional search filters
            
        Returns:
            CollectionResult with properties
        """
        location = kwargs.get("location", "istanbul")
        property_type = kwargs.get("property_type", "konut")
        listing_type = kwargs.get("listing_type", "satilik")
        filters = kwargs.get("filters", {})
        max_pages = kwargs.get("max_pages", 5)
        
        try:
            await self.initialize_browser()
            
            properties = []
            page = await self.browser.new_page()
            
            # Build search URL
            search_url = self._build_search_url(location, property_type, listing_type, filters)
            
            for page_num in range(max_pages):
                if page_num > 0:
                    current_url = f"{search_url}&pagingOffset={page_num * 20}"
                else:
                    current_url = search_url
                
                # Navigate to page
                await page.goto(current_url, wait_until='networkidle')
                
                # Extract listings
                page_properties = await self._extract_listings(page)
                properties.extend(page_properties)
                
                # Check if there's a next page
                has_next = await page.query_selector('a.prevNextBut:has-text("Sonraki")')
                if not has_next:
                    break
                
                # Rate limiting
                await asyncio.sleep(2)
            
            # Get detailed information for top properties
            detailed_properties = []
            for prop in properties[:10]:  # Limit to top 10 for detailed scraping
                if prop.get("url"):
                    detailed = await self._get_property_details(page, prop["url"])
                    if detailed:
                        prop.update(detailed)
                detailed_properties.append(prop)
            
            await page.close()
            
            return CollectionResult(
                success=True,
                data={
                    "properties": detailed_properties,
                    "total_found": len(properties),
                    "location": location,
                    "search_url": search_url
                },
                source=self.config.source,
                quality_score=self.calculate_quality_score(detailed_properties)
            )
            
        except Exception as e:
            logger.error(f"Sahibinden scraping failed: {e}")
            return CollectionResult(
                success=False,
                error=str(e),
                source=self.config.source
            )
    
    def _build_search_url(
        self,
        location: str,
        property_type: str,
        listing_type: str,
        filters: Dict[str, Any]
    ) -> str:
        """Build Sahibinden search URL"""
        # Category mapping
        category_map = {
            "konut": "emlak-konut",
            "arsa": "emlak-arsa",
            "isyeri": "emlak-isyeri-satilik",
            "turistik": "emlak-turistik-isletme"
        }
        
        category = category_map.get(property_type, "emlak-konut")
        
        # Build base URL
        url_parts = [self.base_url, listing_type]
        
        # Add category
        if property_type == "konut":
            url_parts.append("daire")
        else:
            url_parts.append(property_type)
        
        # Add location
        location_slug = location.lower().replace(" ", "-").replace("ı", "i").replace("ş", "s").replace("ğ", "g").replace("ç", "c").replace("ö", "o").replace("ü", "u")
        url_parts.append(location_slug)
        
        base_url = "/".join(url_parts)
        
        # Add filters as query parameters
        params = {}
        
        if filters.get("min_price"):
            params["price_min"] = filters["min_price"]
        if filters.get("max_price"):
            params["price_max"] = filters["max_price"]
        if filters.get("min_size"):
            params["m2_min"] = filters["min_size"]
        if filters.get("max_size"):
            params["m2_max"] = filters["max_size"]
        if filters.get("rooms"):
            # Convert room format (e.g., "3+1" to parameter)
            params["room"] = filters["rooms"]
        if filters.get("building_age_max"):
            params["buildingAge_max"] = filters["building_age_max"]
        
        if params:
            base_url += "?" + urlencode(params)
        
        return base_url
    
    async def _extract_listings(self, page: Page) -> List[Dict[str, Any]]:
        """Extract property listings from search page"""
        properties = []
        
        # Wait for listings to load
        await page.wait_for_selector('tbody.searchResultsRowClass', timeout=10000)
        
        # Get page content
        content = await page.content()
        soup = BeautifulSoup(content, 'html.parser')
        
        # Find all listing rows
        listings = soup.find_all('tr', class_='searchResultsItem')
        
        for listing in listings:
            try:
                property_data = {
                    "source": "sahibinden",
                    "scraped_at": datetime.now().isoformat()
                }
                
                # Title and URL
                title_elem = listing.find('a', class_='classifiedTitle')
                if title_elem:
                    property_data['title'] = title_elem.get_text(strip=True)
                    property_data['url'] = urljoin(self.base_url, title_elem.get('href', ''))
                
                # Listing ID
                listing_id = listing.get('data-id')
                if listing_id:
                    property_data['listing_id'] = listing_id
                
                # Price
                price_elem = listing.find('td', class_='searchResultsPriceValue')
                if price_elem:
                    price_text = price_elem.get_text(strip=True)
                    property_data['price'] = self._parse_price(price_text)
                    property_data['price_text'] = price_text
                
                # Location
                location_elem = listing.find('td', class_='searchResultsLocationValue')
                if location_elem:
                    location_parts = location_elem.get_text(strip=True).split('\n')
                    property_data['location'] = ', '.join(p.strip() for p in location_parts if p.strip())
                
                # Attributes (size, rooms, etc.)
                attr_elems = listing.find_all('td', class_='searchResultsAttributeValue')
                if len(attr_elems) >= 2:
                    # Usually: [date, m2, rooms, floor, age]
                    property_data['listing_date'] = attr_elems[0].get_text(strip=True)
                    
                    if len(attr_elems) > 1:
                        size_text = attr_elems[1].get_text(strip=True)
                        property_data['size'] = self._parse_size(size_text)
                        property_data['size_text'] = size_text
                    
                    if len(attr_elems) > 2:
                        property_data['rooms'] = attr_elems[2].get_text(strip=True)
                    
                    if len(attr_elems) > 3:
                        property_data['floor'] = attr_elems[3].get_text(strip=True)
                    
                    if len(attr_elems) > 4:
                        age_text = attr_elems[4].get_text(strip=True)
                        property_data['building_age'] = self._parse_age(age_text)
                        property_data['age_text'] = age_text
                
                # Store/Shop info
                store_elem = listing.find('td', class_='searchResultsStoreValue')
                if store_elem:
                    property_data['seller_type'] = 'store'
                    property_data['store_name'] = store_elem.get_text(strip=True)
                else:
                    property_data['seller_type'] = 'individual'
                
                properties.append(property_data)
                
            except Exception as e:
                logger.warning(f"Failed to extract listing: {e}")
                continue
        
        return properties
    
    async def _get_property_details(self, page: Page, url: str) -> Optional[Dict[str, Any]]:
        """Get detailed information for a property"""
        try:
            # Navigate to property page
            await page.goto(url, wait_until='networkidle')
            
            # Wait for content to load
            await page.wait_for_selector('.classifiedInfo', timeout=10000)
            
            details = {}
            
            # Get all info items
            info_items = await page.query_selector_all('.classifiedInfo li')
            
            for item in info_items:
                label_elem = await item.query_selector('strong')
                value_elem = await item.query_selector('span')
                
                if label_elem and value_elem:
                    label = await label_elem.inner_text()
                    value = await value_elem.inner_text()
                    
                    # Map Turkish labels to English keys
                    label_map = {
                        "İlan No": "listing_number",
                        "İlan Tarihi": "listing_date_detailed",
                        "Emlak Tipi": "property_type_detailed",
                        "m² (Brüt)": "size_gross",
                        "m² (Net)": "size_net",
                        "Oda Sayısı": "rooms_detailed",
                        "Bina Yaşı": "building_age_detailed",
                        "Bulunduğu Kat": "floor_number",
                        "Kat Sayısı": "total_floors",
                        "Isıtma": "heating",
                        "Banyo Sayısı": "bathrooms",
                        "Balkon": "balcony",
                        "Asansör": "elevator",
                        "Otopark": "parking",
                        "Eşyalı": "furnished",
                        "Kullanım Durumu": "usage_status",
                        "Site İçerisinde": "in_site",
                        "Krediye Uygun": "credit_eligible",
                        "Takas": "exchange",
                        "Cephe": "facade",
                        "Yapı Tipi": "building_type"
                    }
                    
                    key = label_map.get(label.strip(':'), label.lower().replace(' ', '_').strip(':'))
                    details[key] = value.strip()
            
            # Get description
            description_elem = await page.query_selector('#classifiedDescription')
            if description_elem:
                details['description'] = await description_elem.inner_text()
            
            # Get images
            image_elements = await page.query_selector_all('.classifiedDetailMainPhoto img')
            images = []
            for img in image_elements[:10]:  # Limit to 10 images
                src = await img.get_attribute('src')
                if src and not 'no-photo' in src:
                    images.append(src)
            
            if images:
                details['images'] = images
            
            # Get seller info
            seller_name = await page.query_selector('.username-info-area h5')
            if seller_name:
                details['seller_name'] = await seller_name.inner_text()
            
            # Get phone number (if visible)
            phone_elem = await page.query_selector('.pretty-phone-part')
            if phone_elem:
                details['phone_visible'] = True
            
            return details
            
        except Exception as e:
            logger.warning(f"Failed to get property details from {url}: {e}")
            return None
    
    def _parse_price(self, price_text: str) -> Optional[float]:
        """Parse price from Turkish format"""
        try:
            # Remove currency symbols and text
            price_text = re.sub(r'[^\d.,]', '', price_text)
            # Handle Turkish number format (dots for thousands, comma for decimal)
            price_text = price_text.replace('.', '').replace(',', '.')
            return float(price_text) if price_text else None
        except:
            return None
    
    def _parse_size(self, size_text: str) -> Optional[int]:
        """Parse size from text"""
        try:
            match = re.search(r'(\d+)', size_text)
            if match:
                return int(match.group(1))
        except:
            pass
        return None
    
    def _parse_age(self, age_text: str) -> Optional[int]:
        """Parse building age from text"""
        try:
            # Handle different formats
            if "0" in age_text or "Sıfır" in age_text.lower():
                return 0
            
            match = re.search(r'(\d+)', age_text)
            if match:
                return int(match.group(1))
        except:
            pass
        return None
    
    async def validate_data(self, data: Any) -> bool:
        """Validate scraped data"""
        if not data:
            return False
        
        if isinstance(data, dict) and "properties" in data:
            properties = data["properties"]
            if not properties:
                return False
            
            # Check if properties have required fields
            required_fields = ["price", "location"]
            valid_count = sum(
                1 for p in properties
                if all(p.get(field) for field in required_fields)
            )
            
            return valid_count > 0
        
        return False
    
    async def cleanup(self):
        """Cleanup browser resources"""
        if self.browser:
            await self.browser.close()
        if self.playwright:
            await self.playwright.stop()
