"""
Market Reports Collector
========================
Collects official market reports and statistics
"""

from typing import Dict, Any, List, Optional
from datetime import datetime, timedelta
import aiohttp
from bs4 import BeautifulSoup
import PyPDF2
import io

from app.data_collectors.base.base_collector import BaseCollector, CollectorConfig, CollectionResult, DataSource
from app.core.logging import logger


class MarketReportsCollector(BaseCollector):
    """
    Collects official market reports from various sources
    """
    
    def __init__(self):
        """Initialize market reports collector"""
        config = CollectorConfig(
            source=DataSource.CUSTOM,
            cache_duration=timedelta(days=7)
        )
        super().__init__(config)
        
        self.report_sources = [
            {
                "name": "GYODER",
                "full_name": "Gayrimenkul Yatırım Ortaklığı Derneği",
                "url": "https://www.gyoder.org.tr/yayinlar",
                "type": "association",
                "reports": ["quarterly", "annual"]
            },
            {
                "name": "TCMB",
                "full_name": "Turkish Central Bank",
                "url": "https://www.tcmb.gov.tr",
                "type": "government",
                "reports": ["housing_price_index", "inflation"]
            },
            {
                "name": "TUIK",
                "full_name": "Turkish Statistical Institute",
                "url": "https://data.tuik.gov.tr",
                "type": "government",
                "reports": ["construction_statistics", "housing_sales"]
            },
            {
                "name": "REIDIN",
                "full_name": "REIDIN Turkey",
                "url": "https://www.reidin.com",
                "type": "private",
                "reports": ["market_reports", "price_indices"]
            }
        ]
    
    async def collect(self, **kwargs) -> CollectionResult:
        """
        Collect market reports
        
        Args:
            report_type: Type of report to collect
            max_age_days: Maximum age of reports in days
            
        Returns:
            CollectionResult with reports
        """
        report_type = kwargs.get("report_type", "all")
        max_age_days = kwargs.get("max_age_days", 90)
        
        # Check cache
        cache_key = self.get_cache_key(**kwargs)
        cached_data = await self.get_cached_data(cache_key)
        
        if cached_data:
            return CollectionResult(
                success=True,
                data=cached_data,
                source=self.config.source,
                metadata={"from_cache": True}
            )
        
        try:
            all_reports = []
            
            for source in self.report_sources:
                if report_type != "all" and report_type not in source["reports"]:
                    continue
                
                reports = await self._collect_source_reports(source, max_age_days)
                all_reports.extend(reports)
            
            # Process and analyze reports
            processed_reports = self._process_reports(all_reports)
            
            # Extract key metrics
            key_metrics = self._extract_key_metrics(processed_reports)
            
            result_data = {
                "reports": processed_reports,
                "total_reports": len(processed_reports),
                "key_metrics": key_metrics,
                "sources": list(set(r["source"] for r in processed_reports)),
                "collection_date": datetime.now().isoformat()
            }
            
            # Save to cache
            await self.save_to_cache(cache_key, result_data)
            
            return CollectionResult(
                success=True,
                data=result_data,
                source=self.config.source,
                quality_score=self.calculate_quality_score(result_data)
            )
            
        except Exception as e:
            logger.error(f"Market reports collection failed: {e}")
            return CollectionResult(
                success=False,
                error=str(e),
                source=self.config.source
            )
    
    async def _collect_source_reports(
        self,
        source: Dict[str, Any],
        max_age_days: int
    ) -> List[Dict[str, Any]]:
        """Collect reports from a specific source"""
        reports = []
        
        # This would be customized for each source
        # For now, return simulated data
        
        if source["name"] == "GYODER":
            reports.append({
                "source": source["name"],
                "source_full": source["full_name"],
                "title": "Turkish Real Estate Market Q4 2024 Report",
                "type": "quarterly",
                "date": "2024-12-31",
                "url": f"{source['url']}/q4-2024-report",
                "key_findings": [
                    "Property sales increased 15% YoY",
                    "Foreign investment reached $5.2 billion",
                    "Istanbul accounts for 25% of total transactions"
                ],
                "metrics": {
                    "total_sales": 1500000,
                    "foreign_sales": 45000,
                    "average_price_increase": 65.5,
                    "mortgage_rate": 3.49
                }
            })
        
        elif source["name"] == "TCMB":
            reports.append({
                "source": source["name"],
                "source_full": source["full_name"],
                "title": "Housing Price Index - December 2024",
                "type": "housing_price_index",
                "date": "2024-12-31",
                "url": f"{source['url']}/housing-price-index",
                "key_findings": [
                    "Housing prices increased 5.2% monthly",
                    "Annual increase reached 72.3%",
                    "Ankara showed highest monthly increase"
                ],
                "metrics": {
                    "index_value": 892.5,
                    "monthly_change": 5.2,
                    "annual_change": 72.3,
                    "real_return": 8.5
                }
            })
        
        elif source["name"] == "TUIK":
            reports.append({
                "source": source["name"],
                "source_full": source["full_name"],
                "title": "Housing Sales Statistics - December 2024",
                "type": "housing_sales",
                "date": "2024-12-31",
                "url": f"{source['url']}/housing-sales",
                "key_findings": [
                    "125,000 houses sold in December",
                    "First-time sales constitute 35%",
                    "Mortgage sales increased 20%"
                ],
                "metrics": {
                    "monthly_sales": 125000,
                    "first_time_sales": 43750,
                    "mortgage_sales": 25000,
                    "cash_sales": 100000
                }
            })
        
        return reports
    
    def _process_reports(
        self,
        reports: List[Dict[str, Any]]
    ) -> List[Dict[str, Any]]:
        """Process and standardize reports"""
        processed = []
        
        for report in reports:
            # Parse date
            if isinstance(report.get("date"), str):
                try:
                    report["date_parsed"] = datetime.fromisoformat(report["date"])
                except:
                    report["date_parsed"] = None
            
            # Calculate age
            if report.get("date_parsed"):
                age_days = (datetime.now() - report["date_parsed"]).days
                report["age_days"] = age_days
                
                # Determine freshness
                if age_days < 30:
                    report["freshness"] = "current"
                elif age_days < 90:
                    report["freshness"] = "recent"
                else:
                    report["freshness"] = "dated"
            
            # Extract report category
            report_type = report.get("type", "")
            if "quarterly" in report_type or "annual" in report_type:
                report["category"] = "periodic"
            elif "index" in report_type:
                report["category"] = "index"
            elif "sales" in report_type or "statistics" in report_type:
                report["category"] = "statistics"
            else:
                report["category"] = "other"
            
            processed.append(report)
        
        # Sort by date (most recent first)
        processed.sort(
            key=lambda x: x.get("date_parsed", datetime.min),
            reverse=True
        )
        
        return processed
    
    def _extract_key_metrics(
        self,
        reports: List[Dict[str, Any]]
    ) -> Dict[str, Any]:
        """Extract key metrics from all reports"""
        metrics = {
            "latest_metrics": {},
            "aggregated_metrics": {},
            "trends": {}
        }
        
        # Get latest metrics from most recent reports
        for report in reports:
            if report.get("metrics"):
                for key, value in report["metrics"].items():
                    if key not in metrics["latest_metrics"]:
                        metrics["latest_metrics"][key] = {
                            "value": value,
                            "source": report["source"],
                            "date": report.get("date")
                        }
        
        # Aggregate metrics across reports
        all_metrics = {}
        for report in reports:
            if report.get("metrics"):
                for key, value in report["metrics"].items():
                    if key not in all_metrics:
                        all_metrics[key] = []
                    all_metrics[key].append(value)
        
        for key, values in all_metrics.items():
            if values:
                metrics["aggregated_metrics"][key] = {
                    "average": sum(values) / len(values),
                    "min": min(values),
                    "max": max(values),
                    "count": len(values)
                }
        
        # Identify trends
        if "average_price_increase" in metrics["latest_metrics"]:
            price_increase = metrics["latest_metrics"]["average_price_increase"]["value"]
            if price_increase > 50:
                metrics["trends"]["price_trend"] = "rapid_increase"
            elif price_increase > 20:
                metrics["trends"]["price_trend"] = "moderate_increase"
            else:
                metrics["trends"]["price_trend"] = "stable"
        
        if "total_sales" in metrics["latest_metrics"]:
            sales = metrics["latest_metrics"]["total_sales"]["value"]
            if sales > 1000000:
                metrics["trends"]["market_activity"] = "very_active"
            elif sales > 500000:
                metrics["trends"]["market_activity"] = "active"
            else:
                metrics["trends"]["market_activity"] = "moderate"
        
        return metrics
    
    async def download_pdf_report(self, url: str) -> Optional[str]:
        """Download and extract text from PDF report"""
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(url) as response:
                    if response.status == 200:
                        pdf_content = await response.read()
                        
                        # Extract text from PDF
                        pdf_file = io.BytesIO(pdf_content)
                        pdf_reader = PyPDF2.PdfReader(pdf_file)
                        
                        text = ""
                        for page in pdf_reader.pages:
                            text += page.extract_text()
                        
                        return text
        except Exception as e:
            logger.error(f"Failed to download PDF from {url}: {e}")
        
        return None
    
    async def validate_data(self, data: Any) -> bool:
        """Validate collected report data"""
        if not data or not isinstance(data, dict):
            return False
        
        reports = data.get("reports", [])
        return len(reports) > 0
