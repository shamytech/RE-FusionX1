"""
News Collector for Turkish Real Estate Market
==============================================
Collects and analyzes real estate news from multiple sources
"""

import asyncio
from typing import Dict, Any, List, Optional
from datetime import datetime, timedelta
import feedparser
import aiohttp
from bs4 import BeautifulSoup
from newspaper import Article
import hashlib

from app.data_collectors.base.base_collector import BaseCollector, CollectorConfig, CollectionResult, DataSource
from app.core.logging import logger


class NewsCollector(BaseCollector):
    """
    Collects real estate news from Turkish and international sources
    """
    
    def __init__(self):
        """Initialize news collector"""
        config = CollectorConfig(
            source=DataSource.NEWS,
            cache_duration=timedelta(hours=12),
            rate_limit=30
        )
        super().__init__(config)
        
        self.news_sources = {
            "rss_feeds": [
                {
                    "name": "Emlak Kulisi",
                    "url": "https://emlakkulisi.com/feed/",
                    "language": "tr",
                    "category": "real_estate"
                },
                {
                    "name": "Ekonomim",
                    "url": "https://www.ekonomim.com/emlak.rss",
                    "language": "tr",
                    "category": "real_estate"
                },
                {
                    "name": "Property Turkey News",
                    "url": "https://www.propertyturkey.com/rss/news",
                    "language": "en",
                    "category": "real_estate"
                }
            ],
            "web_sources": [
                {
                    "name": "Hurriyet Emlak",
                    "base_url": "https://www.hurriyetemlak.com",
                    "news_path": "/emlak-haberleri",
                    "language": "tr",
                    "selectors": {
                        "articles": "article.news-item",
                        "title": "h3.news-title",
                        "summary": "p.news-summary",
                        "date": "time.news-date",
                        "link": "a.news-link"
                    }
                },
                {
                    "name": "Sabah Emlak",
                    "base_url": "https://www.sabah.com.tr",
                    "news_path": "/emlak",
                    "language": "tr",
                    "selectors": {
                        "articles": "div.news-box",
                        "title": "h3",
                        "summary": "p",
                        "date": "span.date",
                        "link": "a"
                    }
                },
                {
                    "name": "Daily Sabah Property",
                    "base_url": "https://www.dailysabah.com",
                    "news_path": "/business/real-estate",
                    "language": "en",
                    "selectors": {
                        "articles": "div.article_item",
                        "title": "h3",
                        "summary": "p.summary",
                        "date": "span.date",
                        "link": "a"
                    }
                }
            ]
        }
        
        # Keywords for filtering relevant news
        self.keywords = {
            "tr": {
                "must_have": ["emlak", "konut", "gayrimenkul", "inşaat", "ev", "daire"],
                "good_to_have": ["fiyat", "yatırım", "proje", "satış", "kira", "mortgage", "faiz"],
                "exclude": ["kumar", "bahis", "oyun"]
            },
            "en": {
                "must_have": ["real estate", "property", "housing", "construction", "apartment", "house"],
                "good_to_have": ["price", "investment", "project", "sale", "rent", "mortgage", "interest"],
                "exclude": ["gambling", "betting", "game"]
            }
        }
        
        # Sentiment keywords
        self.sentiment_keywords = {
            "positive": {
                "tr": ["artış", "yükseliş", "rekor", "büyüme", "gelişme", "iyileşme", "kazanç"],
                "en": ["increase", "rise", "growth", "improvement", "gain", "boom", "surge"]
            },
            "negative": {
                "tr": ["düşüş", "azalma", "kayıp", "kriz", "durgunluk", "gerileme", "zarar"],
                "en": ["decrease", "fall", "loss", "crisis", "decline", "drop", "crash"]
            }
        }
    
    async def collect(self, **kwargs) -> CollectionResult:
        """
        Collect news from all sources
        
        Args:
            days_back: Number of days to look back
            language: Language filter ('tr', 'en', 'all')
            max_articles: Maximum number of articles
            
        Returns:
            CollectionResult with news data
        """
        days_back = kwargs.get("days_back", 7)
        language = kwargs.get("language", "all")
        max_articles = kwargs.get("max_articles", 100)
        
        # Check cache
        cache_key = self.get_cache_key(**kwargs)
        cached_data = await self.get_cached_data(cache_key)
        
        if cached_data:
            return CollectionResult(
                success=True,
                data=cached_data,
                source=self.config.source,
                metadata={"from_cache": True}
            )
        
        try:
            all_news = []
            cutoff_date = datetime.now() - timedelta(days=days_back)
            
            # Collect from RSS feeds
            rss_news = await self._collect_rss_news(cutoff_date, language)
            all_news.extend(rss_news)
            
            # Collect from web sources
            web_news = await self._collect_web_news(cutoff_date, language)
            all_news.extend(web_news)
            
            # Remove duplicates
            unique_news = self._remove_duplicates(all_news)
            
            # Filter relevant news
            filtered_news = self._filter_relevant_news(unique_news)
            
            # Analyze sentiment
            analyzed_news = self._analyze_sentiment(filtered_news)
            
            # Sort by relevance and date
            sorted_news = self._sort_news(analyzed_news)
            
            # Limit to max_articles
            final_news = sorted_news[:max_articles]
            
            # Extract article content for top news
            if kwargs.get("extract_content", True):
                final_news = await self._extract_full_content(final_news[:20])
            
            # Generate summary statistics
            statistics = self._generate_statistics(final_news)
            
            result_data = {
                "articles": final_news,
                "total_collected": len(all_news),
                "total_filtered": len(final_news),
                "statistics": statistics,
                "collection_date": datetime.now().isoformat(),
                "days_covered": days_back
            }
            
            # Save to cache
            await self.save_to_cache(cache_key, result_data)
            
            return CollectionResult(
                success=True,
                data=result_data,
                source=self.config.source,
                quality_score=self.calculate_quality_score(result_data)
            )
            
        except Exception as e:
            logger.error(f"News collection failed: {e}")
            return CollectionResult(
                success=False,
                error=str(e),
                source=self.config.source
            )
    
    async def _collect_rss_news(
        self,
        cutoff_date: datetime,
        language: str
    ) -> List[Dict[str, Any]]:
        """Collect news from RSS feeds"""
        news_items = []
        
        for source in self.news_sources["rss_feeds"]:
            if language != "all" and source["language"] != language:
                continue
            
            try:
                # Parse RSS feed
                feed = feedparser.parse(source["url"])
                
                for entry in feed.entries:
                    # Parse date
                    pub_date = None
                    if hasattr(entry, 'published_parsed'):
                        pub_date = datetime.fromtimestamp(entry.published_parsed)
                    elif hasattr(entry, 'updated_parsed'):
                        pub_date = datetime.fromtimestamp(entry.updated_parsed)
                    
                    # Skip old news
                    if pub_date and pub_date < cutoff_date:
                        continue
                    
                    news_item = {
                        "source": source["name"],
                        "source_type": "rss",
                        "language": source["language"],
                        "category": source["category"],
                        "title": entry.get("title", ""),
                        "summary": self._clean_html(entry.get("summary", "")),
                        "url": entry.get("link", ""),
                        "published": pub_date.isoformat() if pub_date else None,
                        "tags": [tag.term for tag in entry.get("tags", [])],
                        "collected_at": datetime.now().isoformat()
                    }
                    
                    news_items.append(news_item)
                    
            except Exception as e:
                logger.warning(f"Failed to collect from {source['name']}: {e}")
                continue
        
        return news_items
    
    async def _collect_web_news(
        self,
        cutoff_date: datetime,
        language: str
    ) -> List[Dict[str, Any]]:
        """Collect news from web sources"""
        news_items = []
        
        for source in self.news_sources["web_sources"]:
            if language != "all" and source["language"] != language:
                continue
            
            try:
                url = source["base_url"] + source["news_path"]
                html = await self.fetch_with_retry(url)
                
                if not html:
                    continue
                
                soup = BeautifulSoup(html, 'html.parser')
                articles = soup.select(source["selectors"]["articles"])
                
                for article in articles[:20]:  # Limit per source
                    news_item = self._extract_web_article(article, source)
                    if news_item:
                        # Check date if available
                        if news_item.get("published"):
                            try:
                                pub_date = datetime.fromisoformat(news_item["published"])
                                if pub_date < cutoff_date:
                                    continue
                            except:
                                pass
                        
                        news_items.append(news_item)
                
            except Exception as e:
                logger.warning(f"Failed to collect from {source['name']}: {e}")
                continue
        
        return news_items
    
    def _extract_web_article(
        self,
        article_elem,
        source: Dict[str, Any]
    ) -> Optional[Dict[str, Any]]:
        """Extract article data from web element"""
        try:
            selectors = source["selectors"]
            
            # Extract title
            title_elem = article_elem.select_one(selectors.get("title"))
            title = title_elem.get_text(strip=True) if title_elem else ""
            
            # Extract summary
            summary_elem = article_elem.select_one(selectors.get("summary"))
            summary = summary_elem.get_text(strip=True) if summary_elem else ""
            
            # Extract URL
            link_elem = article_elem.select_one(selectors.get("link"))
            if link_elem:
                href = link_elem.get("href", "")
                url = href if href.startswith("http") else source["base_url"] + href
            else:
                url = ""
            
            # Extract date
            date_elem = article_elem.select_one(selectors.get("date"))
            date_text = date_elem.get_text(strip=True) if date_elem else ""
            published = self._parse_date(date_text)
            
            return {
                "source": source["name"],
                "source_type": "web",
                "language": source["language"],
                "title": title,
                "summary": summary,
                "url": url,
                "published": published,
                "collected_at": datetime.now().isoformat()
            }
            
        except Exception as e:
            logger.warning(f"Failed to extract article: {e}")
            return None
    
    async def _extract_full_content(
        self,
        news_items: List[Dict[str, Any]]
    ) -> List[Dict[str, Any]]:
        """Extract full article content using newspaper3k"""
        enhanced_items = []
        
        for item in news_items:
            if not item.get("url"):
                enhanced_items.append(item)
                continue
            
            try:
                article = Article(item["url"])
                article.download()
                article.parse()
                article.nlp()
                
                item["full_text"] = article.text
                item["keywords"] = article.keywords
                item["summary_generated"] = article.summary
                item["images"] = article.images
                item["content_extracted"] = True
                
            except Exception as e:
                logger.warning(f"Failed to extract content from {item['url']}: {e}")
                item["content_extracted"] = False
            
            enhanced_items.append(item)
        
        return enhanced_items
    
    def _remove_duplicates(self, news_items: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Remove duplicate news items based on title similarity"""
        seen_hashes = set()
        unique_items = []
        
        for item in news_items:
            # Create hash from title
            title_hash = hashlib.md5(
                item.get("title", "").lower().encode()
            ).hexdigest()
            
            if title_hash not in seen_hashes:
                seen_hashes.add(title_hash)
                unique_items.append(item)
        
        return unique_items
    
    def _filter_relevant_news(
        self,
        news_items: List[Dict[str, Any]]
    ) -> List[Dict[str, Any]]:
        """Filter news for relevance to real estate"""
        filtered = []
        
        for item in news_items:
            text = (item.get("title", "") + " " + item.get("summary", "")).lower()
            language = item.get("language", "en")
            
            keywords = self.keywords.get(language, self.keywords["en"])
            
            # Check for excluded keywords
            if any(word in text for word in keywords.get("exclude", [])):
                continue
            
            # Check for must-have keywords
            has_must_have = any(word in text for word in keywords["must_have"])
            
            # Check for good-to-have keywords
            good_to_have_count = sum(1 for word in keywords["good_to_have"] if word in text)
            
            # Calculate relevance score
            relevance_score = 0
            if has_must_have:
                relevance_score += 5
            relevance_score += good_to_have_count
            
            if relevance_score > 0:
                item["relevance_score"] = relevance_score
                filtered.append(item)
        
        return filtered
    
    def _analyze_sentiment(
        self,
        news_items: List[Dict[str, Any]]
    ) -> List[Dict[str, Any]]:
        """Analyze sentiment of news items"""
        for item in news_items:
            text = (item.get("title", "") + " " + item.get("summary", "")).lower()
            language = item.get("language", "en")
            
            positive_words = self.sentiment_keywords["positive"].get(language, [])
            negative_words = self.sentiment_keywords["negative"].get(language, [])
            
            positive_count = sum(1 for word in positive_words if word in text)
            negative_count = sum(1 for word in negative_words if word in text)
            
            # Determine sentiment
            if positive_count > negative_count:
                sentiment = "positive"
                sentiment_score = positive_count - negative_count
            elif negative_count > positive_count:
                sentiment = "negative"
                sentiment_score = -(negative_count - positive_count)
            else:
                sentiment = "neutral"
                sentiment_score = 0
            
            item["sentiment"] = sentiment
            item["sentiment_score"] = sentiment_score
        
        return news_items
    
    def _sort_news(self, news_items: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Sort news by relevance and recency"""
        # Calculate combined score
        for item in news_items:
            relevance = item.get("relevance_score", 0)
            
            # Recency score (0-10 based on age)
            recency = 10
            if item.get("published"):
                try:
                    pub_date = datetime.fromisoformat(item["published"])
                    days_old = (datetime.now() - pub_date).days
                    recency = max(0, 10 - days_old)
                except:
                    pass
            
            # Combined score
            item["combined_score"] = relevance * 0.6 + recency * 0.4
        
        # Sort by combined score
        sorted_items = sorted(
            news_items,
            key=lambda x: x.get("combined_score", 0),
            reverse=True
        )
        
        return sorted_items
    
    def _generate_statistics(
        self,
        news_items: List[Dict[str, Any]]
    ) -> Dict[str, Any]:
        """Generate statistics from collected news"""
        stats = {
            "total_articles": len(news_items),
            "by_language": {},
            "by_source": {},
            "by_sentiment": {"positive": 0, "negative": 0, "neutral": 0},
            "top_keywords": {},
            "date_range": {}
        }
        
        # Count by language
        for item in news_items:
            lang = item.get("language", "unknown")
            stats["by_language"][lang] = stats["by_language"].get(lang, 0) + 1
        
        # Count by source
        for item in news_items:
            source = item.get("source", "unknown")
            stats["by_source"][source] = stats["by_source"].get(source, 0) + 1
        
        # Count by sentiment
        for item in news_items:
            sentiment = item.get("sentiment", "neutral")
            stats["by_sentiment"][sentiment] += 1
        
        # Extract top keywords
        all_keywords = []
        for item in news_items:
            if item.get("keywords"):
                all_keywords.extend(item["keywords"])
        
        if all_keywords:
            from collections import Counter
            keyword_counts = Counter(all_keywords)
            stats["top_keywords"] = dict(keyword_counts.most_common(20))
        
        # Date range
        dates = []
        for item in news_items:
            if item.get("published"):
                try:
                    dates.append(datetime.fromisoformat(item["published"]))
                except:
                    pass
        
        if dates:
            stats["date_range"] = {
                "earliest": min(dates).isoformat(),
                "latest": max(dates).isoformat()
            }
        
        return stats
    
    def _clean_html(self, text: str) -> str:
        """Clean HTML from text"""
        soup = BeautifulSoup(text, 'html.parser')
        return soup.get_text(strip=True)
    
    def _parse_date(self, date_text: str) -> Optional[str]:
        """Parse date from various formats"""
        # This would need more sophisticated date parsing
        # For now, return current date
        return datetime.now().isoformat()
    
    async def validate_data(self, data: Any) -> bool:
        """Validate collected news data"""
        if not data or not isinstance(data, dict):
            return False
        
        articles = data.get("articles", [])
        return len(articles) > 0
