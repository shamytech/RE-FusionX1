"""
Trend Analyzer for Turkish Real Estate Market
==============================================
Analyzes market trends from collected data
"""

from typing import Dict, Any, List, Optional, Tuple
from datetime import datetime, timedelta
import numpy as np
import pandas as pd
from scipy import stats
from sklearn.linear_model import LinearRegression

from app.core.logging import logger


class TrendAnalyzer:
    """
    Analyzes trends in real estate market data
    """
    
    def __init__(self):
        """Initialize trend analyzer"""
        self.trend_periods = {
            "short_term": 30,   # days
            "medium_term": 90,  # days
            "long_term": 365    # days
        }
        
        self.trend_indicators = [
            "price",
            "price_per_sqm",
            "inventory",
            "days_on_market",
            "demand_index"
        ]
    
    def analyze_price_trends(
        self,
        price_data: List[Dict[str, Any]],
        period_days: int = 90
    ) -> Dict[str, Any]:
        """
        Analyze price trends over time
        
        Args:
            price_data: List of price data points with timestamps
            period_days: Analysis period in days
            
        Returns:
            Trend analysis results
        """
        if not price_data:
            return {}
        
        # Convert to DataFrame
        df = pd.DataFrame(price_data)
        
        # Ensure datetime index
        if 'date' in df.columns:
            df['date'] = pd.to_datetime(df['date'])
            df.set_index('date', inplace=True)
        
        # Sort by date
        df.sort_index(inplace=True)
        
        # Filter to period
        cutoff_date = datetime.now() - timedelta(days=period_days)
        df = df[df.index >= cutoff_date]
        
        if df.empty or 'price' not in df.columns:
            return {}
        
        analysis = {
            "period_days": period_days,
            "data_points": len(df),
            "date_range": {
                "start": df.index.min().isoformat(),
                "end": df.index.max().isoformat()
            }
        }
        
        # Basic statistics
        analysis["statistics"] = {
            "mean": float(df['price'].mean()),
            "median": float(df['price'].median()),
            "std_dev": float(df['price'].std()),
            "min": float(df['price'].min()),
            "max": float(df['price'].max()),
            "range": float(df['price'].max() - df['price'].min())
        }
        
        # Trend direction
        trend_result = self._calculate_trend(df['price'])
        analysis.update(trend_result)
        
        # Volatility
        analysis["volatility"] = self._calculate_volatility(df['price'])
        
        # Moving averages
        analysis["moving_averages"] = self._calculate_moving_averages(df['price'])
        
        # Momentum indicators
        analysis["momentum"] = self._calculate_momentum(df['price'])
        
        # Forecast
        analysis["forecast"] = self._generate_forecast(df['price'])
        
        return analysis
    
    def analyze_market_sentiment(
        self,
        news_data: List[Dict[str, Any]],
        period_days: int = 30
    ) -> Dict[str, Any]:
        """
        Analyze market sentiment from news data
        
        Args:
            news_data: List of news articles with sentiment
            period_days: Analysis period
            
        Returns:
            Sentiment analysis results
        """
        if not news_data:
            return {}
        
        # Filter to period
        cutoff_date = datetime.now() - timedelta(days=period_days)
        recent_news = []
        
        for article in news_data:
            if article.get("published"):
                try:
                    pub_date = datetime.fromisoformat(article["published"])
                    if pub_date >= cutoff_date:
                        recent_news.append(article)
                except:
                    pass
        
        if not recent_news:
            return {}
        
        # Count sentiments
        sentiment_counts = {"positive": 0, "negative": 0, "neutral": 0}
        sentiment_scores = []
        
        for article in recent_news:
            sentiment = article.get("sentiment", "neutral")
            sentiment_counts[sentiment] += 1
            
            score = article.get("sentiment_score", 0)
            sentiment_scores.append(score)
        
        total = len(recent_news)
        
        analysis = {
            "period_days": period_days,
            "total_articles": total,
            "sentiment_distribution": {
                "positive": sentiment_counts["positive"] / total,
                "negative": sentiment_counts["negative"] / total,
                "neutral": sentiment_counts["neutral"] / total
            },
            "sentiment_counts": sentiment_counts,
            "average_sentiment_score": np.mean(sentiment_scores) if sentiment_scores else 0,
            "sentiment_trend": self._calculate_sentiment_trend(recent_news)
        }
        
        # Determine overall sentiment
        if sentiment_counts["positive"] > sentiment_counts["negative"] * 1.5:
            analysis["overall_sentiment"] = "bullish"
        elif sentiment_counts["negative"] > sentiment_counts["positive"] * 1.5:
            analysis["overall_sentiment"] = "bearish"
        else:
            analysis["overall_sentiment"] = "neutral"
        
        # Confidence level
        max_sentiment = max(sentiment_counts.values())
        analysis["confidence"] = max_sentiment / total
        
        return analysis
    
    def analyze_supply_demand(
        self,
        inventory_data: List[Dict[str, Any]],
        transaction_data: List[Dict[str, Any]]
    ) -> Dict[str, Any]:
        """
        Analyze supply and demand dynamics
        
        Args:
            inventory_data: Property inventory over time
            transaction_data: Transaction volume data
            
        Returns:
            Supply-demand analysis
        """
        analysis = {
            "supply_indicators": {},
            "demand_indicators": {},
            "market_balance": "unknown"
        }
        
        # Analyze inventory trends
        if inventory_data:
            df_inventory = pd.DataFrame(inventory_data)
            if 'count' in df_inventory.columns:
                analysis["supply_indicators"] = {
                    "current_inventory": int(df_inventory['count'].iloc[-1]),
                    "average_inventory": float(df_inventory['count'].mean()),
                    "inventory_trend": self._get_trend_direction(df_inventory['count'])
                }
        
        # Analyze transaction volume
        if transaction_data:
            df_transactions = pd.DataFrame(transaction_data)
            if 'volume' in df_transactions.columns:
                analysis["demand_indicators"] = {
                    "current_volume": int(df_transactions['volume'].iloc[-1]),
                    "average_volume": float(df_transactions['volume'].mean()),
                    "volume_trend": self._get_trend_direction(df_transactions['volume'])
                }
        
        # Determine market balance
        supply_trend = analysis["supply_indicators"].get("inventory_trend")
        demand_trend = analysis["demand_indicators"].get("volume_trend")
        
        if supply_trend == "decreasing" and demand_trend == "increasing":
            analysis["market_balance"] = "seller's market"
        elif supply_trend == "increasing" and demand_trend == "decreasing":
            analysis["market_balance"] = "buyer's market"
        else:
            analysis["market_balance"] = "balanced market"
        
        return analysis
    
    def identify_market_cycles(
        self,
        price_data: pd.Series,
        min_cycle_length: int = 30
    ) -> Dict[str, Any]:
        """
        Identify market cycles in price data
        
        Args:
            price_data: Price time series
            min_cycle_length: Minimum cycle length in days
            
        Returns:
            Market cycle analysis
        """
        if len(price_data) < min_cycle_length * 2:
            return {"error": "Insufficient data for cycle analysis"}
        
        # Smooth data
        smoothed = price_data.rolling(window=7).mean().dropna()
        
        # Find peaks and troughs
        peaks = []
        troughs = []
        
        for i in range(1, len(smoothed) - 1):
            if smoothed.iloc[i] > smoothed.iloc[i-1] and smoothed.iloc[i] > smoothed.iloc[i+1]:
                peaks.append(i)
            elif smoothed.iloc[i] < smoothed.iloc[i-1] and smoothed.iloc[i] < smoothed.iloc[i+1]:
                troughs.append(i)
        
        # Identify cycles
        cycles = []
        for i in range(len(peaks) - 1):
            cycle = {
                "start_date": smoothed.index[peaks[i]].isoformat(),
                "end_date": smoothed.index[peaks[i+1]].isoformat(),
                "duration_days": (smoothed.index[peaks[i+1]] - smoothed.index[peaks[i]]).days,
                "peak_value": float(smoothed.iloc[peaks[i]]),
                "amplitude": float(smoothed.iloc[peaks[i]] - min(smoothed.iloc[peaks[i]:peaks[i+1]]))
            }
            cycles.append(cycle)
        
        # Current cycle phase
        current_phase = "unknown"
        if peaks and troughs:
            last_peak = peaks[-1] if peaks else 0
            last_trough = troughs[-1] if troughs else 0
            
            if last_peak > last_trough:
                current_phase = "declining"
            else:
                current_phase = "rising"
        
        return {
            "cycles_identified": len(cycles),
            "cycles": cycles,
            "current_phase": current_phase,
            "average_cycle_length": np.mean([c["duration_days"] for c in cycles]) if cycles else None
        }
    
    def _calculate_trend(self, series: pd.Series) -> Dict[str, Any]:
        """Calculate trend using linear regression"""
        if len(series) < 2:
            return {"trend": "insufficient_data"}
        
        # Prepare data for regression
        X = np.arange(len(series)).reshape(-1, 1)
        y = series.values
        
        # Fit linear regression
        model = LinearRegression()
        model.fit(X, y)
        
        # Calculate trend metrics
        slope = model.coef_[0]
        r_squared = model.score(X, y)
        
        # Determine trend direction
        if abs(slope) < 0.01:
            direction = "flat"
        elif slope > 0:
            direction = "increasing"
        else:
            direction = "decreasing"
        
        # Calculate percentage change
        if series.iloc[0] != 0:
            total_change = ((series.iloc[-1] - series.iloc[0]) / series.iloc[0]) * 100
        else:
            total_change = 0
        
        return {
            "trend": direction,
            "slope": float(slope),
            "r_squared": float(r_squared),
            "total_change_percent": float(total_change),
            "daily_change_percent": float(slope / series.mean() * 100) if series.mean() != 0 else 0
        }
    
    def _calculate_volatility(self, series: pd.Series) -> Dict[str, Any]:
        """Calculate price volatility"""
        if len(series) < 2:
            return {"level": "unknown"}
        
        # Calculate returns
        returns = series.pct_change().dropna()
        
        # Calculate volatility metrics
        volatility = float(returns.std())
        
        # Determine volatility level
        if volatility < 0.02:
            level = "low"
        elif volatility < 0.05:
            level = "medium"
        else:
            level = "high"
        
        return {
            "level": level,
            "value": volatility,
            "annualized": volatility * np.sqrt(365)  # Annualized volatility
        }
    
    def _calculate_moving_averages(self, series: pd.Series) -> Dict[str, Any]:
        """Calculate moving averages"""
        ma_periods = [7, 30, 90]
        moving_averages = {}
        
        for period in ma_periods:
            if len(series) >= period:
                ma = series.rolling(window=period).mean().iloc[-1]
                moving_averages[f"ma_{period}"] = float(ma)
                
                # Compare with current value
                current = series.iloc[-1]
                if ma != 0:
                    diff_percent = ((current - ma) / ma) * 100
                    moving_averages[f"diff_from_ma_{period}"] = float(diff_percent)
        
        return moving_averages
    
    def _calculate_momentum(self, series: pd.Series) -> Dict[str, Any]:
        """Calculate momentum indicators"""
        if len(series) < 14:
            return {"rsi": None, "momentum": "unknown"}
        
        # Calculate RSI
        delta = series.diff()
        gain = (delta.where(delta > 0, 0)).rolling(window=14).mean()
        loss = (-delta.where(delta < 0, 0)).rolling(window=14).mean()
        
        rs = gain / loss
        rsi = 100 - (100 / (1 + rs))
        current_rsi = float(rsi.iloc[-1])
        
        # Determine momentum
        if current_rsi > 70:
            momentum = "overbought"
        elif current_rsi < 30:
            momentum = "oversold"
        else:
            momentum = "neutral"
        
        return {
            "rsi": current_rsi,
            "momentum": momentum
        }
    
    def _generate_forecast(
        self,
        series: pd.Series,
        periods: int = 30
    ) -> Dict[str, Any]:
        """Generate simple forecast"""
        if len(series) < 30:
            return {"error": "Insufficient data for forecast"}
        
        # Use simple linear extrapolation
        X = np.arange(len(series)).reshape(-1, 1)
        y = series.values
        
        model = LinearRegression()
        model.fit(X, y)
        
        # Predict future values
        future_X = np.arange(len(series), len(series) + periods).reshape(-1, 1)
        predictions = model.predict(future_X)
        
        return {
            "periods": periods,
            "predicted_value": float(predictions[-1]),
            "predicted_change": float(predictions[-1] - series.iloc[-1]),
            "predicted_change_percent": float((predictions[-1] - series.iloc[-1]) / series.iloc[-1] * 100) if series.iloc[-1] != 0 else 0,
            "confidence": "low"  # Simple model, low confidence
        }
    
    def _get_trend_direction(self, series: pd.Series) -> str:
        """Get simple trend direction"""
        if len(series) < 2:
            return "unknown"
        
        if series.iloc[-1] > series.iloc[0]:
            return "increasing"
        elif series.iloc[-1] < series.iloc[0]:
            return "decreasing"
        else:
            return "stable"
    
    def _calculate_sentiment_trend(
        self,
        news_articles: List[Dict[str, Any]]
    ) -> str:
        """Calculate sentiment trend over time"""
        if not news_articles:
            return "unknown"
        
        # Sort by date
        sorted_articles = sorted(
            news_articles,
            key=lambda x: x.get("published", ""),
            reverse=False
        )
        
        # Split into halves
        mid_point = len(sorted_articles) // 2
        first_half = sorted_articles[:mid_point]
        second_half = sorted_articles[mid_point:]
        
        # Calculate average sentiment for each half
        first_sentiment = np.mean([
            a.get("sentiment_score", 0) for a in first_half
        ])
        second_sentiment = np.mean([
            a.get("sentiment_score", 0) for a in second_half
        ])
        
        # Determine trend
        if second_sentiment > first_sentiment + 0.1:
            return "improving"
        elif second_sentiment < first_sentiment - 0.1:
            return "declining"
        else:
            return "stable"
