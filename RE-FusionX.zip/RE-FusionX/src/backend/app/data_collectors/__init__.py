"""
RE-FusionX Data Collectors Package
===================================
Comprehensive data collection system for Turkish real estate analysis
"""

__version__ = "1.0.0"
__author__ = "RE-FusionX Team"

# Export only the names, not the actual objects
__all__ = [
    "get_collector_manager",
    "get_property_scraper",
    "get_ai_scraper",
    "get_economic_api",
    "get_news_collector",
    "get_cache_manager",
    "BaseCollector",
    "CollectorConfig",
    "CollectionResult",
    "DataSource"
]

# Lazy loading functions
def get_collector_manager():
    """Get an instance of CollectorManager"""
    from .base.collector_manager import CollectorManager
    return CollectorManager()

def get_property_scraper():
    """Get an instance of PropertyScraper"""
    from .real_estate.property_scraper import PropertyScraper
    return PropertyScraper()

def get_ai_scraper():
    """Get an instance of AIScraper (Basic)"""
    from .smart_collectors.ai_scraper import AIScraper
    return AIScraper()

def get_economic_api():
    """Get an instance of EconomicDataAPI"""
    from .economic.api_clients import EconomicDataAPI
    return EconomicDataAPI()

def get_news_collector():
    """Get an instance of NewsCollector"""
    from .market_intelligence.news_collector import NewsCollector
    return NewsCollector()

def get_cache_manager():
    """Get an instance of CacheManager"""
    from .cache.cache_manager import CacheManager
    return CacheManager()

# Import base classes
try:
    from .base.base_collector import (
        BaseCollector,
        CollectorConfig,
        CollectionResult,
        DataSource
    )
except ImportError as e:
    import warnings
    warnings.warn(f"Could not import base collector classes: {e}")
    BaseCollector = None
    CollectorConfig = None
    CollectionResult = None
    DataSource = None
