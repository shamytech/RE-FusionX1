#!/usr/bin/env python3
"""
Economic Data API Client for Turkish Real Estate Analysis (EVDS Version)
========================================================================

Innovation Feature #11: Economic Integration
This module provides access to Turkish and global economic indicators
that influence real estate prices using REAL API credentials and official TCMB evds library.

Features:
- Turkish Central Bank (TCMB) EVDS data integration with official evds library https://www.tcmb.gov.tr/
- Federal Reserve Economic Data (FRED) for international context with REAL API key https://fred.stlouisfed.org/
- World Bank economic indicators (no key required) https://data.worldbank.org/
- Frankfurter API for free exchange rates (no key required) https://www.frankfurter.app/

Author: Mahmoud Al-Mohammad
Year: 2025
"""

import requests
import pandas as pd
import numpy as np
from typing import Dict, List, Optional, Any, Union
from datetime import datetime, timedelta
import json
import time
import os
from pathlib import Path
import warnings

# TCMB official library
try:
    from evds import evdsAPI
    EVDS_AVAILABLE = True
except ImportError:
    EVDS_AVAILABLE = False

# Rich for console output
try:
    from rich.console import Console
    from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn
    from rich.table import Table
    from rich.panel import Panel
    RICH_AVAILABLE = True
except ImportError:
    RICH_AVAILABLE = False

warnings.filterwarnings('ignore', category=UserWarning)


class EconomicDataAPI:
    """
    Economic Data API for Turkish Real Estate Analysis with EVDS Integration
    
    Innovation Feature #11: Economic Integration
    Provides access to economic indicators affecting Turkish real estate
    """
    
    # REAL API keys provided by the user
    TCMB_API_KEY = 'SxGcYQPhph'  # Turkish Central Bank EVDS
    FRED_API_KEY = '948226d4972ce7463140d93b2d2da616'  # Federal Reserve Economic Data
    
    # Turkish economic indicators with TCMB EVDS codes and frequency parameters
    # UPDATED: Fixed codes based on comprehensive testing (2025-06-16)
    TCMB_INDICATORS = {
        'usd_try': {'code': 'TP.DK.USD.S.YTL', 'frequency': 1},  # USD/TRY Exchange Rate - Daily
        'eur_try': {'code': 'TP.DK.EUR.S.YTL', 'frequency': 1},  # EUR/TRY Exchange Rate - Daily
        'policy_rate': {'code': 'TP.TLDOV05.FWD', 'frequency': 1},  # FIXED: TL Forward rates (522 records) - Daily
        'cpi_annual': {'code': 'TP.FG.J0', 'frequency': 8},  # Consumer Price Index (Annual) - Annual
        'cpi_monthly': {'code': 'TP.FG.J0', 'frequency': 5},  # Consumer Price Index (Monthly) - Monthly frequency
        'housing_price_index': {'code': 'TP.HKFE01', 'frequency': 5},  # Housing Price Index - Monthly
        'construction_cost_index': {'code': 'TP.TUFE1YI.T1', 'frequency': 5},  # FIXED: General Producer Price Index (24 records) - Monthly
        'current_account': {'code': 'TP.DB.B01', 'frequency': 5},  # FIXED: External debt data (8 records) - Monthly
        'foreign_reserves': {'code': 'TP.MKNETHAR.M1', 'frequency': 5},  # FIXED: Securities held by non-residents (105 records) - Monthly
        'interest_rates': {
            'codes': ['TP.TLDOV05.FWD', 'TP.TLDOV05.SPT', 'TP.TLDOV05.SWP', 'TP.TLDOV06.EFK'],
            'frequency': 1  # Interest rate series - Daily
        }
    }
    
    # API endpoints
    API_ENDPOINTS = {
        'worldbank': 'https://api.worldbank.org/v2/',
        'fred': 'https://api.stlouisfed.org/fred/',
        'frankfurter': 'https://api.frankfurter.app/',
    }
    
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """Initialize Economic Data API with REAL credentials and EVDS library"""
        self.config = config or {}
        self.console = Console() if RICH_AVAILABLE else None
        
        # Initialize TCMB EVDS API
        if EVDS_AVAILABLE:
            try:
                self.evds = evdsAPI(self.TCMB_API_KEY)
                self.tcmb_available = True
                if self.console:
                    self.console.print("[bold green]✅ TCMB EVDS API initialized successfully![/bold green]")
            except Exception as e:
                self.evds = None
                self.tcmb_available = False
                if self.console:
                    self.console.print(f"[yellow]⚠️ TCMB EVDS initialization failed: {e}[/yellow]")
        else:
            self.evds = None
            self.tcmb_available = False
            if self.console:
                self.console.print("[yellow]⚠️ evds library not available. Install with: pip install evds[/yellow]")
        
        # Request session for connection pooling
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'RE-FusionX-Economic-Data-API/1.0'
        })
        
        # Statistics
        self.stats = {
            'api_calls_made': 0,
            'cache_hits': 0,
            'failed_requests': 0,
            'data_points_retrieved': 0
        }
        
        if self.console:
            self.console.print('[bold green]🏦 Economic Data API initialized with REAL credentials and EVDS[/bold green]')
            self._display_api_status()
    
    def _display_api_status(self):
        """Display API configuration status"""
        if not self.console:
            return
        
        table = Table(title="Economic Data API Configuration - REAL CREDENTIALS + EVDS")
        table.add_column("API Source", style="cyan")
        table.add_column("Status", style="green")
        table.add_column("Description", style="yellow")
        
        # TCMB EVDS
        tcmb_status = "✅ EVDS Library Ready" if self.tcmb_available else "❌ EVDS Not Available"
        table.add_row("TCMB", tcmb_status, "Turkish Central Bank EVDS - Official library")
        
        # Other APIs
        table.add_row("FRED", "✅ REAL KEY Configured", "Federal Reserve Economic Data - International indicators")
        table.add_row("WORLDBANK", "✅ No Key Required", "World Bank Open Data - Global economic indicators")
        table.add_row("FRANKFURTER", "✅ No Key Required", "Frankfurter API - Free exchange rates")
        
        self.console.print(table)
    
    def get_tcmb_data(self, series_code: str,
                 start_date: str = "01-01-2020",
                 end_date: Optional[str] = None,
                 frequency: Optional[int] = None) -> Optional[pd.DataFrame]:
        """
        Get data from Turkish Central Bank using official evds library

        Args:
            series_code: TCMB series code (e.g., 'TP.DK.USD.S.YTL')
            start_date: Start date (DD-MM-YYYY)
            end_date: End date (DD-MM-YYYY)
            frequency: Frequency parameter (1=Daily, 2=Business, 3=Weekly, 4=Bi-monthly, 5=Monthly, 6=Quarterly, 7=Semi-annual, 8=Annual)

        Returns:
            DataFrame with TCMB data
        """
        if not self.tcmb_available or self.evds is None:
            if self.console:
                self.console.print("[yellow]⚠ TCMB EVDS not available[/yellow]")
            return None
        
        if not end_date:
            end_date = datetime.now().strftime('%d-%m-%Y')
        
        try:
            self.stats['api_calls_made'] += 1

            if self.console:
                self.console.print(f"[cyan]📊 Fetching TCMB data: {series_code}[/cyan]")

            # Get data using evds library with error handling
            # Add frequency parameter if specified (convert to string as required by evds)
            if frequency is not None:
                data = self.evds.get_data([series_code], startdate=start_date, enddate=end_date, frequency=str(frequency))
            else:
                data = self.evds.get_data([series_code], startdate=start_date, enddate=end_date)
            
            if data is not None and not data.empty:
                # Clean and format the data
                df = data.copy()
                
                # Reset index to get date as column
                if df.index.name == 'Tarih' or 'Tarih' in df.index.names:
                    df = df.reset_index()
                
                # Find date and value columns
                date_col = None
                value_col = None
                
                for col in df.columns:
                    if 'tarih' in col.lower() or 'date' in col.lower():
                        date_col = col
                    elif col != date_col and pd.api.types.is_numeric_dtype(df[col]):
                        value_col = col
                        break
                
                if date_col and value_col:
                    # Rename columns for consistency
                    df = df.rename(columns={date_col: 'date', value_col: 'value'})
                    df = df[['date', 'value']].copy()
                    
                    # Convert date column to datetime with proper format handling
                    # IMPORTANT FIX: Handle Turkish date format (DD-MM-YYYY)
                    try:
                        # First try with explicit DD-MM-YYYY format
                        df['date'] = pd.to_datetime(df['date'], format='%d-%m-%Y')
                    except:
                        try:
                            # If that fails, try with dayfirst=True
                            df['date'] = pd.to_datetime(df['date'], dayfirst=True)
                        except:
                            # Last resort: let pandas infer
                            df['date'] = pd.to_datetime(df['date'], format='mixed', dayfirst=True)
                    
                    # Sort by date
                    df = df.sort_values('date')
                    
                    # Set date as index
                    df.set_index('date', inplace=True)
                    
                    # Remove any rows with null values
                    df = df.dropna()
                    
                    self.stats['data_points_retrieved'] += len(df)
                    
                    if self.console:
                        self.console.print(f"[green]✅ Retrieved {len(df)} data points for {series_code}[/green]")
                    
                    return df
                else:
                    if self.console:
                        self.console.print(f"[yellow]⚠ Could not identify date/value columns in {series_code} data[/yellow]")
                    return None
            else:
                if self.console:
                    self.console.print(f"[yellow]⚠ No data returned for {series_code}[/yellow]")
                return None
                
        except Exception as e:
            self.stats['failed_requests'] += 1
            if self.console:
                self.console.print(f"[red]❌ TCMB API error for {series_code}: {e}[/red]")
            return None

    def get_tcmb_indicator(self, indicator_name: str,
                          start_date: str = "01-01-2020",
                          end_date: Optional[str] = None) -> Optional[pd.DataFrame]:
        """
        Get a specific Turkish economic indicator by name
        
        Args:
            indicator_name: Name of the indicator (e.g., 'usd_try', 'cpi_annual')
            start_date: Start date (DD-MM-YYYY)
            end_date: End date (DD-MM-YYYY)
            
        Returns:
            DataFrame with indicator data
        """
        if indicator_name not in self.TCMB_INDICATORS:
            available_indicators = list(self.TCMB_INDICATORS.keys())
            if self.console:
                self.console.print(f"[red]❌ Unknown indicator: {indicator_name}[/red]")
                self.console.print(f"[yellow]Available indicators: {available_indicators}[/yellow]")
            return None
        
        indicator_config = self.TCMB_INDICATORS[indicator_name]
        
        # Handle indicators with multiple codes
        if 'codes' in indicator_config:
            # Try each code until we get data
            for code in indicator_config['codes']:
                data = self.get_tcmb_data(
                    series_code=code,
                    start_date=start_date,
                    end_date=end_date,
                    frequency=indicator_config.get('frequency')
                )
                if data is not None and not data.empty:
                    return data
            
            if self.console:
                self.console.print(f"[yellow]⚠️ No data found for any code in {indicator_name}[/yellow]")
            return None
        else:
            # Single code indicator
            return self.get_tcmb_data(
                series_code=indicator_config['code'],
                start_date=start_date,
                end_date=end_date,
                frequency=indicator_config.get('frequency')
            )
    
    def get_tcmb_multiple_series(self, series_codes: List[str],
                                start_date: str = "01-01-2020",
                                end_date: Optional[str] = None,
                                frequency: Optional[int] = None) -> Optional[pd.DataFrame]:
        """
        Get multiple TCMB series at once using evds library
        
        Args:
            series_codes: List of TCMB series codes
            start_date: Start date (DD-MM-YYYY)
            end_date: End date (DD-MM-YYYY)
            frequency: Frequency parameter
            
        Returns:
            DataFrame with multiple series data
        """
        if not self.tcmb_available or self.evds is None:
            if self.console:
                self.console.print("[yellow]⚠️ TCMB EVDS not available[/yellow]")
            return None
        
        if not end_date:
            end_date = datetime.now().strftime('%d-%m-%Y')
        
        try:
            self.stats['api_calls_made'] += 1
            
            if self.console:
                self.console.print(f"[cyan]📊 Fetching multiple TCMB series: {series_codes}[/cyan]")
            
            # Get data using evds library
            if frequency is not None:
                data = self.evds.get_data(series_codes, startdate=start_date, enddate=end_date, frequency=str(frequency))
            else:
                data = self.evds.get_data(series_codes, startdate=start_date, enddate=end_date)
            
            if data is not None and not data.empty:
                self.stats['data_points_retrieved'] += len(data)
                
                if self.console:
                    self.console.print(f"[green]✅ Retrieved {len(data)} data points for multiple series[/green]")
                
                return data
            else:
                if self.console:
                    self.console.print("[yellow]⚠️ No data returned for multiple series[/yellow]")
                return None
                
        except Exception as e:
            self.stats['failed_requests'] += 1
            if self.console:
                self.console.print(f"[red]❌ TCMB API error for multiple series: {e}[/red]")
            return None
    
    def get_tcmb_categories(self) -> Optional[pd.DataFrame]:
        """Get available TCMB data categories"""
        if not self.tcmb_available or self.evds is None:
            return None
        
        try:
            categories = self.evds.get_categories()
            if self.console:
                self.console.print(f"[green]✅ Retrieved {len(categories)} TCMB categories[/green]")
            return categories
        except Exception as e:
            if self.console:
                self.console.print(f"[red]❌ Error getting TCMB categories: {e}[/red]")
            return None
    
    def get_tcmb_subcategories(self, category_id: str) -> Optional[pd.DataFrame]:
        """Get subcategories for a specific TCMB category"""
        if not self.tcmb_available or self.evds is None:
            return None
        
        try:
            subcategories = self.evds.get_subcategories(category_id)
            if self.console:
                self.console.print(f"[green]✅ Retrieved subcategories for category {category_id}[/green]")
            return subcategories
        except Exception as e:
            if self.console:
                self.console.print(f"[red]❌ Error getting subcategories for {category_id}: {e}[/red]")
            return None
    
    def get_tcmb_series_info(self, series_name: str) -> Optional[pd.DataFrame]:
        """Get information about TCMB series by name search"""
        if not self.tcmb_available or self.evds is None:
            return None
        
        try:
            series_info = self.evds.get_series_list(series_name)
            if self.console:
                self.console.print(f"[green]✅ Retrieved series info for '{series_name}'[/green]")
            return series_info
        except Exception as e:
            if self.console:
                self.console.print(f"[red]❌ Error getting series info for '{series_name}': {e}[/red]")
            return None
    
    def get_fred_data(self, indicator: str, 
                     start_date: Optional[str] = None, 
                     end_date: Optional[str] = None) -> Optional[pd.DataFrame]:
        """
        Get data from Federal Reserve Economic Data (FRED) API
        
        Args:
            indicator: FRED series ID (e.g., 'FEDFUNDS')
            start_date: Start date (YYYY-MM-DD)
            end_date: End date (YYYY-MM-DD)
            
        Returns:
            DataFrame with FRED data
        """
        if not end_date:
            end_date = datetime.now().strftime('%Y-%m-%d')
        if not start_date:
            start_date = (datetime.now() - timedelta(days=365*2)).strftime('%Y-%m-%d')  # 2 years ago
        
        try:
            self.stats['api_calls_made'] += 1
            
            url = f"{self.API_ENDPOINTS['fred']}series/observations"
            params = {
                'series_id': indicator,
                'api_key': self.FRED_API_KEY,
                'file_type': 'json',
                'observation_start': start_date,
                'observation_end': end_date,
                'frequency': 'm',  # Monthly data
                'sort_order': 'desc'
            }
            
            if self.console:
                self.console.print(f"[cyan]📊 Fetching FRED data: {indicator}[/cyan]")
            
            response = self.session.get(url, params=params, timeout=30)
            response.raise_for_status()
            
            data = response.json()
            
            if 'observations' in data and data['observations']:
                observations = data['observations']
                
                # Create DataFrame
                df = pd.DataFrame(observations)
                df['date'] = pd.to_datetime(df['date'])
                df['value'] = pd.to_numeric(df['value'], errors='coerce')
                
                # Remove invalid values
                df = df.dropna(subset=['value'])
                df = df[df['value'] != '.']  # FRED uses '.' for missing values
                
                # Set date as index and sort
                df.set_index('date', inplace=True)
                df = df.sort_index()
                
                # Keep only value column
                df = df[['value']]
                
                self.stats['data_points_retrieved'] += len(df)
                
                if self.console:
                    self.console.print(f"[green]✅ Retrieved {len(df)} data points from FRED for {indicator}[/green]")
                
                return df
            else:
                if self.console:
                    self.console.print(f"[yellow]⚠️ No data returned from FRED for {indicator}[/yellow]")
                return None
                
        except Exception as e:
            self.stats['failed_requests'] += 1
            if self.console:
                self.console.print(f"[red]❌ FRED API error for {indicator}: {e}[/red]")
            return None
    
    def get_frankfurter_exchange_rates(self, base_currency: str = 'USD', 
                                     target_currency: str = 'TRY',
                                     date: Optional[str] = None) -> Optional[Dict[str, Any]]:
        """
        Get exchange rates from Frankfurter API (free)
        
        Args:
            base_currency: Base currency code (e.g., 'USD')
            target_currency: Target currency code (e.g., 'TRY')
            date: Specific date (YYYY-MM-DD) or None for latest
            
        Returns:
            Dictionary with exchange rate data
        """
        try:
            self.stats['api_calls_made'] += 1
            
            if date:
                url = f"{self.API_ENDPOINTS['frankfurter']}{date}"
            else:
                url = f"{self.API_ENDPOINTS['frankfurter']}latest"
            
            params = {
                'from': base_currency,
                'to': target_currency
            }
            
            if self.console:
                self.console.print(f"[cyan]💱 Fetching exchange rate: {base_currency}/{target_currency}[/cyan]")
            
            response = self.session.get(url, params=params, timeout=15)
            response.raise_for_status()
            
            data = response.json()
            
            if 'rates' in data and target_currency in data['rates']:
                rate_data = {
                    'date': data['date'],
                    'base': data['base'],
                    'target': target_currency,
                    'rate': data['rates'][target_currency]
                }
                
                self.stats['data_points_retrieved'] += 1
                
                if self.console:
                    self.console.print(f"[green]✅ Retrieved exchange rate: {base_currency}/{target_currency} = {rate_data['rate']}[/green]")
                
                return rate_data
            else:
                if self.console:
                    self.console.print(f"[yellow]⚠️ Exchange rate not available: {base_currency}/{target_currency}[/yellow]")
                return None
                
        except Exception as e:
            self.stats['failed_requests'] += 1
            if self.console:
                self.console.print(f"[red]❌ Frankfurter API error: {e}[/red]")
            return None
    
    def get_world_bank_data(self, indicator: str, country: str = 'TR', 
                          start_year: Optional[int] = None, 
                          end_year: Optional[int] = None) -> Optional[pd.DataFrame]:
        """
        Get data from World Bank API
        
        Args:
            indicator: World Bank indicator code (e.g., 'NY.GDP.MKTP.KD.ZG')
            country: Country code (default: 'TR' for Turkey)
            start_year: Start year
            end_year: End year
            
        Returns:
            DataFrame with World Bank data
        """
        if not end_year:
            end_year = datetime.now().year
        if not start_year:
            start_year = end_year - 10  # 10 years ago
        
        try:
            self.stats['api_calls_made'] += 1
            
            url = f"{self.API_ENDPOINTS['worldbank']}country/{country}/indicator/{indicator}"
            params = {
                'format': 'json',
                'date': f"{start_year}:{end_year}",
                'per_page': 1000
            }
            
            if self.console:
                self.console.print(f"[cyan]🌍 Fetching World Bank data: {indicator} for {country}[/cyan]")
            
            response = self.session.get(url, params=params, timeout=30)
            response.raise_for_status()
            
            data = response.json()
            
            if len(data) > 1 and data[1]:  # World Bank returns [metadata, data]
                records = data[1]
                
                # Create DataFrame
                df_data = []
                for record in records:
                    if record['value'] is not None:
                        df_data.append({
                            'date': f"{record['date']}-12-31",  # Assume end of year
                            'value': float(record['value'])
                        })
                
                if df_data:
                    df = pd.DataFrame(df_data)
                    df['date'] = pd.to_datetime(df['date'])
                    df.set_index('date', inplace=True)
                    df = df.sort_index()
                    
                    self.stats['data_points_retrieved'] += len(df)
                    
                    if self.console:
                        self.console.print(f"[green]✅ Retrieved {len(df)} data points from World Bank for {indicator}[/green]")
                    
                    return df
                else:
                    if self.console:
                        self.console.print(f"[yellow]⚠️ No valid data from World Bank for {indicator}[/yellow]")
                    return None
            else:
                if self.console:
                    self.console.print(f"[yellow]⚠️ No data returned from World Bank for {indicator}[/yellow]")
                return None
                
        except Exception as e:
            self.stats['failed_requests'] += 1
            if self.console:
                self.console.print(f"[red]❌ World Bank API error for {indicator}: {e}[/red]")
            return None
    
    def test_tcmb_evds_features(self):
        """Test TCMB EVDS library features"""
        if not self.tcmb_available:
            if self.console:
                self.console.print("[red]❌ TCMB EVDS not available for testing[/red]")
            return
        
        if self.console:
            self.console.print("[bold blue]🧪 Testing TCMB EVDS Features[/bold blue]")
        
        # Test 1: Get categories
        try:
            categories = self.get_tcmb_categories()
            if categories is not None:
                if self.console:
                    self.console.print(f"[green]✅ Categories test passed: {len(categories)} categories[/green]")
            else:
                if self.console:
                    self.console.print("[yellow]⚠️ Categories test: No data returned[/yellow]")
        except Exception as e:
            if self.console:
                self.console.print(f"[red]❌ Categories test failed: {e}[/red]")
        
        # Test 2: Get USD/TRY exchange rate
        try:
            usd_try = self.get_tcmb_indicator('usd_try', start_date="01-01-2024")
            if usd_try is not None and not usd_try.empty:
                if self.console:
                    self.console.print(f"[green]✅ USD/TRY test passed: {len(usd_try)} data points[/green]")
            else:
                if self.console:
                    self.console.print("[yellow]⚠️ USD/TRY test: No data returned[/yellow]")
        except Exception as e:
            if self.console:
                self.console.print(f"[red]❌ USD/TRY test failed: {e}[/red]")
    
    def get_comprehensive_turkish_data(self, start_date: Optional[str] = None, end_date: Optional[str] = None) -> Dict[str, pd.DataFrame]:
        """
        Get comprehensive Turkish economic data for real estate analysis
        
        Args:
            start_date: Start date in format 'YYYY-MM-DD' or 'DD-MM-YYYY'
            end_date: End date in format 'YYYY-MM-DD' or 'DD-MM-YYYY'
        
        Returns:
            Dictionary mapping indicator names to DataFrames
        """
        data = {}
        
        # Convert date format if needed
        if start_date:
            # Check if date is in YYYY-MM-DD format
            if '-' in start_date and len(start_date.split('-')[0]) == 4:
                # Convert from YYYY-MM-DD to DD-MM-YYYY for TCMB
                date_parts = start_date.split('-')
                tcmb_start_date = f"{date_parts[2]}-{date_parts[1]}-{date_parts[0]}"
            else:
                tcmb_start_date = start_date
        else:
            tcmb_start_date = "01-01-2020"
        
        if end_date:
            # Check if date is in YYYY-MM-DD format
            if '-' in end_date and len(end_date.split('-')[0]) == 4:
                # Convert from YYYY-MM-DD to DD-MM-YYYY for TCMB
                date_parts = end_date.split('-')
                tcmb_end_date = f"{date_parts[2]}-{date_parts[1]}-{date_parts[0]}"
            else:
                tcmb_end_date = end_date
        else:
            tcmb_end_date = None
        
        if self.console:
            self.console.print(f"[bold blue]📊 Fetching comprehensive Turkish economic data...[/bold blue]")
            self.console.print(f"  Date range: {tcmb_start_date} to {tcmb_end_date or 'current'}")
        
        # Get all TCMB indicators
        for indicator_name in self.TCMB_INDICATORS.keys():
            try:
                df = self.get_tcmb_indicator(indicator_name, start_date=tcmb_start_date, end_date=tcmb_end_date)
                if df is not None and not df.empty:
                    data[indicator_name] = df
                    if self.console:
                        self.console.print(f"  ✅ {indicator_name}: {len(df)} data points")
                else:
                    if self.console:
                        self.console.print(f"  ⚠️ {indicator_name}: No data")
            except Exception as e:
                if self.console:
                    self.console.print(f"  ❌ {indicator_name}: {e}")
        
        # Get international indicators with date range
        try:
            # US Fed rate
            fed_rate = self.get_fred_data('FEDFUNDS', start_date=start_date, end_date=end_date)
            if fed_rate is not None:
                data['us_fed_rate'] = fed_rate
                if self.console:
                    self.console.print(f"  ✅ us_fed_rate: {len(fed_rate)} data points")
        except Exception as e:
            if self.console:
                self.console.print(f"  ❌ us_fed_rate: {e}")
        
        try:
            # Turkey GDP growth
            if start_date and end_date:
                start_year = int(start_date.split('-')[0]) if len(start_date.split('-')[0]) == 4 else int(start_date.split('-')[2])
                end_year = int(end_date.split('-')[0]) if len(end_date.split('-')[0]) == 4 else int(end_date.split('-')[2])
            else:
                end_year = datetime.now().year
                start_year = end_year - 5
            
            gdp_growth = self.get_world_bank_data('NY.GDP.MKTP.KD.ZG', 'TR', start_year=start_year, end_year=end_year)
            if gdp_growth is not None:
                data['turkey_gdp_growth'] = gdp_growth
                if self.console:
                    self.console.print(f"  ✅ turkey_gdp_growth: {len(gdp_growth)} data points")
        except Exception as e:
            if self.console:
                self.console.print(f"  ❌ turkey_gdp_growth: {e}")
        
        if self.console:
            self.console.print(f"[bold green]✅ Data collection complete: {len(data)} indicators[/bold green]")
        
        return data

    def get_api_statistics(self) -> Dict[str, Any]:
        """Get API usage statistics"""
        return self.stats.copy()
    
    def print_statistics(self):
        """Print API usage statistics"""
        if not self.console:
            print(f"API Statistics: {self.stats}")
            return
        
        table = Table(title="Economic Data API Statistics")
        table.add_column("Metric", style="cyan")
        table.add_column("Value", style="green")
        
        for key, value in self.stats.items():
            table.add_row(key.replace('_', ' ').title(), str(value))
        
        self.console.print(table)
    
    def test_api_connections(self) -> Dict[str, bool]:
        """
        Test all API connections
        
        Returns:
            Dictionary mapping API names to connection status
        """
        results = {}
        
        if self.console:
            self.console.print("[bold blue]🔗 Testing API Connections[/bold blue]")
        
        # Test TCMB
        try:
            if self.tcmb_available:
                test_data = self.get_tcmb_indicator('usd_try', start_date="01-12-2024", end_date="31-12-2024")
                results['TCMB'] = test_data is not None
            else:
                results['TCMB'] = False
            
            if self.console:
                status = "✅ Connected" if results['TCMB'] else "❌ Failed"
                self.console.print(f"TCMB: {status}")
        except:
            results['TCMB'] = False
            if self.console:
                self.console.print("TCMB: ❌ Failed")
        
        # Test FRED
        try:
            test_data = self.get_fred_data('FEDFUNDS', start_date="2024-01-01", end_date="2024-12-31")
            results['FRED'] = test_data is not None
            
            if self.console:
                status = "✅ Connected" if results['FRED'] else "❌ Failed"
                self.console.print(f"FRED: {status}")
        except:
            results['FRED'] = False
            if self.console:
                self.console.print("FRED: ❌ Failed")
        
        # Test World Bank
        try:
            test_data = self.get_world_bank_data('NY.GDP.MKTP.KD.ZG', 'TR', 2023, 2024)
            results['WorldBank'] = test_data is not None
            
            if self.console:
                status = "✅ Connected" if results['WorldBank'] else "❌ Failed"
                self.console.print(f"WorldBank: {status}")
        except:
            results['WorldBank'] = False
            if self.console:
                self.console.print("WorldBank: ❌ Failed")
        
        # Test Frankfurter
        try:
            test_data = self.get_frankfurter_exchange_rates('USD', 'TRY')
            results['Frankfurter'] = test_data is not None
            
            if self.console:
                status = "✅ Connected" if results['Frankfurter'] else "❌ Failed"
                self.console.print(f"Frankfurter: {status}")
        except:
            results['Frankfurter'] = False
            if self.console:
                self.console.print("Frankfurter: ❌ Failed")
        
        return results
    
    def __del__(self):
        """Cleanup when object is destroyed"""
        if hasattr(self, 'session'):
            self.session.close() 