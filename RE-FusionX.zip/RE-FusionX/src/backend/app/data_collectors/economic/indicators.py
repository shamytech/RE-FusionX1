"""
Economic Indicators Configuration for Turkish Real Estate Analysis
================================================================

This module contains the economic indicators mapping, configuration,
and documentation for the RE-FusionX system.

Innovation Feature #11: Economic Integration
Comprehensive Turkish economic context with real-time data integration.
"""

from typing import Dict, Any, List, Optional
from dataclasses import dataclass


@dataclass 
class IndicatorConfig:
    """Configuration for a single economic indicator."""
    code: Optional[str] = None
    codes: Optional[List[str]] = None
    fallback_code: Optional[str] = None
    fallback_codes: Optional[List[str]] = None
    frequency: Optional[int] = None
    name: str = ""
    description: str = ""
    importance: str = ""
    real_estate_impact: str = ""
    integration_method: str = ""
    source: Optional[str] = None
    base: Optional[str] = None
    target: Optional[str] = None


class EconomicIndicators:
    """
    Economic Indicators Configuration Manager
    
    Manages the comprehensive mapping of Turkish and international
    economic indicators used for real estate price prediction.
    """
    
    def __init__(self):
        """Initialize economic indicators configuration."""
        self.indicators = self._initialize_indicators()
    
    def _initialize_indicators(self) -> Dict[str, Dict[str, IndicatorConfig]]:
        """
        Initialize economic indicators mapping with corrected EVDS codes.
        
        Returns:
            Nested dictionary of categorized economic indicators
        """
        return {
            # Exchange Rates - WORKING
            'currency': {
                'usd_try': IndicatorConfig(
                    code='TP.DK.USD.S.YTL',
                    name='USD/TRY Exchange Rate',
                    description='US Dollar to Turkish Lira exchange rate',
                    importance='Primary currency benchmark for Turkish economy',
                    real_estate_impact='Higher USD/TRY increases costs for foreign buyers',
                    integration_method='currency_adjustment_factor'
                ),
                'eur_try': IndicatorConfig(
                    code='TP.DK.EUR.S.YTL',
                    name='EUR/TRY Exchange Rate',
                    description='Euro to Turkish Lira exchange rate',
                    importance='Major European trading partner currency',
                    real_estate_impact='Affects European investor purchasing power',
                    integration_method='currency_adjustment_factor'
                )
            },
            
            # Inflation and Price Indices
            'inflation': {
                'cpi_annual': IndicatorConfig(
                    code='TP.FG.J0',
                    frequency=8,  # Annual
                    name='Consumer Price Index (Annual)',
                    description='Annual inflation rate',
                    importance='Primary inflation measure',
                    real_estate_impact='Higher inflation generally increases property prices',
                    integration_method='inflation_adjustment_factor'
                ),
                'cpi_monthly': IndicatorConfig(
                    code='TP.FG.J0',
                    frequency=5,  # Monthly - FIXED: Use same code with monthly frequency
                    name='Consumer Price Index (Monthly)',
                    description='Monthly inflation rate',
                    importance='Short-term inflation tracking',
                    real_estate_impact='Monthly price level changes',
                    integration_method='inflation_adjustment_factor'
                ),
                'housing_price_index': IndicatorConfig(
                    code='TP.HKFE01',
                    name='Housing Price Index',
                    description='Official Turkish housing price index',
                    importance='Direct housing market indicator',
                    real_estate_impact='Direct correlation with property values',
                    integration_method='direct_price_correlation'
                ),
                'construction_cost_index': IndicatorConfig(
                    # FIXED: Working codes found through comprehensive testing
                    code='TP.TUFE1YI.T1',  # General Producer Price Index (WORKING - 24 records)
                    codes=['TP.TUFE1YI.T67', 'TP.TUFE1YI.T80', 'TP.HUFE.GK18224'],  # Clay construction, Metal construction, Construction services
                    fallback_codes=['TP.TUFE1YI.T23', 'TP.TUFE1YI.T24'],  # Wood products, Paper products
                    name='Construction Cost Index',
                    description='Construction materials and labor cost index',
                    importance='Input costs for construction industry',
                    real_estate_impact='Higher construction costs increase new property prices',
                    integration_method='cost_adjustment_factor'
                )
            },
            
            # Interest Rates and Monetary Policy  
            'monetary': {
                'policy_rate': IndicatorConfig(
                    # FIXED: Working TL interest rate codes found through testing
                    code='TP.TLDOV05.FWD',  # TL Forward rates (WORKING - 522 records)
                    codes=['TP.TLDOV05.SPT', 'TP.TLDOV05.SWP', 'TP.TLDOV06.EFK'],  # TL Spot, Swap, Effective rates
                    fallback_codes=['TP.TLDOV05.FWD', 'TP.TLDOV05.SPT'],  # Confirmed working codes
                    name='TCMB Policy Rate',
                    description='Turkish Central Bank main policy interest rate',
                    importance='Primary monetary policy tool',
                    real_estate_impact='Higher rates increase mortgage costs, reducing demand',
                    integration_method='interest_rate_adjustment'
                ),
                'interest_rates': IndicatorConfig(
                    codes=['TP.TLDOV05.FWD', 'TP.TLDOV05.SPT', 'TP.TLDOV05.SWP', 'TP.TLDOV06.EFK'],
                    name='Turkish Lira Interest Rates',
                    description='Various Turkish Lira interest rate benchmarks',
                    importance='Market interest rate environment',
                    real_estate_impact='Mortgage rates and investment opportunity costs',
                    integration_method='weighted_interest_rate_factor'
                )
            },
            
            # Balance of Payments and External Sector
            'macroeconomic': {
                'current_account': IndicatorConfig(
                    # FIXED: Working external debt codes found through testing
                    code='TP.DB.B01',  # External debt data (WORKING - 8 records)
                    codes=['TP.DB.B02'],  # External debt breakdown
                    fallback_codes=['TP.DK.USD.S.YTL'],  # Use USD/TRY as stability proxy
                    name='Current Account Balance',
                    description='Turkey\'s current account balance proxy',
                    importance='External economic stability measure',
                    real_estate_impact='Affects foreign investment confidence',
                    integration_method='external_stability_factor'
                ),
                'foreign_reserves': IndicatorConfig(
                    # FIXED: Working securities statistics codes found through testing
                    code='TP.MKNETHAR.M1',  # Securities held by non-residents (WORKING - 105 records)
                    codes=['TP.MKNETHAR.M2'],  # Securities breakdown
                    fallback_codes=['TP.DK.USD.S.YTL', 'TP.DK.EUR.S.YTL'],  # Exchange rates as stability proxy
                    name='Foreign Exchange Reserves',
                    description='Central bank foreign currency reserves proxy',
                    importance='Economic stability and crisis resilience',
                    real_estate_impact='Investor confidence in market stability',
                    integration_method='stability_confidence_factor'
                )
            },
            
            # International Indicators
            'international': {
                'us_fed_rate': IndicatorConfig(
                    code='FEDFUNDS',
                    name='US Federal Funds Rate',
                    description='US monetary policy benchmark rate',
                    importance='Global capital flow determinant',
                    real_estate_impact='Higher US rates can reduce foreign investment flows to Turkey',
                    integration_method='global_capital_flow_adjustment'
                ),
                'turkey_gdp_growth': IndicatorConfig(
                    code='NY.GDP.MKTP.KD.ZG',
                    name='Turkey GDP Growth Rate',
                    description='Annual GDP growth rate for Turkey',
                    importance='Overall economic health indicator',
                    real_estate_impact='Economic growth drives housing demand and prices',
                    integration_method='economic_growth_multiplier'
                ),
                # NEW: Add current exchange rates from Frankfurter
                'usd_try_current': IndicatorConfig(
                    source='frankfurter',
                    base='USD',
                    target='TRY',
                    name='USD/TRY Current Rate',
                    description='Current USD to TRY exchange rate',
                    importance='Real-time currency valuation',
                    real_estate_impact='Current foreign investment costs',
                    integration_method='current_exchange_rate'
                ),
                'eur_try_current': IndicatorConfig(
                    source='frankfurter',
                    base='EUR',
                    target='TRY',
                    name='EUR/TRY Current Rate',
                    description='Current EUR to TRY exchange rate',
                    importance='Real-time European currency valuation',
                    real_estate_impact='Current European investment costs',
                    integration_method='current_exchange_rate'
                )
            }
        }
    
    def get_indicator_config(self, category: str, indicator_name: str) -> Optional[IndicatorConfig]:
        """
        Get configuration for a specific indicator.
        
        Args:
            category: Indicator category (e.g., 'currency', 'inflation')
            indicator_name: Name of the indicator
            
        Returns:
            IndicatorConfig object or None if not found
        """
        return self.indicators.get(category, {}).get(indicator_name)
    
    def get_all_indicators(self) -> Dict[str, Dict[str, IndicatorConfig]]:
        """Get all economic indicators."""
        return self.indicators
    
    def get_category_indicators(self, category: str) -> Dict[str, IndicatorConfig]:
        """
        Get all indicators in a specific category.
        
        Args:
            category: Category name
            
        Returns:
            Dictionary of indicators in the category
        """
        return self.indicators.get(category, {})
    
    def get_indicator_names(self, category: Optional[str] = None) -> List[str]:
        """
        Get list of indicator names.
        
        Args:
            category: Optional category filter
            
        Returns:
            List of indicator names
        """
        if category:
            return list(self.indicators.get(category, {}).keys())
        else:
            names = []
            for cat_indicators in self.indicators.values():
                names.extend(cat_indicators.keys())
            return names
    
    def get_categories(self) -> List[str]:
        """Get list of all indicator categories."""
        return list(self.indicators.keys())
    
    def get_indicators_documentation(self) -> Dict[str, Any]:
        """
        Get comprehensive documentation for all indicators.
        
        Returns:
            Dictionary with detailed indicator documentation
        """
        documentation = {
            'overview': {
                'title': 'Economic Indicators for Turkish Real Estate Analysis',
                'description': 'Comprehensive set of 12 economic indicators covering Turkish and international economic factors',
                'innovation': 'Innovation Feature #11: Economic Integration with real-time Turkish economic context',
                'total_indicators': sum(len(cat) for cat in self.indicators.values()),
                'categories': len(self.indicators)
            },
            'categories': {},
            'indicators': {}
        }
        
        for category_name, category_indicators in self.indicators.items():
            # Category description
            documentation['categories'][category_name] = {
                'name': category_name.replace('_', ' ').title(),
                'description': self._get_category_description(category_name),
                'indicator_count': len(category_indicators),
                'indicators': list(category_indicators.keys())
            }
            
            # Individual indicators
            for indicator_name, config in category_indicators.items():
                documentation['indicators'][indicator_name] = {
                    'category': category_name,
                    'name': config.name,
                    'description': config.description,
                    'importance': config.importance,
                    'real_estate_impact': config.real_estate_impact,
                    'integration_method': config.integration_method,
                    'data_source': self._get_data_source(config),
                    'update_frequency': self._get_update_frequency(config),
                    'technical_details': {
                        'code': config.code,
                        'codes': config.codes,
                        'fallback_code': config.fallback_code,
                        'fallback_codes': config.fallback_codes,
                        'frequency': config.frequency,
                        'source': config.source,
                        'base': config.base,
                        'target': config.target
                    }
                }
        
        return documentation
    
    def _get_category_description(self, category_name: str) -> str:
        """Get description for a category."""
        descriptions = {
            'currency': 'Exchange rates affecting foreign investment and purchasing power',
            'inflation': 'Price level indicators showing economic pressure and cost trends',
            'monetary': 'Interest rates and monetary policy tools affecting borrowing costs',
            'macroeconomic': 'Broad economic stability and external sector indicators',
            'international': 'Global economic factors influencing Turkish market dynamics'
        }
        return descriptions.get(category_name, 'Economic indicators category')
    
    def _get_data_source(self, config: IndicatorConfig) -> str:
        """Get data source description for an indicator."""
        if config.source == 'frankfurter':
            return 'Frankfurter API (Free exchange rates)'
        elif config.code and config.code.startswith('TP.'):
            return 'Turkish Central Bank (TCMB) EVDS'
        elif config.code == 'FEDFUNDS':
            return 'Federal Reserve Economic Data (FRED)'
        elif config.code and config.code.startswith('NY.'):
            return 'World Bank Open Data'
        else:
            return 'Multiple sources'
    
    def _get_update_frequency(self, config: IndicatorConfig) -> str:
        """Get update frequency for an indicator."""
        if config.frequency:
            freq_map = {
                1: 'Daily',
                2: 'Business days',
                3: 'Weekly', 
                4: 'Bi-monthly',
                5: 'Monthly',
                6: 'Quarterly',
                7: 'Semi-annual',
                8: 'Annual'
            }
            return freq_map.get(config.frequency, 'Unknown')
        elif config.source == 'frankfurter':
            return 'Real-time'
        else:
            return 'Variable'
    
    def apply_economic_context(self, indicator_name: str, value: float, 
                              additional_context: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Apply economic context and interpretation to an indicator value.
        
        Args:
            indicator_name: Name of the economic indicator
            value: Current value of the indicator
            additional_context: Optional additional context data
            
        Returns:
            Dictionary with contextualized economic information
        """
        # Find the indicator configuration
        config = None
        category = None
        
        for cat_name, cat_indicators in self.indicators.items():
            if indicator_name in cat_indicators:
                config = cat_indicators[indicator_name]
                category = cat_name
                break
        
        if not config:
            return {
                'indicator': indicator_name,
                'value': value,
                'context': 'Unknown indicator',
                'real_estate_impact': 'Impact assessment not available'
            }
        
        # Base context
        context_data = {
            'indicator': indicator_name,
            'category': category,
            'value': value,
            'name': config.name,
            'description': config.description,
            'importance': config.importance,
            'real_estate_impact': config.real_estate_impact,
            'integration_method': config.integration_method
        }
        
        # Apply specific contextual interpretations
        if indicator_name in ['usd_try', 'eur_try', 'usd_try_current', 'eur_try_current']:
            context_data.update(self._interpret_exchange_rate(indicator_name, value))
        elif indicator_name in ['cpi_annual', 'cpi_monthly']:
            context_data.update(self._interpret_inflation(indicator_name, value))
        elif indicator_name == 'housing_price_index':
            context_data.update(self._interpret_housing_index(value))
        elif indicator_name in ['policy_rate', 'interest_rates']:
            context_data.update(self._interpret_interest_rate(indicator_name, value))
        elif indicator_name == 'us_fed_rate':
            context_data.update(self._interpret_fed_rate(value))
        elif indicator_name == 'turkey_gdp_growth':
            context_data.update(self._interpret_gdp_growth(value))
        
        # Add historical context if available
        if additional_context:
            context_data['historical_context'] = additional_context
        
        return context_data
    
    def _interpret_exchange_rate(self, indicator_name: str, value: float) -> Dict[str, Any]:
        """Interpret exchange rate values."""
        base_currency = 'USD' if 'usd' in indicator_name else 'EUR'
        
        # Define thresholds (these should be updated based on historical analysis)
        thresholds = {
            'USD': {'low': 15, 'moderate': 25, 'high': 35},
            'EUR': {'low': 17, 'moderate': 28, 'high': 38}
        }
        
        currency_thresholds = thresholds[base_currency]
        
        if value <= currency_thresholds['low']:
            strength = 'Strong TRY'
            impact = 'Attractive for foreign property buyers, may increase demand'
        elif value <= currency_thresholds['moderate']:
            strength = 'Moderate TRY'
            impact = 'Balanced exchange rate, stable foreign investment environment'
        else:
            strength = 'Weak TRY'
            impact = 'Expensive for foreign buyers, may reduce international demand'
        
        return {
            'currency_strength': strength,
            'market_interpretation': impact,
            'threshold_analysis': {
                'level': 'high' if value > currency_thresholds['high'] else 'moderate' if value > currency_thresholds['low'] else 'low',
                'base_currency': base_currency
            }
        }
    
    def _interpret_inflation(self, indicator_name: str, value: float) -> Dict[str, Any]:
        """Interpret inflation values."""
        # Turkish inflation thresholds (should be updated with current economic conditions)
        if value <= 5:
            level = 'Low inflation'
            impact = 'Stable price environment, predictable real estate costs'
        elif value <= 15:
            level = 'Moderate inflation'
            impact = 'Some price pressure, real estate may serve as inflation hedge'
        elif value <= 30:
            level = 'High inflation'
            impact = 'Significant price pressure, real estate attractive as store of value'
        else:
            level = 'Very high inflation'
            impact = 'Economic instability, real estate becomes primary inflation hedge'
        
        return {
            'inflation_level': level,
            'market_interpretation': impact,
            'annual_equivalent': value if 'annual' in indicator_name else value * 12
        }
    
    def _interpret_housing_index(self, value: float) -> Dict[str, Any]:
        """Interpret housing price index values."""
        # Assuming 100 is the base index
        change_from_base = ((value - 100) / 100) * 100
        
        if change_from_base <= -10:
            trend = 'Declining market'
            impact = 'Price correction period, potential buying opportunities'
        elif change_from_base <= 5:
            trend = 'Stable market'
            impact = 'Balanced price environment with modest growth'
        elif change_from_base <= 20:
            trend = 'Growing market'
            impact = 'Healthy price appreciation, good investment environment'
        else:
            trend = 'Rapidly appreciating'
            impact = 'Strong price growth, potential bubble risk'
        
        return {
            'market_trend': trend,
            'market_interpretation': impact,
            'change_from_base': f"{change_from_base:.1f}%"
        }
    
    def _interpret_interest_rate(self, indicator_name: str, value: float) -> Dict[str, Any]:
        """Interpret interest rate values."""
        if value <= 10:
            level = 'Low rates'
            impact = 'Favorable borrowing conditions, increased real estate demand'
        elif value <= 20:
            level = 'Moderate rates'
            impact = 'Balanced financing costs, stable market conditions'
        elif value <= 35:
            level = 'High rates'
            impact = 'Expensive borrowing, may reduce leveraged purchases'
        else:
            level = 'Very high rates'
            impact = 'Prohibitive borrowing costs, cash buyers favored'
        
        return {
            'rate_level': level,
            'market_interpretation': impact,
            'borrowing_environment': 'favorable' if value <= 15 else 'challenging'
        }
    
    def _interpret_fed_rate(self, value: float) -> Dict[str, Any]:
        """Interpret US Federal Funds Rate values."""
        if value <= 2:
            level = 'Accommodative'
            impact = 'Low global rates support capital flows to emerging markets like Turkey'
        elif value <= 5:
            level = 'Neutral'
            impact = 'Balanced global monetary policy, stable international capital flows'
        else:
            level = 'Restrictive'
            impact = 'High US rates may attract capital away from Turkish real estate'
        
        return {
            'policy_stance': level,
            'global_impact': impact,
            'capital_flow_pressure': 'supportive' if value <= 3 else 'neutral' if value <= 5 else 'restrictive'
        }
    
    def _interpret_gdp_growth(self, value: float) -> Dict[str, Any]:
        """Interpret GDP growth rate values."""
        if value <= 0:
            level = 'Contracting economy'
            impact = 'Economic weakness, potential pressure on real estate demand'
        elif value <= 3:
            level = 'Slow growth'
            impact = 'Modest economic expansion, stable real estate fundamentals'
        elif value <= 6:
            level = 'Healthy growth'
            impact = 'Strong economic performance supports real estate demand'
        else:
            level = 'Rapid growth'
            impact = 'Very strong economy, high real estate investment attractiveness'
        
        return {
            'growth_level': level,
            'market_interpretation': impact,
            'economic_momentum': 'positive' if value > 2 else 'negative' if value < 0 else 'neutral'
        } 