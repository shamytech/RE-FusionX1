"""
Economic data integration components for RE-FusionX.

Contains economic indicators, API clients, and integration logic
for Turkish real estate market analysis.
"""

from .api_clients import EconomicDataAPI
from .indicators import EconomicIndicators
from .integrator import EconomicIntegrator
from .snapshot import EconomicSnapshot

def get_current_economic_snapshot():
    """Helper function to get current economic snapshot."""
    snapshot = EconomicSnapshot()
    return snapshot.get_current_economic_snapshot()

__all__ = [
    "EconomicDataAPI",
    "EconomicIndicators", 
    "EconomicIntegrator",
    "EconomicSnapshot",
    "get_current_economic_snapshot"
] 