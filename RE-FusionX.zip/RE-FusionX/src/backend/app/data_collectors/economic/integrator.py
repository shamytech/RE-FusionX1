"""
Economic Data Integration Logic for RE-FusionX
==============================================

This module handles the integration of economic indicators with real estate data.

Innovation Feature #11: Economic Integration
Enhanced with Turkish economic context and real-time data integration.
"""

import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Tuple
from pathlib import Path
import json
import yaml

from rich.console import Console
from rich.progress import Progress, BarColumn, TextColumn, SpinnerColumn, TimeElapsedColumn
from rich.table import Table
from rich.panel import Panel
from rich import box

from .api_clients import EconomicDataAPI
from .indicators import EconomicIndicators


class EconomicIntegrator:
    """
    Economic Data Integrator for Turkish Real Estate Price Prediction
    
    Enhanced with comprehensive Turkish economic indicators from multiple sources:
    - Turkish Central Bank (TCMB) via EVDS API
    - Federal Reserve Economic Data (FRED) API  
    - World Bank API
    - European Central Bank data via Frankfurter API
    
    Innovation Features:
    - Real-time economic data integration
    - Turkish real estate market context
    - Multi-source data validation
    - Economic impact modeling
    """
    
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """
        Initialize Economic Integrator
        
        Args:
            config: Configuration dictionary for economic integration
        """
        self.console = Console()
        self.economic_api = EconomicDataAPI()
        self.indicators = EconomicIndicators()
        
        # Load configuration
        if config is None:
            config_path = Path(__file__).parent.parent.parent.parent / "configs" / "economic_indicators.yaml"
            if config_path.exists():
                with open(config_path, 'r', encoding='utf-8') as f:
                    self.config = yaml.safe_load(f)
            else:
                self.config = self._get_default_config()
        else:
            self.config = config
    
    def _get_default_config(self) -> Dict[str, Any]:
        """Get default configuration for economic integration."""
        return {
            'economic_indicators': {
                'fetch_timeframe_days': 730,  # 2 years
                'cache_duration_hours': 6,
                'integration_method': 'smart_merge',
                'quality_threshold': 0.8
            },
            'integration_settings': {
                'interpolation_method': 'linear',
                'missing_value_strategy': 'forward_fill',
                'outlier_detection': True,
                'normalization': True
            }
        }
    
    def fetch_economic_data(self, 
                           start_date: str = "01-01-2023", 
                           end_date: Optional[str] = None,
                           force_refresh: bool = False) -> Dict[str, pd.DataFrame]:
        """
        Fetch economic data from all sources with enhanced error handling
        
        Args:
            start_date: Start date for data fetching (DD-MM-YYYY)
            end_date: End date for data fetching (DD-MM-YYYY) 
            force_refresh: Force refresh even if cached data exists
            
        Returns:
            Dictionary mapping indicator names to DataFrames
        """
        if not end_date:
            end_date = datetime.now().strftime('%d-%m-%Y')
        
        economic_data = {}
        
        self.console.print(Panel(
            f"[bold blue]🏦 Fetching Economic Data[/bold blue]\n"
            f"Period: {start_date} to {end_date}\n"
            f"Force Refresh: {force_refresh}",
            title="Economic Data Integration",
            box=box.ROUNDED
        ))
        
        # Get all indicators from the configuration
        all_indicators = self.indicators.get_all_indicators()
        total_indicators = sum(len(cat) for cat in all_indicators.values())
        
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            BarColumn(),
            TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
            TimeElapsedColumn(),
            console=self.console
        ) as progress:
            
            main_task = progress.add_task("Fetching Economic Indicators", total=total_indicators)
            
            # Process each category
            for category_name, category_indicators in all_indicators.items():
                category_task = progress.add_task(f"Category: {category_name}", total=len(category_indicators))
                
                for indicator_name, config in category_indicators.items():
                    try:
                        progress.update(category_task, description=f"Fetching {indicator_name}")
                        
                        # Fetch data based on source
                        if config.source == 'frankfurter':
                            # Current exchange rates
                            rate_data = self.economic_api.get_frankfurter_exchange_rates(
                                base_currency=config.base,
                                target_currency=config.target
                            )
                            if rate_data:
                                # Convert to DataFrame format
                                df = pd.DataFrame([{
                                    'date': pd.to_datetime(rate_data['date']),
                                    'value': rate_data['rate']
                                }])
                                df.set_index('date', inplace=True)
                                economic_data[indicator_name] = df
                        
                        elif indicator_name == 'us_fed_rate':
                            # FRED data
                            df = self.economic_api.get_fred_data('FEDFUNDS')
                            if df is not None and not df.empty:
                                economic_data[indicator_name] = df
                        
                        elif indicator_name == 'turkey_gdp_growth':
                            # World Bank data
                            df = self.economic_api.get_world_bank_data('NY.GDP.MKTP.KD.ZG', 'TR')
                            if df is not None and not df.empty:
                                economic_data[indicator_name] = df
                        
                        else:
                            # TCMB indicators
                            df = self.economic_api.get_tcmb_indicator(
                                indicator_name, 
                                start_date=start_date, 
                                end_date=end_date
                            )
                            if df is not None and not df.empty:
                                economic_data[indicator_name] = df
                        
                        progress.update(category_task, advance=1)
                        progress.update(main_task, advance=1)
                        
                    except Exception as e:
                        self.console.print(f"[yellow]⚠️ Error fetching {indicator_name}: {str(e)[:50]}...[/yellow]")
                        progress.update(category_task, advance=1)
                        progress.update(main_task, advance=1)
                        continue
        
        # Display fetch summary
        self._display_fetch_summary(economic_data)
        
        return economic_data
    
    def _display_fetch_summary(self, economic_data: Dict[str, pd.DataFrame]):
        """Display summary of fetched economic data."""
        fetched_indicators = len([k for k, v in economic_data.items() if v is not None and not v.empty])
        total_indicators = 12  # Expected number of indicators
        success_rate = (fetched_indicators / total_indicators) * 100
        
        self.console.print("\n[bold blue]📋 ECONOMIC INDICATORS SUMMARY[/bold blue]")
        self.console.print("=" * 40)
        
        for indicator_name, indicator_data in economic_data.items():
            records_count = len(indicator_data) if indicator_data is not None else 0
            self.console.print(f"[green]✅ {indicator_name}[/green]: {records_count} records")
        
        # Missing indicators
        all_expected = ['usd_try', 'eur_try', 'cpi_annual', 'cpi_monthly', 'housing_price_index', 
                       'construction_cost_index', 'policy_rate', 'interest_rates', 'current_account', 
                       'foreign_reserves', 'us_fed_rate', 'turkey_gdp_growth']
        
        missing = set(all_expected) - set(economic_data.keys())
        for missing_indicator in missing:
            self.console.print(f"[red]❌ {missing_indicator}[/red]: Not fetched")
        
        # Results summary
        self.console.print(f"\n[bold green]🎯 RESULTS:[/bold green]")
        self.console.print(f"Working: {fetched_indicators}/{total_indicators} ({success_rate:.1f}%)")
        self.console.print(f"Failing: {total_indicators - fetched_indicators}/{total_indicators}")
        
        if fetched_indicators > 9:
            self.console.print("[green]🚀 IMPROVEMENT: All critical indicators working![/green]")
        elif fetched_indicators >= 9:
            self.console.print("[yellow]⚠️ Most indicators working, minor issues remain[/yellow]")
        else:
            self.console.print("[red]❌ Several indicators need fixing[/red]")

    def integrate_with_real_estate_data(self, 
                                      real_estate_df: pd.DataFrame, 
                                      economic_data: Dict[str, pd.DataFrame],
                                      integration_method: str = 'smart_merge') -> pd.DataFrame:
        """
        Integrate economic indicators with real estate data using advanced methods
        
        Args:
            real_estate_df: Real estate dataset
            economic_data: Economic indicators data
            integration_method: Method for integration ('smart_merge', 'time_based', 'interpolation')
            
        Returns:
            Enhanced real estate DataFrame with economic features
        """
        if real_estate_df.empty:
            self.console.print("[yellow]⚠️ Real estate DataFrame is empty[/yellow]")
            return real_estate_df
        
        enhanced_df = real_estate_df.copy()
        
        # Ensure date column exists and is properly formatted
        if 'date' not in enhanced_df.columns:
            if 'listing_date' in enhanced_df.columns:
                enhanced_df['date'] = pd.to_datetime(enhanced_df['listing_date'])
            else:
                # Create synthetic dates if no date column exists
                enhanced_df['date'] = pd.date_range(start='2020-01-01', periods=len(enhanced_df), freq='D')
        else:
            enhanced_df['date'] = pd.to_datetime(enhanced_df['date'])
        
        # Integration statistics
        integration_stats = {
            'total_indicators': len(economic_data),
            'successful_integrations': 0,
            'failed_integrations': 0,
            'data_quality_score': 0.0
        }
        
        with Progress(console=self.console) as progress:
            task = progress.add_task("Integrating Economic Data", total=len(economic_data))
            
            for indicator_name, indicator_df in economic_data.items():
                try:
                    if indicator_df.empty:
                        integration_stats['failed_integrations'] += 1
                        progress.update(task, advance=1)
                        continue
                    
                    # Prepare indicator data
                    indicator_clean = indicator_df.copy()
                    
                    # Ensure proper date index
                    if not isinstance(indicator_clean.index, pd.DatetimeIndex):
                        if 'date' in indicator_clean.columns:
                            indicator_clean.set_index('date', inplace=True)
                        indicator_clean.index = pd.to_datetime(indicator_clean.index)
                    
                    # Forward fill missing values for better integration
                    indicator_clean = indicator_clean.fillna(method='ffill').fillna(method='bfill')
                    
                    # Integration based on method
                    if integration_method == 'smart_merge':
                        # Use nearest date matching with interpolation
                        enhanced_df[f'economic_{indicator_name}'] = enhanced_df['date'].apply(
                            lambda x: self._get_nearest_economic_value(x, indicator_clean)
                        )
                    
                    elif integration_method == 'time_based':
                        # Direct time-based merge
                        enhanced_df = enhanced_df.merge(
                            indicator_clean.reset_index().rename(columns={'index': 'date', 'value': f'economic_{indicator_name}'}),
                            on='date',
                            how='left'
                        )
                    
                    elif integration_method == 'interpolation':
                        # Linear interpolation for missing values
                        temp_df = enhanced_df.set_index('date')[[]].join(
                            indicator_clean.rename(columns={'value': f'economic_{indicator_name}'}),
                            how='left'
                        )
                        temp_df[f'economic_{indicator_name}'] = temp_df[f'economic_{indicator_name}'].interpolate()
                        enhanced_df[f'economic_{indicator_name}'] = temp_df[f'economic_{indicator_name}'].values
                    
                    # Apply economic context
                    if f'economic_{indicator_name}' in enhanced_df.columns:
                        latest_value = enhanced_df[f'economic_{indicator_name}'].iloc[-1]
                        context = self.indicators.apply_economic_context(indicator_name, latest_value)
                        enhanced_df[f'economic_{indicator_name}_context'] = context.get('market_interpretation', 'No context available')
                        
                        integration_stats['successful_integrations'] += 1
                    
                except Exception as e:
                    self.console.print(f"[yellow]⚠️ Failed to integrate {indicator_name}: {str(e)[:50]}...[/yellow]")
                    integration_stats['failed_integrations'] += 1
                
                progress.update(task, advance=1)
        
        # Calculate integration quality score
        if integration_stats['total_indicators'] > 0:
            integration_stats['data_quality_score'] = (
                integration_stats['successful_integrations'] / integration_stats['total_indicators']
            )
        
        # Add integration metadata
        enhanced_df.attrs['economic_integration'] = integration_stats
        
        # Display integration summary
        self._display_integration_summary(integration_stats)
        
        return enhanced_df

    def _get_nearest_economic_value(self, target_date: pd.Timestamp, indicator_df: pd.DataFrame) -> float:
        """Get nearest economic indicator value for a target date"""
        try:
            if indicator_df.empty:
                return np.nan
            
            # Find nearest date
            nearest_idx = indicator_df.index.get_indexer([target_date], method='nearest')[0]
            if nearest_idx >= 0:
                return indicator_df.iloc[nearest_idx]['value'] if 'value' in indicator_df.columns else indicator_df.iloc[nearest_idx, 0]
            else:
                return np.nan
        except:
            return np.nan

    def _display_integration_summary(self, integration_stats: Dict[str, Any]):
        """Display economic integration summary"""
        summary_table = Table(title="Economic Integration Summary", box=box.ROUNDED)
        summary_table.add_column("Metric", style="cyan")
        summary_table.add_column("Value", style="green")
        
        summary_table.add_row("Total Indicators", str(integration_stats['total_indicators']))
        summary_table.add_row("Successful Integrations", str(integration_stats['successful_integrations']))
        summary_table.add_row("Failed Integrations", str(integration_stats['failed_integrations']))
        summary_table.add_row("Data Quality Score", f"{integration_stats['data_quality_score']:.2%}")
        
        self.console.print(summary_table)

    def save_economic_data(self, economic_data: Dict[str, pd.DataFrame], 
                          output_dir: Path) -> Dict[str, Any]:
        """
        Save economic data and integration summary
        
        Args:
            economic_data: Economic indicators data
            output_dir: Output directory for saving data
            
        Returns:
            Save summary with file paths and statistics
        """
        output_dir = Path(output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)
        
        save_summary = {
            'timestamp': datetime.now().isoformat(),
            'indicators_saved': [],
            'total_records': 0,
            'file_paths': {},
            'data_quality': {}
        }
        
        # Save individual indicator files
        for indicator_name, indicator_df in economic_data.items():
            if not indicator_df.empty:
                file_path = output_dir / f"{indicator_name}_data.csv"
                indicator_df.to_csv(file_path)
                
                save_summary['indicators_saved'].append(indicator_name)
                save_summary['total_records'] += len(indicator_df)
                save_summary['file_paths'][indicator_name] = str(file_path)
                
                # Data quality metrics
                save_summary['data_quality'][indicator_name] = {
                    'records': len(indicator_df),
                    'missing_values': indicator_df.isnull().sum().sum(),
                    'date_range': {
                        'start': str(indicator_df.index.min()),
                        'end': str(indicator_df.index.max())
                    }
                }
        
        # Save comprehensive economic data file
        if economic_data:
            all_data_path = output_dir / "all_economic_indicators.json"
            with open(all_data_path, 'w') as f:
                # Convert DataFrames to JSON-serializable format
                json_data = {}
                for name, df in economic_data.items():
                    if not df.empty:
                        json_data[name] = {
                            'data': df.reset_index().to_dict('records'),
                            'metadata': save_summary['data_quality'].get(name, {})
                        }
                json.dump(json_data, f, indent=2, default=str)
            
            save_summary['file_paths']['comprehensive'] = str(all_data_path)
        
        # Save summary file
        summary_path = output_dir / "economic_data_summary.json"
        with open(summary_path, 'w') as f:
            json.dump(save_summary, f, indent=2)
        
        save_summary['file_paths']['summary'] = str(summary_path)
        
        # Display save summary
        self.console.print(Panel(
            f"[bold green]💾 Economic Data Saved[/bold green]\n"
            f"Indicators: {len(save_summary['indicators_saved'])}\n"
            f"Total Records: {save_summary['total_records']:,}\n"
            f"Output Directory: {output_dir}",
            title="Save Summary",
            box=box.ROUNDED
        ))
        
        return save_summary 