"""
Economic Snapshot Module for RE-FusionX
=======================================

This module provides current economic snapshots and summaries
for real-time economic context in real estate analysis.

Innovation Feature #11: Economic Integration
Real-time economic snapshot for current market conditions.
"""

import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any
import json

from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich import box

from .api_clients import EconomicDataAPI
from .indicators import EconomicIndicators


class EconomicSnapshot:
    """
    Economic Snapshot Generator
    
    Provides current economic conditions summary and real-time indicators
    for Turkish real estate market analysis.
    """
    
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """
        Initialize Economic Snapshot generator.
        
        Args:
            config: Optional configuration dictionary
        """
        self.console = Console()
        self.economic_api = EconomicDataAPI()
        self.indicators = EconomicIndicators()
        self.config = config or {}
    
    def get_current_economic_snapshot(self) -> Dict[str, Any]:
        """
        Get current economic snapshot with all indicators
        
        Returns:
            Dictionary containing current economic indicators and analysis
        """
        snapshot_data = {
            'timestamp': datetime.now().isoformat(),
            'indicators': {},
            'analysis': {},
            'summary': {},
            'data_quality': {
                'total_indicators': 0,
                'successful_fetches': 0,
                'failed_fetches': 0,
                'success_rate': 0.0
            }
        }
        
        self.console.print(Panel(
            "[bold blue]📸 Generating Economic Snapshot[/bold blue]\n"
            "Fetching current economic indicators...",
            title="Economic Snapshot",
            box=box.ROUNDED
        ))
        
        # Get all indicators
        all_indicators = self.indicators.get_all_indicators()
        total_indicators = sum(len(cat) for cat in all_indicators.values())
        snapshot_data['data_quality']['total_indicators'] = total_indicators
        
        # Fetch current data for each indicator
        for category_name, category_indicators in all_indicators.items():
            for indicator_name, config in category_indicators.items():
                try:
                    # Get recent data (2 years for better coverage)
                    start_date = (datetime.now() - timedelta(days=730)).strftime('%d-%m-%Y')
                    end_date = datetime.now().strftime('%d-%m-%Y')
                    
                    current_value = None
                    data_date = None
                    
                    if config.source == 'frankfurter':
                        # Current exchange rates
                        rate_data = self.economic_api.get_frankfurter_exchange_rates(
                            base_currency=config.base,
                            target_currency=config.target
                        )
                        if rate_data:
                            current_value = rate_data['rate']
                            data_date = rate_data['date']
                    
                    elif indicator_name == 'us_fed_rate':
                        # FRED data
                        df = self.economic_api.get_fred_data('FEDFUNDS')
                        if df is not None and not df.empty:
                            current_value = df.iloc[-1]['value']
                            data_date = df.index[-1].strftime('%Y-%m-%d')
                    
                    elif indicator_name == 'turkey_gdp_growth':
                        # World Bank data (annual)
                        df = self.economic_api.get_world_bank_data('NY.GDP.MKTP.KD.ZG', 'TR')
                        if df is not None and not df.empty:
                            current_value = df.iloc[-1]['value']
                            data_date = df.index[-1].strftime('%Y-%m-%d')
                    
                    else:
                        # TCMB indicators
                        df = self.economic_api.get_tcmb_indicator(
                            indicator_name, 
                            start_date=start_date, 
                            end_date=end_date
                        )
                        if df is not None and not df.empty:
                            current_value = df.iloc[-1]['value'] if 'value' in df.columns else df.iloc[-1, 0]
                            data_date = df.index[-1].strftime('%Y-%m-%d')
                    
                    if current_value is not None:
                        # Apply economic context
                        context = self.indicators.apply_economic_context(indicator_name, current_value)
                        
                        snapshot_data['indicators'][indicator_name] = {
                            'value': float(current_value),
                            'date': data_date,
                            'category': category_name,
                            'name': config.name,
                            'description': config.description,
                            'context': context
                        }
                        
                        snapshot_data['data_quality']['successful_fetches'] += 1
                        
                        self.console.print(f"[green]✅ {indicator_name}[/green]: {current_value}")
                    else:
                        snapshot_data['data_quality']['failed_fetches'] += 1
                        self.console.print(f"[red]❌ {indicator_name}[/red]: No data")
                
                except Exception as e:
                    snapshot_data['data_quality']['failed_fetches'] += 1
                    self.console.print(f"[yellow]⚠️ {indicator_name}[/yellow]: {str(e)[:50]}...")
        
        # Calculate success rate
        if total_indicators > 0:
            snapshot_data['data_quality']['success_rate'] = (
                snapshot_data['data_quality']['successful_fetches'] / total_indicators
            ) * 100
        
        # Generate analysis and summary
        snapshot_data['analysis'] = self._analyze_economic_conditions(snapshot_data['indicators'])
        snapshot_data['summary'] = self._create_economic_summary(snapshot_data['indicators'])
        
        # Display snapshot summary
        self._display_snapshot_summary(snapshot_data)
        
        return snapshot_data
    
    def _analyze_economic_conditions(self, indicators: Dict[str, Any]) -> Dict[str, Any]:
        """
        Analyze current economic conditions based on indicator values.
        
        Args:
            indicators: Dictionary of current indicator values
            
        Returns:
            Economic analysis and interpretation
        """
        analysis = {
            'overall_assessment': 'neutral',
            'currency_stability': 'unknown',
            'inflation_environment': 'unknown',
            'monetary_policy_stance': 'unknown',
            'international_pressure': 'unknown',
            'real_estate_outlook': 'unknown',
            'risk_factors': [],
            'opportunities': [],
            'key_metrics': {}
        }
        
        # Currency analysis
        usd_try = indicators.get('usd_try', {}).get('value')
        eur_try = indicators.get('eur_try', {}).get('value')
        
        if usd_try and eur_try:
            avg_rate = (usd_try + eur_try) / 2
            if avg_rate > 30:
                analysis['currency_stability'] = 'weak'
                analysis['risk_factors'].append('High exchange rates increase foreign buyer costs')
            elif avg_rate > 20:
                analysis['currency_stability'] = 'moderate'
            else:
                analysis['currency_stability'] = 'strong'
                analysis['opportunities'].append('Favorable exchange rates for foreign investment')
        
        # Inflation analysis
        cpi_annual = indicators.get('cpi_annual', {}).get('value')
        if cpi_annual:
            if cpi_annual > 20:
                analysis['inflation_environment'] = 'high'
                analysis['opportunities'].append('Real estate as inflation hedge')
            elif cpi_annual > 10:
                analysis['inflation_environment'] = 'moderate'
            else:
                analysis['inflation_environment'] = 'low'
                analysis['risk_factors'].append('Low inflation may indicate economic weakness')
        
        # Interest rate analysis
        policy_rate = indicators.get('policy_rate', {}).get('value')
        interest_rates = indicators.get('interest_rates', {}).get('value')
        
        rate_to_analyze = policy_rate or interest_rates
        if rate_to_analyze:
            if rate_to_analyze > 25:
                analysis['monetary_policy_stance'] = 'very_restrictive'
                analysis['risk_factors'].append('Very high interest rates limit mortgage accessibility')
            elif rate_to_analyze > 15:
                analysis['monetary_policy_stance'] = 'restrictive'
                analysis['risk_factors'].append('High interest rates increase borrowing costs')
            elif rate_to_analyze > 5:
                analysis['monetary_policy_stance'] = 'neutral'
            else:
                analysis['monetary_policy_stance'] = 'accommodative'
                analysis['opportunities'].append('Low interest rates support real estate financing')
        
        # International pressure
        us_fed_rate = indicators.get('us_fed_rate', {}).get('value')
        if us_fed_rate and rate_to_analyze:
            rate_differential = rate_to_analyze - us_fed_rate
            if rate_differential > 15:
                analysis['international_pressure'] = 'favorable'
                analysis['opportunities'].append('High rate differential attracts foreign capital')
            elif rate_differential > 5:
                analysis['international_pressure'] = 'neutral'
            else:
                analysis['international_pressure'] = 'challenging'
                analysis['risk_factors'].append('Low rate differential may lead to capital outflows')
        
        # Overall assessment
        risk_count = len(analysis['risk_factors'])
        opportunity_count = len(analysis['opportunities'])
        
        if opportunity_count > risk_count:
            analysis['overall_assessment'] = 'positive'
            analysis['real_estate_outlook'] = 'favorable'
        elif risk_count > opportunity_count:
            analysis['overall_assessment'] = 'cautious'
            analysis['real_estate_outlook'] = 'challenging'
        else:
            analysis['overall_assessment'] = 'neutral'
            analysis['real_estate_outlook'] = 'mixed'
        
        # Key metrics summary
        analysis['key_metrics'] = {
            'usd_try_rate': usd_try,
            'inflation_rate': cpi_annual,
            'policy_rate': rate_to_analyze,
            'fed_rate': us_fed_rate,
            'rate_differential': rate_to_analyze - us_fed_rate if (rate_to_analyze and us_fed_rate) else None
        }
        
        return analysis
    
    def _create_economic_summary(self, indicators: Dict[str, Any]) -> Dict[str, Any]:
        """
        Create a concise economic summary.
        
        Args:
            indicators: Dictionary of current indicator values
            
        Returns:
            Economic summary for easy consumption
        """
        summary = {
            'snapshot_date': datetime.now().strftime('%Y-%m-%d'),
            'data_coverage': f"{len(indicators)}/12 indicators",
            'key_indicators': {},
            'market_conditions': {},
            'investor_considerations': []
        }
        
        # Key indicators summary
        key_mapping = {
            'usd_try': 'USD/TRY Exchange Rate',
            'cpi_annual': 'Annual Inflation (%)',
            'policy_rate': 'Policy Rate (%)',
            'housing_price_index': 'Housing Price Index',
            'us_fed_rate': 'US Fed Rate (%)'
        }
        
        for indicator_key, display_name in key_mapping.items():
            if indicator_key in indicators:
                value = indicators[indicator_key]['value']
                summary['key_indicators'][display_name] = {
                    'value': value,
                    'date': indicators[indicator_key]['date'],
                    'impact': indicators[indicator_key]['context'].get('market_interpretation', 'No interpretation available')
                }
        
        # Market conditions summary
        if 'usd_try' in indicators and 'cpi_annual' in indicators:
            usd_rate = indicators['usd_try']['value']
            inflation = indicators['cpi_annual']['value']
            
            if usd_rate > 25 and inflation > 15:
                summary['market_conditions']['environment'] = 'High volatility environment'
                summary['market_conditions']['recommendation'] = 'Caution advised, focus on fundamentals'
            elif usd_rate < 20 and inflation < 10:
                summary['market_conditions']['environment'] = 'Stable economic environment'
                summary['market_conditions']['recommendation'] = 'Favorable conditions for investment'
            else:
                summary['market_conditions']['environment'] = 'Mixed economic signals'
                summary['market_conditions']['recommendation'] = 'Selective investment approach recommended'
        
        # Investor considerations
        summary['investor_considerations'] = [
            'Monitor exchange rate trends for foreign investment timing',
            'Consider inflation hedge properties in high inflation periods',
            'Evaluate financing costs based on current interest rates',
            'Track international rate differentials for capital flow impacts'
        ]
        
        return summary
    
    def _display_snapshot_summary(self, snapshot_data: Dict[str, Any]):
        """Display economic snapshot summary in a formatted table."""
        
        # Data quality summary
        quality = snapshot_data['data_quality']
        self.console.print(f"\n[bold blue]📊 Economic Snapshot Summary[/bold blue]")
        self.console.print(f"Success Rate: {quality['success_rate']:.1f}% ({quality['successful_fetches']}/{quality['total_indicators']})")
        
        # Key indicators table
        if snapshot_data['indicators']:
            table = Table(title="Current Economic Indicators", box=box.ROUNDED)
            table.add_column("Indicator", style="cyan")
            table.add_column("Value", style="green")
            table.add_column("Date", style="yellow")
            table.add_column("Impact", style="magenta")
            
            for name, data in snapshot_data['indicators'].items():
                impact = data['context'].get('market_interpretation', 'No analysis')[:50] + "..."
                table.add_row(
                    data['name'],
                    f"{data['value']:.2f}",
                    data['date'],
                    impact
                )
            
            self.console.print(table)
        
        # Analysis summary
        if snapshot_data['analysis']:
            analysis = snapshot_data['analysis']
            self.console.print(f"\n[bold green]🎯 Economic Analysis[/bold green]")
            self.console.print(f"Overall Assessment: {analysis['overall_assessment'].title()}")
            self.console.print(f"Real Estate Outlook: {analysis['real_estate_outlook'].title()}")
            
            if analysis['opportunities']:
                self.console.print(f"\n[green]Opportunities:[/green]")
                for opp in analysis['opportunities']:
                    self.console.print(f"  • {opp}")
            
            if analysis['risk_factors']:
                self.console.print(f"\n[red]Risk Factors:[/red]")
                for risk in analysis['risk_factors']:
                    self.console.print(f"  • {risk}")
    
    def save_economic_indicators_separately(self, indicators: Dict[str, Any], output_dir) -> Dict[str, str]:
        """
        Save economic indicators to separate dedicated files.
        
        Args:
            indicators: Economic indicators data
            output_dir: Output directory path
            
        Returns:
            Dictionary with file paths
        """
        from pathlib import Path
        
        output_dir = Path(output_dir)
        economic_dir = output_dir / 'economic'
        economic_dir.mkdir(parents=True, exist_ok=True)
        
        # Detailed economic indicators file
        detailed_path = economic_dir / 'economic_indicators.json'
        with open(detailed_path, 'w') as f:
            json.dump(indicators, f, indent=2, default=str)
        
        # Simplified summary file
        summary_data = {}
        for name, data in indicators.items():
            summary_data[name] = {
                'value': data['value'],
                'date': data['date'],
                'name': data['name']
            }
        
        summary_path = economic_dir / 'economic_summary.json'
        with open(summary_path, 'w') as f:
            json.dump(summary_data, f, indent=2, default=str)
        
        self.console.print(f"[green]💾 Economic indicators saved to {economic_dir}[/green]")
        
        return {
            'detailed': str(detailed_path),
            'summary': str(summary_path)
        } 