"""
Property data validation.
Ensures property information is complete and valid.
"""

from typing import Dict, Any, List, Tuple, Optional
import re

from app.core.constants import (
    PropertyType, RoomConfiguration, HeatingType,
    BuildingAge, ValidationLimits
)
from app.core.logging import logger


class PropertyValidator:
    """
    Validates property-specific data.
    """
    
    def __init__(self):
        """Initialize property validator."""
        self.turkish_cities = self.load_turkish_cities()
        self.district_data = self.load_district_data()
    
    def load_turkish_cities(self) -> List[str]:
        """Load list of Turkish cities."""
        return [
            "Istanbul", "Ankara", "Izmir", "Bursa", "Antalya", "Adana",
            "Konya", "Gaziantep", "Mersin", "Kayseri", "Eskişehir",
            "Diyarbakır", "Samsun", "Denizli", "Şanlıurfa", "Malatya",
            "Kahramanmaraş", "Van", "Batman", "Elazığ", "Erzurum",
            "Kocaeli", "Muğla", "Manisa", "Aydın", "Balıkesir",
            "Tekirdağ", "Sakarya", "Trabzon", "Ordu", "Afyonkarahisar"
        ]
    
    def load_district_data(self) -> Dict[str, List[str]]:
        """Load district data for major cities."""
        return {
            "Istanbul": [
                "Kadıköy", "Beşiktaş", "Şişli", "Bakırköy", "Üsküdar",
                "Ataşehir", "Maltepe", "Kartal", "Pendik", "Tuzla",
                "Beyoğlu", "Fatih", "Eyüp", "Sarıyer", "Beykoz",
                "Başakşehir", "Esenyurt", "Avcılar", "Beylikdüzü", "Büyükçekmece"
            ],
            "Ankara": [
                "Çankaya", "Keçiören", "Yenimahalle", "Mamak", "Etimesgut",
                "Sincan", "Altındağ", "Pursaklar", "Gölbaşı", "Polatlı"
            ],
            "Izmir": [
                "Konak", "Bornova", "Karşıyaka", "Buca", "Çiğli",
                "Bayraklı", "Gaziemir", "Narlıdere", "Balçova", "Güzelbahçe"
            ]
        }
    
    def validate_property(
        self,
        property_data: Dict[str, Any]
    ) -> Tuple[bool, List[str], Dict[str, Any]]:
        """
        Comprehensive property validation.
        
        Args:
            property_data: Property data to validate
            
        Returns:
            Tuple of (is_valid, errors, cleaned_data)
        """
        errors = []
        cleaned_data = {}
        
        # Validate location
        location_valid, location_errors, location_data = self.validate_location(
            property_data.get("location")
        )
        if not location_valid:
            errors.extend(location_errors)
        else:
            cleaned_data["location"] = location_data
        
        # Validate property type
        prop_type_valid, prop_type_error, prop_type = self.validate_property_type(
            property_data.get("property_type")
        )
        if not prop_type_valid:
            errors.append(prop_type_error)
        else:
            cleaned_data["property_type"] = prop_type
        
        # Validate size
        size_valid, size_error, size_data = self.validate_size(
            property_data.get("size_net"),
            property_data.get("size_gross")
        )
        if not size_valid:
            errors.append(size_error)
        else:
            cleaned_data.update(size_data)
        
        # Validate rooms
        rooms_valid, rooms_error, rooms = self.validate_rooms(
            property_data.get("rooms")
        )
        if not rooms_valid:
            errors.append(rooms_error)
        else:
            cleaned_data["rooms"] = rooms
        
        # Validate price
        if "price" in property_data:
            price_valid, price_error, price = self.validate_price(
                property_data["price"]
            )
            if not price_valid:
                errors.append(price_error)
            else:
                cleaned_data["price"] = price
        
        # Validate floor
        if "floor" in property_data:
            floor_valid, floor_error, floor_data = self.validate_floor(
                property_data.get("floor"),
                property_data.get("total_floors")
            )
            if not floor_valid:
                errors.append(floor_error)
            else:
                cleaned_data.update(floor_data)
        
        # Validate building age
        if "building_age" in property_data:
            age_valid, age_error, age = self.validate_building_age(
                property_data["building_age"]
            )
            if not age_valid:
                errors.append(age_error)
            else:
                cleaned_data["building_age"] = age
        
        # Validate heating
        if "heating" in property_data:
            heating_valid, heating_error, heating = self.validate_heating(
                property_data["heating"]
            )
            if not heating_valid:
                errors.append(heating_error)
            else:
                cleaned_data["heating"] = heating
        
        # Add other fields without validation
        for key in ["bathrooms", "furnished", "in_site", "credit_eligible", "features"]:
            if key in property_data:
                cleaned_data[key] = property_data[key]
        
        return len(errors) == 0, errors, cleaned_data
    
    def validate_location(
        self,
        location: Optional[str]
    ) -> Tuple[bool, List[str], Dict[str, str]]:
        """
        Validate and parse location.
        
        Args:
            location: Location string
            
        Returns:
            Tuple of (is_valid, errors, parsed_location)
        """
        if not location:
            return False, ["Location is required"], {}
        
        errors = []
        parsed = {}
        
        # Split location parts
        parts = [p.strip() for p in location.split("-")]
        
        if len(parts) == 0:
            return False, ["Invalid location format"], {}
        
        # Try to identify city
        city = None
        for part in parts:
            for known_city in self.turkish_cities:
                if known_city.lower() in part.lower():
                    city = known_city
                    parsed["city"] = city
                    break
            if city:
                break
        
        if not city:
            errors.append(f"Could not identify Turkish city in location: {location}")
        
        # Try to identify district
        if city and len(parts) > 1:
            districts = self.district_data.get(city, [])
            for part in parts[1:]:
                for district in districts:
                    if district.lower() in part.lower():
                        parsed["district"] = district
                        break
        
        # Add neighborhood if available
        if len(parts) > 2:
            parsed["neighborhood"] = parts[-1]
        
        # Store full location
        parsed["full_location"] = location
        
        return len(errors) == 0, errors, parsed
    
    def validate_property_type(
        self,
        property_type: Optional[str]
    ) -> Tuple[bool, str, str]:
        """
        Validate property type.
        
        Args:
            property_type: Property type to validate
            
        Returns:
            Tuple of (is_valid, error, cleaned_type)
        """
        if not property_type:
            return True, "", ""  # Optional field
        
        valid_types = [pt.value for pt in PropertyType]
        
        if property_type in valid_types:
            return True, "", property_type
        
        # Try to match similar
        for valid_type in valid_types:
            if valid_type.lower() == property_type.lower():
                return True, "", valid_type
        
        return False, f"Invalid property type. Must be one of: {', '.join(valid_types)}", ""
    
    def validate_size(
        self,
        size_net: Optional[Any],
        size_gross: Optional[Any]
    ) -> Tuple[bool, str, Dict[str, float]]:
        """
        Validate property size.
        
        Args:
            size_net: Net size
            size_gross: Gross size
            
        Returns:
            Tuple of (is_valid, error, size_data)
        """
        if not size_net and not size_gross:
            return False, "At least one size measurement is required", {}
        
        size_data = {}
        
        # Validate net size
        if size_net:
            try:
                net_value = float(str(size_net).replace(" m²", "").replace(",", "."))
                
                if net_value < ValidationLimits.MIN_SIZE:
                    return False, f"Net size must be at least {ValidationLimits.MIN_SIZE} m²", {}
                
                if net_value > ValidationLimits.MAX_SIZE:
                    return False, f"Net size cannot exceed {ValidationLimits.MAX_SIZE} m²", {}
                
                size_data["size_net"] = net_value
                
            except:
                return False, "Invalid net size format", {}
        
        # Validate gross size
        if size_gross:
            try:
                gross_value = float(str(size_gross).replace(" m²", "").replace(",", "."))
                
                if gross_value < ValidationLimits.MIN_SIZE:
                    return False, f"Gross size must be at least {ValidationLimits.MIN_SIZE} m²", {}
                
                if gross_value > ValidationLimits.MAX_SIZE:
                    return False, f"Gross size cannot exceed {ValidationLimits.MAX_SIZE} m²", {}
                
                size_data["size_gross"] = gross_value
                
                # Check consistency
                if "size_net" in size_data and size_data["size_net"] > gross_value:
                    return False, "Net size cannot be larger than gross size", {}
                
            except:
                return False, "Invalid gross size format", {}
        
        return True, "", size_data
    
    def validate_rooms(
        self,
        rooms: Optional[str]
    ) -> Tuple[bool, str, str]:
        """
        Validate room configuration.
        
        Args:
            rooms: Room configuration
            
        Returns:
            Tuple of (is_valid, error, cleaned_rooms)
        """
        if not rooms:
            return False, "Room configuration is required", ""
        
        # Check against enum
        valid_configs = [rc.value for rc in RoomConfiguration]
        
        if rooms in valid_configs:
            return True, "", rooms
        
        # Try to parse and validate format
        pattern = r'^(\d+)\+(\d+)$'
        match = re.match(pattern, str(rooms))
        
        if match:
            main_rooms = int(match.group(1))
            living_rooms = int(match.group(2))
            
            if main_rooms < ValidationLimits.MIN_ROOMS:
                return False, f"Main rooms must be at least {ValidationLimits.MIN_ROOMS}", ""
            
            if main_rooms > ValidationLimits.MAX_ROOMS:
                return False, f"Main rooms cannot exceed {ValidationLimits.MAX_ROOMS}", ""
            
            formatted = f"{main_rooms}+{living_rooms}"
            return True, "", formatted
        
        return False, "Invalid room format. Use format like '3+1'", ""
    
    def validate_price(
        self,
        price: Optional[Any]
    ) -> Tuple[bool, str, float]:
        """
        Validate property price.
        
        Args:
            price: Price to validate
            
        Returns:
            Tuple of (is_valid, error, cleaned_price)
        """
        if not price:
            return True, "", 0  # Optional field
        
        try:
            # Clean and convert price
            price_str = str(price).replace(" TL", "").replace(".", "").replace(",", ".")
            price_value = float(price_str)
            
            if price_value < ValidationLimits.MIN_PRICE:
                return False, f"Price must be at least {ValidationLimits.MIN_PRICE} TL", 0
            
            if price_value > ValidationLimits.MAX_PRICE:
                return False, f"Price cannot exceed {ValidationLimits.MAX_PRICE} TL", 0
            
            return True, "", price_value
            
        except:
            return False, "Invalid price format", 0
    
    def validate_floor(
        self,
        floor: Optional[Any],
        total_floors: Optional[Any]
    ) -> Tuple[bool, str, Dict[str, Any]]:
        """
        Validate floor information.
        
        Args:
            floor: Floor number
            total_floors: Total floors in building
            
        Returns:
            Tuple of (is_valid, error, floor_data)
        """
        floor_data = {}
        
        # Validate floor
        if floor is not None:
            # Handle text floors
            if isinstance(floor, str):
                floor_lower = floor.lower()
                if "zemin" in floor_lower or "giriş" in floor_lower:
                    floor_data["floor"] = 0
                    floor_data["floor_text"] = floor
                elif "bodrum" in floor_lower:
                    floor_data["floor"] = -1
                    floor_data["floor_text"] = floor
                else:
                    # Try to extract number
                    try:
                        floor_num = int(re.search(r'\d+', floor).group())
                        if floor_num < ValidationLimits.MIN_FLOOR:
                            return False, f"Floor cannot be less than {ValidationLimits.MIN_FLOOR}", {}
                        if floor_num > ValidationLimits.MAX_FLOOR:
                            return False, f"Floor cannot exceed {ValidationLimits.MAX_FLOOR}", {}
                        floor_data["floor"] = floor_num
                    except:
                        floor_data["floor_text"] = floor
            else:
                try:
                    floor_num = int(floor)
                    if floor_num < ValidationLimits.MIN_FLOOR:
                        return False, f"Floor cannot be less than {ValidationLimits.MIN_FLOOR}", {}
                    if floor_num > ValidationLimits.MAX_FLOOR:
                        return False, f"Floor cannot exceed {ValidationLimits.MAX_FLOOR}", {}
                    floor_data["floor"] = floor_num
                except:
                    return False, "Invalid floor format", {}
        
        # Validate total floors
        if total_floors is not None:
            try:
                total_num = int(total_floors)
                if total_num < 1:
                    return False, "Total floors must be at least 1", {}
                if total_num > ValidationLimits.MAX_FLOOR:
                    return False, f"Total floors cannot exceed {ValidationLimits.MAX_FLOOR}", {}
                floor_data["total_floors"] = total_num
                
                # Check consistency
                if "floor" in floor_data and floor_data["floor"] > total_num:
                    return False, "Floor number cannot exceed total floors", {}
                    
            except:
                return False, "Invalid total floors format", {}
        
        return True, "", floor_data
    
    def validate_building_age(
        self,
        building_age: Optional[str]
    ) -> Tuple[bool, str, str]:
        """
        Validate building age.
        
        Args:
            building_age: Building age to validate
            
        Returns:
            Tuple of (is_valid, error, cleaned_age)
        """
        if not building_age:
            return True, "", ""  # Optional field
        
        valid_ages = [age.value for age in BuildingAge]
        
        if building_age in valid_ages:
            return True, "", building_age
        
        # Try to match similar
        age_str = str(building_age).lower()
        
        if "yeni" in age_str or "new" in age_str:
            return True, "", BuildingAge.NEW.value
        
        # Try to extract year range
        year_match = re.search(r'(\d+)\s*-\s*(\d+)', building_age)
        if year_match:
            return True, "", building_age
        
        # Single year
        single_year = re.search(r'^\d+$', building_age)
        if single_year:
            year = int(single_year.group())
            if year == 0:
                return True, "", BuildingAge.NEW.value
            elif year <= 4:
                return True, "", BuildingAge.ONE_TO_FOUR.value
            elif year <= 10:
                return True, "", BuildingAge.FIVE_TO_TEN.value
            elif year <= 15:
                return True, "", BuildingAge.ELEVEN_TO_FIFTEEN.value
            elif year <= 20:
                return True, "", BuildingAge.SIXTEEN_TO_TWENTY.value
            elif year <= 25:
                return True, "", BuildingAge.TWENTY_ONE_TO_TWENTY_FIVE.value
            elif year <= 30:
                return True, "", BuildingAge.TWENTY_SIX_TO_THIRTY.value
            else:
                return True, "", BuildingAge.THIRTY_PLUS.value
        
        return False, f"Invalid building age. Use format like '5-10' or choose from: {', '.join(valid_ages)}", ""
    
    def validate_heating(
        self,
        heating: Optional[str]
    ) -> Tuple[bool, str, str]:
        """
        Validate heating type.
        
        Args:
            heating: Heating type to validate
            
        Returns:
            Tuple of (is_valid, error, cleaned_heating)
        """
        if not heating:
            return True, "", ""  # Optional field
        
        valid_types = [ht.value for ht in HeatingType]
        
        if heating in valid_types:
            return True, "", heating
        
        # Try to match keywords
        heating_lower = heating.lower()
        
        if "merkezi" in heating_lower or "central" in heating_lower:
            if "pay" in heating_lower or "ölçer" in heating_lower:
                return True, "", HeatingType.CENTRAL_METERED.value
            return True, "", HeatingType.CENTRAL.value
        elif "kombi" in heating_lower:
            return True, "", HeatingType.COMBI.value
        elif "yerden" in heating_lower or "underfloor" in heating_lower:
            return True, "", HeatingType.UNDERFLOOR.value
        elif "klima" in heating_lower or "ac" in heating_lower:
            return True, "", HeatingType.AC.value
        elif "soba" in heating_lower or "stove" in heating_lower:
            return True, "", HeatingType.STOVE.value
        
        return False, f"Invalid heating type. Choose from: {', '.join(valid_types)}", ""
