"""
Context validation for maintaining conversation coherence.
Ensures context consistency and relevance.
"""

from typing import Dict, Any, List, Optional
from datetime import datetime, timedelta

from app.core.logging import logger


class ContextValidator:
    """
    Validates and manages conversation context.
    """
    
    def __init__(self):
        """Initialize context validator."""
        self.max_context_age = timedelta(hours=1)
        self.max_context_size = 10
        self.context_requirements = self.define_context_requirements()
    
    def define_context_requirements(self) -> Dict[str, List[str]]:
        """Define required context for different intents."""
        return {
            "price_estimation": ["property_data"],
            "property_analysis": ["property_data"],
            "market_analysis": ["location"],
            "investment_advice": ["budget", "preferences"],
            "comparison": ["properties_to_compare"],
            "follow_up": ["previous_intent", "previous_response"]
        }
    
    def validate_context(
        self,
        context: Dict[str, Any],
        intent: str
    ) -> Dict[str, Any]:
        """
        Validate context for specific intent.
        
        Args:
            context: Current context
            intent: User intent
            
        Returns:
            Validation results
        """
        try:
            # Check context age
            if not self.is_context_fresh(context):
                return {
                    "is_valid": False,
                    "reason": "Context has expired",
                    "action": "refresh_context"
                }
            
            # Check required fields for intent
            required_fields = self.context_requirements.get(intent, [])
            missing_fields = []
            
            for field in required_fields:
                if field not in context or not context[field]:
                    missing_fields.append(field)
            
            if missing_fields:
                return {
                    "is_valid": False,
                    "reason": "Missing required context",
                    "missing_fields": missing_fields,
                    "action": "request_information"
                }
            
            # Validate context consistency
            if not self.is_context_consistent(context):
                return {
                    "is_valid": False,
                    "reason": "Inconsistent context detected",
                    "action": "clarify_context"
                }
            
            return {
                "is_valid": True,
                "context_quality": self.assess_context_quality(context)
            }
            
        except Exception as e:
            logger.error(f"Context validation failed: {e}")
            return {
                "is_valid": False,
                "reason": "Validation error",
                "action": "reset_context"
            }
    
    def is_context_fresh(self, context: Dict[str, Any]) -> bool:
        """
        Check if context is still fresh.
        
        Args:
            context: Context to check
            
        Returns:
            True if fresh
        """
        if "timestamp" not in context:
            return False
        
        try:
            context_time = datetime.fromisoformat(context["timestamp"])
            age = datetime.utcnow() - context_time
            
            return age < self.max_context_age
            
        except:
            return False
    
    def is_context_consistent(self, context: Dict[str, Any]) -> bool:
        """
        Check if context is internally consistent.
        
        Args:
            context: Context to check
            
        Returns:
            True if consistent
        """
        # Check for conflicting information
        if "property_data" in context:
            property_data = context["property_data"]
            
            # Check size consistency
            if "size_net" in property_data and "size_gross" in property_data:
                try:
                    net = float(property_data["size_net"])
                    gross = float(property_data["size_gross"])
                    
                    # Net area should be less than gross
                    if net > gross:
                        return False
                except:
                    pass
            
            # Check floor consistency
            if "floor" in property_data and "total_floors" in property_data:
                try:
                    floor = int(property_data["floor"])
                    total = int(property_data["total_floors"])
                    
                    # Floor should not exceed total
                    if floor > total:
                        return False
                except:
                    pass
        
        return True
    
    def assess_context_quality(self, context: Dict[str, Any]) -> str:
        """
        Assess the quality of context.
        
        Args:
            context: Context to assess
            
        Returns:
            Quality assessment
        """
        score = 0
        max_score = 0
        
        # Check completeness
        if "property_data" in context:
            property_fields = [
                "location", "size", "rooms", "property_type",
                "building_age", "floor", "heating", "features"
            ]
            
            for field in property_fields:
                max_score += 1
                if field in context["property_data"] and context["property_data"][field]:
                    score += 1
        
        # Check conversation history
        if "history" in context:
            max_score += 2
            if len(context["history"]) > 0:
                score += 1
            if len(context["history"]) > 3:
                score += 1
        
        # Check user preferences
        if "preferences" in context:
            max_score += 1
            score += 1
        
        # Calculate quality
        if max_score == 0:
            return "minimal"
        
        quality_ratio = score / max_score
        
        if quality_ratio >= 0.8:
            return "excellent"
        elif quality_ratio >= 0.6:
            return "good"
        elif quality_ratio >= 0.4:
            return "fair"
        else:
            return "poor"
    
    def merge_contexts(
        self,
        existing_context: Dict[str, Any],
        new_context: Dict[str, Any]
    ) -> Dict[str, Any]:
        """
        Merge two contexts intelligently.
        
        Args:
            existing_context: Existing context
            new_context: New context to merge
            
        Returns:
            Merged context
        """
        merged = existing_context.copy()
        
        # Update with new values
        for key, value in new_context.items():
            if key == "history":
                # Append to history
                if key in merged:
                    merged[key].extend(value)
                    # Keep only recent history
                    merged[key] = merged[key][-self.max_context_size:]
                else:
                    merged[key] = value
            elif key == "property_data" and key in merged:
                # Merge property data
                merged[key].update(value)
            else:
                # Override with new value
                merged[key] = value
        
        # Update timestamp
        merged["timestamp"] = datetime.utcnow().isoformat()
        
        return merged
    
    def extract_relevant_context(
        self,
        full_context: Dict[str, Any],
        intent: str
    ) -> Dict[str, Any]:
        """
        Extract only relevant context for intent.
        
        Args:
            full_context: Full context
            intent: Current intent
            
        Returns:
            Relevant context subset
        """
        relevant = {
            "timestamp": full_context.get("timestamp"),
            "session_id": full_context.get("session_id")
        }
        
        # Get required fields for intent
        required_fields = self.context_requirements.get(intent, [])
        
        for field in required_fields:
            if field in full_context:
                relevant[field] = full_context[field]
        
        # Always include recent history if available
        if "history" in full_context:
            relevant["history"] = full_context["history"][-3:]  # Last 3 exchanges
        
        return relevant
    
    def suggest_missing_information(
        self,
        context: Dict[str, Any],
        intent: str
    ) -> List[str]:
        """
        Suggest what information is missing.
        
        Args:
            context: Current context
            intent: User intent
            
        Returns:
            List of suggestions
        """
        suggestions = []
        
        if intent in ["price_estimation", "property_analysis"]:
            if "property_data" not in context:
                suggestions.append("Please provide property details (location, size, rooms)")
            else:
                property_data = context["property_data"]
                
                if not property_data.get("location"):
                    suggestions.append("Where is the property located?")
                if not property_data.get("size"):
                    suggestions.append("What is the property size in square meters?")
                if not property_data.get("rooms"):
                    suggestions.append("How many rooms does the property have?")
                if not property_data.get("building_age"):
                    suggestions.append("How old is the building?")
        
        elif intent == "market_analysis":
            if not context.get("location"):
                suggestions.append("Which area would you like market analysis for?")
        
        elif intent == "investment_advice":
            if not context.get("budget"):
                suggestions.append("What is your investment budget?")
            if not context.get("preferences"):
                suggestions.append("What are your investment preferences?")
        
        return suggestions
