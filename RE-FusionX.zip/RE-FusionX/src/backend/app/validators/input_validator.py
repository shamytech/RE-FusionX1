"""
Input validation for user inputs.
Ensures data quality and relevance before processing.
"""

from typing import Dict, Any, List, Optional, Tuple
import re
from datetime import datetime
import langdetect
from langdetect import detect_langs

from app.core.logging import logger
from app.core.exceptions import ValidationException
from app.core.constants import PropertyType, RoomConfiguration, HeatingType


class InputValidator:
    """
    Validates and classifies user inputs.
    """
    
    def __init__(self):
        """Initialize input validator."""
        self.supported_languages = ["en", "tr"]
        self.real_estate_keywords = self.load_real_estate_keywords()
        self.intent_patterns = self.load_intent_patterns()
        
    def load_real_estate_keywords(self) -> Dict[str, List[str]]:
        """Load real estate related keywords."""
        return {
            "english": [
                "property", "house", "apartment", "villa", "price", "rent", "buy", "sell",
                "real estate", "location", "investment", "market", "mortgage", "square meter",
                "room", "bedroom", "bathroom", "kitchen", "floor", "building", "neighborhood",
                "district", "value", "valuation", "analysis", "forecast", "trend",
                # إضافات جديدة لتحسين كشف العقارات
                "budget", "area", "prefer", "looking for", "want", "need", "around", "about",
                "1+1", "2+1", "3+1", "4+1", "5+1", "lira", "tl", "million", "thousand",
                "kadıköy", "beşiktaş", "istanbul", "ankara", "izmir", "şişli", "üsküdar",
                "purchase", "buying", "seeking", "search", "find", "interested"
            ],
            "turkish": [
                "ev", "daire", "villa", "konut", "emlak", "fiyat", "kira", "satılık", "kiralık",
                "gayrimenkul", "konum", "yatırım", "piyasa", "kredi", "metrekare", "oda",
                "yatak odası", "banyo", "mutfak", "kat", "bina", "mahalle", "ilçe", "değer",
                "değerleme", "analiz", "tahmin", "trend"
            ]
        }
    
    def load_intent_patterns(self) -> Dict[str, List[str]]:
        """Load intent classification patterns."""
        return {
            "price_estimation": [
                r"how much.*worth", r"what.*price", r"estimate.*value", r"valuation",
                r"price.*property", r"cost.*apartment", r"değer.*nedir", r"fiyat.*tahmin"
            ],
            "property_analysis": [
                r"analyze.*property", r"evaluate.*house", r"assess.*apartment",
                r"property.*analysis", r"inspection", r"condition", r"features"
            ],
            "market_analysis": [
                r"market.*trend", r"market.*analysis", r"area.*price", r"neighborhood.*value",
                r"investment.*opportunity", r"growth.*potential", r"piyasa.*analiz"
            ],
            "investment_advice": [
                r"should.*buy", r"good.*investment", r"worth.*investing", r"roi",
                r"return.*investment", r"yatırım.*tavsiye", r"almali.*miyim"
            ],
            "comparison": [
                r"compare.*properties", r"which.*better", r"difference.*between",
                r"versus", r"karşılaştır", r"hangisi.*daha.*iyi"
            ],
            "location_analysis": [
                r"best.*area", r"where.*buy", r"good.*neighborhood", r"location.*analysis",
                r"en.*iyi.*bölge", r"nerede.*almalı"
            ],
            "general_inquiry": [
                r"tell.*about", r"information.*about", r"what.*know", r"help.*with",
                r"hakkında.*bilgi", r"yardım.*eder.*misin"
            ]
        }
    
    async def validate_message(self, message: str) -> Dict[str, Any]:
        try:
            # Check if message is empty or too short
            if not message or len(message.strip()) < 2:  # خفض من 3 إلى 2
                return {
                    "is_valid": False,
                    "error": "Message is too short. Please provide more details."
                }
            
            # Check message length
            if len(message) > 5000:
                return {
                    "is_valid": False,
                    "error": "Message is too long. Please limit to 5000 characters."
                }
            
            # Detect language
            language = self.detect_language(message)
            
            follow_up_keywords = [
                "can't adjust", "cannot adjust", "what can i do",
                "alternatives", "other options", "suggestions"
            ]
            
            message_lower = message.lower()
            is_follow_up = any(keyword in message_lower for keyword in follow_up_keywords)
            
            # إذا كانت متابعة، اعتبرها صالحة
            if is_follow_up:
                return {
                    "is_valid": True,
                    "language": self.detect_language(message),
                    "relevance_score": 1.0,
                    "is_follow_up": True
                }
            
            # Check if language is supported (لكن لا نرفض بسببها)
            if language not in self.supported_languages:
                language = "en"  # افتراضي للإنجليزية
            
            # Check relevance to real estate
            is_relevant = self.check_relevance(message, language)
            
            # خفف من الصرامة - فقط ارفض إذا كان واضح جداً أنه غير متعلق
            if not is_relevant:
                # تحقق مرة أخرى بطريقة أكثر تساهلاً
                message_lower = message.lower()
                
                # قائمة موسعة من الكلمات المتعلقة بالعقارات
                extended_keywords = [
                    "mortgage", "financing", "invest", "market", "trend", "property",
                    "real estate", "house", "apartment", "buy", "sell", "rent",
                    "price", "value", "location", "turkey", "turkish", "istanbul",
                    "ankara", "analysis", "roi", "loan", "credit", "legal", "tax",
                    # Property specifications
                    "area", "size", "room", "bedroom", "m²", "m2", "meter", "square",
                    "budget", "million", "tl", "lira", "currency",
                    # Room configurations  
                    "+1", "+2", "+3", "+4", "rom", "oda",
                    # Turkish districts/cities
                    "kadıköy", "beşiktaş", "beyoğlu", "şişli", "bakırköy", "üsküdar",
                    "izmir", "ankara", "bursa", "antalya", "konya", "adana"
                ]
                
                # إذا وجدت أي كلمة متعلقة، اعتبرها صالحة
                if any(keyword in message_lower for keyword in extended_keywords):
                    is_relevant = True
            
            # فقط ارفض النصوص العشوائية الواضحة
            if self.is_gibberish(message) and not is_relevant:
                return {
                    "is_valid": False,
                    "error": "Unable to understand your message. Please rephrase clearly."
                }
            
            # إذا لم تكن متعلقة لكنها ليست عشوائية، أعطِ تحذير لطيف
            if not is_relevant:
                # تحقق إذا كانت تحية أو سؤال عام
                greetings = ["hello", "hi", "hey", "how are you", "merhaba", "selam"]
                if any(greet in message.lower() for greet in greetings):
                    # السماح بالتحيات
                    is_relevant = True
                else:
                    return {
                        "is_valid": False,
                        "error": "I'm specialized in Turkish real estate. Please ask about properties, prices, markets, or investments."
                    }
            
            return {
                "is_valid": True,
                "language": language,
                "relevance_score": self.calculate_relevance_score(message, language)
            }
            
        except Exception as e:
            logger.error(f"Message validation failed: {e}")
            # في حالة الخطأ، اسمح بالرسالة
            return {
                "is_valid": True,
                "language": "en",
                "relevance_score": 0.5
            }

    def detect_language(self, text: str) -> str:
        """
        Detect the language of the text.
        
        Args:
            text: Text to analyze
            
        Returns:
            Language code (en, tr, etc.)
        """
        try:
            # Use langdetect for initial detection
            detected = detect_langs(text)
            
            if detected:
                lang = detected[0].lang
                
                # Map to our supported languages
                if lang == "en":
                    return "en"
                elif lang == "tr":
                    return "tr"
                else:
                    # Check for Turkish characters as fallback
                    turkish_chars = "ğĞıİöÖşŞüÜçÇ"
                    if any(char in text for char in turkish_chars):
                        return "tr"
                    else:
                        return "en"  # Default to English
            
            return "en"
            
        except:
            # Fallback: check for Turkish characters
            turkish_chars = "ğĞıİöÖşŞüÜçÇ"
            if any(char in text for char in turkish_chars):
                return "tr"
            return "en"
    
    def check_relevance(self, message: str, language: str) -> bool:
        """
        Check if message is relevant to real estate.
        
        Args:
            message: Message to check
            language: Detected language
            
        Returns:
            True if relevant
        """
        message_lower = message.lower()
        
        # Get keywords based on language
        keywords = self.real_estate_keywords.get(
            "english" if language == "en" else "turkish",
            []
        )
        
        # Check for keyword presence
        keyword_count = sum(1 for keyword in keywords if keyword in message_lower)
        
        # Need at least 1 keyword for relevance
        return keyword_count >= 1
    
    def calculate_relevance_score(self, message: str, language: str) -> float:
        """
        Calculate relevance score (0-1).
        
        Args:
            message: Message to score
            language: Message language
            
        Returns:
            Relevance score
        """
        message_lower = message.lower()
        
        # Get keywords
        keywords = self.real_estate_keywords.get(
            "english" if language == "en" else "turkish",
            []
        )
        
        # Count keyword occurrences
        keyword_count = sum(1 for keyword in keywords if keyword in message_lower)
        
        # Calculate score (max out at 1.0)
        score = min(1.0, keyword_count / 5.0)
        
        return score
    
    def is_gibberish(self, text: str) -> bool:
        """
        Check if text appears to be gibberish.
        
        Args:
            text: Text to check
            
        Returns:
            True if likely gibberish
        """
        # لا تعتبر النصوص القصيرة gibberish
        if len(text) < 10:
            return False
        
        # Check for excessive repetition
        if len(set(text)) < len(text) / 5:  # خفف من 4 إلى 5
            return True
        
        # Check for no spaces in long text
        if len(text) > 30 and ' ' not in text:  # رفع من 20 إلى 30
            return True
        
        # Check for excessive special characters
        special_char_ratio = sum(1 for c in text if not c.isalnum() and c not in ' .,!?-\'\"') / len(text)
        if special_char_ratio > 0.4:  # رفع من 0.3 إلى 0.4
            return True
        
        # Check for random character sequences
        import re
        consonant_clusters = re.findall(r'[bcdfghjklmnpqrstvwxyz]{6,}', text.lower())  # رفع من 5 إلى 6
        if consonant_clusters:
            return True
        
        return False


    async def classify_intent(self, message: str) -> Dict[str, Any]:
        """
        Classify the intent of a message.
        
        Args:
            message: Message to classify
            
        Returns:
            Intent classification results
        """
        message_lower = message.lower()
        intent_scores = {}
        
        # Check each intent pattern
        for intent, patterns in self.intent_patterns.items():
            score = 0
            for pattern in patterns:
                if re.search(pattern, message_lower):
                    score += 1
            
            if score > 0:
                intent_scores[intent] = score
        
        # Get the highest scoring intent
        if intent_scores:
            best_intent = max(intent_scores, key=intent_scores.get)
            confidence = min(1.0, intent_scores[best_intent] / 3.0)
        else:
            best_intent = "general_inquiry"
            confidence = 0.3
        
        # Extract entities
        entities = self.extract_entities(message)
        
        return {
            "intent": best_intent,
            "confidence": confidence,
            "entities": entities,
            "all_intents": intent_scores
        }
    
    def extract_entities(self, message: str) -> Dict[str, Any]:
        """
        Extract entities from message.
        
        Args:
            message: Message to extract from
            
        Returns:
            Extracted entities
        """
        entities = {}
        message_lower = message.lower()
        
        # Extract location
        location_pattern = r'(?:in|at|near|around)\s+([A-Za-zğĞıİöÖşŞüÜçÇ\s\-]+?)(?:\s|,|\.|\?|$)'
        location_match = re.search(location_pattern, message)
        if location_match:
            entities["location"] = location_match.group(1).strip()
        
        # Extract price
        price_patterns = [
            r'(\d+[\.,]?\d*)\s*(?:tl|lira|₺)',
            r'(?:tl|lira|₺)\s*(\d+[\.,]?\d*)',
            r'(\d+[\.,]?\d*)\s*(?:thousand|million|bin|milyon)'
        ]
        
        for pattern in price_patterns:
            price_match = re.search(pattern, message_lower)
            if price_match:
                entities["price"] = price_match.group(1)
                break
        
        # Extract size
        size_pattern = r'(\d+)\s*(?:m2|m²|sqm|square\s*meter|metrekare)'
        size_match = re.search(size_pattern, message_lower)
        if size_match:
            entities["size"] = size_match.group(1)
        
        # Extract room configuration
        room_pattern = r'(\d\+\d|\d\s*\+\s*\d)'
        room_match = re.search(room_pattern, message)
        if room_match:
            entities["rooms"] = room_match.group(1).replace(" ", "")
        
        # Extract property type
        for prop_type in PropertyType:
            if prop_type.value.lower() in message_lower:
                entities["property_type"] = prop_type.value
                break
        
        return entities
    
    def validate_property_data(self, property_data: Dict[str, Any]) -> Tuple[bool, List[str]]:
        """
        Validate property data structure.
        
        Args:
            property_data: Property data to validate
            
        Returns:
            Tuple of (is_valid, list_of_errors)
        """
        errors = []
        
        # Check required fields
        required_fields = ["location", "size", "rooms"]
        for field in required_fields:
            if field not in property_data or not property_data[field]:
                errors.append(f"Missing required field: {field}")
        
        # Validate location
        if "location" in property_data:
            location = property_data["location"]
            if not isinstance(location, str) or len(location) < 3:
                errors.append("Invalid location format")
        
        # Validate size
        if "size" in property_data:
            try:
                size = float(str(property_data["size"]).replace(" m²", "").replace(",", "."))
                if size <= 0 or size > 10000:
                    errors.append("Size must be between 1 and 10000 m²")
            except:
                errors.append("Invalid size format")
        
        # Validate rooms
        if "rooms" in property_data:
            rooms = property_data["rooms"]
            if not re.match(r'^\d+\+\d+$', str(rooms)):
                errors.append("Invalid room format (should be like 3+1)")
        
        # Validate price if provided
        if "price" in property_data:
            try:
                price = float(property_data["price"])
                if price < 0:
                    errors.append("Price cannot be negative")
            except:
                errors.append("Invalid price format")
        
        # Validate property type if provided
        if "property_type" in property_data:
            valid_types = [pt.value for pt in PropertyType]
            if property_data["property_type"] not in valid_types:
                errors.append(f"Invalid property type. Must be one of: {', '.join(valid_types)}")
        
        # Validate floor if provided
        if "floor" in property_data:
            try:
                floor = int(property_data["floor"])
                if floor < -2 or floor > 100:
                    errors.append("Floor must be between -2 and 100")
            except:
                pass  # Some floors are text like "Zemin"
        
        return len(errors) == 0, errors
