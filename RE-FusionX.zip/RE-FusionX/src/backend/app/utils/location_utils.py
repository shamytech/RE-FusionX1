"""
Location Utilities - مركزية معالجة المواقع والتطبيع
"""

import json
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Set
from functools import lru_cache
from app.core.logging import logger


class LocationManager:
    """مدير المواقع المركزي"""
    
    _instance = None
    _cities_data = None
    _district_to_city = None
    _all_locations_normalized = None
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._initialize()
        return cls._instance
    
    def _initialize(self):
        """تهيئة بيانات المواقع"""
        self._load_cities_data()
    
    def _load_cities_data(self):
        """تحميل بيانات المدن والمناطق من الملف"""
        if self._cities_data is not None:
            return  # Already loaded
        config_path = Path(__file__).parent.parent.parent / "app" / "data_collectors" / "real_estate" / "configs" / "cities_and_districts_data.json"
        
        try:
            with open(config_path, 'r', encoding='utf-8') as f:
                self._cities_data = json.load(f)
                
            # إنشاء قاموس عكسي (منطقة -> مدينة)
            self._district_to_city = {}
            self._all_locations_normalized = {}
            
            for city, districts in self._cities_data.items():
                # حفظ المدينة نفسها
                city_norm = self.normalize_text(city)
                self._all_locations_normalized[city_norm] = {
                    'type': 'city',
                    'original': city,
                    'city': city,
                    'district': None
                }
                
                # حفظ المناطق
                for district in districts:
                    district_norm = self.normalize_text(district)
                    self._district_to_city[district_norm] = city
                    self._all_locations_normalized[district_norm] = {
                        'type': 'district',
                        'original': district,
                        'city': city,
                        'district': district
                    }
            
            logger.info(f"✅ Loaded {len(self._cities_data)} cities with {len(self._district_to_city)} districts")
            
        except FileNotFoundError:
            logger.error(f"Cities data file not found: {config_path}")
            self._cities_data = {}
            self._district_to_city = {}
            self._all_locations_normalized = {}
        except Exception as e:
            logger.error(f"Failed to load cities data: {e}")
            self._cities_data = {}
            self._district_to_city = {}
            self._all_locations_normalized = {}
    
    @staticmethod
    def normalize_text(text: str) -> str:
        """
        تطبيع النص - دالة مركزية للتطبيع
        
        Args:
            text: النص للتطبيع
            
        Returns:
            النص المطبع
        """
        if not text:
            return ""
        
        # تحويل إلى lowercase أولاً
        text = text.lower()
        
        # استبدال الأحرف التركية يدوياً (أكثر موثوقية)
        replacements = {
            'ı': 'i',
            'i̇': 'i',  # هذا مهم! İ عندما تصبح lowercase تصبح i̇
            'ğ': 'g',
            'ü': 'u', 
            'ş': 's',
            'ö': 'o',
            'ç': 'c',
            'İ': 'i',
            'I': 'i',
            'Ğ': 'g',
            'Ü': 'u',
            'Ş': 's',
            'Ö': 'o',
            'Ç': 'c'
        }
        
        for turkish, latin in replacements.items():
            text = text.replace(turkish, latin)
        
        # إزالة المسافات الزائدة
        text = ' '.join(text.split())
        
        return text.strip()

    @staticmethod
    def normalize_for_path(text: str) -> str:
        """
        تطبيع النص لاستخدامه في المسارات
        
        Args:
            text: النص للتطبيع
            
        Returns:
            النص المطبع للمسارات
        """
        if not text:
            return "unknown"
        
        normalized = LocationManager.normalize_text(text)
        # استبدال المسافات والرموز الخاصة
        normalized = normalized.replace(' ', '-').replace('/', '-').replace('\\', '-')
        normalized = normalized.replace('.', '').replace(',', '').replace('(', '').replace(')', '')
        
        import re
        # إزالة الأحرف غير المسموحة في المسارات
        normalized = re.sub(r'[^a-z0-9\-]', '', normalized)
        # إزالة الشرطات المتعددة
        normalized = re.sub(r'-+', '-', normalized)
        
        return normalized.strip('-')
    
    def get_cities(self) -> List[str]:
        """الحصول على قائمة المدن"""
        return list(self._cities_data.keys())
    
    def get_districts(self, city: str) -> List[str]:
        """الحصول على مناطق مدينة معينة"""
        # جرب المطابقة المباشرة
        if city in self._cities_data:
            return self._cities_data[city]
        
        # جرب المطابقة بالتطبيع
        city_norm = self.normalize_text(city)
        for c, districts in self._cities_data.items():
            if self.normalize_text(c) == city_norm:
                return districts
        
        return []
    
    def find_city_for_district(self, district: str) -> Optional[str]:
        """إيجاد المدينة التي تنتمي إليها المنطقة"""
        district_norm = self.normalize_text(district)
        return self._district_to_city.get(district_norm)
    
    def extract_location_from_text(self, text: str) -> Dict[str, Optional[str]]:
        """
        استخراج معلومات الموقع من نص عام
        
        Args:
            text: النص الذي قد يحتوي على معلومات موقع
            
        Returns:
            قاموس يحتوي على city, district, neighborhood
        """
        result = {
            'city': None,
            'district': None,
            'neighborhood': None
        }
        
        if not text:
            return result
        
        text_norm = self.normalize_text(text)
        
        # البحث عن المدن
        for city_norm, info in self._all_locations_normalized.items():
            if info['type'] == 'city' and city_norm in text_norm:
                result['city'] = info['original']
                break
        
        # البحث عن المناطق
        for district_norm, info in self._all_locations_normalized.items():
            if info['type'] == 'district' and district_norm in text_norm:
                result['district'] = info['original']
                if not result['city']:
                    result['city'] = info['city']
                break
        
        return result
    
    def is_valid_city(self, city: str) -> bool:
        """التحقق من صحة اسم المدينة"""
        city_norm = self.normalize_text(city)
        return any(self.normalize_text(c) == city_norm for c in self._cities_data.keys())
    
    def is_valid_district(self, district: str) -> bool:
        """التحقق من صحة اسم المنطقة"""
        district_norm = self.normalize_text(district)
        return district_norm in self._district_to_city
    
    def get_location_suggestions(self, partial: str, limit: int = 10) -> List[Dict[str, str]]:
        """
        الحصول على اقتراحات للموقع بناءً على نص جزئي
        
        Args:
            partial: النص الجزئي
            limit: عدد الاقتراحات الأقصى
            
        Returns:
            قائمة الاقتراحات
        """
        partial_norm = self.normalize_text(partial)
        suggestions = []
        
        for norm_name, info in self._all_locations_normalized.items():
            if partial_norm in norm_name:
                suggestion = {
                    'display': info['original'],
                    'type': info['type'],
                    'city': info['city']
                }
                
                if info['type'] == 'district':
                    suggestion['display'] = f"{info['district']}, {info['city']}"
                
                suggestions.append(suggestion)
                
                if len(suggestions) >= limit:
                    break
        
        return suggestions

    def parse_location(self, location_text: str) -> Dict[str, Optional[str]]:
        """
        تحليل نص الموقع إلى مكوناته مع دعم فواصل متعددة
        
        Args:
            location_text: نص الموقع 
            Examples:
                "İstanbul - Kadıköy - Fenerbahçe"
                "İstanbul / Kadıköy"
                "İstanbul-Kadıköy"
                "istanbul kadikoy"
                
        Returns:
            قاموس يحتوي على city, district, neighborhood
        """
        result = {
            'city': None,
            'district': None,
            'neighborhood': None
        }
        
        if not location_text:
            return result
        
        # تنظيف النص
        location_text = location_text.strip()
        
        # قائمة الفواصل المحتملة (مرتبة حسب الأولوية)
        separators = [' - ', ' / ', ' – ', ' — ', '/', '-', '–', '—']
        
        # محاولة التقسيم بالفواصل
        parts = None
        for sep in separators:
            if sep in location_text:
                parts = [p.strip() for p in location_text.split(sep) if p.strip()]
                break
        
        # إذا لم نجد فاصل، جرب بالمسافة
        if not parts:
            parts = location_text.split()
        
        # تحليل كل جزء
        for i, part in enumerate(parts):
            if not part:
                continue
                
            part_norm = self.normalize_text(part)
            
            # تحقق من البيانات المحملة
            if part_norm in self._all_locations_normalized:
                location_info = self._all_locations_normalized[part_norm]
                
                if location_info['type'] == 'city':
                    if not result['city']:  # لا نستبدل إذا كان موجود
                        result['city'] = location_info['original']
                elif location_info['type'] == 'district':
                    result['district'] = location_info['original']
                    if not result['city']:
                        result['city'] = location_info['city']
            else:
                # البحث في قاعدة البيانات بشكل أكثر مرونة
                # ربما الجزء الأول مدينة والثاني منطقة
                if i == 0 and not result['city']:
                    # جرب كمدينة
                    for city in self.get_cities():
                        if self.normalize_text(city) == part_norm:
                            result['city'] = city
                            break
                elif i == 1 and not result['district']:
                    # جرب كمنطقة
                    if result['city']:
                        districts = self.get_districts(result['city'])
                        for district in districts:
                            if self.normalize_text(district) == part_norm:
                                result['district'] = district
                                break
                    else:
                        # ابحث في جميع المناطق
                        city = self.find_city_for_district(part)
                        if city:
                            result['city'] = city
                            result['district'] = part
                elif i == 2 or (i == len(parts) - 1 and not result['neighborhood']):
                    # آخر جزء قد يكون حي
                    neighborhood = part.replace('Mahallesi', '').replace('Mah.', '').replace('Mah', '').strip()
                    result['neighborhood'] = neighborhood
        
        # حالة خاصة: إذا كان لدينا جزء واحد فقط
        if len(parts) == 1 and not result['city'] and not result['district']:
            part = parts[0]
            part_norm = self.normalize_text(part)
            
            # جرب كمنطقة أولاً
            city = self.find_city_for_district(part)
            if city:
                result['city'] = city
                result['district'] = part
            else:
                # جرب كمدينة
                if self.is_valid_city(part):
                    result['city'] = part
        
        return result

    def parse_location_string(location_str: str) -> Dict[str, str]:
        """
        دالة مساعدة إضافية لتحليل نص الموقع (للتوافق مع الكود القديم)
        
        Examples:
            "İstanbul - Kadıköy" -> {"city": "İstanbul", "district": "Kadıköy"}
            "İstanbul/Kadıköy" -> {"city": "İstanbul", "district": "Kadıköy"}
            "istanbul kadikoy" -> {"city": "İstanbul", "district": "Kadıköy"}
            "Kadıköy" -> {"city": "İstanbul", "district": "Kadıköy"}
        """
        manager = get_location_manager()
        result = manager.parse_location(location_str)
        
        # تحويل None إلى سلسلة فارغة للتوافق
        return {
            "city": result.get("city", ""),
            "district": result.get("district", ""),
            "neighborhood": result.get("neighborhood", "")
        }

    @staticmethod
    def normalize_location_for_search(location_str: str) -> List[str]:
        """
        تطبيع الموقع للبحث وإرجاع قائمة بالصيغ المحتملة
        
        Args:
            location_str: نص الموقع الأصلي
            
        Returns:
            قائمة بالصيغ المحتملة للبحث
        """
        if not location_str:
            return []
        
        manager = get_location_manager()
        parsed = manager.parse_location(location_str)
        
        variations = set()  # استخدم set لتجنب التكرار
        
        # إضافة الصيغ المختلفة
        if parsed['city'] and parsed['district']:
            city = parsed['city']
            district = parsed['district']
            
            # صيغ مع الأحرف الأصلية
            variations.add(f"{city} {district}")
            variations.add(f"{city}/{district}")
            variations.add(f"{city} / {district}")
            variations.add(f"{city} - {district}")
            variations.add(f"{city}-{district}")
            
            # صيغ مع التطبيع الكامل
            city_norm = normalize_text(city)
            district_norm = normalize_text(district)
            variations.add(f"{city_norm} {district_norm}")
            variations.add(f"{city_norm}/{district_norm}")
            variations.add(f"{city_norm}-{district_norm}")
            
        elif parsed['city']:
            variations.add(parsed['city'])
            variations.add(normalize_text(parsed['city']))
            
        elif parsed['district']:
            variations.add(parsed['district'])
            variations.add(normalize_text(parsed['district']))
            # إضافة المدينة إذا كنا نعرفها
            city = manager.find_city_for_district(parsed['district'])
            if city:
                variations.add(f"{city} {parsed['district']}")
                variations.add(f"{normalize_text(city)} {normalize_text(parsed['district'])}")
        
        # إضافة النص الأصلي
        variations.add(location_str)
        variations.add(normalize_text(location_str))
        
        # تنظيف وإرجاع القائمة
        return [v for v in variations if v]


 
# Singleton instance getter
_location_manager = None

def get_location_manager() -> LocationManager:
    """الحصول على مدير المواقع المركزي"""
    global _location_manager
    if _location_manager is None:
        _location_manager = LocationManager()
    return _location_manager


# دوال مساعدة للاستخدام المباشر
def normalize_text(text: str) -> str:
    """تطبيع النص - دالة مساعدة"""
    return LocationManager.normalize_text(text)


def normalize_for_path(text: str) -> str:
    """تطبيع النص للمسارات - دالة مساعدة"""
    return LocationManager.normalize_for_path(text)


def parse_location(location_text: str) -> Dict[str, Optional[str]]:
    """تحليل نص الموقع - دالة مساعدة"""
    return get_location_manager().parse_location(location_text)


def extract_location_from_text(text: str) -> Dict[str, Optional[str]]:
    """استخراج الموقع من النص - دالة مساعدة"""
    return get_location_manager().extract_location_from_text(text)


def parse_location_string(location_str: str) -> Dict[str, str]:
    """تحليل نص الموقع - دالة مساعدة"""
    return get_location_manager().parse_location_string(location_str)


def normalize_location_for_search(location_str: str) -> List[str]:
    """تطبيع الموقع للبحث - دالة مساعدة"""
    return get_location_manager().normalize_location_for_search(location_str)


