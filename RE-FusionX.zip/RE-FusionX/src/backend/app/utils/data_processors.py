"""
Data processing utilities.
Handles data transformation and processing.
"""

import pandas as pd
import numpy as np
from typing import Dict, Any, List, Optional, Union
import json
from datetime import datetime


class DataProcessors:
    """Data processing utilities."""
    
    @staticmethod
    def normalize_location(location: str) -> str:
        """
        Normalize location string.
        
        Args:
            location: Raw location string
            
        Returns:
            Normalized location
        """
        # Standardize separators
        location = location.replace(",", " - ").replace("/", " - ")
        
        # Remove extra spaces
        location = " ".join(location.split())
        
        # Title case
        parts = location.split(" - ")
        normalized_parts = []
        
        for part in parts:
            # Keep Turkish characters
            if part.lower() in ['i̇stanbul', 'i̇zmir']:
                normalized_parts.append(part.title())
            else:
                normalized_parts.append(part.strip().title())
        
        return " - ".join(normalized_parts)
    
    @staticmethod
    def parse_property_features(features_text: str) -> Dict[str, List[str]]:
        """
        Parse property features from text.
        
        Args:
            features_text: Raw features text
            
        Returns:
            Categorized features
        """
        features = {
            "interior": [],
            "exterior": [],
            "location": [],
            "security": [],
            "comfort": []
        }
        
        # Define feature categories
        interior_keywords = ['mutfak', 'kitchen', 'banyo', 'bathroom', 'oda', 'room', 
                           'salon', 'living', 'parke', 'laminat', 'döşeme']
        
        exterior_keywords = ['bahçe', 'garden', 'balkon', 'balcony', 'teras', 'terrace',
                           'otopark', 'parking', 'garaj', 'garage']
        
        security_keywords = ['güvenlik', 'security', 'kamera', 'camera', 'alarm',
                           'kapıcı', 'doorman', 'site', 'gated']
        
        # Parse features
        feature_list = features_text.lower().split(',') if ',' in features_text else features_text.lower().split()
        
        for feature in feature_list:
            feature = feature.strip()
            
            if any(keyword in feature for keyword in interior_keywords):
                features["interior"].append(feature)
            elif any(keyword in feature for keyword in exterior_keywords):
                features["exterior"].append(feature)
            elif any(keyword in feature for keyword in security_keywords):
                features["security"].append(feature)
            else:
                features["comfort"].append(feature)
        
        return features
    
    @staticmethod
    def calculate_statistics(values: List[float]) -> Dict[str, float]:
        """
        Calculate statistical measures.
        
        Args:
            values: List of numeric values
            
        Returns:
            Statistical measures
        """
        if not values:
            return {
                "count": 0,
                "mean": 0,
                "median": 0,
                "std": 0,
                "min": 0,
                "max": 0,
                "q1": 0,
                "q3": 0
            }
        
        arr = np.array(values)
        
        return {
            "count": len(values),
            "mean": float(np.mean(arr)),
            "median": float(np.median(arr)),
            "std": float(np.std(arr)),
            "min": float(np.min(arr)),
            "max": float(np.max(arr)),
            "q1": float(np.percentile(arr, 25)),
            "q3": float(np.percentile(arr, 75))
        }
    
    @staticmethod
    def aggregate_property_data(properties: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Aggregate property data for analysis.
        
        Args:
            properties: List of properties
            
        Returns:
            Aggregated data
        """
        if not properties:
            return {}
        
        # Extract numeric values
        prices = []
        sizes = []
        ages = []
        
        for prop in properties:
            # Price
            try:
                price = float(prop.get('price', '0').replace(' TL', '').replace('.', '').replace(',', '.'))
                if price > 0:
                    prices.append(price)
            except:
                pass
            
            # Size
            try:
                size = float(prop.get('size_net', prop.get('size_gross', '0')).replace(' m²', '').replace(',', '.'))
                if size > 0:
                    sizes.append(size)
            except:
                pass
            
            # Age
            age_str = prop.get('building_age', '')
            if 'Yeni' in age_str or '0' in age_str:
                ages.append(0)
            elif '-' in age_str:
                try:
                    ages.append(int(age_str.split('-')[0]))
                except:
                    pass
        
        return {
            "total_properties": len(properties),
            "price_stats": DataProcessors.calculate_statistics(prices),
            "size_stats": DataProcessors.calculate_statistics(sizes),
            "age_stats": DataProcessors.calculate_statistics(ages),
            "price_per_sqm": DataProcessors.calculate_statistics(
                [p/s for p, s in zip(prices, sizes) if s > 0]
            ) if prices and sizes else {}
        }
    
    @staticmethod
    def create_property_dataframe(properties: List[Dict[str, Any]]) -> pd.DataFrame:
        """
        Create pandas DataFrame from properties.
        
        Args:
            properties: List of properties
            
        Returns:
            Property DataFrame
        """
        if not properties:
            return pd.DataFrame()
        
        # Prepare data for DataFrame
        data = []
        
        for prop in properties:
            row = {
                'location': prop.get('location', ''),
                'property_type': prop.get('property_type', ''),
                'rooms': prop.get('room_count', ''),
                'price': DataProcessors.parse_price(prop.get('price', 0)),
                'size': DataProcessors.parse_size(prop.get('size_net', prop.get('size_gross', 0))),
                'building_age': prop.get('building_age', ''),
                'floor': prop.get('floor', ''),
                'in_site': prop.get('in_site', ''),
                'heating': prop.get('heating', '')
            }
            
            data.append(row)
        
        return pd.DataFrame(data)
    
    @staticmethod
    def parse_price(price: Any) -> float:
        """Parse price to float."""
        if isinstance(price, (int, float)):
            return float(price)
        
        try:
            price_str = str(price).replace(' TL', '').replace('.', '').replace(',', '.')
            return float(price_str)
        except:
            return 0.0
    
    @staticmethod
    def parse_size(size: Any) -> float:
        """Parse size to float."""
        if isinstance(size, (int, float)):
            return float(size)
        
        try:
            size_str = str(size).replace(' m²', '').replace(',', '.')
            return float(size_str)
        except:
            return 0.0
    
    @staticmethod
    def export_to_excel(data: Union[pd.DataFrame, List[Dict]], filename: str) -> bool:
        """
        Export data to Excel file.
        
        Args:
            data: Data to export
            filename: Output filename
            
        Returns:
            Success status
        """
        try:
            if isinstance(data, list):
                df = pd.DataFrame(data)
            else:
                df = data
            
            df.to_excel(filename, index=False, engine='openpyxl')
            return True
            
        except Exception as e:
            print(f"Export failed: {e}")
            return False
    
    @staticmethod
    def export_to_json(data: Any, filename: str, pretty: bool = True) -> bool:
        """
        Export data to JSON file.
        
        Args:
            data: Data to export
            filename: Output filename
            pretty: Whether to pretty print
            
        Returns:
            Success status
        """
        try:
            with open(filename, 'w', encoding='utf-8') as f:
                if pretty:
                    json.dump(data, f, ensure_ascii=False, indent=2)
                else:
                    json.dump(data, f, ensure_ascii=False)
            
            return True
            
        except Exception as e:
            print(f"Export failed: {e}")
            return False
