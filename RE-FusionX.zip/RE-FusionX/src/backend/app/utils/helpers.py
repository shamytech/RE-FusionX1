"""
Helper utilities.
General helper functions for the application.
"""

import hashlib
import json
import re
from typing import Any, Dict, List, Optional, Union
from datetime import datetime, timedelta
import unicodedata


class Helpers:
    """General helper utilities."""
    
    @staticmethod
    def generate_hash(data: Any) -> str:
        """
        Generate hash for data.
        
        Args:
            data: Data to hash
            
        Returns:
            Hash string
        """
        if not isinstance(data, str):
            data = json.dumps(data, sort_keys=True)
        
        return hashlib.sha256(data.encode()).hexdigest()
    
    @staticmethod
    def clean_text(text: str) -> str:
        """
        Clean text for processing.
        
        Args:
            text: Text to clean
            
        Returns:
            Cleaned text
        """
        # Remove extra whitespace
        text = re.sub(r'\s+', ' ', text)
        
        # Remove special characters
        text = re.sub(r'[^\w\s\-.,!?]', '', text)
        
        # Normalize unicode
        text = unicodedata.normalize('NFKD', text)
        
        return text.strip()
    
    @staticmethod
    def extract_numbers(text: str) -> List[float]:
        """
        Extract numbers from text.
        
        Args:
            text: Text containing numbers
            
        Returns:
            List of extracted numbers
        """
        # Find all numbers (including decimals)
        pattern = r'[-+]?\d*\.?\d+'
        matches = re.findall(pattern, text)
        
        numbers = []
        for match in matches:
            try:
                numbers.append(float(match))
            except:
                pass
        
        return numbers
    
    @staticmethod
    def parse_turkish_number(text: str) -> Optional[float]:
        """
        Parse Turkish formatted number.
        
        Args:
            text: Turkish formatted number
            
        Returns:
            Parsed number or None
        """
        try:
            # Remove currency symbols
            text = re.sub(r'[₺TL$€]', '', text)
            
            # Turkish format: 1.234.567,89
            # Replace dots with empty, comma with dot
            text = text.replace(".", "").replace(",", ".")
            
            return float(text)
            
        except:
            return None
    
    @staticmethod
    def calculate_distance(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
        """
        Calculate distance between two coordinates (Haversine formula).
        
        Args:
            lat1, lon1: First coordinate
            lat2, lon2: Second coordinate
            
        Returns:
            Distance in kilometers
        """
        from math import radians, sin, cos, sqrt, atan2
        
        R = 6371  # Earth's radius in kilometers
        
        lat1, lon1, lat2, lon2 = map(radians, [lat1, lon1, lat2, lon2])
        
        dlat = lat2 - lat1
        dlon = lon2 - lon1
        
        a = sin(dlat/2)**2 + cos(lat1) * cos(lat2) * sin(dlon/2)**2
        c = 2 * atan2(sqrt(a), sqrt(1-a))
        
        return R * c
    
    @staticmethod
    def merge_dicts(dict1: Dict, dict2: Dict, deep: bool = True) -> Dict:
        """
        Merge two dictionaries.
        
        Args:
            dict1: First dictionary
            dict2: Second dictionary
            deep: Whether to deep merge
            
        Returns:
            Merged dictionary
        """
        result = dict1.copy()
        
        if not deep:
            result.update(dict2)
            return result
        
        for key, value in dict2.items():
            if key in result and isinstance(result[key], dict) and isinstance(value, dict):
                result[key] = Helpers.merge_dicts(result[key], value, deep=True)
            else:
                result[key] = value
        
        return result
    
    @staticmethod
    def chunk_list(lst: List, chunk_size: int) -> List[List]:
        """
        Split list into chunks.
        
        Args:
            lst: List to chunk
            chunk_size: Size of each chunk
            
        Returns:
            List of chunks
        """
        return [lst[i:i + chunk_size] for i in range(0, len(lst), chunk_size)]
    
    @staticmethod
    def flatten_dict(d: Dict, parent_key: str = '', separator: str = '.') -> Dict:
        """
        Flatten nested dictionary.
        
        Args:
            d: Dictionary to flatten
            parent_key: Parent key for recursion
            separator: Key separator
            
        Returns:
            Flattened dictionary
        """
        items = []
        
        for k, v in d.items():
            new_key = f"{parent_key}{separator}{k}" if parent_key else k
            
            if isinstance(v, dict):
                items.extend(
                    Helpers.flatten_dict(v, new_key, separator).items()
                )
            else:
                items.append((new_key, v))
        
        return dict(items)
    
    @staticmethod
    def safe_get(d: Dict, path: str, default: Any = None) -> Any:
        """
        Safely get nested dictionary value.
        
        Args:
            d: Dictionary
            path: Dot-separated path
            default: Default value
            
        Returns:
            Value or default
        """
        keys = path.split('.')
        value = d
        
        for key in keys:
            if isinstance(value, dict) and key in value:
                value = value[key]
            else:
                return default
        
        return value
    
    @staticmethod
    def calculate_age(date_str: str) -> int:
        """
        Calculate age from date string.
        
        Args:
            date_str: Date string
            
        Returns:
            Age in years
        """
        try:
            if isinstance(date_str, str):
                date = datetime.fromisoformat(date_str)
            else:
                date = date_str
            
            today = datetime.now()
            age = today.year - date.year
            
            if today.month < date.month or (today.month == date.month and today.day < date.day):
                age -= 1
            
            return age
            
        except:
            return 0
    
    @staticmethod
    def is_valid_turkish_phone(phone: str) -> bool:
        """
        Validate Turkish phone number.
        
        Args:
            phone: Phone number
            
        Returns:
            True if valid
        """
        # Remove spaces and special characters
        phone = re.sub(r'[^\d]', '', phone)
        
        # Turkish phone: 05XXXXXXXXX or 5XXXXXXXXX or +905XXXXXXXXX
        patterns = [
            r'^05\d{9}$',
            r'^5\d{9}$',
            r'^905\d{9}$',
            r'^\+905\d{9}$'
        ]
        
        return any(re.match(pattern, phone) for pattern in patterns)
