"""
Formatting utilities.
Handles data formatting for display.
"""

from typing import Any, Optional, Union, List
from datetime import datetime
import re


class Formatters:
    """Data formatting utilities."""
    
    @staticmethod
    def format_price(price: Union[float, int, str]) -> str:
        """
        Format price for display.
        
        Args:
            price: Price value
            
        Returns:
            Formatted price string
        """
        try:
            if isinstance(price, str):
                # Remove existing formatting
                price = price.replace(" TL", "").replace(".", "").replace(",", ".")
                price = float(price)
            
            # Format with thousand separators
            formatted = f"{price:,.0f}".replace(",", ".")
            return f"{formatted} TL"
            
        except:
            return str(price)
    
    @staticmethod
    def format_size(size: Union[float, int, str]) -> str:
        """
        Format size for display.
        
        Args:
            size: Size value
            
        Returns:
            Formatted size string
        """
        try:
            if isinstance(size, str):
                size = size.replace(" m²", "").replace(",", ".")
                size = float(size)
            
            return f"{size:.0f} m²"
            
        except:
            return str(size)
    
    @staticmethod
    def format_percentage(value: float, decimals: int = 1) -> str:
        """
        Format percentage for display.
        
        Args:
            value: Percentage value
            decimals: Number of decimal places
            
        Returns:
            Formatted percentage string
        """
        return f"{value:.{decimals}f}%"
    
    @staticmethod
    def format_date(date: Union[datetime, str], format: str = "%d/%m/%Y") -> str:
        """
        Format date for display.
        
        Args:
            date: Date to format
            format: Date format string
            
        Returns:
            Formatted date string
        """
        try:
            if isinstance(date, str):
                date = datetime.fromisoformat(date)
            
            return date.strftime(format)
            
        except:
            return str(date)
    
    @staticmethod
    def format_location(location: str, max_length: Optional[int] = None) -> str:
        """
        Format location string.
        
        Args:
            location: Location string
            max_length: Maximum length
            
        Returns:
            Formatted location
        """
        # Clean up location
        location = location.strip()
        
        # Shorten if needed
        if max_length and len(location) > max_length:
            parts = location.split("-")
            if len(parts) > 2:
                # Keep first and last part
                location = f"{parts[0].strip()}...{parts[-1].strip()}"
            elif len(location) > max_length:
                location = location[:max_length-3] + "..."
        
        return location
    
    @staticmethod
    def format_room_count(rooms: str) -> str:
        """
        Format room count for display.
        
        Args:
            rooms: Room configuration
            
        Returns:
            Formatted room count
        """
        # Ensure proper formatting (e.g., "3+1")
        if "+" in rooms:
            return rooms.replace(" ", "")
        
        return rooms
    
    @staticmethod
    def format_floor(floor: Union[int, str]) -> str:
        """
        Format floor information.
        
        Args:
            floor: Floor number or description
            
        Returns:
            Formatted floor string
        """
        if isinstance(floor, int):
            if floor == 0:
                return "Ground Floor"
            elif floor < 0:
                return f"Basement {abs(floor)}"
            else:
                return f"Floor {floor}"
        
        return str(floor)
    
    @staticmethod
    def format_list(items: List[str], separator: str = ", ", max_items: int = 5) -> str:
        """
        Format list for display.
        
        Args:
            items: List of items
            separator: Item separator
            max_items: Maximum items to show
            
        Returns:
            Formatted list string
        """
        if not items:
            return ""
        
        if len(items) <= max_items:
            return separator.join(items)
        
        shown = items[:max_items]
        remaining = len(items) - max_items
        
        return f"{separator.join(shown)} and {remaining} more"
    
    @staticmethod
    def format_confidence(confidence: float) -> str:
        """
        Format confidence score.
        
        Args:
            confidence: Confidence value (0-1)
            
        Returns:
            Formatted confidence string
        """
        percentage = confidence * 100
        
        if percentage >= 90:
            level = "Very High"
        elif percentage >= 75:
            level = "High"
        elif percentage >= 60:
            level = "Moderate"
        elif percentage >= 40:
            level = "Low"
        else:
            level = "Very Low"
        
        return f"{level} ({percentage:.0f}%)"
    
    @staticmethod
    def format_duration(seconds: float) -> str:
        """
        Format duration for display.
        
        Args:
            seconds: Duration in seconds
            
        Returns:
            Formatted duration string
        """
        if seconds < 60:
            return f"{seconds:.1f} seconds"
        elif seconds < 3600:
            minutes = seconds / 60
            return f"{minutes:.1f} minutes"
        else:
            hours = seconds / 3600
            return f"{hours:.1f} hours"
