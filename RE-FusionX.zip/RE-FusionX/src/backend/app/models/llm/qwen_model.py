"""
Qwen model wrapper for the application.
Handles interaction with the Qwen2.5-VL model.
"""

import torch
from typing import Dict, Any, List, Optional, Union, Tuple
from pathlib import Path
import asyncio
from PIL import Image
import io
import sys
import torchvision
from torchvision import transforms
from transformers import BitsAndBytesConfig, AutoProcessor
from transformers import Qwen2_5_VLForConditionalGeneration  # الاستيراد الصحيح

from app.core.config import settings
from app.core.logging import logger


class QwenModel:
    """Wrapper for Qwen2.5-VL model."""
    
    def __init__(self, model_path: Path):
        """
        Initialize Qwen model.
        
        Args:
            model_path: Path to the model
        """
        self.model_path = Path(r"D:\Phd\RE-FusionX\src\LLaMA-Factory\output\merged_model")
        self.model = None
        self.processor = None
        self.device = None
        self.loaded = False
        self.conversations = {}  # تخزين سجل المحادثات
    
    async def load(self) -> bool:
        """Load the model asynchronously."""
        try:
            return await asyncio.get_event_loop().run_in_executor(
                None,
                self._load_sync
            )
        except Exception as e:
            logger.error(f"Failed to load Qwen model: {e}")
            return False
    
    def _load_sync(self) -> bool:
        """Synchronously load the model."""
        try:
            # طباعة معلومات النظام للتشخيص
            logger.info(f"🐍 Python version: {sys.version}")
            logger.info(f"🔥 PyTorch version: {torch.__version__}")
            logger.info(f"🖼️ Torchvision version: {torchvision.__version__}")
            logger.info(f"🛠️ Transforms module available: {hasattr(transforms, 'Compose')}")
            
            # التحقق من دعم CUDA
            self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
            logger.info(f"⚡ CUDA available: {torch.cuda.is_available()}")
            
            if torch.cuda.is_available():
                logger.info(f"🔢 CUDA version: {torch.version.cuda}")
                logger.info(f"💻 GPU name: {torch.cuda.get_device_name(0)}")
            
            logger.info(f"Using device: {self.device}")
            logger.info(f"Loading model from: {self.model_path}")
            
            # التحقق من وجود المسار
            if not Path(self.model_path).exists():
                logger.error(f"Model path does not exist: {self.model_path}")
                return False
            
            # تحميل المعالج
            logger.info("Loading processor...")
            self.processor = AutoProcessor.from_pretrained(
                str(self.model_path),
                trust_remote_code=True
            )
            logger.info(" ⚙️  Processor loaded successfully")
            
            # إعداد تكوين البت والبايت للذاكرة المنخفضة (نفس التكوين من app.py)
            bnb_config = BitsAndBytesConfig(
                load_in_4bit=True,
                bnb_4bit_compute_dtype=torch.float16,
                bnb_4bit_use_double_quant=True,
                bnb_4bit_quant_type="nf4"
            )
            
            # تحميل النموذج (استخدام Qwen2_5_VLForConditionalGeneration مباشرة)
            logger.info("Loading Qwen2.5-VL model...")
            self.model = Qwen2_5_VLForConditionalGeneration.from_pretrained(
                str(self.model_path),
                torch_dtype=torch.float16 if torch.cuda.is_available() else torch.float32,
                device_map="auto",
                trust_remote_code=True,
                quantization_config=bnb_config if torch.cuda.is_available() else None
            )
            
            self.loaded = True
            logger.info("🤖، 🧠، 📦 Qwen model loaded successfully!")
            return True
            
        except ImportError as e:
            logger.error(f"❌ Import error - missing dependencies: {e}")
            logger.info("Try: pip install transformers accelerate bitsandbytes")
            return False
            
        except Exception as e:
            logger.error(f"❌ Error loading Qwen model: {e}", exc_info=True)
            self.loaded = False
            return False
    
    def process_image(self, image_input: Union[str, Image.Image, bytes]) -> Image.Image:
        """
        معالجة الصورة للنموذج (نفس الطريقة من app.py).
        
        Args:
            image_input: مسار الصورة أو كائن PIL Image أو بايتات
            
        Returns:
            PIL Image object في RGB
        """
        try:
            if isinstance(image_input, str):
                # إذا كان مسار ملف
                image = Image.open(image_input)
            elif isinstance(image_input, bytes):
                # إذا كانت بايتات
                image = Image.open(io.BytesIO(image_input))
            elif isinstance(image_input, Image.Image):
                # إذا كانت بالفعل PIL Image
                image = image_input
            else:
                raise ValueError(f"Unsupported image input type: {type(image_input)}")
            
            # تحويل إلى RGB إذا لزم الأمر
            if image.mode != 'RGB':
                image = image.convert('RGB')
            
            return image
            
        except Exception as e:
            logger.error(f"Error processing image: {e}")
            raise
    
    async def generate(
        self,
        prompt: str,
        images: Optional[List[Union[str, Image.Image, bytes]]] = None,
        conversation_id: Optional[str] = None,
        max_tokens: int = 2048,
        temperature: float = 0.7,
        top_p: float = 0.9,
        **kwargs
    ) -> str:
        """
        Generate response from the model.
        """
        if not self.loaded:
            logger.error("Model not loaded, attempting to load...")
            success = await self.load()
            if not success:
                return "Model is not loaded. Please check the logs for errors."
        
        try:
            # Run generation in executor to avoid blocking
            return await asyncio.get_event_loop().run_in_executor(
                None,
                self._generate_sync,
                prompt,
                images,
                conversation_id,
                max_tokens,
                temperature,
                top_p,
                kwargs
            )
        except Exception as e:
            logger.error(f"Generation failed: {e}", exc_info=True)
            return f"I apologize, but I encountered an error: {str(e)}"
    
    def _generate_sync(
        self,
        prompt: str,
        images: Optional[List[Union[str, Image.Image, bytes]]],
        conversation_id: Optional[str],
        max_tokens: int,
        temperature: float,
        top_p: float,
        kwargs: Dict[str, Any]
    ) -> str:
        """Synchronously generate response (نفس المنطق من app.py)."""
        try:
            # معالجة الصور إذا وجدت
            image_objects = None
            if images:
                image_objects = [self.process_image(img) for img in images]
            
            # إعداد الرسائل
            if image_objects:
                messages = [
                    {
                        "role": "user",
                        "content": [
                            {"type": "image", "image": img} for img in image_objects
                        ] + [
                            {"type": "text", "text": prompt}
                        ]
                    }
                ]
            else:
                messages = [
                    {"role": "user", "content": prompt}
                ]
            
            # إضافة سياق المحادثة السابقة إذا وجد
            if conversation_id and conversation_id in self.conversations:
                context = self.conversations[conversation_id][-5:]  # آخر 5 رسائل
                messages = context + messages
            
            # تطبيق قالب المحادثة
            text = self.processor.apply_chat_template(
                messages,
                tokenize=False,
                add_generation_prompt=True
            )
            
            # معالجة المدخلات
            inputs = self.processor(
                text=text,
                images=image_objects if image_objects else None,
                return_tensors="pt",
                padding=True
            )
            
            # نقل إلى الجهاز المناسب
            if self.device:
                inputs = {k: v.to(self.device) if hasattr(v, 'to') else v 
                         for k, v in inputs.items()}
            
            # توليد الرد
            with torch.no_grad():
                outputs = self.model.generate(
                    **inputs,
                    max_new_tokens=max_tokens,
                    temperature=temperature,
                    top_p=top_p,
                    do_sample=True,
                    pad_token_id=self.processor.tokenizer.pad_token_id,
                    eos_token_id=self.processor.tokenizer.eos_token_id,
                    **kwargs
                )
            
            # فك التشفير
            response = self.processor.decode(
                outputs[0][inputs['input_ids'].shape[1]:],
                skip_special_tokens=True
            )
            
            # حفظ في سجل المحادثة
            if conversation_id:
                if conversation_id not in self.conversations:
                    self.conversations[conversation_id] = []
                
                self.conversations[conversation_id].append({
                    "role": "user",
                    "content": prompt
                })
                self.conversations[conversation_id].append({
                    "role": "assistant",
                    "content": response
                })
            
            return response
            
        except Exception as e:
            logger.error(f"Sync generation error: {e}", exc_info=True)
            return f"Error generating response: {str(e)}"
    
    async def analyze_image(
        self,
        image: Union[str, Image.Image, bytes],
        prompt: str = "Analyze this property image and provide insights."
    ) -> str:
        """
        Analyze an image with a prompt.
        """
        return await self.generate(
            prompt=prompt,
            images=[image],
            max_tokens=512
        )
    
    def unload(self) -> None:
        """Unload the model from memory."""
        if self.model:
            del self.model
            self.model = None
        
        if self.processor:
            del self.processor
            self.processor = None
        
        self.conversations.clear()
        self.loaded = False
        
        # Clear GPU cache if available
        if torch.cuda.is_available():
            torch.cuda.empty_cache()
        
        logger.info("Model unloaded from memory")
