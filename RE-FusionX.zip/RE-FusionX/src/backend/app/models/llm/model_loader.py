"""
Model loader for managing LLM models.
Handles model loading, caching, and lifecycle.
"""

import asyncio
from typing import Optional, Dict, Any
from pathlib import Path

from app.models.llm.qwen_model import QwenModel
from app.core.config import settings
from app.core.logging import logger


class ModelLoader:
    """Manages loading and access to LLM models."""
    
    def __init__(self):
        """Initialize model loader."""
        self.models: Dict[str, Any] = {}
        self.default_model: Optional[QwenModel] = None
        self.initialized = False
    
    async def initialize(self) -> bool:
        """Initialize and load default model."""
        try:
            logger.info("Initializing model loader...")
            
            # Load Qwen model
            qwen_model = QwenModel(settings.QWEN_MODEL_PATH)
            success = await qwen_model.load()
            
            if success:
                self.models['qwen'] = qwen_model
                self.default_model = qwen_model
                self.initialized = True
                logger.info("Model loader initialized successfully")
                return True
            else:
                logger.error("Failed to load Qwen model")
                # Create fallback model
                self.create_fallback_model()
                return False
                
        except Exception as e:
            logger.error(f"Model loader initialization failed: {e}")
            self.create_fallback_model()
            return False
    
    def create_fallback_model(self):
        """Create a fallback model for when main model fails."""
        from app.models.llm.fallback_model import FallbackModel
        
        # استخدام المسار الصحيح للنموذج
        self.default_model = FallbackModel(str(settings.MERGED_MODEL_DIR))
        self.models['fallback'] = self.default_model
        self.initialized = True
        logger.info("Using enhanced fallback model with Turkish real estate data")
    
    async def get_model(self, model_name: Optional[str] = None) -> Any:
        """
        Get a loaded model.
        
        Args:
            model_name: Name of model to get (default: default model)
            
        Returns:
            Model instance
        """
        if not self.initialized:
            await self.initialize()
            
        logger.info(f"Returning model: {type(self.default_model).__name__}")
        
        if model_name:
            model = self.models.get(model_name)
            if not model:
                logger.warning(f"Model {model_name} not found, using default")
                return self.default_model
            return model
        
        return self.default_model
    
    def is_loaded(self, model_name: Optional[str] = None) -> bool:
        """
        Check if model is loaded.
        
        Args:
            model_name: Model to check (default: any model)
            
        Returns:
            True if loaded
        """
        if model_name:
            return model_name in self.models
        
        return self.initialized and self.default_model is not None
    
    async def reload_model(self, model_name: str = 'qwen') -> bool:
        """
        Reload a specific model.
        
        Args:
            model_name: Model to reload
            
        Returns:
            Success status
        """
        try:
            # Unload existing model
            if model_name in self.models:
                old_model = self.models[model_name]
                if hasattr(old_model, 'unload'):
                    old_model.unload()
                del self.models[model_name]
            
            # Load new model
            if model_name == 'qwen':
                qwen_model = QwenModel(settings.QWEN_MODEL_PATH)
                success = await qwen_model.load()
                
                if success:
                    self.models['qwen'] = qwen_model
                    if self.default_model and hasattr(self.default_model, 'unload'):
                        self.default_model.unload()
                    self.default_model = qwen_model
                    return True
            
            return False
            
        except Exception as e:
            logger.error(f"Failed to reload model {model_name}: {e}")
            return False
    
    def get_model_info(self) -> Dict[str, Any]:
        """Get information about loaded models."""
        info = {
            "initialized": self.initialized,
            "models_loaded": list(self.models.keys()),
            "default_model": type(self.default_model).__name__ if self.default_model else None
        }
        
        # Add model-specific info
        for name, model in self.models.items():
            if hasattr(model, 'model_path'):
                info[f"{name}_path"] = str(model.model_path)
            if hasattr(model, 'device'):
                info[f"{name}_device"] = str(model.device)
        
        return info
    
    async def cleanup(self):
        """Clean up and unload all models."""
        logger.info("Cleaning up model loader...")
        
        for name, model in self.models.items():
            if hasattr(model, 'unload'):
                model.unload()
            logger.info(f"Unloaded model: {name}")
        
        self.models.clear()
        self.default_model = None
        self.initialized = False
        
        logger.info("Model loader cleanup complete")


class FallbackModel:
    """Simple fallback model for when main model is unavailable."""
    
    def __init__(self):
        """Initialize fallback model."""
        self.loaded = True
    
    async def generate(
        self,
        prompt: str,
        **kwargs
    ) -> str:
        """Generate fallback response."""
        if "price" in prompt.lower() or "fiyat" in prompt.lower():
            return """I can help with property pricing analysis. Based on the Turkish real estate market:

• Location is the primary factor (40-50% of value)
• Property size and room count significantly impact price
• Building age affects value (new buildings command 10-20% premium)
• Site amenities can add 5-15% to property value

For accurate pricing, please provide: location, size, rooms, and building age."""
        
        elif "market" in prompt.lower() or "piyasa" in prompt.lower():
            return """Turkish real estate market insights:

• Istanbul, Ankara, and Izmir are the top investment cities
• Annual property appreciation averages 15-20% in major cities
• Foreign investment is strong in coastal areas
• Mortgage rates affect market dynamics significantly

Which specific market area interests you?"""
        
        else:
            return """I'm RE-FusionX, your Turkish real estate assistant. I can help with:

• Property valuation and analysis
• Market trends and insights
• Investment recommendations
• Location comparisons

What would you like to know about Turkish real estate?"""
    
    async def analyze_image(self, image: Any, prompt: str) -> str:
        """Fallback image analysis."""
        return "Image analysis requires the full model. Please ensure the model is properly loaded."
