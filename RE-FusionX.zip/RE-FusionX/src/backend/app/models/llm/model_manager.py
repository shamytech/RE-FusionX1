# app/models/llm/model_manager.py
"""
Universal Model Manager with Multiple Provider Support
======================================================
Supports: OpenAI, Groq, Together, Ollama, LlamaCpp, HuggingFace
"""

import os
import json
from typing import Dict, Any, Optional, List
from enum import Enum
from pathlib import Path
import asyncio

from app.core.logging import logger
from app.core.config import settings

class ModelProvider(Enum):
    """Supported model providers"""
    OPENAI = "openai"
    GROQ = "groq"
    TOGETHER = "together"
    OLLAMA = "ollama"
    LLAMACPP = "llamacpp"
    HUGGINGFACE = "huggingface"
    QWEN = "qwen"  # Your existing Qwen model

class ModelCapability(Enum):
    """Model capabilities"""
    CHAT = "chat"
    EXTRACTION = "extraction"
    ANALYSIS = "analysis"
    EMBEDDING = "embedding"

class ModelManager:
    """
    Centralized model management with automatic fallback
    """
    
    def __init__(self):
        self.providers: Dict[ModelProvider, Dict[str, Any]] = {}
        self.active_provider: Optional[ModelProvider] = None
        self._initialize_providers()
        self._select_best_provider()
        
    def _initialize_providers(self):
        """Initialize all available model providers"""
        
        # 1. OpenAI
        if openai_key := os.getenv("OPENAI_API_KEY"):
            self.providers[ModelProvider.OPENAI] = {
                "api_key": openai_key,
                "models": {
                    "chat": "gpt-3.5-turbo",
                    "extraction": "gpt-3.5-turbo",
                    "embedding": "text-embedding-ada-002"
                },
                "base_url": "https://api.openai.com/v1",
                "cost": "paid",
                "quality": 5,
                "speed": 3,
                "available": self._test_openai(openai_key)
            }
            
        # 2. Groq (Free & Fast)
        if groq_key := os.getenv("GROQ_API_KEY"):
            self.providers[ModelProvider.GROQ] = {
                "api_key": groq_key,
                "models": {
                    "chat": "mixtral-8x7b-32768",
                    "extraction": "mixtral-8x7b-32768",
                    "embedding": None  # Groq doesn't provide embeddings
                },
                "base_url": "https://api.groq.com/openai/v1",
                "cost": "free",
                "quality": 4,
                "speed": 5,
                "rate_limit": "30/min",
                "available": self._test_groq(groq_key)
            }
            
        # 3. Together AI
        if together_key := os.getenv("TOGETHER_API_KEY"):
            self.providers[ModelProvider.TOGETHER] = {
                "api_key": together_key,
                "models": {
                    "chat": "mistralai/Mixtral-8x7B-Instruct-v0.1",
                    "extraction": "mistralai/Mixtral-8x7B-Instruct-v0.1",
                    "embedding": "togethercomputer/m2-bert-80M-8k-retrieval"
                },
                "base_url": "https://api.together.xyz/v1",
                "cost": "free_tier",
                "quality": 4,
                "speed": 4,
                "available": self._test_together(together_key)
            }
            
        # 4. Ollama (Local)
        if self._check_ollama():
            models = self._get_ollama_models()
            if models:
                self.providers[ModelProvider.OLLAMA] = {
                    "models": {
                        "chat": models[0] if models else "llama2",
                        "extraction": models[0] if models else "llama2",
                        "embedding": "nomic-embed-text" if "nomic-embed-text" in models else None
                    },
                    "base_url": os.getenv("OLLAMA_HOST", "http://localhost:11434"),
                    "cost": "free",
                    "quality": 3,
                    "speed": 4,
                    "local": True,
                    "available": True
                }
                
        # 5. LlamaCpp (Local)
        if self._check_llamacpp():
            model_path = self._find_gguf_model()
            if model_path:
                self.providers[ModelProvider.LLAMACPP] = {
                    "model_path": str(model_path),
                    "models": {
                        "chat": model_path.name,
                        "extraction": model_path.name,
                        "embedding": None
                    },
                    "n_ctx": 4096,
                    "n_gpu_layers": int(os.getenv("GPU_LAYERS", "35")),
                    "cost": "free",
                    "quality": 3,
                    "speed": 3,
                    "local": True,
                    "available": True
                }
                
        # 6. Your existing Qwen model
        try:
            from app.models.llm.qwen_model import QwenModel
            self.providers[ModelProvider.QWEN] = {
                "model_class": QwenModel,
                "models": {
                    "chat": "Qwen/Qwen2.5-7B-Instruct",
                    "extraction": "Qwen/Qwen2.5-7B-Instruct"
                },
                "cost": "free",
                "quality": 3,
                "speed": 3,
                "local": True,
                "available": True
            }
        except ImportError:
            pass
            
        logger.info(f"Initialized {len(self.providers)} model providers")
        
    def _check_ollama(self) -> bool:
        """Check if Ollama is running"""
        try:
            import requests
            response = requests.get(
                f"{os.getenv('OLLAMA_HOST', 'http://localhost:11434')}/api/tags",
                timeout=2
            )
            return response.status_code == 200
        except:
            return False
            
    def _get_ollama_models(self) -> List[str]:
        """Get list of available Ollama models"""
        try:
            import requests
            response = requests.get(
                f"{os.getenv('OLLAMA_HOST', 'http://localhost:11434')}/api/tags"
            )
            if response.status_code == 200:
                models = response.json().get("models", [])
                return [m["name"] for m in models]
        except:
            pass
        return []
        
    def _check_llamacpp(self) -> bool:
        """Check if llama-cpp-python is available"""
        try:
            from llama_cpp import Llama
            return True
        except ImportError:
            return False
            
    def _find_gguf_model(self) -> Optional[Path]:
        """Find GGUF model files"""
        model_dirs = [
            Path("data/models"),
            Path("models"),
            Path.home() / "models"
        ]
        
        for model_dir in model_dirs:
            if model_dir.exists():
                gguf_files = list(model_dir.glob("*.gguf"))
                if gguf_files:
                    return gguf_files[0]
        return None
        
    def _test_openai(self, api_key: str) -> bool:
        """Test OpenAI API"""
        try:
            import openai
            client = openai.OpenAI(api_key=api_key)
            client.models.list()
            return True
        except:
            return False
            
    def _test_groq(self, api_key: str) -> bool:
        """Test Groq API"""
        try:
            import requests
            headers = {"Authorization": f"Bearer {api_key}"}
            response = requests.get(
                "https://api.groq.com/openai/v1/models",
                headers=headers,
                timeout=5
            )
            return response.status_code == 200
        except:
            return False
            
    def _test_together(self, api_key: str) -> bool:
        """Test Together API"""
        try:
            import requests
            headers = {"Authorization": f"Bearer {api_key}"}
            response = requests.get(
                "https://api.together.xyz/v1/models",
                headers=headers,
                timeout=5
            )
            return response.status_code == 200
        except:
            return False
            
    def _select_best_provider(self):
        """Select the best available provider"""
        # Priority order (configurable via env)
        priority_str = os.getenv("MODEL_PRIORITY", "groq,ollama,together,openai,qwen,llamacpp")
        priority = [ModelProvider(p.strip()) for p in priority_str.split(",") if p.strip()]
        
        for provider in priority:
            if provider in self.providers and self.providers[provider].get("available", False):
                self.active_provider = provider
                logger.info(f"Selected {provider.value} as primary model provider")
                return
                
        # Fallback to any available
        for provider, config in self.providers.items():
            if config.get("available", False):
                self.active_provider = provider
                logger.warning(f"Using fallback provider: {provider.value}")
                return
                
        logger.error("No model providers available!")
        
    def get_provider_config(self, provider: Optional[ModelProvider] = None) -> Optional[Dict[str, Any]]:
        """Get configuration for a specific provider"""
        if provider:
            return self.providers.get(provider)
        return self.providers.get(self.active_provider) if self.active_provider else None
        
    def get_model_for_task(self, capability: ModelCapability, provider: Optional[ModelProvider] = None) -> Optional[str]:
        """Get the best model for a specific task"""
        config = self.get_provider_config(provider)
        if config and "models" in config:
            return config["models"].get(capability.value)
        return None
        
    def list_available_providers(self) -> List[Dict[str, Any]]:
        """List all available providers with their status"""
        providers_info = []
        for provider, config in self.providers.items():
            providers_info.append({
                "name": provider.value,
                "available": config.get("available", False),
                "cost": config.get("cost", "unknown"),
                "quality": config.get("quality", 0),
                "speed": config.get("speed", 0),
                "local": config.get("local", False),
                "models": config.get("models", {})
            })
        return providers_info

# Singleton instance
model_manager = ModelManager()
