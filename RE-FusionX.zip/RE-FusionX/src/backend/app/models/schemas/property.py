"""
Property data schemas.
Defines property-related data structures.
"""

from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field, field_validator, ConfigDict
from datetime import datetime


class PropertyBase(BaseModel):
    """Base property schema."""
    city: Optional[str] = Field(None, description="City name")
    district: Optional[str] = Field(None, description="District name")
    neighborhood: Optional[str] = Field(None, description="Neighborhood")
    size: Optional[float] = Field(None, description="Size in m² (generic)")
    price_per_sqm: Optional[float] = Field(None, description="Price per square meter")
    scraped_at: Optional[datetime] = Field(None, description="Scraping timestamp")
    source: Optional[str] = Field(None, description="Data source")
    

class PropertyInput(PropertyBase):
    """Schema for property input."""
    location: Optional[str] = Field(None, description="Full location string")
    property_type: Optional[str] = Field(None, description="Property type")
    rooms: Optional[str] = Field(None, description="Room configuration")
    size_net: Optional[float] = Field(None, description="Net size in m²")
    size_gross: Optional[float] = Field(None, description="Gross size in m²")
    price: Optional[float] = Field(None, description="Property price")
    floor: Optional[str] = Field(None, description="Floor number")
    total_floors: Optional[int] = Field(None, description="Total floors in building")
    building_age: Optional[str] = Field(None, description="Building age")
    bathrooms: Optional[int] = Field(None, description="Number of bathrooms")
    heating: Optional[str] = Field(None, description="Heating system")
    usage_status: Optional[str] = Field(None, description="Usage status")
    deed_status: Optional[str] = Field(None, description="Deed status")
    furnished: Optional[str] = Field(None, description="Furnished status")
    in_site: Optional[str] = Field(None, description="In site (Yes/No)")
    credit_eligible: Optional[str] = Field(None, description="Credit eligibility")
    features: Optional[Dict[str, List[str]]] = Field(None, description="Property features")
    images: Optional[List[str]] = Field(None, description="Property images")
    
    @field_validator('size_net', 'size_gross', mode='after')
    @classmethod
    def validate_size(cls, v: Optional[float]) -> Optional[float]:
        """Validate size values."""
        if v is not None and v <= 0:
            raise ValueError("Size must be positive")
        if v is not None and v > 10000:
            raise ValueError("Size seems unrealistic")
        return v
    
    @field_validator('price', mode='after')
    @classmethod
    def validate_price(cls, v: Optional[float]) -> Optional[float]:
        """Validate price."""
        if v is not None and v < 0:
            raise ValueError("Price cannot be negative")
        return v
    
    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "location": "Istanbul - Kadıköy - Fenerbahçe",
                "property_type": "Daire",
                "rooms": "3+1",
                "size_net": 120,
                "size_gross": 140,
                "price": 5500000,
                "floor": "3",
                "total_floors": 8,
                "building_age": "5-10",
                "bathrooms": 2,
                "heating": "Kombi Doğalgaz",
                "in_site": "Evet",
                "credit_eligible": "Krediye Uygun"
            }
        }
    )


class PropertyDetails(PropertyBase):
    """Detailed property information."""
    id: Optional[str] = Field(None, description="Property ID")
    floor: Optional[str] = Field(None, description="Floor information")
    total_floors: Optional[int] = Field(None, description="Total floors")
    building_age: Optional[str] = Field(None, description="Building age")
    bathrooms: Optional[int] = Field(None, description="Number of bathrooms")
    heating: Optional[str] = Field(None, description="Heating system")
    in_site: Optional[str] = Field(None, description="In site status")
    features: Optional[Dict[str, Any]] = Field(None, description="Property features")
    
    # Analysis results
    estimated_price: Optional[float] = Field(None, description="Estimated price")
    price_per_sqm: Optional[float] = Field(None, description="Price per square meter")
    investment_score: Optional[float] = Field(None, description="Investment score")
    
    # Metadata
    listed_date: Optional[datetime] = Field(None, description="Listing date")
    last_updated: Optional[datetime] = Field(None, description="Last update date")
    view_count: Optional[int] = Field(None, description="View count")
    
    model_config = ConfigDict(from_attributes=True)


class PropertySearch(BaseModel):
    """Property search criteria."""
    location: Optional[str] = Field(None, description="Search location")
    property_type: Optional[str] = Field(None, description="Property type filter")
    rooms: Optional[str] = Field(None, description="Room configuration filter")
    min_price: Optional[float] = Field(None, ge=0, description="Minimum price")
    max_price: Optional[float] = Field(None, ge=0, description="Maximum price")
    min_size: Optional[float] = Field(None, ge=0, description="Minimum size")
    max_size: Optional[float] = Field(None, ge=0, description="Maximum size")
    building_age: Optional[str] = Field(None, description="Building age filter")
    in_site: Optional[str] = Field(None, description="In site filter")
    features: Optional[List[str]] = Field(None, description="Required features")
    sort_by: Optional[str] = Field("price", description="Sort field")
    sort_order: Optional[str] = Field("asc", description="Sort order")
    limit: Optional[int] = Field(20, ge=1, le=100, description="Result limit")
    offset: Optional[int] = Field(0, ge=0, description="Result offset")
    
    @field_validator('sort_by', mode='after')
    @classmethod
    def validate_sort_by(cls, v: Optional[str]) -> Optional[str]:
        """Validate sort field."""
        if v is not None:
            valid_fields = ['price', 'size', 'age', 'date']
            if v not in valid_fields:
                raise ValueError(f"Sort by must be one of {valid_fields}")
        return v
    
    @field_validator('sort_order', mode='after')
    @classmethod
    def validate_sort_order(cls, v: Optional[str]) -> Optional[str]:
        """Validate sort order."""
        if v is not None:
            if v not in ['asc', 'desc']:
                raise ValueError("Sort order must be 'asc' or 'desc'")
        return v
