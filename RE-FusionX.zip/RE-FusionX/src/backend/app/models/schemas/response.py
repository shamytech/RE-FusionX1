"""
Response schemas.
Defines API response structures.
"""

from typing import Optional, List, Dict, Any, Generic, TypeVar
from pydantic import BaseModel, Field, ConfigDict
from datetime import datetime


T = TypeVar('T')


class ChatMessage(BaseModel):
    """Chat message schema."""
    role: str = Field(..., description="Message role (user/assistant)")
    content: str = Field(..., description="Message content")
    timestamp: datetime = Field(default_factory=datetime.utcnow, description="Message timestamp")
    metadata: Optional[Dict[str, Any]] = Field(default=None, description="Additional metadata")
    images: Optional[List[str]] = Field(default=None, description="Attached images")
    
    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "role": "user",
                "content": "What is the market value of a 3+1 apartment in Kadıköy?",
                "timestamp": "2024-01-15T10:30:00Z"
            }
        }
    )


class ChatResponse(BaseModel):
    """Chat response schema."""
    response: str = Field(..., description="Assistant response")
    type: str = Field(default="message", description="Response type")
    confidence: Optional[float] = Field(default=None, description="Response confidence")
    sources: Optional[List[str]] = Field(default=None, description="Information sources")
    suggestions: Optional[List[str]] = Field(default=None, description="Follow-up suggestions")
    metadata: Optional[Dict[str, Any]] = Field(default=None, description="Response metadata")
    
    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "response": "Based on current market data, a 3+1 apartment in Kadıköy...",
                "type": "message",
                "confidence": 0.85,
                "sources": ["market_data", "similar_properties"]
            }
        }
    )


class APIResponse(BaseModel, Generic[T]):
    """Generic API response wrapper."""
    success: bool = Field(..., description="Request success status")
    data: Optional[T] = Field(default=None, description="Response data")
    error: Optional[str] = Field(default=None, description="Error message if failed")
    error_code: Optional[str] = Field(default=None, description="Error code if failed")
    metadata: Optional[Dict[str, Any]] = Field(default=None, description="Response metadata")
    timestamp: datetime = Field(default_factory=datetime.utcnow, description="Response timestamp")
    
    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "success": True,
                "data": {"result": "example"},
                "error": None,
                "timestamp": "2024-01-15T10:30:00Z"
            }
        }
    )


class PaginatedResponse(BaseModel, Generic[T]):
    """Paginated response schema."""
    items: List[T] = Field(..., description="Page items")
    total: int = Field(..., description="Total items count")
    page: int = Field(..., description="Current page")
    page_size: int = Field(..., description="Page size")
    total_pages: int = Field(..., description="Total pages")
    has_next: bool = Field(..., description="Has next page")
    has_previous: bool = Field(..., description="Has previous page")
    
    model_config = ConfigDict(from_attributes=True)


class ErrorResponse(BaseModel):
    """Error response schema."""
    error: str = Field(..., description="Error type")
    message: str = Field(..., description="Error message")
    details: Optional[Dict[str, Any]] = Field(default=None, description="Error details")
    request_id: Optional[str] = Field(default=None, description="Request ID for tracking")
    timestamp: datetime = Field(default_factory=datetime.utcnow, description="Error timestamp")
    
    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "error": "VALIDATION_ERROR",
                "message": "Invalid input provided",
                "details": {"field": "price", "issue": "Must be positive"},
                "timestamp": "2024-01-15T10:30:00Z"
            }
        }
    )


class HealthResponse(BaseModel):
    """Health check response."""
    status: str = Field(..., description="Service status")
    service: str = Field(..., description="Service name")
    version: str = Field(..., description="Service version")
    timestamp: datetime = Field(..., description="Check timestamp")
    checks: Optional[Dict[str, bool]] = Field(default=None, description="Component checks")
    
    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "status": "healthy",
                "service": "RE-FusionX",
                "version": "2.0.0",
                "timestamp": "2024-01-15T10:30:00Z",
                "checks": {
                    "database": True,
                    "cache": True,
                    "model": True
                }
            }
        }
    )
