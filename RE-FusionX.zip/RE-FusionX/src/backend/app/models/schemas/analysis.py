"""
Analysis schemas.
Defines analysis request and response structures.
"""

from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field, ConfigDict
from datetime import datetime


class AnalysisRequest(BaseModel):
    """Analysis request schema."""
    property_data: Dict[str, Any] = Field(..., description="Property information")
    analysis_type: Optional[str] = Field(
        default="comprehensive",
        description="Type of analysis to perform"
    )
    include_market: Optional[bool] = Field(default=True, description="Include market analysis")
    include_investment: Optional[bool] = Field(default=True, description="Include investment analysis")
    include_comparison: Optional[bool] = Field(default=True, description="Include similar properties")
    comparison_radius: Optional[float] = Field(default=5.0, description="Search radius in km")
    
    model_config = ConfigDict(
        json_schema_extra={
            "example": {
                "property_data": {
                    "location": "Istanbul - Kadıköy",
                    "rooms": "3+1",
                    "size": 120,
                    "building_age": "5-10"
                },
                "analysis_type": "comprehensive",
                "include_market": True,
                "include_investment": True
            }
        }
    )


class PriceEstimation(BaseModel):
    """Price estimation results."""
    estimated_price: float = Field(..., description="Estimated price in TL")
    price_range: Dict[str, float] = Field(..., description="Price range")
    confidence: float = Field(..., description="Confidence score (0-1)")
    factors: List[Dict[str, Any]] = Field(..., description="Price factors")
    methodology: Optional[str] = Field(default=None, description="Estimation methodology")


class MarketAnalysis(BaseModel):
    """Market analysis results."""
    market_position: str = Field(..., description="Market position")
    average_price: Optional[float] = Field(default=None, description="Average area price")
    price_trend: str = Field(..., description="Price trend")
    demand_level: str = Field(..., description="Demand level")
    supply_level: str = Field(..., description="Supply level")
    growth_forecast: Optional[float] = Field(default=None, description="Growth forecast %")


class InvestmentAnalysis(BaseModel):
    """Investment analysis results."""
    investment_score: float = Field(..., description="Investment score (0-10)")
    roi_potential: str = Field(..., description="ROI potential")
    rental_yield: Optional[float] = Field(default=None, description="Rental yield %")
    appreciation_forecast: str = Field(..., description="Appreciation forecast")
    risk_level: str = Field(..., description="Risk level")
    payback_period: Optional[float] = Field(default=None, description="Payback period in years")


class LocationAnalysis(BaseModel):
    """Location analysis results."""
    district_grade: str = Field(..., description="District grade")
    accessibility_score: float = Field(..., description="Accessibility score (0-10)")
    amenities: List[str] = Field(..., description="Available amenities")
    demographics: Dict[str, Any] = Field(..., description="Demographic information")
    growth_potential: str = Field(..., description="Growth potential")


class AnalysisResponse(BaseModel):
    """Complete analysis response."""
    analysis_id: Optional[str] = Field(default=None, description="Analysis ID")
    timestamp: datetime = Field(default_factory=datetime.utcnow, description="Analysis timestamp")
    
    # Core analyses
    price_estimation: Optional[PriceEstimation] = Field(default=None, description="Price estimation")
    market_analysis: Optional[MarketAnalysis] = Field(default=None, description="Market analysis")
    investment_analysis: Optional[InvestmentAnalysis] = Field(default=None, description="Investment analysis")
    location_analysis: Optional[LocationAnalysis] = Field(default=None, description="Location analysis")
    
    # Additional data
    similar_properties: Optional[List[Dict[str, Any]]] = Field(default=None, description="Similar properties")
    recommendations: List[str] = Field(default_factory=list, description="Recommendations")
    key_insights: List[str] = Field(default_factory=list, description="Key insights")
    qwen_analysis: Optional[str] = Field(default=None, description="Full Qwen analysis text")  # 🔧 ADD: Qwen analysis field
    confidence_score: float = Field(..., description="Overall confidence score")
    
    # Metadata
    analysis_type: str = Field(..., description="Type of analysis performed")
    data_sources: List[str] = Field(default_factory=list, description="Data sources used")
    processing_time: Optional[float] = Field(default=None, description="Processing time in seconds")
    
    model_config = ConfigDict(from_attributes=True)
