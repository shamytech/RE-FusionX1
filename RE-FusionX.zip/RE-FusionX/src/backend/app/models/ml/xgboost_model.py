"""
XGBoost model for price prediction.
Handles training, prediction, and model management.
"""

import pickle
import numpy as np
import pandas as pd
from typing import Dict, Any, Optional, List
from pathlib import Path
from sklearn.preprocessing import StandardScaler
import xgboost as xgb

from app.core.config import settings
from app.core.logging import logger


class XGBoostModel:
    """XGBoost model for property price prediction."""
    
    def __init__(self, model_path: Optional[Path] = None):
        """
        Initialize XGBoost model.
        
        Args:
            model_path: Path to saved model
        """
        self.model_path = model_path or settings.XGBOOST_MODEL_PATH
        self.model = None
        self.scaler = None
        self.feature_columns = None
        self.loaded = False
    
    def load(self) -> bool:
        """Load saved model."""
        try:
            if self.model_path.exists():
                with open(self.model_path, 'rb') as f:
                    model_data = pickle.load(f)
                    self.model = model_data['model']
                    self.scaler = model_data.get('scaler')
                    self.feature_columns = model_data.get('features', self.get_default_features())
                    self.loaded = True
                    logger.info(f"XGBoost model loaded from {self.model_path}")
                    return True
            else:
                logger.warning(f"Model file not found at {self.model_path}")
                self.create_default_model()
                return False
                
        except Exception as e:
            logger.error(f"Failed to load XGBoost model: {e}")
            self.create_default_model()
            return False
    
    def get_default_features(self) -> List[str]:
        """Get default feature columns."""
        return [
            'size_net', 'room_count', 'bathroom_count', 'floor',
            'total_floors', 'building_age_years', 'location_score',
            'has_parking', 'has_elevator', 'has_security', 'has_pool',
            'has_gym', 'has_garden', 'in_site', 'is_furnished',
            'has_balcony', 'has_central_heating', 'has_combi',
            'is_ground_floor', 'is_top_floor', 'city_tier'
        ]
    
    def create_default_model(self):
        """Create a default model with basic parameters."""
        self.model = None
        self.scaler = StandardScaler()
        self.feature_columns = self.get_default_features()
        self.loaded = False
        logger.info("Using default XGBoost configuration")
    
    def prepare_features(self, property_data: Dict[str, Any]) -> pd.DataFrame:
        """
        Prepare features for prediction.
        
        Args:
            property_data: Raw property data
            
        Returns:
            Feature dataframe
        """
        features = {}
        
        # Numeric features
        features['size_net'] = self.extract_size(property_data.get('size_net', property_data.get('size')))
        features['room_count'] = self.extract_room_count(property_data.get('rooms', '2+1'))
        features['bathroom_count'] = int(property_data.get('bathrooms', 1))
        features['floor'] = self.extract_floor(property_data.get('floor', 1))
        features['total_floors'] = int(property_data.get('total_floors', 5))
        features['building_age_years'] = self.extract_building_age(property_data.get('building_age', '5-10'))
        
        # Location features
        features['location_score'] = self.calculate_location_score(property_data.get('location', ''))
        features['city_tier'] = self.get_city_tier(property_data.get('location', ''))
        
        # Boolean features
        property_features = property_data.get('features', {})
        features['has_parking'] = int('parking' in str(property_features).lower())
        features['has_elevator'] = int('elevator' in str(property_features).lower() or 'asansör' in str(property_features).lower())
        features['has_security'] = int('security' in str(property_features).lower() or 'güvenlik' in str(property_features).lower())
        features['has_pool'] = int('pool' in str(property_features).lower() or 'havuz' in str(property_features).lower())
        features['has_gym'] = int('gym' in str(property_features).lower() or 'fitness' in str(property_features).lower())
        features['has_garden'] = int('garden' in str(property_features).lower() or 'bahçe' in str(property_features).lower())
        features['has_balcony'] = int('balcony' in str(property_features).lower() or 'balkon' in str(property_features).lower())
        
        # Other features
        features['in_site'] = int(property_data.get('in_site') == 'Evet')
        features['is_furnished'] = int(property_data.get('furnished') == 'Eşyalı')
        
        # Heating features
        heating = property_data.get('heating', '').lower()
        features['has_central_heating'] = int('merkezi' in heating)
        features['has_combi'] = int('kombi' in heating)
        
        # Floor features
        features['is_ground_floor'] = int(features['floor'] == 0)
        features['is_top_floor'] = int(features['floor'] == features['total_floors'])
        
        # Create dataframe
        df = pd.DataFrame([features])
        
        # Ensure all required columns exist
        for col in self.feature_columns:
            if col not in df.columns:
                df[col] = 0
        
        # Select and order columns
        return df[self.feature_columns]
    
    def extract_size(self, size_str: Any) -> float:
        """Extract size from string."""
        if not size_str:
            return 100
        
        try:
            size_str = str(size_str).replace(' m²', '').replace(',', '.')
            return float(size_str)
        except:
            return 100
    
    def extract_room_count(self, rooms: str) -> int:
        """Extract room count from string."""
        if not rooms:
            return 2
        
        try:
            if '+' in str(rooms):
                return int(str(rooms).split('+')[0])
            return 2
        except:
            return 2
    
    def extract_floor(self, floor: Any) -> int:
        """Extract floor number."""
        if not floor:
            return 1
        
        floor_str = str(floor).lower()
        
        if 'zemin' in floor_str or 'giriş' in floor_str:
            return 0
        elif 'bodrum' in floor_str:
            return -1
        
        try:
            import re
            numbers = re.findall(r'\d+', floor_str)
            if numbers:
                return int(numbers[0])
        except:
            pass
        
        return 1
    
    def extract_building_age(self, age: str) -> float:
        """Extract building age in years."""
        if not age:
            return 10
        
        age_str = str(age).lower()
        
        if 'yeni' in age_str or '0' in age_str:
            return 0
        elif '1-4' in age_str:
            return 2.5
        elif '5-10' in age_str:
            return 7.5
        elif '11-15' in age_str:
            return 13
        elif '16-20' in age_str:
            return 18
        elif '21-25' in age_str:
            return 23
        elif '26-30' in age_str:
            return 28
        elif '31' in age_str:
            return 35
        
        return 15
    
    def calculate_location_score(self, location: str) -> float:
        """Calculate location score (0-10)."""
        location_lower = location.lower()
        
        # Premium cities
        if any(city in location_lower for city in ['istanbul', 'ankara', 'izmir']):
            base_score = 8
        elif any(city in location_lower for city in ['antalya', 'bursa', 'kocaeli']):
            base_score = 6
        else:
            base_score = 4
        
        # Premium districts
        premium_districts = ['kadıköy', 'beşiktaş', 'şişli', 'çankaya', 'alsancak']
        if any(district in location_lower for district in premium_districts):
            base_score += 1.5
        
        return min(10, base_score)
    
    def get_city_tier(self, location: str) -> int:
        """Get city tier (1-5)."""
        location_lower = location.lower()
        
        if any(city in location_lower for city in ['istanbul', 'ankara', 'izmir']):
            return 1
        elif any(city in location_lower for city in ['antalya', 'bursa', 'adana', 'konya']):
            return 2
        elif any(city in location_lower for city in ['kocaeli', 'gaziantep', 'mersin', 'kayseri']):
            return 3
        else:
            return 4
    
    def predict(self, property_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Predict property price.
        
        Args:
            property_data: Property information
            
        Returns:
            Prediction results
        """
        try:
            # Prepare features
            features_df = self.prepare_features(property_data)
            
            if self.model:
                # Scale features if scaler available
                if self.scaler:
                    features_scaled = self.scaler.transform(features_df)
                else:
                    features_scaled = features_df.values
                
                # Make prediction
                prediction = self.model.predict(features_scaled)[0]
                
                # Calculate confidence based on feature completeness
                confidence = self.calculate_confidence(property_data)
                
                return {
                    'price': float(prediction),
                    'confidence': confidence,
                    'method': 'xgboost',
                    'features_used': list(features_df.columns)
                }
            else:
                # Fallback calculation
                return self.fallback_prediction(property_data, features_df)
                
        except Exception as e:
            logger.error(f"Prediction failed: {e}")
            return self.fallback_prediction(property_data)
    
    def fallback_prediction(
        self,
        property_data: Dict[str, Any],
        features_df: Optional[pd.DataFrame] = None
    ) -> Dict[str, Any]:
        """Fallback price calculation."""
        # Base price per sqm by location
        location_score = self.calculate_location_score(property_data.get('location', ''))
        
        if location_score >= 8:
            base_price_per_sqm = 45000
        elif location_score >= 6:
            base_price_per_sqm = 30000
        else:
            base_price_per_sqm = 20000
        
        # Get size
        size = self.extract_size(property_data.get('size_net', property_data.get('size', 100)))
        
        # Calculate base price
        base_price = size * base_price_per_sqm
        
        # Apply adjustments
        age = self.extract_building_age(property_data.get('building_age', '5-10'))
        if age == 0:
            base_price *= 1.2
        elif age < 5:
            base_price *= 1.1
        elif age > 20:
            base_price *= 0.85
        
        # Site adjustment
        if property_data.get('in_site') == 'Evet':
            base_price *= 1.1
        
        return {
            'price': round(base_price, -3),
            'confidence': 0.6,
            'method': 'fallback',
            'features_used': ['location', 'size', 'age', 'in_site']
        }
    
    def calculate_confidence(self, property_data: Dict[str, Any]) -> float:
        """Calculate prediction confidence."""
        confidence = 0.5
        
        # Check data completeness
        important_fields = ['location', 'size', 'rooms', 'building_age', 'floor']
        provided = sum(1 for field in important_fields if property_data.get(field))
        
        confidence += (provided / len(important_fields)) * 0.3
        
        # Model availability
        if self.model:
            confidence += 0.2
        
        return min(0.95, confidence)
    
    def save(self, path: Optional[Path] = None) -> bool:
        """Save model to file."""
        save_path = path or self.model_path
        
        try:
            model_data = {
                'model': self.model,
                'scaler': self.scaler,
                'features': self.feature_columns
            }
            
            with open(save_path, 'wb') as f:
                pickle.dump(model_data, f)
            
            logger.info(f"Model saved to {save_path}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to save model: {e}")
            return False
