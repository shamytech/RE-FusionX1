# نظام إدارة الـ Prompts الموحد

هذا المجلد يحتوي على جميع الـ prompts المستخدمة في النظام، مع نظام Fallback موحد لجميع الوكلاء، منظمة بطريقة تجعل الكود أكثر نظافة وقابلية للقراءة والتعديل.

## 📁 هيكل الملفات

```
prompts/
├── README.md                           # هذا الملف
├── prompt_manager.py                   # مدير الـ prompts الرئيسي
├── fallback_system.py                  # نظام Fallback موحد لجميع الوكلاء
├── groq_context_analysis.txt           # GROQ context analysis prompt
├── ollama_extraction.txt               # Ollama extraction prompt
├── openai_analysis.txt                 # OpenAI analysis prompt
├── qwen_analysis.txt                   # Qwen analysis prompt
├── simple_extraction.txt               # Simple extraction prompt
├── qwen_simple_extraction.txt          # Qwen simple extraction prompt
├── progressive_updates_groq.txt        # GROQ progressive updates prompt
├── progressive_updates_qwen.txt        # Qwen progressive updates prompt
├── intent_extraction_groq.txt          # GROQ intent extraction prompt
├── intent_extraction_ollama.txt        # Ollama intent extraction prompt
├── response_formatting_groq.txt        # GROQ response formatting prompt
└── response_formatting_ollama.txt      # Ollama response formatting prompt
```

## 🚀 الاستخدام

### 1. الاستيراد
```python
# استيراد مدير الـ prompts
from prompts.prompt_manager import (
    get_groq_context_prompt,
    get_ollama_prompt,
    get_openai_prompt,
    get_qwen_prompt,
    get_simple_extraction_prompt,
    get_qwen_simple_prompt,
    get_progressive_updates_groq_prompt,
    get_progressive_updates_qwen_prompt,
    get_intent_extraction_groq_prompt,
    get_intent_extraction_ollama_prompt,
    get_response_formatting_groq_prompt,
    get_response_formatting_ollama_prompt
)

# استيراد النظام الموحد للـ Fallback
from prompts.fallback_system import (
    process_intent_extraction,
    process_response_formatting,
    process_context_analysis,
    unified_fallback
)
```

### 2. استخدام الـ prompts
```python
# GROQ context analysis
prompt = get_groq_context_prompt(current_message, conversation_history)

# Ollama extraction
prompt = get_ollama_prompt(current_message, conversation_history)

# Simple extraction
prompt = get_simple_extraction_prompt(conversation_text)
```

### 3. استخدام مدير الـ prompts مباشرة
```python
from prompts.prompt_manager import prompt_manager

# الحصول على prompt مع متغيرات
prompt = prompt_manager.get_prompt('groq_context_analysis', 
                                  current_message=message, 
                                  history_text=history)

# قائمة الـ prompts المتاحة
available = prompt_manager.list_available_prompts()

# إعادة تحميل الـ prompts
prompt_manager.reload_prompts()
```

## 📝 أنواع الـ Prompts

### 1. GROQ Context Analysis
- **الملف**: `groq_context_analysis.txt`
- **الاستخدام**: تحليل السياق الذكي للمحادثات
- **المتغيرات**: `current_message`, `history_text`

### 2. Ollama Extraction
- **الملف**: `ollama_extraction.txt`
- **الاستخدام**: استخراج المعلومات باستخدام Ollama المحلي
- **المتغيرات**: `conversation_text`

### 3. OpenAI Analysis
- **الملف**: `openai_analysis.txt`
- **الاستخدام**: تحليل المحادثات باستخدام OpenAI
- **المتغيرات**: `current_message`, `history_text`

### 4. Qwen Analysis
- **الملف**: `qwen_analysis.txt`
- **الاستخدام**: تحليل المحادثات باستخدام Qwen
- **المتغيرات**: `current_message`, `history_text`

### 5. Simple Extraction
- **الملف**: `simple_extraction.txt`
- **الاستخدام**: استخراج بسيط للمعلومات
- **المتغيرات**: `conversation_text`

### 6. Progressive Updates
- **الملفات**: `progressive_updates_groq.txt`, `progressive_updates_qwen.txt`
- **الاستخدام**: كشف التحديثات التدريجية في المحادثات
- **المتغيرات**: `current_message`, `previous_context`, `cumulative_info`

## 🔧 التعديل والإضافة

### إضافة prompt جديد:
1. إنشاء ملف `.txt` جديد في المجلد
2. إضافة اسم الملف إلى `prompt_files` في `prompt_manager.py`
3. إنشاء دالة مساعدة في `prompt_manager.py`

### تعديل prompt موجود:
1. تعديل الملف `.txt` مباشرة
2. إعادة تشغيل النظام أو استدعاء `prompt_manager.reload_prompts()`

## ✅ المميزات

- **تنظيم أفضل**: جميع الـ prompts في مكان واحد
- **سهولة التعديل**: تعديل الـ prompts بدون لمس الكود
- **إدارة مركزية**: مدير واحد لجميع الـ prompts
- **دعم المتغيرات**: استبدال تلقائي للمتغيرات
- **إعادة التحميل**: تحديث الـ prompts بدون إعادة تشغيل
- **دعم متعدد اللغات**: prompts بالعربية والإنجليزية والتركية
- **نظام Fallback موحد**: نظام متدرج لجميع الوكلاء
- **معالجة أخطاء ذكية**: استخراج JSON من استجابات Markdown
- **دعم جميع المهام**: intent extraction, response formatting, context analysis

## 🧪 الاختبار

```bash
python test_refactored_system.py
```

هذا الاختبار يتحقق من:
- وجود جميع ملفات الـ prompts
- عمل مدير الـ prompts
- عمل ContextManagerAgent مع النظام الجديد
