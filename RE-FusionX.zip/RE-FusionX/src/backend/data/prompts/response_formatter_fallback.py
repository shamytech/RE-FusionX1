#!/usr/bin/env python3
"""
Response Formatter Fallback System - نظام Fallback مخصص لتنسيق الردود
ترتيب خاص: Qwen → Ollama → GROQ → Traditional
"""

import json
import os
import requests
import asyncio
import subprocess
from typing import Dict, Any, List, Optional, Callable
from datetime import datetime

class ResponseFormatterFallbackSystem:
    """نظام Fallback مخصص لتنسيق الردود مع ترتيب خاص"""
    
    def __init__(self):
        """تهيئة النظام المخصص"""
        self.methods = [
            ("Qwen", self._try_qwen),
            ("Ollama", self._try_ollama),
            ("GROQ", self._try_groq),
            ("Enhanced Traditional", self._try_enhanced_traditional)
        ]
        
        # تحقق من توفر الخدمات
        self.groq_available = self._check_groq()
        self.ollama_available = self._check_ollama()
        self.qwen_available = False  # سيتم تعيينه من الخارج
    
    def _check_groq(self) -> bool:
        """فحص توفر GROQ"""
        try:
            groq_key = os.getenv("GROQ_API_KEY")
            return bool(groq_key)
        except:
            return False
    
    def _check_ollama(self) -> bool:
        """فحص توفر Ollama"""
        try:
            response = requests.get("http://localhost:11434/api/tags", timeout=5)
            return response.status_code == 200
        except:
            return False
    
    def _stop_ollama_model(self, model_name: str = "gpt-oss:20b"):
        """إيقاف نموذج Ollama لتوفير الذاكرة"""
        try:
            subprocess.run(["ollama", "stop", model_name], 
                         capture_output=True, timeout=10)
            # Removed print statement for cleaner output
        except Exception as e:
            print(f"⚠️ Failed to stop Ollama model: {e}")
    
    async def _try_qwen(self, prompt: str, model_loader=None, **kwargs) -> Dict[str, Any]:
        """محاولة استخدام Qwen (الأولوية الأولى)"""
        try:
            if not model_loader:
                raise Exception("Model loader not available")
            
            # الحصول على النموذج مع Lazy Loading
            model = await model_loader.get_model()
            
            if not model:
                raise Exception("Qwen model not available")
            
            # استخدام Qwen بالطريقة الصحيحة
            result = await model.generate(
                prompt,
                max_tokens=1024,
                temperature=0.7
            )
            
            # تنظيف النتيجة
            if isinstance(result, dict):
                result = result.get("response", str(result))
            
            cleaned_result = str(result).strip()
            
            if cleaned_result:
                # إنشاء هيكل الاستجابة
                return {
                    "response": cleaned_result,
                    "method": "qwen",
                    "timestamp": datetime.utcnow().isoformat()
                }
            
            raise Exception("Qwen returned empty response")
            
        except Exception as e:
            raise Exception(f"Qwen failed: {e}")
    
    async def _try_ollama(self, prompt: str, model_loader=None, **kwargs) -> Dict[str, Any]:
        """محاولة استخدام Ollama (الاحتياطي المحلي)"""
        try:
            if not self.ollama_available:
                raise Exception("Ollama not available")
            
            response = requests.post(
                "http://localhost:11434/api/generate",
                json={
                    "model": "gpt-oss:20b",
                    "prompt": prompt,
                    "stream": False,
                    "options": {
                        "temperature": 0.1,
                        "num_predict": 8192,
                        "stop": ["```\n", "\n\n\n"]
                    }
                },
                timeout=60
            )
            
            if response.status_code != 200:
                raise Exception(f"Ollama request failed with status {response.status_code}")
            
            result = response.json()
            raw_response = result.get('response', '')
            
            if not raw_response:
                raise Exception("Ollama returned empty response")
            
            # تنظيف الاستجابة
            cleaned_response = self._clean_response(raw_response)
            
            # محاولة تحليل JSON
            try:
                response_data = json.loads(cleaned_response)
                if self._validate_response_result(response_data):
                    # إيقاف نموذج Ollama لتوفير الذاكرة
                    self._stop_ollama_model("gpt-oss:20b")
                    return response_data
            except:
                # إذا فشل JSON، إنشاء هيكل افتراضي
                # إيقاف نموذج Ollama لتوفير الذاكرة
                self._stop_ollama_model("gpt-oss:20b")
                return {
                    "response": cleaned_response,
                    "method": "ollama",
                    "timestamp": datetime.utcnow().isoformat()
                }
            
            raise Exception("Ollama returned invalid JSON")
            
        except Exception as e:
            raise Exception(f"Ollama failed: {e}")
    
    async def _try_groq(self, prompt: str, model_loader=None, **kwargs) -> Dict[str, Any]:
        """محاولة استخدام GROQ (الاحتياطي الثالث)"""
        try:
            if not self.groq_available:
                raise Exception("GROQ not available")
            
            import openai
            from openai import OpenAI
            
            client = OpenAI(
                api_key=os.getenv("GROQ_API_KEY"),
                base_url="https://api.groq.com/openai/v1"
            )
            
            response = client.chat.completions.create(
                model="llama-3.3-70b-versatile",
                messages=[{"role": "user", "content": prompt}],
                temperature=0.1,
                max_tokens=4000
            )
            
            result_text = response.choices[0].message.content
            
            if not result_text:
                raise Exception("GROQ returned empty response")
            
            # تنظيف النتيجة
            cleaned_result = self._clean_response(result_text)
            
            # محاولة تحليل JSON
            try:
                response_data = json.loads(cleaned_result)
                if self._validate_response_result(response_data):
                    return response_data
            except:
                # إذا فشل JSON، إنشاء هيكل افتراضي
                return {
                    "response": cleaned_result,
                    "method": "groq",
                    "timestamp": datetime.utcnow().isoformat()
                }
            
            raise Exception("GROQ returned invalid JSON")
            
        except Exception as e:
            raise Exception(f"GROQ failed: {e}")
    
    def _try_enhanced_traditional(self, prompt: str, model_loader=None, **kwargs) -> Dict[str, Any]:
        """الطريقة التقليدية المحسنة (النهائية)"""
        try:
            # استخراج المعلومات من kwargs
            user_query = kwargs.get("user_query", "")
            intent = kwargs.get("intent", {})
            language = kwargs.get("language", "en")
            agent_data = kwargs.get("agent_data", {})
            
            # إنشاء رد تقليدي بسيط
            response = self._create_traditional_response(user_query, intent, language, agent_data)
            
            return {
                "response": response,
                "method": "traditional",
                "timestamp": datetime.utcnow().isoformat()
            }
            
        except Exception as e:
            raise Exception(f"Traditional method failed: {e}")
    
    def _create_traditional_response(self, user_query: str, intent: Dict[str, Any], language: str, agent_data: Dict[str, Any]) -> str:
        """إنشاء رد تقليدي بسيط"""
        try:
            # استخراج المعلومات الأساسية
            intent_type = intent.get("intent", "search")
            confidence = intent.get("confidence", 0.0)
            
            # إنشاء رد حسب اللغة
            if language.lower() in ["ar", "arabic"]:
                return f"تم العثور على {intent_type} مع ثقة {confidence:.2f}. البيانات: {json.dumps(agent_data, ensure_ascii=False)}"
            elif language.lower() in ["tr", "turkish"]:
                return f"{intent_type} bulundu, güven: {confidence:.2f}. Veriler: {json.dumps(agent_data, ensure_ascii=False)}"
            else:
                return f"Found {intent_type} with confidence {confidence:.2f}. Data: {json.dumps(agent_data, ensure_ascii=False)}"
                
        except Exception as e:
            return f"Response generated with traditional method. Error: {e}"
    
    def _clean_response(self, response: str) -> str:
        """تنظيف الاستجابة من Markdown والرموز غير المرغوبة"""
        if not response:
            return ""
        
        # إزالة Markdown code blocks
        import re
        response = re.sub(r'```(?:json)?\s*', '', response)
        response = re.sub(r'```\s*', '', response)
        
        # إزالة المسافات الزائدة
        response = response.strip()
        
        return response
    
    def _validate_response_result(self, result: Dict[str, Any]) -> bool:
        """التحقق من صحة نتيجة تنسيق الرد"""
        if not isinstance(result, dict):
            return False
        
        # التحقق من وجود الحقول الأساسية
        if "response" in result:
            return True
        else:
            # fallback للطرق الأخرى
            return True
    
    async def process_with_fallback(self, task_type: str, prompt: str, model_loader=None, **kwargs) -> Dict[str, Any]:
        """معالجة المهمة مع نظام Fallback المخصص"""
        print(f"🔄 Processing {task_type} with custom fallback system...")
        
        for method_name, method_func in self.methods:
            try:
                print(f"  → Trying {method_name}...")
                
                if asyncio.iscoroutinefunction(method_func):
                    result = await method_func(prompt, model_loader, **kwargs)
                else:
                    result = method_func(prompt, model_loader, **kwargs)
                
                if result and self._validate_response_result(result):
                    print(f"  ✅ {method_name} succeeded for {task_type}")
                    # إيقاف Ollama بعد نجاح أي طريقة لتوفير الذاكرة
                    if method_name != "Qwen":
                        self._stop_ollama_model("gpt-oss:20b")
                    return result
                else:
                    print(f"  ❌ {method_name} returned invalid result for {task_type}")
                    
            except Exception as e:
                print(f"  ❌ {method_name} failed for {task_type}: {e}")
                continue
        
        # إيقاف Ollama في النهاية لتوفير الذاكرة
        self._stop_ollama_model("gpt-oss:20b")
        
        # إذا فشلت جميع الطرق
        raise Exception(f"All methods failed for {task_type}")

# إنشاء مثيل النظام
response_formatter_fallback = ResponseFormatterFallbackSystem()

# دوال مساعدة للاستيراد
async def process_response_formatting_custom(user_query: str, intent: str, language: str, agent_data: dict, model_loader=None) -> Dict[str, Any]:
    """معالجة تنسيق الرد مع النظام المخصص"""
    from .prompt_manager import get_response_formatting_groq_prompt
    
    prompt = get_response_formatting_groq_prompt(user_query, intent, language, agent_data)
    return await response_formatter_fallback.process_with_fallback(
        "response_formatting",
        prompt,
        model_loader,
        user_query=user_query,
        intent=intent,
        language=language,
        agent_data=agent_data
    )
