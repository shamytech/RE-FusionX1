#!/usr/bin/env python3
"""
Unified Fallback System - نظام Fallback موحد لجميع الوكلاء
"""

import json
import os
import requests
import subprocess
from typing import Dict, Any, List, Optional, Callable
from datetime import datetime

class UnifiedFallbackSystem:
    """نظام Fallback موحد لجميع الوكلاء"""
    
    def __init__(self):
        """تهيئة النظام الموحد"""
        self.methods = [
            ("GROQ", self._try_groq),
            ("Ollama", self._try_ollama),
            ("Qwen", self._try_qwen),
            ("OpenAI", self._try_openai),
            ("Enhanced Traditional", self._try_enhanced_traditional)
        ]
        
        # تحقق من توفر الخدمات
        self.groq_available = self._check_groq()
        self.ollama_available = self._check_ollama()
        self.openai_available = self._check_openai()
        self.qwen_available = False  # سيتم تعيينه من الخارج
    
    def _check_groq(self) -> bool:
        """فحص توفر GROQ"""
        try:
            groq_key = os.getenv("GROQ_API_KEY")
            return bool(groq_key)
        except:
            return False
    
    def _check_ollama(self) -> bool:
        """فحص توفر Ollama"""
        try:
            response = requests.get("http://localhost:11434/api/tags", timeout=5)
            return response.status_code == 200
        except:
            return False
    
    def _stop_ollama_model(self, model_name: str = "gpt-oss:20b"):
        """إيقاف نموذج Ollama لتوفير الذاكرة"""
        try:
            subprocess.run(["ollama", "stop", model_name], 
                         capture_output=True, timeout=10)
            # Removed print statement for cleaner output
        except Exception as e:
            print(f"⚠️ Failed to stop Ollama model: {e}")
    
    def _check_openai(self) -> bool:
        """فحص توفر OpenAI"""
        try:
            openai_key = os.getenv("OPENAI_API_KEY")
            return bool(openai_key)
        except:
            return False
    
    async def process_with_fallback(
        self,
        task_type: str,
        prompt: str,
        model_loader=None,
        **kwargs
    ) -> Dict[str, Any]:
        """
        معالجة المهمة مع نظام Fallback متدرج
        
        Args:
            task_type: نوع المهمة (intent_extraction, response_formatting, context_analysis, etc.)
            prompt: الـ prompt المرسل
            model_loader: Qwen model loader
            **kwargs: متغيرات إضافية
            
        Returns:
            نتيجة المعالجة مع معلومات الطريقة المستخدمة
        """
        # تحديث حالة Qwen
        self.qwen_available = bool(model_loader)
        
        # ترتيب الطرق حسب التوفر
        available_methods = self._get_available_methods()
        
        for method_name, method_func in available_methods:
            try:
                print(f"🔄 Trying {method_name} for {task_type}...")
                result = await method_func(prompt, **kwargs)
                
                if result and self._validate_result(result):
                    print(f"✅ {method_name} succeeded for {task_type}")
                    # إيقاف Ollama بعد نجاح أي طريقة لتوفير الذاكرة
                    if method_name == "Ollama":
                        self._stop_ollama_model("gpt-oss:20b")
                    return {
                        **result,
                        "method_used": method_name,
                        "task_type": task_type,
                        "timestamp": datetime.utcnow().isoformat()
                    }
                else:
                    print(f"⚠️ {method_name} returned invalid result for {task_type}")
                    
            except Exception as e:
                print(f"❌ {method_name} failed for {task_type}: {str(e)}")
                continue
        
        # إيقاف Ollama في النهاية لتوفير الذاكرة
        self._stop_ollama_model("gpt-oss:20b")
        
        # إذا فشلت جميع الطرق
        print(f"💥 All methods failed for {task_type}, using basic fallback")
        return self._create_basic_fallback(task_type, prompt)
    
    def cleanup(self):
        """تنظيف الموارد وإيقاف النماذج"""
        try:
            self._stop_ollama_model("gpt-oss:20b")
            print("🧹 Fallback system cleanup completed")
        except Exception as e:
            print(f"⚠️ Cleanup failed: {e}")
    
    def _get_available_methods(self) -> List[tuple]:
        """الحصول على الطرق المتاحة مرتبة حسب الأولوية"""
        available = []
        
        for method_name, method_func in self.methods:
            if method_name == "GROQ" and self.groq_available:
                available.append((method_name, method_func))
            elif method_name == "Ollama" and self.ollama_available:
                available.append((method_name, method_func))
            elif method_name == "OpenAI" and self.openai_available:
                available.append((method_name, method_func))
            elif method_name == "Qwen" and self.qwen_available:
                available.append((method_name, method_func))
            elif method_name == "Enhanced Traditional":
                available.append((method_name, method_func))
        
        return available
    
    async def _try_groq(self, prompt: str, **kwargs) -> Dict[str, Any]:
        """محاولة استخدام GROQ"""
        try:
            from groq import Groq
            groq_key = os.getenv("GROQ_API_KEY")
            client = Groq(api_key=groq_key)
            
            response = client.chat.completions.create(
                model="llama-3.3-70b-versatile",
                messages=[{"role": "user", "content": prompt}],
                temperature=0.1,
                max_completion_tokens=1024,
                response_format={"type": "json_object"}
            )
            
            content = response.choices[0].message.content
            if not content:
                raise Exception("Empty response")
            
            # تنظيف JSON
            if content.startswith('```json'):
                content = content.split('```json')[1].split('```')[0].strip()
            elif content.startswith('```'):
                content = content.split('```')[1].split('```')[0].strip()
            
            return json.loads(content)
            
        except Exception as e:
            if "429" in str(e) or "rate_limit" in str(e).lower():
                print(f"⚠️ GROQ rate limit reached: {e}")
            raise e
    
    async def _try_ollama(self, prompt: str, **kwargs) -> Dict[str, Any]:
        """محاولة استخدام Ollama"""
        try:
            response = requests.post(
                "http://localhost:11434/api/generate",
                json={
                    "model": "gpt-oss:20b",
                    "prompt": prompt,
                    "stream": False,
                    "options": {
                        "temperature": 0.1,
                        "num_predict": 8192,  # زيادة كبيرة جداً لضمان JSON مكتمل
                        "stop": ["```\n", "\n\n\n"]  # إيقاف عند نهاية JSON فقط
                    }
                },
                timeout=60  # زيادة timeout للردود الطويلة
            )
            
            if response.status_code != 200:
                raise Exception(f"Ollama request failed with status {response.status_code}")
            
            result = response.json()
            content = result.get("response", "").strip()
            
            # Print raw response only for debugging when needed
            # Check if debugging is enabled via environment variable
            debug_mode = os.getenv("DEBUG_OLLAMA_RESPONSE", "false").lower() == "true"
            if debug_mode:
                print(f"\n🔍 Raw Ollama Response:")
                print(f"   Length: {len(content)}")
                print(f"   Content: {content}")
                print(f"   Full Response: {content}")
            
            if not content:
                raise Exception("Empty response from Ollama")
            
            # تنظيف JSON
            if content.startswith('```json'):
                content = content.split('```json')[1].split('```')[0].strip()
            elif content.startswith('```'):
                content = content.split('```')[1].split('```')[0].strip()
            
            # محاولة استخراج JSON من النص
            import re
            
            # البحث عن JSON في النص - تحسين للردود الطويلة
            json_patterns = [
                r'\{[^{}]*\}',  # JSON بسيط
                r'\{.*?\}',     # JSON مع محتوى
                r'\{[^}]*\}',   # JSON مع محتوى واحد
                r'\{.*\}(?=\s*$)',  # JSON في نهاية النص
                r'\{.*\}(?=\s*\n)',  # JSON قبل سطر جديد
            ]
            
            json_found = False
            best_json = None
            max_length = 0
            
            for pattern in json_patterns:
                matches = re.finditer(pattern, content, re.DOTALL)
                for match in matches:
                    json_candidate = match.group(0)
                    if len(json_candidate) > max_length:
                        best_json = json_candidate
                        max_length = len(json_candidate)
                        json_found = True
            
            if json_found and best_json:
                content = best_json
            
            # إذا لم نجد JSON، نحاول إنشاء JSON بسيط من المحتوى
            if not json_found:
                # تحليل المحتوى لاستخراج المعلومات
                if 'apartment' in content.lower() or 'daire' in content.lower() or 'شقة' in content.lower():
                    content = '{"intent": "property_search", "confidence": 0.5, "language": "en", "entities": {"property": {"type": "apartment"}}}'
                elif 'value' in content.lower() or 'قيمة' in content.lower() or 'değer' in content.lower():
                    content = '{"intent": "property_valuation", "confidence": 0.5, "language": "en", "entities": {}}'
                else:
                    content = '{"intent": "general_inquiry", "confidence": 0.3, "language": "en", "entities": {}}'
            
            # التحقق من أن المحتوى يحتوي على JSON صالح
            if not content or not content.strip().startswith('{'):
                raise Exception(f"Invalid JSON response from Ollama: {content[:100]}...")
            
            try:
                parsed_json = json.loads(content)
                # التحقق من وجود الحقول المطلوبة
                if not isinstance(parsed_json, dict):
                    raise Exception("Response is not a valid JSON object")
                
                # إيقاف نموذج Ollama بعد الاستخدام لتوفير الذاكرة
                self._stop_ollama_model("gpt-oss:20b")
                return parsed_json
                
            except json.JSONDecodeError as json_err:
                # محاولة إصلاح JSON مقطوع
                print(f"⚠️ JSON parsing failed, attempting to fix: {json_err}")
                fixed_json = self._fix_incomplete_json(content)
                if fixed_json:
                    try:
                        parsed_json = json.loads(fixed_json)
                        print(f"✅ JSON fixed successfully")
                        # إيقاف نموذج Ollama بعد الاستخدام لتوفير الذاكرة
                        self._stop_ollama_model("gpt-oss:20b")
                        return parsed_json
                    except:
                        pass
                
                # إيقاف نموذج Ollama حتى لو فشل التحليل
                self._stop_ollama_model("gpt-oss:20b")
                raise Exception(f"JSON parsing failed: {json_err}. Content: {content[:200]}...")
            
        except Exception as e:
            # إيقاف نموذج Ollama في حالة الخطأ
            self._stop_ollama_model("gpt-oss:20b")
            raise e
    
    def _fix_incomplete_json(self, content: str) -> str:
        """إصلاح JSON مقطوع"""
        try:
            # إزالة المسافات الزائدة
            content = content.strip()
            
            # إذا لم يبدأ بـ {، نحاول العثور على البداية
            if not content.startswith('{'):
                start_idx = content.find('{')
                if start_idx != -1:
                    content = content[start_idx:]
            
            # إصلاح الاقتباسات غير المغلقة أولاً
            if content.count('"') % 2 != 0:
                # إضافة اقتباس في النهاية
                content += '"'
            
            # إذا لم ينته بـ }، نحاول إضافة النهاية
            if not content.endswith('}'):
                # عد الأقواس المفتوحة والمغلقة
                open_braces = content.count('{')
                close_braces = content.count('}')
                
                # إضافة الأقواس المفقودة
                missing_braces = open_braces - close_braces
                if missing_braces > 0:
                    content += '}' * missing_braces
            
            # إصلاح الفواصل المفقودة
            if content.endswith('"') and not content.endswith('"}'):
                content += '}'
            
            return content
            
        except Exception as e:
            print(f"⚠️ Failed to fix JSON: {e}")
            return None
    
    async def _try_openai(self, prompt: str, **kwargs) -> Dict[str, Any]:
        """محاولة استخدام OpenAI"""
        try:
            import openai
            openai_key = os.getenv("OPENAI_API_KEY")
            client = openai.OpenAI(api_key=openai_key)
            
            response = client.chat.completions.create(
                model="gpt-3.5-turbo",
                messages=[{"role": "user", "content": prompt}],
                temperature=0.1,
                max_tokens=1024,
                response_format={"type": "json_object"}
            )
            
            content = response.choices[0].message.content.strip()
            if not content:
                raise Exception("Empty response")
            
            return json.loads(content)
            
        except Exception as e:
            raise e
    
    async def _try_qwen(self, prompt: str, model_loader=None, **kwargs) -> Dict[str, Any]:
        """محاولة استخدام Qwen"""
        try:
            if not model_loader:
                raise Exception("Qwen model loader not available")
            
            # الحصول على النموذج مع Lazy Loading
            model = await model_loader.get_model()
            
            if not model:
                raise Exception("Qwen model not available")
            
            response = await model.generate(
                prompt,
                max_tokens=1024,
                temperature=0.1
            )
            
            # تنظيف النتيجة
            if isinstance(response, dict):
                response = response.get("response", str(response))
            
            content = str(response).strip()
            if not content:
                raise Exception("Empty response")
            
            # تنظيف JSON
            if content.startswith('```json'):
                content = content.split('```json')[1].split('```')[0].strip()
            elif content.startswith('```'):
                content = content.split('```')[1].split('```')[0].strip()
            
            return json.loads(content)
            
        except Exception as e:
            raise e
    
    async def _try_enhanced_traditional(self, prompt: str, **kwargs) -> Dict[str, Any]:
        """محاولة استخدام الطريقة التقليدية المحسنة"""
        try:
            # تحليل بسيط للـ prompt لاستخراج المعلومات
            return self._extract_with_traditional_methods(prompt, **kwargs)
            
        except Exception as e:
            raise e
    
    def _extract_with_traditional_methods(self, prompt: str, **kwargs) -> Dict[str, Any]:
        """استخراج المعلومات بالطرق التقليدية"""
        # تحليل بسيط للنص
        text_lower = prompt.lower()
        
        # تحديد نوع المهمة من الـ prompt أو المعاملات
        task_type = kwargs.get('task_type', 'intent_extraction')
        
        # إذا لم يتم تحديد نوع المهمة، نحاول استنتاجه من الـ prompt
        if 'response_formatting' in prompt.lower() or 'user_query' in prompt.lower():
            task_type = 'response_formatting'
        elif 'context_analysis' in prompt.lower() or 'conversation' in prompt.lower():
            task_type = 'context_analysis'
        
        if task_type == 'response_formatting':
            return self._create_response_formatting_fallback(prompt, **kwargs)
        elif task_type == 'context_analysis':
            return self._create_context_analysis_fallback(prompt, **kwargs)
        else:
            return self._create_intent_extraction_fallback(prompt, **kwargs)
    
    def _create_intent_extraction_fallback(self, prompt: str, **kwargs) -> Dict[str, Any]:
        """إنشاء fallback لاستخراج النية"""
        text_lower = prompt.lower()
        
        result = {
            "intent": "general_inquiry",
            "confidence": 0.3,
            "language": "en",
            "entities": {
                "property": {},
                "location": {},
                "financial": {},
                "purpose": "unknown"
            },
            "required_agents": [],
            "complexity": "simple",
            "urgency": "low"
        }
        
        # كشف اللغة
        if any(word in text_lower for word in ["أريد", "شقة", "منزل", "ميزانية"]):
            result["language"] = "ar"
        elif any(word in text_lower for word in ["daire", "ev", "bütçe", "milyon"]):
            result["language"] = "tr"
        
        # كشف النية
        if any(word in text_lower for word in ["value", "price", "worth", "قيمة", "سعر", "değer", "fiyat"]):
            result["intent"] = "property_valuation"
            result["required_agents"] = ["property", "market"]
        elif any(word in text_lower for word in ["search", "find", "looking", "أبحث", "أريد", "arıyorum", "istiyorum"]):
            result["intent"] = "property_search"
            result["required_agents"] = ["property", "location"]
        elif any(word in text_lower for word in ["market", "trend", "analysis", "سوق", "تحليل", "pazar", "analiz"]):
            result["intent"] = "market_analysis"
            result["required_agents"] = ["market", "location"]
        
        # استخراج الموقع
        if "istanbul" in text_lower or "اسطنبول" in text_lower:
            result["entities"]["location"]["city"] = "Istanbul"
        
        # استخراج نوع العقار
        if any(word in text_lower for word in ["apartment", "daire", "شقة"]):
            result["entities"]["property"]["type"] = "apartment"
        elif any(word in text_lower for word in ["house", "ev", "منزل"]):
            result["entities"]["property"]["type"] = "house"
        
        # استخراج الغرف
        import re
        room_match = re.search(r'(\d+\+\d+)', text_lower)
        if room_match:
            result["entities"]["property"]["rooms"] = room_match.group(1)
        
        # استخراج الميزانية
        budget_patterns = [
            r'(\d+)\s*million\s*tl',
            r'(\d+)\s*m\s*tl',
            r'(\d+)\s*مليون\s*ليرة',
            r'(\d+)\s*مليون\s*ليرة'
        ]
        
        for pattern in budget_patterns:
            match = re.search(pattern, text_lower)
            if match:
                try:
                    budget = float(match.group(1)) * 1000000
                    result["entities"]["financial"]["budget"] = budget
                    break
                except:
                    continue
        
        return result
    
    def _create_response_formatting_fallback(self, prompt: str, **kwargs) -> Dict[str, Any]:
        """إنشاء fallback لتنسيق الرد"""
        # استخراج المعلومات من الـ prompt
        user_query = kwargs.get('user_query', '')
        intent = kwargs.get('intent', 'general_inquiry')
        language = kwargs.get('language', 'en')
        agent_data = kwargs.get('agent_data', {})
        
        # إنشاء رد بسيط
        if intent == 'property_valuation':
            response = f"Based on the available data, I can provide you with property valuation information. Please provide more specific details about your property for a more accurate assessment."
        elif intent == 'property_search':
            response = f"I can help you find properties that match your criteria. Please specify your requirements for location, budget, and property type."
        elif intent == 'market_analysis':
            response = f"I can provide market analysis and trends for the real estate market. Please specify the area or type of analysis you're interested in."
        else:
            response = f"I'm here to help you with your real estate needs. Please let me know how I can assist you."
        
        return {
            "response": response,
            "intent": intent,
            "language": language,
            "data_sources": list(agent_data.keys()) if isinstance(agent_data, dict) else [],
            "confidence": 0.3,
            "key_insights": ["Basic response generated using fallback method"],
            "recommendations": ["Please provide more specific information for better analysis"],
            "next_steps": ["Specify your requirements for more detailed assistance"]
        }
    
    def _create_context_analysis_fallback(self, prompt: str, **kwargs) -> Dict[str, Any]:
        """إنشاء fallback لتحليل السياق"""
        text_lower = prompt.lower()
        
        # تحليل بسيط للسياق
        is_related = any(word in text_lower for word in ["budget", "price", "can't", "won't", "fixed", "ميزانية", "سعر", "لا أستطيع", "ثابت"])
        relationship_type = "constraint" if is_related else "new_request"
        
        return {
            "message_relationship": {
                "is_related_to_previous": is_related,
                "relationship_type": relationship_type,
                "related_to_message": None,
                "confidence": 0.3
            },
            "intent": {
                "primary_intent": "property_search",
                "sub_intent": None,
                "confidence": 0.3
            },
            "extracted_information": {
                "location": {"city": None, "district": None, "neighborhood": None, "raw_location": ""},
                "property": {"type": None, "size": None, "rooms": None, "age": None, "features": []},
                "financial": {"budget": None, "budget_flexibility": "unknown", "constraints": []},
                "purpose": "unknown",
                "preferences": []
            },
            "context_signals": {
                "limitation_expressed": is_related,
                "alternatives_requested": False,
                "frustration_level": "low",
                "urgency": "low"
            },
            "conversation_state": {
                "phase": "information_gathering",
                "user_satisfaction": "unknown",
                "next_expected": "more_info"
            }
        }
    
    def _validate_result(self, result: Dict[str, Any]) -> bool:
        """التحقق من صحة النتيجة"""
        if not isinstance(result, dict):
            return False
        
        # التحقق من وجود الحقول الأساسية حسب نوع المهمة
        if "extracted_information" in result:
            # نتيجة context analysis
            return True
        elif "intent" in result and "confidence" in result:
            # نتيجة intent extraction
            return True
        elif "response" in result:
            # نتيجة response formatting
            return True
        else:
            # fallback للطرق الأخرى
            return True
    
    def _create_basic_fallback(self, task_type: str, prompt: str) -> Dict[str, Any]:
        """إنشاء fallback أساسي عند فشل جميع الطرق"""
        return {
            "intent": "general_inquiry",
            "confidence": 0.1,
            "language": "en",
            "entities": {
                "property": {},
                "location": {},
                "financial": {},
                "purpose": "unknown"
            },
            "required_agents": [],
            "complexity": "simple",
            "urgency": "low",
            "method_used": "basic_fallback",
            "task_type": task_type,
            "error": "All fallback methods failed",
            "timestamp": datetime.utcnow().isoformat()
        }

# إنشاء instance عام
unified_fallback = UnifiedFallbackSystem()

# دوال مساعدة للاستخدام المباشر
async def process_intent_extraction(message: str, model_loader=None) -> Dict[str, Any]:
    """معالجة استخراج النية مع نظام Fallback"""
    from .prompt_manager import get_groq_context_prompt
    
    prompt = get_groq_context_prompt(message, [])
    return await unified_fallback.process_with_fallback(
        "intent_extraction",
        prompt,
        model_loader,
        message=message,
        conversation_history=[]
    )

async def process_response_formatting(user_query: str, agent_data: dict, intent: str, language: str, model_loader=None) -> Dict[str, Any]:
    """معالجة تنسيق الرد مع نظام Fallback"""
    from .prompt_manager import get_groq_context_prompt
    
    prompt = f"""
    USER QUERY: {user_query}
    INTENT: {intent}
    LANGUAGE: {language}
    AGENT DATA: {json.dumps(agent_data, ensure_ascii=False, indent=2)}
    
    Generate a comprehensive response based on this data.
    """
    
    return await unified_fallback.process_with_fallback(
        "response_formatting",
        prompt,
        model_loader,
        user_query=user_query,
        intent=intent,
        language=language,
        agent_data=agent_data
    )

async def process_context_analysis(current_message: str, conversation_history: list, model_loader=None) -> Dict[str, Any]:
    """معالجة تحليل السياق مع نظام Fallback"""
    from .prompt_manager import get_groq_context_prompt
    
    prompt = get_groq_context_prompt(current_message, conversation_history)
    return await unified_fallback.process_with_fallback(
        "context_analysis",
        prompt,
        model_loader,
        message=current_message,
        conversation_history=conversation_history
    )
