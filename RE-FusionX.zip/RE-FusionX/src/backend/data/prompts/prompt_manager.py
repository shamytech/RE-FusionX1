#!/usr/bin/env python3
"""
Prompt Manager - إدارة وتحميل الـ prompts من الملفات
"""

import os
from typing import Dict, Any
from pathlib import Path

class PromptManager:
    """مدير الـ prompts لتحميل واستخدام الـ prompts من الملفات"""
    
    def __init__(self, prompts_dir: str = None):
        """
        تهيئة مدير الـ prompts
        
        Args:
            prompts_dir: مسار مجلد الـ prompts
        """
        if prompts_dir is None:
            # المسار الافتراضي
            current_dir = Path(__file__).parent
            self.prompts_dir = current_dir
        else:
            self.prompts_dir = Path(prompts_dir)
        
        # تحميل جميع الـ prompts عند التهيئة
        self._load_all_prompts()
    
    def _load_all_prompts(self):
        """تحميل جميع الـ prompts من الملفات"""
        self.prompts = {}
        
        # قائمة ملفات الـ prompts
        prompt_files = {
            'groq_context_analysis': 'groq_context_analysis.txt',
            'ollama_extraction': 'ollama_extraction.txt',
            'openai_analysis': 'openai_analysis.txt',
            'qwen_analysis': 'qwen_analysis.txt',
            'simple_extraction': 'simple_extraction.txt',
            'qwen_simple_extraction': 'qwen_simple_extraction.txt',
            'progressive_updates_groq': 'progressive_updates_groq.txt',
            'progressive_updates_qwen': 'progressive_updates_qwen.txt',
            'intent_extraction_groq': 'intent_extraction_groq.txt',
            'intent_extraction_ollama': 'intent_extraction_ollama.txt',
            'response_formatting_groq': 'response_formatting_groq.txt',
            'response_formatting_ollama': 'response_formatting_ollama.txt'
        }
        
        for prompt_name, filename in prompt_files.items():
            try:
                file_path = self.prompts_dir / filename
                if file_path.exists():
                    with open(file_path, 'r', encoding='utf-8') as f:
                        self.prompts[prompt_name] = f.read().strip()
                else:
                    print(f"⚠️ Warning: Prompt file not found: {file_path}")
                    self.prompts[prompt_name] = ""
            except Exception as e:
                print(f"❌ Error loading prompt {prompt_name}: {e}")
                self.prompts[prompt_name] = ""
    
    def get_prompt(self, prompt_name: str, **kwargs) -> str:
        """
        الحصول على prompt مع استبدال المتغيرات
        
        Args:
            prompt_name: اسم الـ prompt
            **kwargs: المتغيرات للاستبدال
            
        Returns:
            الـ prompt مع المتغيرات المستبدلة
        """
        if prompt_name not in self.prompts:
            raise ValueError(f"Prompt '{prompt_name}' not found")
        
        prompt_template = self.prompts[prompt_name]
        
        # استبدال المتغيرات
        try:
            return prompt_template.format(**kwargs)
        except KeyError as e:
            print(f"⚠️ Warning: Missing variable {e} in prompt {prompt_name}")
            return prompt_template
    
    def get_groq_context_prompt(self, current_message: str, conversation_history: list) -> str:
        """الحصول على GROQ context analysis prompt"""
        history_text = ""
        if conversation_history:
            history_text = "\nCONVERSATION HISTORY:\n"
            for i, msg in enumerate(conversation_history[-5:], 1):
                role = msg.get('role', 'unknown')
                content = msg.get('content', '')
                history_text += f"{i}. {role.upper()}: {content}\n"
        
        return self.get_prompt(
            'groq_context_analysis',
            current_message=current_message,
            history_text=history_text
        )
    
    def get_ollama_prompt(self, current_message: str, conversation_history: list) -> str:
        """الحصول على Ollama extraction prompt"""
        history_text = ""
        if conversation_history:
            history_text = "\nCONVERSATION HISTORY:\n"
            for i, msg in enumerate(conversation_history[-3:], 1):
                role = msg.get('role', 'unknown')
                content = msg.get('content', '')
                history_text += f"{i}. {role.upper()}: {content}\n"
        
        return self.get_prompt(
            'ollama_extraction',
            conversation_text=f"{current_message}{history_text}"
        )
    
    def get_openai_prompt(self, current_message: str, conversation_history: list) -> str:
        """الحصول على OpenAI analysis prompt"""
        history_text = ""
        if conversation_history:
            history_text = "\nCONVERSATION HISTORY:\n"
            for i, msg in enumerate(conversation_history[-3:], 1):
                role = msg.get('role', 'unknown')
                content = msg.get('content', '')
                history_text += f"{i}. {role.upper()}: {content}\n"
        
        return self.get_prompt(
            'openai_analysis',
            current_message=current_message,
            history_text=history_text
        )
    
    def get_qwen_prompt(self, current_message: str, conversation_history: list) -> str:
        """الحصول على Qwen analysis prompt"""
        history_text = ""
        if conversation_history:
            history_text = "\nالمحادثة السابقة:\n"
            for i, msg in enumerate(conversation_history[-3:], 1):
                role = msg.get('role', 'unknown')
                content = msg.get('content', '')
                history_text += f"{i}. {role.upper()}: {content}\n"
        
        return self.get_prompt(
            'qwen_analysis',
            current_message=current_message,
            history_text=history_text
        )
    
    def get_simple_extraction_prompt(self, conversation_text: str) -> str:
        """الحصول على simple extraction prompt"""
        return self.get_prompt('simple_extraction', conversation_text=conversation_text)
    
    def get_qwen_simple_prompt(self, conversation_text: str) -> str:
        """الحصول على Qwen simple extraction prompt"""
        return self.get_prompt('qwen_simple_extraction', conversation_text=conversation_text)
    
    def get_progressive_updates_groq_prompt(self, current_message: str, previous_context: str, cumulative_info: dict) -> str:
        """الحصول على GROQ progressive updates prompt"""
        import json
        return self.get_prompt(
            'progressive_updates_groq',
            current_message=current_message,
            previous_context=previous_context,
            cumulative_info=json.dumps(cumulative_info, ensure_ascii=False, indent=2)
        )
    
    def get_progressive_updates_qwen_prompt(self, current_message: str, previous_context: str, cumulative_info: dict) -> str:
        """الحصول على Qwen progressive updates prompt"""
        import json
        return self.get_prompt(
            'progressive_updates_qwen',
            current_message=current_message,
            previous_context=previous_context,
            cumulative_info=json.dumps(cumulative_info, ensure_ascii=False, indent=2)
        )
    
    def reload_prompts(self):
        """إعادة تحميل جميع الـ prompts من الملفات"""
        self._load_all_prompts()
        print("✅ Prompts reloaded successfully")
    
    def list_available_prompts(self) -> list:
        """قائمة الـ prompts المتاحة"""
        return list(self.prompts.keys())
    
    def get_prompt_info(self, prompt_name: str) -> dict:
        """معلومات عن prompt معين"""
        if prompt_name not in self.prompts:
            return {"error": f"Prompt '{prompt_name}' not found"}
        
        prompt_content = self.prompts[prompt_name]
        return {
            "name": prompt_name,
            "length": len(prompt_content),
            "lines": len(prompt_content.split('\n')),
            "has_variables": '{' in prompt_content and '}' in prompt_content
        }

# إنشاء instance عام للاستخدام
prompt_manager = PromptManager()

# دوال مساعدة للاستخدام المباشر
def get_groq_context_prompt(current_message: str, conversation_history: list) -> str:
    """دالة مساعدة للحصول على GROQ context prompt"""
    return prompt_manager.get_groq_context_prompt(current_message, conversation_history)

def get_ollama_prompt(current_message: str, conversation_history: list) -> str:
    """دالة مساعدة للحصول على Ollama prompt"""
    return prompt_manager.get_ollama_prompt(current_message, conversation_history)

def get_openai_prompt(current_message: str, conversation_history: list) -> str:
    """دالة مساعدة للحصول على OpenAI prompt"""
    return prompt_manager.get_openai_prompt(current_message, conversation_history)

def get_qwen_prompt(current_message: str, conversation_history: list) -> str:
    """دالة مساعدة للحصول على Qwen prompt"""
    return prompt_manager.get_qwen_prompt(current_message, conversation_history)

def get_simple_extraction_prompt(conversation_text: str) -> str:
    """دالة مساعدة للحصول على simple extraction prompt"""
    return prompt_manager.get_simple_extraction_prompt(conversation_text)

def get_qwen_simple_prompt(conversation_text: str) -> str:
    """دالة مساعدة للحصول على Qwen simple prompt"""
    return prompt_manager.get_qwen_simple_prompt(conversation_text)

def get_progressive_updates_groq_prompt(current_message: str, previous_context: str, cumulative_info: dict) -> str:
    """دالة مساعدة للحصول على GROQ progressive updates prompt"""
    return prompt_manager.get_progressive_updates_groq_prompt(current_message, previous_context, cumulative_info)

def get_progressive_updates_qwen_prompt(current_message: str, previous_context: str, cumulative_info: dict) -> str:
    """دالة مساعدة للحصول على Qwen progressive updates prompt"""
    return prompt_manager.get_progressive_updates_qwen_prompt(current_message, previous_context, cumulative_info)

def get_intent_extraction_groq_prompt(message: str) -> str:
    """دالة مساعدة للحصول على GROQ intent extraction prompt"""
    return prompt_manager.get_prompt('intent_extraction_groq', message=message)

def get_intent_extraction_ollama_prompt(message: str) -> str:
    """دالة مساعدة للحصول على Ollama intent extraction prompt"""
    return prompt_manager.get_prompt('intent_extraction_ollama', message=message)

def get_response_formatting_groq_prompt(user_query: str, intent: str, language: str, agent_data: dict) -> str:
    """دالة مساعدة للحصول على GROQ response formatting prompt"""
    import json
    return prompt_manager.get_prompt(
        'response_formatting_groq',
        user_query=user_query,
        intent=intent,
        language=language,
        agent_data=json.dumps(agent_data, ensure_ascii=False, indent=2)
    )

def get_response_formatting_ollama_prompt(user_query: str, intent: str, language: str, agent_data: dict) -> str:
    """دالة مساعدة للحصول على Ollama response formatting prompt"""
    import json
    return prompt_manager.get_prompt(
        'response_formatting_ollama',
        user_query=user_query,
        intent=intent,
        language=language,
        agent_data=json.dumps(agent_data, ensure_ascii=False, indent=2)
    )

def get_progressive_updates_ollama_prompt(current_message: str, previous_context: str, cumulative_info: dict) -> str:
    """دالة مساعدة للحصول على Ollama progressive updates prompt"""
    import json
    return prompt_manager.get_prompt(
        'progressive_updates_ollama',
        current_message=current_message,
        previous_context=previous_context,
        cumulative_info=json.dumps(cumulative_info, ensure_ascii=False, indent=2)
    )
