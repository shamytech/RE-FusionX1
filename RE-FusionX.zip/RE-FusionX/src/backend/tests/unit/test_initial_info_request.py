import os
import sys
import unittest

# Ensure src/backend is on sys.path
CURRENT_DIR = os.path.dirname(__file__)
BACKEND_ROOT = os.path.abspath(os.path.join(CURRENT_DIR, "..", ".."))
if BACKEND_ROOT not in sys.path:
    sys.path.insert(0, BACKEND_ROOT)

from app.agents.smart_response_generator import SmartResponseGenerator


class TestInitialInfoRequest(unittest.IsolatedAsyncioTestCase):
    async def test_initial_request_generated_with_low_completion_and_city_only(self):
        gen = SmartResponseGenerator(model_loader=None)

        completeness = {
            "completion_percentage": 10.0,
            "critical_missing": ["location", "property", "financial"],
            "missing_categories": ["location", "property", "financial"]
        }
        entities = {"location": {"city": "Istanbul"}}

        response = await gen.generate_context_aware_response(
            message_type="initial_property_inquiry",
            intent="property_search",
            completeness=completeness,
            entities=entities,
            conversation_history=[],
            language="en"
        )

        self.assertIn("Real Estate Search Assistant - RE-FusionX v2.0.0", response)
        self.assertIn("For Accurate Analysis, I Need:", response)
        # Should include Information Collected section with the city mentioned
        self.assertIn("Information Collected", response)
        self.assertIn("City: Istanbul", response)

    async def test_initial_request_generated_when_no_entities(self):
        gen = SmartResponseGenerator(model_loader=None)

        completeness = {
            "completion_percentage": 5.0,
            "critical_missing": ["location", "property", "financial"],
            "missing_categories": ["location", "property", "financial"]
        }
        entities = {}

        response = await gen.generate_context_aware_response(
            message_type="initial_property_inquiry",
            intent="property_search",
            completeness=completeness,
            entities=entities,
            conversation_history=[],
            language="en"
        )

        self.assertIn("Real Estate Search Assistant - RE-FusionX v2.0.0", response)
        self.assertIn("For Accurate Analysis, I Need:", response)
        # No collected section expected
        self.assertNotIn("Information Collected:\n\n", response)


if __name__ == "__main__":
    unittest.main()
