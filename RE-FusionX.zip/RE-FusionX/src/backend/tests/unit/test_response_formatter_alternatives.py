import unittest

from app.agents.response_formatter_agent import ResponseFormatterAgent


class TestResponseFormatterAlternatives(unittest.TestCase):
    def test_alternative_hint_in_prompt_when_budget_below_market(self):
        agent = ResponseFormatterAgent(model_loader=None)

        data = {
            "property": {
                "property_info": {
                    "budget": 5_000_000,
                    "location": "Istanbul - Bayrampaşa",
                    "rooms": "3+1",
                    "size": 120
                }
            },
            "market": {
                "statistics": {
                    "average_price": 6_178_666,
                    "median_price": 4_750_000
                }
            }
        }

        prompt = agent._create_smart_prompt(
            user_query="I prefer Bayrampaşa area, 3+1, budget 5M",
            data=data,
            intent="property_search",
            language="en"
        )

        self.assertIn("ALTERNATIVE SUGGESTIONS GUIDELINE:", prompt)
        self.assertIn("Nearby district/neighborhood", prompt)
        self.assertIn("Slightly smaller size", prompt)


if __name__ == "__main__":
    unittest.main()
