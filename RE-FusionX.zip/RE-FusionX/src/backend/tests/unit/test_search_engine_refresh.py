import unittest
from pathlib import Path

from app.core.storage.search_engine import SearchEngine


class TestSearchEngineRefresh(unittest.TestCase):
    def test_refresh_properties_view_does_not_fail(self):
        se = SearchEngine(Path("data"))
        # Should not raise
        se.refresh_properties_view()
        # Ensure view exists and count query works
        try:
            count = se.conn.execute("SELECT COUNT(*) FROM properties").fetchone()[0]
        except Exception as e:
            self.fail(f"refresh_properties_view failed to maintain properties view: {e}")
        self.assertIsInstance(count, (int,))


if __name__ == "__main__":
    unittest.main()
